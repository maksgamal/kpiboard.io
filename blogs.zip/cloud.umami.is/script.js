!(function () {
  "use strict";
  ((t) => {
    const {
        screen: { width: e, height: a },
        navigator: { language: r, doNotTrack: n, msDoNotTrack: i },
        location: o,
        document: s,
        history: c,
        top: u,
        doNotTrack: d,
      } = t,
      { currentScript: l, referrer: h } = s;
    if (!l) return;
    const { hostname: f, href: m, origin: p } = o,
      y = m.startsWith("data:") ? void 0 : t.localStorage,
      g = "data-",
      b = "true",
      v = l.getAttribute.bind(l),
      w = v(g + "website-id"),
      S = v(g + "host-url"),
      k = v(g + "before-send"),
      N = v(g + "tag") || void 0,
      T = "false" !== v(g + "auto-track"),
      A = v(g + "do-not-track") === b,
      j = v(g + "exclude-search") === b,
      x = v(g + "exclude-hash") === b,
      L = v(g + "domains") || "",
      $ = L.split(",").map((t) => t.trim()),
      E = `${(S || "https://api-gateway.umami.dev").replace(
        /\/$/,
        ""
      )}/api/send`,
      K = `${e}x${a}`,
      O = /data-umami-event-([\w-_]+)/,
      U = g + "umami-event",
      _ = 300,
      D = (t) => {
        if (!t) return t;
        try {
          const e = new URL(t, o.href);
          return j && (e.search = ""), x && (e.hash = ""), e.toString();
        } catch (e) {
          return t;
        }
      },
      P = () => ({
        website: w,
        screen: K,
        language: r,
        title: s.title,
        hostname: f,
        url: F,
        referrer: G,
        tag: N,
        id: z || void 0,
      }),
      R = (t, e, a) => {
        a &&
          ((G = F),
          (F = D(new URL(a, o.href).toString())),
          F !== G && setTimeout(I, _));
      },
      W = () =>
        M ||
        !w ||
        (y && y.getItem("umami.disabled")) ||
        (L && !$.includes(f)) ||
        (A &&
          (() => {
            const t = d || n || i;
            return 1 === t || "1" === t || "yes" === t;
          })()),
      B = async (e, a = "event") => {
        if (W()) return;
        const r = t[k];
        if (("function" == typeof r && (e = await Promise.resolve(r(a, e))), e))
          try {
            const t = await fetch(E, {
                keepalive: !0,
                method: "POST",
                body: JSON.stringify({ type: a, payload: e }),
                headers: {
                  "Content-Type": "application/json",
                  ...(void 0 !== q && { "x-umami-cache": q }),
                },
                credentials: "omit",
              }),
              r = await t.json();
            r && ((M = !!r.disabled), (q = r.cache));
          } catch (t) {}
      },
      C = () => {
        H ||
          ((H = !0),
          I(),
          (() => {
            const t = (t, e, a) => {
              const r = t[e];
              return (...e) => (a.apply(null, e), r.apply(t, e));
            };
            (c.pushState = t(c, "pushState", R)),
              (c.replaceState = t(c, "replaceState", R));
          })(),
          (() => {
            const t = async (t) => {
              const e = t.getAttribute(U);
              if (e) {
                const a = {};
                return (
                  t.getAttributeNames().forEach((e) => {
                    const r = e.match(O);
                    r && (a[r[1]] = t.getAttribute(e));
                  }),
                  I(e, a)
                );
              }
            };
            s.addEventListener(
              "click",
              async (e) => {
                const a = e.target,
                  r = a.closest("a,button");
                if (!r) return t(a);
                const { href: n, target: i } = r;
                if (r.getAttribute(U)) {
                  if ("BUTTON" === r.tagName) return t(r);
                  if ("A" === r.tagName && n) {
                    const a =
                      "_blank" === i ||
                      e.ctrlKey ||
                      e.shiftKey ||
                      e.metaKey ||
                      (e.button && 1 === e.button);
                    return (
                      a || e.preventDefault(),
                      t(r).then(() => {
                        a || (("_top" === i ? u.location : o).href = n);
                      })
                    );
                  }
                }
              },
              !0
            );
          })());
      },
      I = (t, e) =>
        B(
          "string" == typeof t
            ? { ...P(), name: t, data: e }
            : "object" == typeof t
            ? { ...t }
            : "function" == typeof t
            ? t(P())
            : P()
        ),
      J = (t, e) => (
        "string" == typeof t && (z = t),
        (q = ""),
        B({ ...P(), data: "object" == typeof t ? t : e }, "identify")
      );
    t.umami || (t.umami = { track: I, identify: J });
    let q,
      z,
      F = D(m),
      G = D(h.startsWith(p) ? "" : h),
      H = !1,
      M = !1;
    T &&
      !W() &&
      ("complete" === s.readyState
        ? C()
        : s.addEventListener("readystatechange", C, !0));
  })(window);
})();
