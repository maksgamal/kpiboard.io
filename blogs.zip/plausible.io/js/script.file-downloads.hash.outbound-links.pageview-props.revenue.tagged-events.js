!(function () {
  var e,
    t,
    n,
    i = document.currentScript,
    r = {};
  function o(e, t, n) {
    window.fetch &&
      fetch(e, {
        method: "POST",
        headers: { "Content-Type": "text/plain" },
        keepalive: !0,
        body: JSON.stringify(t),
      })
        .then(function (e) {
          n && n.callback && n.callback({ status: e.status });
        })
        .catch(function (e) {
          n && n.callback && n.callback({ error: e });
        });
  }
  var a = !1,
    c = location.href,
    u = {},
    l = -1,
    s = 0,
    d = 0;
  function p() {
    var i = f();
    if (!e && (l < n || i >= 3e3)) {
      l = n;
      var a = {
        n: "engagement",
        sd: Math.round((n / t) * 100),
        d: r.domain,
        u: c,
        p: u,
        e: i,
        v: 33,
      };
      (s = 0), (d = 0), (a.h = 1), o(r.endpoint, a);
    }
  }
  function v() {
    "visible" === document.visibilityState && document.hasFocus() && 0 === s
      ? (s = Date.now())
      : ("hidden" !== document.visibilityState && document.hasFocus()) ||
        ((d = f()), (s = 0), p());
  }
  function f() {
    return s ? d + (Date.now() - s) : d;
  }
  function m() {
    var e = document.body || {},
      t = document.documentElement || {};
    return Math.max(
      e.scrollHeight || 0,
      e.offsetHeight || 0,
      e.clientHeight || 0,
      t.scrollHeight || 0,
      t.offsetHeight || 0,
      t.clientHeight || 0
    );
  }
  function g() {
    var e = document.body || {},
      n = document.documentElement || {},
      i = window.innerHeight || n.clientHeight || 0,
      r = window.scrollY || n.scrollTop || e.scrollTop || 0;
    return t <= i ? t : r + i;
  }
  function w(f, w) {
    var b,
      y = "pageview" === f;
    if (
      (y && a && (p(), (t = m()), (n = g())),
      /^localhost$|^127(\.[0-9]+){0,2}\.[0-9]+$|^\[::1?\]$/.test(
        location.hostname
      ) || "file:" === location.protocol)
    )
      return h(f, w, "localhost");
    if (
      (window._phantom ||
        window.__nightmare ||
        window.navigator.webdriver ||
        window.Cypress) &&
      !window.__plausible
    )
      return h(f, w);
    try {
      if ("true" === window.localStorage.plausible_ignore)
        return h(f, w, "localStorage flag");
    } catch (e) {}
    var L = {};
    (L.n = f),
      (L.v = 33),
      (L.u = location.href),
      (L.d = r.domain),
      (L.r = document.referrer || null),
      w && w.meta && (L.m = JSON.stringify(w.meta)),
      w && w.props && (L.p = w.props),
      w && !1 === w.interactive && (L.i = !1),
      w && w.revenue && (L.$ = w.revenue);
    var k = i.getAttributeNames().filter(function (e) {
        return "event-" === e.substring(0, 6);
      }),
      b = L.p || {};
    k.forEach(function (e) {
      var t = e.replace("event-", ""),
        n = i.getAttribute(e);
      b[t] = b[t] || n;
    }),
      (L.p = b),
      (L.h = 1),
      y &&
        ((e = !1),
        (c = L.u),
        (u = L.p),
        (l = -1),
        (d = 0),
        (s = Date.now()),
        a ||
          (document.addEventListener("visibilitychange", v),
          window.addEventListener("blur", v),
          window.addEventListener("focus", v),
          (a = !0))),
      o(r.endpoint, L, w);
  }
  function h(t, n, i) {
    i && r.logging && console.warn("Ignoring Event: " + i),
      n && n.callback && n.callback(),
      "pageview" === t && (e = !0);
  }
  var b = [
      "pdf",
      "xlsx",
      "docx",
      "txt",
      "rtf",
      "csv",
      "exe",
      "key",
      "pps",
      "ppt",
      "pptx",
      "7z",
      "pkg",
      "rar",
      "gz",
      "zip",
      "avi",
      "mov",
      "mp4",
      "mpeg",
      "wmv",
      "midi",
      "mp3",
      "wav",
      "wma",
      "dmg",
    ],
    y = b;
  function L(e) {
    return e && e.tagName && "a" === e.tagName.toLowerCase();
  }
  function k(e) {
    if ("auxclick" !== e.type || 1 === e.button) {
      var t = (function (e) {
          for (; e && (void 0 === e.tagName || !L(e) || !e.href); )
            e = e.parentNode;
          return e;
        })(e.target),
        n = t && "string" == typeof t.href && t.href.split("?")[0];
      if (
        !(function e(t, n) {
          return !!t && !(n > 3) && (!!x(t) || e(t.parentNode, n + 1));
        })(t, 0)
      ) {
        if (
          t &&
          "string" == typeof t.href &&
          t.host &&
          t.host !== location.host
        )
          return E(e, t, {
            name: "Outbound Link: Click",
            props: { url: t.href },
          });
        if (
          (function (e) {
            if (!e) return !1;
            var t = e.split(".").pop();
            return y.some(function (e) {
              return e === t;
            });
          })(n)
        )
          return E(e, t, { name: "File Download", props: { url: n } });
      }
    }
  }
  function E(e, t, n) {
    var i;
    ((i = { props: n.props }).revenue = n.revenue), w(n.name, i);
  }
  function x(e) {
    var t = e && e.classList;
    if (t) {
      for (var n = 0; n < t.length; n++)
        if (t.item(n).match(/plausible-event-name(=|--)(.+)/)) return !0;
    }
    return !1;
  }
  function N(e) {
    var t = x(e) ? e : e && e.parentNode,
      n = { name: null, props: {} };
    n.revenue = {};
    var i = t && t.classList;
    if (!i) return n;
    for (var r = 0; r < i.length; r++) {
      var o,
        a,
        c = i.item(r),
        u = c.match(/plausible-event-(.+)(=|--)(.+)/);
      u &&
        ((o = u[1]),
        (a = u[3].replace(/\+/g, " ")),
        "name" == o.toLowerCase() ? (n.name = a) : (n.props[o] = a));
      var l = c.match(/plausible-revenue-(.+)(=|--)(.+)/);
      l && ((o = l[1]), (a = l[3]), (n.revenue[o] = a));
    }
    return n;
  }
  !(function e(o) {
    (r.endpoint =
      i.getAttribute("data-api") || new URL(i.src).origin + "/api/event"),
      (r.domain = i.getAttribute("data-domain")),
      (r.logging = !0),
      (t = m()),
      (n = g()),
      window.addEventListener("load", function () {
        t = m();
        var e = 0,
          n = setInterval(function () {
            (t = m()), 15 == ++e && clearInterval(n);
          }, 200);
      }),
      document.addEventListener("scroll", function () {
        t = m();
        var e = g();
        e > n && (n = e);
      }),
      (function (e) {
        var t;
        function n(n) {
          (t = location.pathname), e("pageview");
        }
        window.addEventListener("hashchange", function () {
          n(!0);
        }),
          "hidden" === document.visibilityState ||
          "prerender" === document.visibilityState
            ? document.addEventListener("visibilitychange", function () {
                t || "visible" !== document.visibilityState || n();
              })
            : n(),
          window.addEventListener("pageshow", function (e) {
            e.persisted && n();
          });
      })(w),
      (function () {
        document.addEventListener("click", k),
          document.addEventListener("auxclick", k);
        var e = i.getAttribute("file-types"),
          t = i.getAttribute("add-file-types");
        function n(e) {
          if ("auxclick" !== e.type || 1 === e.button) {
            for (var t, n, i, r = e.target, o = 0; o <= 3 && r; o++) {
              if ((t = r) && t.tagName && "form" === t.tagName.toLowerCase())
                return;
              L(r) && (n = r), x(r) && (i = r), (r = r.parentNode);
            }
            if (i) {
              var a = N(i);
              if (n) (a.props.url = n.href), E(e, n, a);
              else {
                var c = {};
                (c.props = a.props), (c.revenue = a.revenue), w(a.name, c);
              }
            }
          }
        }
        e && (y = e.split(",")),
          t && (y = t.split(",").concat(b)),
          document.addEventListener("submit", function (e) {
            var t,
              n = N(e.target);
            n.name &&
              (((t = { props: n.props }).revenue = n.revenue), w(n.name, t));
          }),
          document.addEventListener("click", n),
          document.addEventListener("auxclick", n);
      })();
    for (
      var a = (window.plausible && window.plausible.q) || [], c = 0;
      c < a.length;
      c++
    )
      w.apply(this, a[c]);
    (window.plausible = w),
      (window.plausible.init = e),
      (window.plausible.v = 33),
      (window.plausible.l = !0);
  })();
})();
