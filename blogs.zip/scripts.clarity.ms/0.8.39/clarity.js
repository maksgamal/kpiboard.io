/* clarity-js v0.8.39: https://github.com/microsoft/clarity (License: MIT) */
!(function () {
  "use strict";
  var t = Object.freeze({
      __proto__: null,
      get add() {
        return Ba;
      },
      get get() {
        return rr;
      },
      get getId() {
        return Va;
      },
      get getNode() {
        return nr;
      },
      get getValue() {
        return ar;
      },
      get has() {
        return or;
      },
      get hashText() {
        return er;
      },
      get iframe() {
        return Ka;
      },
      get iframeContent() {
        return Za;
      },
      get lookup() {
        return ir;
      },
      get parse() {
        return Fa;
      },
      get removeIFrame() {
        return Qa;
      },
      get sameorigin() {
        return Ga;
      },
      get start() {
        return Ha;
      },
      get stop() {
        return qa;
      },
      get update() {
        return Ja;
      },
      get updates() {
        return ur;
      },
    }),
    e = Object.freeze({
      __proto__: null,
      get queue() {
        return ei;
      },
      get start() {
        return ti;
      },
      get stop() {
        return ni;
      },
      get track() {
        return Br;
      },
    }),
    n = Object.freeze({
      __proto__: null,
      get data() {
        return Pi;
      },
      get start() {
        return Ri;
      },
      get stop() {
        return Yi;
      },
      get upgrade() {
        return Ai;
      },
    }),
    a = Object.freeze({
      __proto__: null,
      get check() {
        return Li;
      },
      get compute() {
        return zi;
      },
      get data() {
        return Di;
      },
      get start() {
        return Xi;
      },
      get stop() {
        return Hi;
      },
      get trigger() {
        return Wi;
      },
    }),
    r = Object.freeze({
      __proto__: null,
      get compute() {
        return Gi;
      },
      get data() {
        return qi;
      },
      get log() {
        return Ji;
      },
      get reset() {
        return Ki;
      },
      get start() {
        return Vi;
      },
      get stop() {
        return Bi;
      },
      get updates() {
        return Ui;
      },
    }),
    i = Object.freeze({
      __proto__: null,
      get callback() {
        return ho;
      },
      get callbacks() {
        return Qi;
      },
      get clear() {
        return fo;
      },
      get consent() {
        return uo;
      },
      get consentv2() {
        return co;
      },
      get data() {
        return Zi;
      },
      get electron() {
        return $i;
      },
      get id() {
        return oo;
      },
      get metadata() {
        return io;
      },
      get save() {
        return po;
      },
      get shortid() {
        return mo;
      },
      get start() {
        return ao;
      },
      get stop() {
        return ro;
      },
    }),
    o = Object.freeze({
      __proto__: null,
      get data() {
        return Eo;
      },
      get envelope() {
        return No;
      },
      get start() {
        return To;
      },
      get stop() {
        return _o;
      },
    }),
    u = {
      projectId: null,
      delay: 1e3,
      lean: !1,
      lite: !1,
      track: !0,
      content: !0,
      drop: [],
      mask: [],
      unmask: [],
      regions: [],
      cookies: [],
      fraud: !0,
      checksum: [],
      report: null,
      upload: null,
      fallback: null,
      upgrade: null,
      action: null,
      dob: null,
      delayDom: !1,
      throttleDom: !0,
      conversions: !1,
      includeSubdomains: !0,
    };
  function c(t) {
    return window.Zone && "__symbol__" in window.Zone
      ? window.Zone.__symbol__(t)
      : t;
  }
  var s = 0;
  function l() {
    return performance.now() + performance.timeOrigin;
  }
  function d(t) {
    void 0 === t && (t = null);
    var e = 0 === s ? l() : s,
      n = t && t.timeStamp > 0 ? t.timeStamp : performance.now(),
      a = t && t.view ? t.view.performance.timeOrigin : performance.timeOrigin;
    return Math.max(Math.round(n + a - e), 0);
  }
  var f = "0.8.39";
  function h(t, e) {
    void 0 === e && (e = null);
    for (var n, a = 5381, r = a, i = 0; i < t.length; i += 2) {
      if (((a = ((a << 5) + a) ^ t.charCodeAt(i)), i + 1 < t.length))
        r = ((r << 5) + r) ^ t.charCodeAt(i + 1);
    }
    return (
      (n = Math.abs(a + 11579 * r)), (e ? n % Math.pow(2, e) : n).toString(36)
    );
  }
  var p = /\S/gi,
    v = 255,
    g = !0,
    m = null,
    y = null,
    b = null;
  function w(t, e, n, a, r) {
    if ((void 0 === a && (a = !1), t)) {
      if ("input" == e && ("checkbox" === r || "radio" === r)) return t;
      switch (n) {
        case 0:
          return t;
        case 1:
          switch (e) {
            case "*T":
            case "value":
            case "placeholder":
            case "click":
              return (function (t) {
                var e = -1,
                  n = 0,
                  a = !1,
                  r = !1,
                  i = !1,
                  o = null;
                _();
                for (var u = 0; u < t.length; u++) {
                  var c = t.charCodeAt(u);
                  if (
                    ((a = a || (c >= 48 && c <= 57)),
                    (r = r || 64 === c),
                    (i = 9 === c || 10 === c || 13 === c || 32 === c),
                    0 === u || u === t.length - 1 || i)
                  ) {
                    if (a || r) {
                      null === o && (o = t.split(""));
                      var s = t.substring(e + 1, i ? u : u + 1);
                      (s =
                        g && null !== b
                          ? s.match(b)
                            ? s
                            : E(s, "▪", "▫")
                          : O(s)),
                        o.splice(e + 1 - n, s.length, s),
                        (n += s.length - 1);
                    }
                    i && ((a = !1), (r = !1), (e = u));
                  }
                }
                return o ? o.join("") : t;
              })(t);
            case "input":
            case "change":
              return T(t);
          }
          return t;
        case 2:
        case 3:
          switch (e) {
            case "*T":
            case "data-":
              return a ? k(t) : O(t);
            case "src":
            case "srcset":
            case "title":
            case "alt":
              return 3 === n
                ? "src" === e && (null == t ? void 0 : t.startsWith("blob:"))
                  ? "blob:"
                  : ""
                : t;
            case "value":
            case "click":
            case "input":
            case "change":
              return T(t);
            case "placeholder":
              return O(t);
          }
          break;
        case 4:
          switch (e) {
            case "*T":
            case "data-":
              return a ? k(t) : O(t);
            case "value":
            case "input":
            case "click":
            case "change":
              return Array(5).join("•");
            case "checksum":
              return "";
          }
          break;
        case 5:
          switch (e) {
            case "*T":
            case "data-":
              return E(t, "▪", "▫");
            case "value":
            case "input":
            case "click":
            case "change":
              return Array(5).join("•");
            case "checksum":
            case "src":
            case "srcset":
            case "alt":
            case "title":
              return "";
          }
      }
    }
    return t;
  }
  function S(t, e, n) {
    void 0 === e && (e = !1), void 0 === n && (n = !1);
    var a = t;
    if (e) a = "".concat("https://").concat("Electron");
    else {
      var r = u.drop;
      if (r && r.length > 0 && t && t.indexOf("?") > 0) {
        var i = t.split("?"),
          o = i[0],
          c = i[1];
        a =
          o +
          "?" +
          c
            .split("&")
            .map(function (t) {
              return r.some(function (e) {
                return 0 === t.indexOf("".concat(e, "="));
              })
                ? "".concat(t.split("=")[0], "=").concat("*na*")
                : t;
            })
            .join("&");
      }
    }
    return n && (a = a.substring(0, v)), a;
  }
  function k(t) {
    var e = t.trim();
    if (e.length > 0) {
      var n = e[0],
        a = t.indexOf(n),
        r = t.substr(0, a),
        i = t.substr(a + e.length);
      return "".concat(r).concat(e.length.toString(36)).concat(i);
    }
    return t;
  }
  function O(t) {
    return t.replace(p, "•");
  }
  function E(t, e, n) {
    return _(), t ? t.replace(y, e).replace(m, n) : t;
  }
  function T(t) {
    for (var e = 5 * (Math.floor(t.length / 5) + 1), n = "", a = 0; a < e; a++)
      n += a > 0 && a % 5 == 0 ? " " : "•";
    return n;
  }
  function _() {
    if (g && null === m)
      try {
        (m = new RegExp("\\p{N}", "gu")),
          (y = new RegExp("\\p{L}", "gu")),
          (b = new RegExp("\\p{Sc}", "gu"));
      } catch (t) {
        g = !1;
      }
  }
  var N = null,
    M = null,
    x = !1;
  function I() {
    x &&
      (N = {
        time: d(),
        event: 4,
        data: {
          visible: M.visible,
          docWidth: M.docWidth,
          docHeight: M.docHeight,
          screenWidth: M.screenWidth,
          screenHeight: M.screenHeight,
          scrollX: M.scrollX,
          scrollY: M.scrollY,
          pointerX: M.pointerX,
          pointerY: M.pointerY,
          activityTime: M.activityTime,
          scrollTime: M.scrollTime,
          pointerTime: M.pointerTime,
          moveX: M.moveX,
          moveY: M.moveY,
          moveTime: M.moveTime,
          downX: M.downX,
          downY: M.downY,
          downTime: M.downTime,
          upX: M.upX,
          upY: M.upY,
          upTime: M.upTime,
          pointerPrevX: M.pointerPrevX,
          pointerPrevY: M.pointerPrevY,
          pointerPrevTime: M.pointerPrevTime,
          modules: M.modules,
        },
      }),
      (M = M || {
        visible: 1,
        docWidth: 0,
        docHeight: 0,
        screenWidth: 0,
        screenHeight: 0,
        scrollX: 0,
        scrollY: 0,
        pointerX: 0,
        pointerY: 0,
        activityTime: 0,
        scrollTime: 0,
        pointerTime: void 0,
        moveX: void 0,
        moveY: void 0,
        moveTime: void 0,
        downX: void 0,
        downY: void 0,
        downTime: void 0,
        upX: void 0,
        upY: void 0,
        upTime: void 0,
        pointerPrevX: void 0,
        pointerPrevY: void 0,
        pointerPrevTime: void 0,
        modules: null,
      });
  }
  function C(t, e, n, a) {
    switch (t) {
      case 8:
        (M.docWidth = e), (M.docHeight = n);
        break;
      case 11:
        (M.screenWidth = e), (M.screenHeight = n);
        break;
      case 10:
        (M.scrollX = e), (M.scrollY = n), (M.scrollTime = a);
        break;
      case 12:
        (M.moveX = e),
          (M.moveY = n),
          (M.moveTime = a),
          (M.pointerPrevX = M.pointerX),
          (M.pointerPrevY = M.pointerY),
          (M.pointerPrevTime = M.pointerTime),
          (M.pointerX = e),
          (M.pointerY = n),
          (M.pointerTime = a);
        break;
      case 13:
        (M.downX = e),
          (M.downY = n),
          (M.downTime = a),
          (M.pointerPrevX = M.pointerX),
          (M.pointerPrevY = M.pointerY),
          (M.pointerPrevTime = M.pointerTime),
          (M.pointerX = e),
          (M.pointerY = n),
          (M.pointerTime = a);
        break;
      case 14:
        (M.upX = e),
          (M.upY = n),
          (M.upTime = a),
          (M.pointerPrevX = M.pointerX),
          (M.pointerPrevY = M.pointerY),
          (M.pointerPrevTime = M.pointerTime),
          (M.pointerX = e),
          (M.pointerY = n),
          (M.pointerTime = a);
        break;
      default:
        (M.pointerPrevX = M.pointerX),
          (M.pointerPrevY = M.pointerY),
          (M.pointerPrevTime = M.pointerTime),
          (M.pointerX = e),
          (M.pointerY = n),
          (M.pointerTime = a);
    }
    x = !0;
  }
  function D(t) {
    M.activityTime = t;
  }
  function P(t, e) {
    (M.visible = e), M.visible || D(t), (x = !0);
  }
  function R(t) {
    (M.modules = Array.from(t)), (x = !0);
  }
  function A() {
    x && ji(4);
  }
  var Y = Object.freeze({
      __proto__: null,
      activity: D,
      compute: A,
      dynamic: R,
      reset: I,
      start: function () {
        (x = !1), I();
      },
      get state() {
        return N;
      },
      stop: function () {
        I();
      },
      track: C,
      visibility: P,
    }),
    j = null,
    X = !0;
  function L() {
    var t,
      e =
        null === (t = window.google_tag_data) || void 0 === t ? void 0 : t.ics;
    if (null == e ? void 0 : e.getConsentState) {
      var n = e.getConsentState("analytics_storage");
      co(
        (function (t) {
          var e = {
            ad_Storage: 1 === t.ad_Storage ? "granted" : "denied",
            analytics_Storage: 1 === t.analytics_Storage ? "granted" : "denied",
          };
          return e;
        })({
          ad_Storage: e.getConsentState("ad_storage"),
          analytics_Storage: n,
        }),
        2
      );
    }
  }
  function W(t) {
    H(t.analytics_Storage ? 1 : 0), (j = t);
  }
  function z() {
    H(2);
  }
  function H(t) {
    Ji(36, t.toString());
  }
  function q(t) {
    (j = t), ji(47);
  }
  function U() {
    var t;
    if (X) {
      ji(47), (X = !1);
      var e =
        null === (t = window.google_tag_data) || void 0 === t ? void 0 : t.ics;
      (null == e ? void 0 : e.usedUpdate) && L();
    }
  }
  var F = Object.freeze({
      __proto__: null,
      compute: U,
      config: W,
      consent: z,
      get data() {
        return j;
      },
      start: function () {
        var t,
          e =
            null === (t = window.google_tag_data) || void 0 === t
              ? void 0
              : t.ics;
        (X = !0),
          (null == e ? void 0 : e.addListener) &&
            e.addListener(["ad_storage", "analytics_storage"], L);
      },
      stop: function () {
        X = !0;
      },
      trackConsentv2: q,
    }),
    V = null;
  function B(t, e) {
    Jo() &&
      t &&
      "string" == typeof t &&
      t.length < 255 &&
      ((V =
        e && "string" == typeof e && e.length < 255
          ? { key: t, value: e }
          : { value: t }),
      ji(24));
  }
  var J,
    G = null,
    K = null;
  function Z(t) {
    t in G || (G[t] = 0), t in K || (K[t] = 0), G[t]++, K[t]++;
  }
  function Q(t, e) {
    null !== e &&
      (t in G || (G[t] = 0), t in K || (K[t] = 0), (G[t] += e), (K[t] += e));
  }
  function $(t, e) {
    null !== e &&
      !1 === isNaN(e) &&
      (t in G || (G[t] = 0),
      (e > G[t] || 0 === G[t]) && ((K[t] = e), (G[t] = e)));
  }
  function tt(t, e, n) {
    return window.setTimeout(Io(t), e, n);
  }
  function et(t) {
    return window.clearTimeout(t);
  }
  var nt = 0,
    at = 0,
    rt = null;
  function it() {
    rt && et(rt), (rt = tt(ot, at)), (nt = d());
  }
  function ot() {
    var t = d();
    (J = { gap: t - nt }),
      ji(25),
      J.gap < 3e5
        ? (rt = tt(ot, at))
        : Fo &&
          (B("clarity", "suspend"),
          bu(),
          ["mousemove", "touchstart"].forEach(function (t) {
            return Do(document, t, Go);
          }),
          ["resize", "scroll", "pageshow"].forEach(function (t) {
            return Do(window, t, Go);
          }));
  }
  var ut = Object.freeze({
      __proto__: null,
      get data() {
        return J;
      },
      reset: it,
      start: function () {
        (at = 6e4), (nt = 0);
      },
      stop: function () {
        et(rt), (nt = 0), (at = 0);
      },
    }),
    ct = null;
  function st(t, e) {
    if (t in ct) {
      var n = ct[t],
        a = n[n.length - 1];
      e - a[0] > 100 ? ct[t].push([e, 0]) : (a[1] = e - a[0]);
    } else ct[t] = [[e, 0]];
  }
  function lt() {
    ji(36);
  }
  function dt() {
    ct = {};
  }
  var ft = Object.freeze({
    __proto__: null,
    compute: lt,
    get data() {
      return ct;
    },
    reset: dt,
    start: function () {
      ct = {};
    },
    stop: function () {
      ct = {};
    },
    track: st,
  });
  function ht(t, e, n, a) {
    return new (n || (n = Promise))(function (r, i) {
      function o(t) {
        try {
          c(a.next(t));
        } catch (t) {
          i(t);
        }
      }
      function u(t) {
        try {
          c(a.throw(t));
        } catch (t) {
          i(t);
        }
      }
      function c(t) {
        var e;
        t.done
          ? r(t.value)
          : ((e = t.value),
            e instanceof n
              ? e
              : new n(function (t) {
                  t(e);
                })).then(o, u);
      }
      c((a = a.apply(t, e || [])).next());
    });
  }
  function pt(t, e) {
    var n,
      a,
      r,
      i,
      o = {
        label: 0,
        sent: function () {
          if (1 & r[0]) throw r[1];
          return r[1];
        },
        trys: [],
        ops: [],
      };
    return (
      (i = { next: u(0), throw: u(1), return: u(2) }),
      "function" == typeof Symbol &&
        (i[Symbol.iterator] = function () {
          return this;
        }),
      i
    );
    function u(u) {
      return function (c) {
        return (function (u) {
          if (n) throw new TypeError("Generator is already executing.");
          for (; i && ((i = 0), u[0] && (o = 0)), o; )
            try {
              if (
                ((n = 1),
                a &&
                  (r =
                    2 & u[0]
                      ? a.return
                      : u[0]
                      ? a.throw || ((r = a.return) && r.call(a), 0)
                      : a.next) &&
                  !(r = r.call(a, u[1])).done)
              )
                return r;
              switch (((a = 0), r && (u = [2 & u[0], r.value]), u[0])) {
                case 0:
                case 1:
                  r = u;
                  break;
                case 4:
                  return o.label++, { value: u[1], done: !1 };
                case 5:
                  o.label++, (a = u[1]), (u = [0]);
                  continue;
                case 7:
                  (u = o.ops.pop()), o.trys.pop();
                  continue;
                default:
                  if (
                    !((r = o.trys),
                    (r = r.length > 0 && r[r.length - 1]) ||
                      (6 !== u[0] && 2 !== u[0]))
                  ) {
                    o = 0;
                    continue;
                  }
                  if (3 === u[0] && (!r || (u[1] > r[0] && u[1] < r[3]))) {
                    o.label = u[1];
                    break;
                  }
                  if (6 === u[0] && o.label < r[1]) {
                    (o.label = r[1]), (r = u);
                    break;
                  }
                  if (r && o.label < r[2]) {
                    (o.label = r[2]), o.ops.push(u);
                    break;
                  }
                  r[2] && o.ops.pop(), o.trys.pop();
                  continue;
              }
              u = e.call(t, o);
            } catch (t) {
              (u = [6, t]), (a = 0);
            } finally {
              n = r = 0;
            }
          if (5 & u[0]) throw u[1];
          return { value: u[0] ? u[1] : void 0, done: !0 };
        })([u, c]);
      };
    }
  }
  var vt = "CompressionStream" in window;
  function gt(t) {
    return ht(this, void 0, void 0, function () {
      var e, n;
      return pt(this, function (a) {
        switch (a.label) {
          case 0:
            return (
              a.trys.push([0, 3, , 4]),
              vt
                ? ((e = new ReadableStream({
                    start: function (e) {
                      return ht(this, void 0, void 0, function () {
                        return pt(this, function (n) {
                          return e.enqueue(t), e.close(), [2];
                        });
                      });
                    },
                  })
                    .pipeThrough(new TextEncoderStream())
                    .pipeThrough(new window.CompressionStream("gzip"))),
                  (n = Uint8Array.bind),
                  [4, mt(e)])
                : [3, 2]
            );
          case 1:
            return [2, new (n.apply(Uint8Array, [void 0, a.sent()]))()];
          case 2:
            return [3, 4];
          case 3:
            return a.sent(), [3, 4];
          case 4:
            return [2, null];
        }
      });
    });
  }
  function mt(t) {
    return ht(this, void 0, void 0, function () {
      var e, n, a, r, i;
      return pt(this, function (o) {
        switch (o.label) {
          case 0:
            (e = t.getReader()), (n = []), (a = !1), (r = []), (o.label = 1);
          case 1:
            return a ? [3, 3] : [4, e.read()];
          case 2:
            return (
              (i = o.sent()),
              (a = i.done),
              (r = i.value),
              a ? [2, n] : (n.push.apply(n, r), [3, 1])
            );
          case 3:
            return [2, n];
        }
      });
    });
  }
  var yt = null;
  function bt(t, e) {
    St(t, "string" == typeof e ? [e] : e);
  }
  function wt(t, e, n, a) {
    return (
      void 0 === e && (e = null),
      void 0 === n && (n = null),
      void 0 === a && (a = null),
      ht(this, void 0, void 0, function () {
        var r, i;
        return pt(this, function (o) {
          switch (o.label) {
            case 0:
              return (i = {}), [4, Et(t)];
            case 1:
              return (
                (i.userId = o.sent()),
                (i.userHint =
                  a ||
                  ((u = t) && u.length >= 5
                    ? ""
                        .concat(u.substring(0, 2))
                        .concat(E(u.substring(2), "*", "*"))
                    : E(u, "*", "*"))),
                St("userId", [(r = i).userId]),
                St("userHint", [r.userHint]),
                St("userType", [Tt(t)]),
                e && (St("sessionId", [e]), (r.sessionId = e)),
                n && (St("pageId", [n]), (r.pageId = n)),
                [2, r]
              );
          }
          var u;
        });
      })
    );
  }
  function St(t, e) {
    if (Jo() && t && e && "string" == typeof t && t.length < 255) {
      for (var n = (t in yt) ? yt[t] : [], a = 0; a < e.length; a++)
        "string" == typeof e[a] && e[a].length < 255 && n.push(e[a]);
      yt[t] = n;
    }
  }
  function kt() {
    ji(34);
  }
  function Ot() {
    yt = {};
  }
  function Et(t) {
    return ht(this, void 0, void 0, function () {
      var e;
      return pt(this, function (n) {
        switch (n.label) {
          case 0:
            return (
              n.trys.push([0, 4, , 5]),
              crypto && t
                ? [
                    4,
                    crypto.subtle.digest(
                      "SHA-256",
                      new TextEncoder().encode(t)
                    ),
                  ]
                : [3, 2]
            );
          case 1:
            return (
              (e = n.sent()),
              [
                2,
                Array.prototype.map
                  .call(new Uint8Array(e), function (t) {
                    return ("00" + t.toString(16)).slice(-2);
                  })
                  .join(""),
              ]
            );
          case 2:
            return [2, ""];
          case 3:
            return [3, 5];
          case 4:
            return n.sent(), [2, ""];
          case 5:
            return [2];
        }
      });
    });
  }
  function Tt(t) {
    return t && t.indexOf("@") > 0 ? "email" : "string";
  }
  var _t = Object.freeze({
      __proto__: null,
      compute: kt,
      get data() {
        return yt;
      },
      identify: wt,
      reset: Ot,
      set: bt,
      start: function () {
        Ot();
      },
      stop: function () {
        Ot();
      },
    }),
    Nt = {},
    Mt = new Set(),
    xt = {},
    It = {},
    Ct = {},
    Dt = {};
  function Pt(t) {
    try {
      var e = t && t.length > 0 ? t.split(/ (.*)/) : [""],
        n = e[0].split(/\|(.*)/),
        a = parseInt(n[0]),
        r = n.length > 1 ? n[1] : "",
        i = e.length > 1 ? JSON.parse(e[1]) : {};
      for (var o in ((xt[a] = {}),
      (It[a] = {}),
      (Ct[a] = {}),
      (Dt[a] = r),
      i)) {
        var u = parseInt(o),
          c = i[o],
          s = 2;
        switch (
          (c.startsWith("~") ? (s = 0) : c.startsWith("!") && (s = 4), s)
        ) {
          case 0:
            var l = c.slice(1);
            xt[a][u] = Xt(l);
            break;
          case 2:
            It[a][u] = c;
            break;
          case 4:
            var d = c.slice(1);
            Ct[a][u] = d;
        }
      }
    } catch (t) {
      hi(8, 1, t ? t.name : null);
    }
  }
  function Rt(t) {
    return JSON.parse(JSON.stringify(t));
  }
  function At() {
    try {
      for (var t in xt) {
        var e = parseInt(t);
        if ("" == Dt[e] || document.querySelector(Dt[e])) {
          var n = xt[e];
          for (var a in n) {
            var r = parseInt(a),
              i = (m = Lt(Rt(n[r]))) ? JSON.stringify(m).slice(0, 1e4) : m;
            i && jt(e, r, i);
          }
          var o = It[e];
          for (var u in o) {
            var c = !1,
              s = parseInt(u),
              l = o[s];
            l.startsWith("@") && ((c = !0), (l = l.slice(1)));
            var d = document.querySelectorAll(l);
            if (d) {
              var f = Array.from(d)
                .map(function (t) {
                  return t.textContent;
                })
                .join("<SEP>");
              jt(e, s, (c ? h(f).trim() : f).slice(0, 1e4));
            }
          }
          var p = Ct[e];
          for (var v in p) {
            var g = parseInt(v);
            jt(e, g, er(p[g]).trim().slice(0, 1e4));
          }
        }
      }
      Mt.size > 0 && ji(40);
    } catch (t) {
      hi(5, 1, t ? t.name : null);
    }
    var m;
  }
  function Yt() {
    Mt.clear();
  }
  function jt(t, e, n) {
    var a,
      r = !1;
    t in Nt || ((Nt[t] = {}), (r = !0)),
      (a = Ct[t]),
      0 == Object.keys(a).length || (e in Nt[t] && Nt[t][e] == n) || (r = !0),
      (Nt[t][e] = n),
      r && Mt.add(t);
  }
  function Xt(t) {
    for (var e = [], n = t.split("."); n.length > 0; ) {
      var a = n.shift(),
        r = a.indexOf("["),
        i = a.indexOf("{"),
        o = a.indexOf("}");
      e.push({
        name: r > 0 ? a.slice(0, r) : i > 0 ? a.slice(0, i) : a,
        type: r > 0 ? 1 : i > 0 ? 2 : 3,
        condition: i > 0 ? a.slice(i + 1, o) : null,
      });
    }
    return e;
  }
  function Lt(t, e) {
    if ((void 0 === e && (e = window), 0 == t.length)) return e;
    var n,
      a = t.shift();
    if (e && e[a.name]) {
      var r = e[a.name];
      if (1 !== a.type && Wt(r, a.condition)) n = Lt(t, r);
      else if (Array.isArray(r)) {
        for (var i = [], o = 0, u = r; o < u.length; o++) {
          var c = u[o];
          if (Wt(c, a.condition)) {
            var s = Lt(t, c);
            s && i.push(s);
          }
        }
        n = i;
      }
      return n;
    }
    return null;
  }
  function Wt(t, e) {
    if (e) {
      var n = e.split(":");
      return n.length > 1 ? t[n[0]] == n[1] : t[n[0]];
    }
    return !0;
  }
  var zt = null;
  function Ht(t) {
    try {
      if (!zt) return;
      var e = (function (t) {
        try {
          return JSON.parse(t);
        } catch (t) {
          return [];
        }
      })(t);
      e.forEach(function (t) {
        zt(t);
      });
    } catch (t) {}
  }
  var qt = [
    Y,
    r,
    _t,
    a,
    ft,
    F,
    i,
    o,
    e,
    ut,
    n,
    Object.freeze({
      __proto__: null,
      clone: Rt,
      compute: At,
      data: Nt,
      keys: Mt,
      reset: Yt,
      start: function () {
        Yt();
      },
      stop: function () {
        Yt();
      },
      trigger: Pt,
      update: jt,
    }),
  ];
  function Ut() {
    (G = {}),
      (K = {}),
      Z(5),
      qt.forEach(function (t) {
        return Io(t.start)();
      });
  }
  function Ft() {
    qt
      .slice()
      .reverse()
      .forEach(function (t) {
        return Io(t.stop)();
      }),
      (G = {}),
      (K = {});
  }
  function Vt() {
    kt(), A(), Gi(), ji(0), lt(), zi(), At(), U();
  }
  var Bt,
    Jt = [];
  function Gt(t, e, n) {
    u.fraud &&
      null !== t &&
      n &&
      n.length >= 5 &&
      ((Bt = { id: t, target: e, checksum: h(n, 28) }),
      Jt.indexOf(Bt.checksum) < 0 && (Jt.push(Bt.checksum), li(41)));
  }
  var Kt = [];
  function Zt(t) {
    var e = Er(t);
    if (e) {
      var n = e.value,
        a =
          n &&
          n.length >= 5 &&
          u.fraud &&
          -1 === "password,secret,pass,social,ssn,code,hidden".indexOf(e.type)
            ? h(n, 28)
            : "";
      Kt.push({
        time: d(t),
        event: 42,
        data: { target: Er(t), type: e.type, value: n, checksum: a },
      }),
        Si(_r.bind(this, 42));
    }
  }
  function Qt() {
    Kt = [];
  }
  function $t(t) {
    var e = { x: 0, y: 0 };
    if (t && t.offsetParent)
      do {
        var n = t.offsetParent,
          a = null === n ? Ka(t.ownerDocument) : null;
        (e.x += t.offsetLeft), (e.y += t.offsetTop), (t = a || n);
      } while (t);
    return e;
  }
  var te = ["input", "textarea", "radio", "button", "canvas", "select"],
    ee = [];
  function ne(t, e, n) {
    var a = Ka(e),
      r =
        a && a.contentDocument
          ? a.contentDocument.documentElement
          : document.documentElement,
      i =
        "pageX" in n
          ? Math.round(n.pageX)
          : "clientX" in n
          ? Math.round(n.clientX + r.scrollLeft)
          : null,
      o =
        "pageY" in n
          ? Math.round(n.pageY)
          : "clientY" in n
          ? Math.round(n.clientY + r.scrollTop)
          : null;
    if (a) {
      var u = $t(a);
      (i = i ? i + Math.round(u.x) : i), (o = o ? o + Math.round(u.y) : o);
    }
    var c = Er(n),
      s = (function (t) {
        for (; t && t !== document; ) {
          if (t.nodeType === Node.ELEMENT_NODE) {
            var e = t;
            if ("A" === e.tagName) return e;
          }
          t = t.parentNode;
        }
        return null;
      })(c),
      l = (function (t) {
        var e = null,
          n = document.documentElement;
        if ("function" == typeof t.getBoundingClientRect) {
          var a = t.getBoundingClientRect();
          a &&
            a.width > 0 &&
            a.height > 0 &&
            (e = {
              x: Math.floor(
                a.left +
                  ("pageXOffset" in window ? window.pageXOffset : n.scrollLeft)
              ),
              y: Math.floor(
                a.top +
                  ("pageYOffset" in window ? window.pageYOffset : n.scrollTop)
              ),
              w: Math.floor(a.width),
              h: Math.floor(a.height),
            });
        }
        return e;
      })(c);
    0 === n.detail &&
      l &&
      ((i = Math.round(l.x + l.w / 2)), (o = Math.round(l.y + l.h / 2)));
    var f = l ? Math.max(Math.floor(((i - l.x) / l.w) * 32767), 0) : 0,
      h = l ? Math.max(Math.floor(((o - l.y) / l.h) * 32767), 0) : 0;
    if (null !== i && null !== o) {
      var p = (function (t) {
        var e = null,
          n = !1;
        if (t) {
          var a = t.textContent || String(t.value || "") || t.alt;
          if (a) {
            var r = a.replace(/\s+/g, " ").trim();
            n = (e = r.substring(0, 25)).length === r.length;
          }
        }
        return { text: e, isFullText: n ? 1 : 0 };
      })(c);
      ee.push({
        time: d(n),
        event: t,
        data: {
          target: c,
          x: i,
          y: o,
          eX: f,
          eY: h,
          button: n.button,
          reaction: ae(c),
          context: re(s),
          text: p.text,
          link: s ? s.href : null,
          hash: null,
          trust: n.isTrusted ? 1 : 0,
          isFullText: p.isFullText,
          w: l ? l.w : 0,
          h: l ? l.h : 0,
        },
      }),
        Si(_r.bind(this, t));
    }
  }
  function ae(t) {
    if (t.nodeType === Node.ELEMENT_NODE) {
      var e = t.tagName.toLowerCase();
      if (te.indexOf(e) >= 0) return 0;
    }
    return 1;
  }
  function re(t) {
    if (t && t.hasAttribute("target"))
      switch (t.getAttribute("target")) {
        case "_blank":
          return 1;
        case "_parent":
          return 2;
        case "_top":
          return 3;
      }
    return 0;
  }
  function ie() {
    ee = [];
  }
  var oe = [];
  function ue(t, e) {
    oe.push({ time: d(e), event: 38, data: { target: Er(e), action: t } }),
      Si(_r.bind(this, 38));
  }
  function ce() {
    oe = [];
  }
  var se = null,
    le = [];
  function de(t) {
    var e = Er(t),
      n = rr(e);
    if (e && e.type && n) {
      var a = e.value,
        r = e.type;
      switch (e.type) {
        case "radio":
        case "checkbox":
          a = e.checked ? "true" : "false";
      }
      var i = { target: e, value: a, type: r, trust: t.isTrusted ? 1 : 0 };
      le.length > 0 && le[le.length - 1].data.target === i.target && le.pop(),
        le.push({ time: d(t), event: 27, data: i }),
        et(se),
        (se = tt(fe, 1e3, 27));
    }
  }
  function fe(t) {
    Si(_r.bind(this, t));
  }
  function he() {
    le = [];
  }
  var pe,
    ve = [],
    ge = null,
    me = !1,
    ye = 0,
    be = new Set();
  function we(t, e, n) {
    var a = Ka(e),
      r =
        a && a.contentDocument
          ? a.contentDocument.documentElement
          : document.documentElement,
      i =
        "pageX" in n
          ? Math.round(n.pageX)
          : "clientX" in n
          ? Math.round(n.clientX + r.scrollLeft)
          : null,
      o =
        "pageY" in n
          ? Math.round(n.pageY)
          : "clientY" in n
          ? Math.round(n.clientY + r.scrollTop)
          : null;
    if (a) {
      var u = $t(a);
      (i = i ? i + Math.round(u.x) : i), (o = o ? o + Math.round(u.y) : o);
    }
    null !== i &&
      null !== o &&
      ke({ time: d(n), event: t, data: { target: Er(n), x: i, y: o } });
  }
  function Se(t, e, n) {
    var a = Ka(e),
      r =
        a && a.contentDocument
          ? a.contentDocument.documentElement
          : document.documentElement,
      i = n.changedTouches,
      o = d(n);
    if (i)
      for (var u = 0; u < i.length; u++) {
        var c = i[u],
          s = "clientX" in c ? Math.round(c.clientX + r.scrollLeft) : null,
          l = "clientY" in c ? Math.round(c.clientY + r.scrollTop) : null;
        (s = s && a ? s + Math.round(a.offsetLeft) : s),
          (l = l && a ? l + Math.round(a.offsetTop) : l);
        var f = "identifier" in c ? c.identifier : void 0;
        switch (t) {
          case 17:
            0 === be.size && ((me = !0), (ye = f)), be.add(f);
            break;
          case 18:
          case 20:
            be.delete(f);
        }
        var h = me && ye === f;
        null !== s &&
          null !== l &&
          ke({
            time: o,
            event: t,
            data: { target: Er(n), x: s, y: l, id: f, isPrimary: h },
          }),
          (20 !== t && 18 !== t) || (ye === f && (me = !1));
      }
  }
  function ke(t) {
    switch (t.event) {
      case 12:
      case 15:
      case 19:
        var e = ve.length,
          n = e > 1 ? ve[e - 2] : null;
        n &&
          (function (t, e) {
            var n = t.data.x - e.data.x,
              a = t.data.y - e.data.y,
              r = Math.sqrt(n * n + a * a),
              i = e.time - t.time,
              o = e.data.target === t.data.target,
              u = void 0 === e.data.id || e.data.id === t.data.id;
            return e.event === t.event && o && r < 20 && i < 25 && u;
          })(n, t) &&
          ve.pop(),
          ve.push(t),
          et(ge),
          (ge = tt(Oe, 500, t.event));
        break;
      default:
        ve.push(t), Oe(t.event);
    }
  }
  function Oe(t) {
    Si(_r.bind(this, t));
  }
  function Ee() {
    ve = [];
  }
  function Te(t, e) {
    var n = 0,
      a = null,
      r = null;
    function i() {
      for (var i = this, o = [], u = 0; u < arguments.length; u++)
        o[u] = arguments[u];
      var c = performance.now(),
        s = c - n;
      if (0 !== n && s < e) {
        if (((r = o), a)) return;
        a = setTimeout(function () {
          (n = performance.now()), t.apply(i, r), (r = null), (a = null);
        }, e - s);
      } else (n = c), t.apply(this, o);
    }
    return (
      (i.cleanup = function () {
        a && (clearTimeout(a), (a = null), (r = null));
      }),
      i
    );
  }
  var _e = null,
    Ne = !1,
    Me = Te(xe, 500);
  function xe() {
    var t = document.documentElement;
    (pe = {
      width:
        t && "clientWidth" in t
          ? Math.min(t.clientWidth, window.innerWidth)
          : window.innerWidth,
      height:
        t && "clientHeight" in t
          ? Math.min(t.clientHeight, window.innerHeight)
          : window.innerHeight,
    }),
      Ne ? (et(_e), (_e = tt(Ie, 500, 11))) : (_r(11), (Ne = !0));
  }
  function Ie(t) {
    Si(_r.bind(this, t));
  }
  function Ce() {
    (pe = null), et(_e), Me.cleanup();
  }
  var De = [],
    Pe = null,
    Re = null,
    Ae = null;
  function Ye(t) {
    void 0 === t && (t = null);
    var e = window,
      n = document.documentElement,
      a = t ? Er(t) : n;
    if (a) {
      if (a && a.nodeType === Node.DOCUMENT_NODE) {
        var r = Ka(a);
        (e = r ? r.contentWindow : e), (a = n = a.documentElement);
      }
      var i =
          a === n && "pageXOffset" in e
            ? Math.round(e.pageXOffset)
            : Math.round(a.scrollLeft),
        o =
          a === n && "pageYOffset" in e
            ? Math.round(e.pageYOffset)
            : Math.round(a.scrollTop),
        u = window.innerWidth,
        c = window.innerHeight,
        s = u / 3,
        l = u > c ? 0.15 * c : 0.2 * c,
        f = c - l,
        h = Xe(s, l),
        p = Xe(s, f),
        v = {
          time: d(t),
          event: 10,
          data: { target: a, x: i, y: o, top: h, bottom: p },
        };
      if ((null === t && 0 === i && 0 === o) || null === i || null === o)
        return (Pe = h), void (Re = p);
      var g = De.length,
        m = g > 1 ? De[g - 2] : null;
      m &&
        (function (t, e) {
          var n = t.data.x - e.data.x,
            a = t.data.y - e.data.y;
          return n * n + a * a < 400 && e.time - t.time < 50;
        })(m, v) &&
        De.pop(),
        De.push(v),
        et(Ae),
        (Ae = tt(Le, 500, 10));
    }
  }
  var je = Te(Ye, 25);
  function Xe(t, e) {
    var n, a, r;
    return (
      "caretPositionFromPoint" in document
        ? (r =
            null === (n = document.caretPositionFromPoint(t, e)) || void 0 === n
              ? void 0
              : n.offsetNode)
        : "caretRangeFromPoint" in document &&
          (r =
            null === (a = document.caretRangeFromPoint(t, e)) || void 0 === a
              ? void 0
              : a.startContainer),
      r || (r = document.elementFromPoint(t, e)),
      r && r.nodeType === Node.TEXT_NODE && (r = r.parentNode),
      r
    );
  }
  function Le(t) {
    Si(_r.bind(this, t));
  }
  function We() {
    var t, e;
    if (Pe) {
      var n = Tr(Pe, null);
      Ji(
        31,
        null === (t = null == n ? void 0 : n.hash) || void 0 === t
          ? void 0
          : t.join(".")
      );
    }
    if (Re) {
      var a = Tr(Re, null);
      Ji(
        32,
        null === (e = null == a ? void 0 : a.hash) || void 0 === e
          ? void 0
          : e.join(".")
      );
    }
  }
  var ze = null,
    He = null,
    qe = null;
  function Ue(t) {
    var e = (t.nodeType === Node.DOCUMENT_NODE ? t : document).getSelection();
    if (
      null !== e &&
      !(
        (null === e.anchorNode && null === e.focusNode) ||
        (e.anchorNode === e.focusNode && e.anchorOffset === e.focusOffset)
      )
    ) {
      var n = ze.start ? ze.start : null;
      null !== He &&
        null !== ze.start &&
        n !== e.anchorNode &&
        (et(qe), Fe(21)),
        (ze = {
          start: e.anchorNode,
          startOffset: e.anchorOffset,
          end: e.focusNode,
          endOffset: e.focusOffset,
        }),
        (He = e),
        et(qe),
        (qe = tt(Fe, 500, 21));
    }
  }
  function Fe(t) {
    Si(_r.bind(this, t));
  }
  function Ve() {
    (He = null), (ze = { start: 0, startOffset: 0, end: 0, endOffset: 0 });
  }
  var Be,
    Je,
    Ge,
    Ke = [];
  function Ze(t) {
    Ke.push({ time: d(t), event: 39, data: { target: Er(t) } }),
      Si(_r.bind(this, 39));
  }
  function Qe() {
    Ke = [];
  }
  function $e(t) {
    (Be = { name: t.type, persisted: t.persisted ? 1 : 0 }), _r(26, d(t)), bu();
  }
  function tn() {
    Be = null;
  }
  function en(t) {
    if ((void 0 === t && (t = null), "visibilityState" in document)) {
      var e = "visible" === document.visibilityState ? 1 : 0;
      (Je = { visible: e }), _r(28, d(t));
    }
  }
  function nn() {
    Je = null;
  }
  function an() {
    Ge = null;
  }
  function rn(t) {
    (Ge = { focused: t }), _r(50);
  }
  function on(t) {
    !(function (t) {
      var e = Ka(t);
      Do(e ? e.contentWindow : t === document ? window : t, "scroll", je, !0);
    })(t),
      t.nodeType === Node.DOCUMENT_NODE &&
        ((function (t) {
          Do(t, "click", ne.bind(this, 9, t), !0),
            Do(t, "contextmenu", ne.bind(this, 48, t), !0);
        })(t),
        (function (t) {
          Do(t, "cut", ue.bind(this, 0), !0),
            Do(t, "copy", ue.bind(this, 1), !0),
            Do(t, "paste", ue.bind(this, 2), !0);
        })(t),
        (function (t) {
          Do(t, "mousedown", we.bind(this, 13, t), !0),
            Do(t, "mouseup", we.bind(this, 14, t), !0),
            Do(t, "mousemove", we.bind(this, 12, t), !0),
            Do(t, "wheel", we.bind(this, 15, t), !0),
            Do(t, "dblclick", we.bind(this, 16, t), !0),
            Do(t, "touchstart", Se.bind(this, 17, t), !0),
            Do(t, "touchend", Se.bind(this, 18, t), !0),
            Do(t, "touchmove", Se.bind(this, 19, t), !0),
            Do(t, "touchcancel", Se.bind(this, 20, t), !0);
        })(t),
        (function (t) {
          Do(t, "input", de, !0);
        })(t),
        (function (t) {
          Do(t, "selectstart", Ue.bind(this, t), !0),
            Do(t, "selectionchange", Ue.bind(this, t), !0);
        })(t),
        (function (t) {
          Do(t, "change", Zt, !0);
        })(t),
        (function (t) {
          Do(t, "submit", Ze, !0);
        })(t));
  }
  var un = Object.freeze({
    __proto__: null,
    observe: on,
    start: function () {
      (Nr = []),
        xr(),
        ie(),
        ce(),
        Ee(),
        he(),
        (Ne = !1),
        Do(window, "resize", Me),
        xe(),
        Do(document, "visibilitychange", en),
        en(),
        Do(window, "focus", function () {
          return rn(1);
        }),
        Do(window, "blur", function () {
          return rn(0);
        }),
        (De = []),
        Ye(),
        Ve(),
        Qt(),
        Qe(),
        Do(window, "pagehide", $e);
    },
    stop: function () {
      (Nr = []),
        xr(),
        ie(),
        ce(),
        et(ge),
        ve.length > 0 && Oe(ve[ve.length - 1].event),
        et(se),
        he(),
        Ce(),
        nn(),
        an(),
        et(Ae),
        je.cleanup(),
        (De = []),
        (Pe = null),
        (Re = null),
        Ve(),
        et(qe),
        Qt(),
        Qe(),
        tn();
    },
  });
  function cn(t) {
    for (var e = [], n = {}, a = 0, r = null, i = 0; i < t.length; i++)
      if ("string" == typeof t[i]) {
        var o = t[i],
          u = n[o] || -1;
        u >= 0
          ? r
            ? r.push(u)
            : ((r = [u]), e.push(r), a++)
          : ((r = null), e.push(o), (n[o] = a++));
      } else (r = null), e.push(t[i]), a++;
    return e;
  }
  var sn = [],
    ln = [],
    dn = "claritySheetId",
    fn = {},
    hn = {},
    pn = [],
    vn = [];
  function gn(t) {
    (u.lean && u.lite) ||
      null == t ||
      ((t.clarityOverrides = t.clarityOverrides || {}),
      t.CSSStyleSheet &&
        t.CSSStyleSheet.prototype &&
        (void 0 === t.clarityOverrides.replace &&
          ((t.clarityOverrides.replace = t.CSSStyleSheet.prototype.replace),
          (t.CSSStyleSheet.prototype.replace = function () {
            return (
              Jo() &&
                vn.indexOf(this[dn]) > -1 &&
                wn(d(), this[dn], 1, arguments[0]),
              t.clarityOverrides.replace.apply(this, arguments)
            );
          })),
        void 0 === t.clarityOverrides.replaceSync &&
          ((t.clarityOverrides.replaceSync =
            t.CSSStyleSheet.prototype.replaceSync),
          (t.CSSStyleSheet.prototype.replaceSync = function () {
            return (
              Jo() &&
                vn.indexOf(this[dn]) > -1 &&
                wn(d(), this[dn], 2, arguments[0]),
              t.clarityOverrides.replaceSync.apply(this, arguments)
            );
          }))));
  }
  function mn() {
    gn(window);
  }
  function yn(t, e) {
    if (
      (!u.lean || !u.lite) &&
      (-1 === pn.indexOf(t) && (pn.push(t), t.defaultView && gn(t.defaultView)),
      (e = e || d()),
      null == t ? void 0 : t.adoptedStyleSheets)
    ) {
      for (var n = [], a = 0, r = t.adoptedStyleSheets; a < r.length; a++) {
        var i = r[a];
        (i[dn] && -1 !== vn.indexOf(i[dn])) ||
          ((i[dn] = mo()),
          vn.push(i[dn]),
          wn(e, i[dn], 0),
          wn(e, i[dn], 2, Sa(i))),
          n.push(i[dn]);
      }
      var o = Va(t, !0);
      fn[o] || (fn[o] = []),
        (function (t, e) {
          if (t.length !== e.length) return !1;
          return t.every(function (t, n) {
            return t === e[n];
          });
        })(n, fn[o]) ||
          (!(function (t, e, n, a) {
            ln.push({
              time: t,
              event: 45,
              data: { id: e, operation: n, newIds: a },
            }),
              Wn(45);
          })(e, t == document ? -1 : Va(t), 3, n),
          (fn[o] = n),
          (hn[o] = e));
    }
  }
  function bn() {
    (ln = []), (sn = []);
  }
  function wn(t, e, n, a) {
    sn.push({ time: t, event: 46, data: { id: e, operation: n, cssRules: a } }),
      Wn(46);
  }
  var Sn = [],
    kn = null,
    On = null,
    En = null,
    Tn = null,
    _n = null,
    Nn = null,
    Mn = "clarityAnimationId",
    xn = "clarityOperationCount",
    In = 20;
  function Cn() {
    Sn = [];
  }
  function Dn(t, e, n, a, r, i, o) {
    Sn.push({
      time: t,
      event: 44,
      data: {
        id: e,
        operation: n,
        keyFrames: a,
        timing: r,
        targetId: i,
        timeline: o,
      },
    }),
      Wn(44);
  }
  function Pn(t, e) {
    null === t &&
      ((t = Animation.prototype[e]),
      (Animation.prototype[e] = function () {
        return Rn(this, e), t.apply(this, arguments);
      }));
  }
  function Rn(t, e) {
    if (Jo()) {
      var n = t.effect,
        a = (null == n ? void 0 : n.target) ? Va(n.target) : null;
      if (null !== a && n.getKeyframes && n.getTiming) {
        if (!t[Mn]) {
          (t[Mn] = mo()), (t[xn] = 0);
          var r = n.getKeyframes(),
            i = n.getTiming();
          Dn(d(), t[Mn], 0, JSON.stringify(r), JSON.stringify(i), a);
        }
        if (t[xn]++ < In) {
          var o = null;
          switch (e) {
            case "play":
              o = 1;
              break;
            case "pause":
              o = 2;
              break;
            case "cancel":
              o = 3;
              break;
            case "finish":
              o = 4;
              break;
            case "commitStyles":
              o = 5;
          }
          o && Dn(d(), t[Mn], o);
        }
      }
    }
  }
  var An,
    Yn = [],
    jn = new Set();
  function Xn(t) {
    jn.has(t) || (jn.add(t), Yn.push(t), Si(Wn.bind(this, 51)));
  }
  function Ln() {
    Yn.length = 0;
  }
  function Wn(t, e, n) {
    return (
      void 0 === e && (e = null),
      void 0 === n && (n = null),
      ht(this, void 0, void 0, function () {
        var a,
          r,
          i,
          o,
          c,
          s,
          l,
          f,
          h,
          p,
          v,
          g,
          m,
          y,
          b,
          S,
          k,
          O,
          E,
          T,
          _,
          N,
          M,
          x,
          I,
          P,
          R,
          A,
          Y,
          j,
          X,
          L;
        return pt(this, function (W) {
          switch (W.label) {
            case 0:
              switch (((a = n || d()), (r = [a, t]), t)) {
                case 8:
                  return [3, 1];
                case 7:
                  return [3, 2];
                case 45:
                case 46:
                  return [3, 3];
                case 44:
                  return [3, 4];
                case 5:
                case 6:
                  return [3, 5];
                case 51:
                  return [3, 12];
              }
              return [3, 13];
            case 1:
              return (
                (i = An),
                r.push(i.width),
                r.push(i.height),
                C(t, i.width, i.height),
                ei(r),
                [3, 13]
              );
            case 2:
              for (o = 0, c = dr; o < c.length; o++)
                (s = c[o]),
                  (r = [s.time, 7]).push(s.data.id),
                  r.push(s.data.interaction),
                  r.push(s.data.visibility),
                  r.push(s.data.name),
                  ei(r, !1);
              return Or(), [3, 13];
            case 3:
              for (l = 0, f = ln; l < f.length; l++)
                (m = f[l]),
                  (r = [m.time, m.event]).push(m.data.id),
                  r.push(m.data.operation),
                  r.push(m.data.newIds),
                  ei(r);
              for (h = 0, p = sn; h < p.length; h++)
                (m = p[h]),
                  (r = [m.time, m.event]).push(m.data.id),
                  r.push(m.data.operation),
                  r.push(m.data.cssRules),
                  ei(r, !1);
              return bn(), [3, 13];
            case 4:
              for (v = 0, g = Sn; v < g.length; v++)
                (m = g[v]),
                  (r = [m.time, m.event]).push(m.data.id),
                  r.push(m.data.operation),
                  r.push(m.data.keyFrames),
                  r.push(m.data.timing),
                  r.push(m.data.timeline),
                  r.push(m.data.targetId),
                  ei(r);
              return Cn(), [3, 13];
            case 5:
              if (2 === Oi(e)) return [3, 13];
              if (!((y = ur()).length > 0)) return [3, 11];
              (b = 0), (S = y), (W.label = 6);
            case 6:
              return b < S.length
                ? ((k = S[b]), 0 !== (O = Oi(e)) ? [3, 8] : [4, _i(e)])
                : [3, 10];
            case 7:
              (O = W.sent()), (W.label = 8);
            case 8:
              if (2 === O) return [3, 10];
              for (
                E = k.data,
                  T = k.metadata.active,
                  _ = k.metadata.suspend,
                  N = k.metadata.privacy,
                  M = (function (t) {
                    var e = t.metadata.privacy;
                    return "*T" === t.data.tag && !(0 === e || 1 === e);
                  })(k),
                  x = 0,
                  I = T ? ["tag", "attributes", "value"] : ["tag"];
                x < I.length;
                x++
              )
                if (E[(P = I[x])] || "" === E[P])
                  switch (P) {
                    case "tag":
                      (R = zn(k)),
                        (A = M ? -1 : 1),
                        r.push(k.id * A),
                        k.parent &&
                          T &&
                          (r.push(k.parent), k.previous && r.push(k.previous)),
                        r.push(_ ? "*M" : E[P]),
                        R &&
                          2 === R.length &&
                          r.push(
                            ""
                              .concat("#")
                              .concat(Hn(R[0]), ".")
                              .concat(Hn(R[1]))
                          );
                      break;
                    case "attributes":
                      for (Y in E[P])
                        void 0 !== E[P][Y] && r.push(qn(Y, E[P][Y], N));
                      break;
                    case "value":
                      Gt(k.metadata.fraud, k.id, E[P]),
                        r.push(w(E[P], E.tag, N, M));
                  }
              W.label = 9;
            case 9:
              return b++, [3, 6];
            case 10:
              6 === t && D(a), ei(cn(r), !u.lean), (W.label = 11);
            case 11:
              return [3, 13];
            case 12:
              for (j = 0, X = Yn; j < X.length; j++) (L = X[j]), ei([a, 51, L]);
              return Ln(), [3, 13];
            case 13:
              return [2];
          }
        });
      })
    );
  }
  function zn(t) {
    if (null !== t.metadata.size && 0 === t.metadata.size.length) {
      var e = nr(t.id);
      if (e)
        return [
          Math.floor(100 * e.offsetWidth),
          Math.floor(100 * e.offsetHeight),
        ];
    }
    return t.metadata.size;
  }
  function Hn(t) {
    return t.toString(36);
  }
  function qn(t, e, n) {
    return ""
      .concat(t, "=")
      .concat(w(e, 0 === t.indexOf("data-") ? "data-" : t, n));
  }
  function Un() {
    An = null;
  }
  function Fn() {
    var t = document.body,
      e = document.documentElement,
      n = t ? t.clientWidth : null,
      a = t ? t.scrollWidth : null,
      r = t ? t.offsetWidth : null,
      i = e ? e.clientWidth : null,
      o = e ? e.scrollWidth : null,
      u = e ? e.offsetWidth : null,
      c = Math.max(n, a, r, i, o, u),
      s = t ? t.clientHeight : null,
      l = t ? t.scrollHeight : null,
      d = t ? t.offsetHeight : null,
      f = e ? e.clientHeight : null,
      h = e ? e.scrollHeight : null,
      p = e ? e.offsetHeight : null,
      v = Math.max(s, l, d, f, h, p);
    (null !== An && c === An.width && v === An.height) ||
      null === c ||
      null === v ||
      ((An = { width: c, height: v }), Wn(8));
  }
  function Vn(t, e, n, a) {
    return ht(this, void 0, void 0, function () {
      var r, i, o, u, c;
      return pt(this, function (s) {
        switch (s.label) {
          case 0:
            (r = [t]), (s.label = 1);
          case 1:
            if (!(r.length > 0)) return [3, 4];
            for (i = r.shift(), o = i.firstChild; o; )
              r.push(o), (o = o.nextSibling);
            return 0 !== (u = Oi(e)) ? [3, 3] : [4, _i(e)];
          case 2:
            (u = s.sent()), (s.label = 3);
          case 3:
            return 2 === u ? [3, 4] : ((c = ma(i, n, a)) && r.push(c), [3, 1]);
          case 4:
            return [2];
        }
      });
    });
  }
  var Bn = new Set(),
    Jn = [],
    Gn = {},
    Kn = [],
    Zn = null,
    Qn = null,
    $n = null,
    ta = {},
    ea = new WeakMap(),
    na = [
      "data-google-query-id",
      "data-load-complete",
      "data-google-container-id",
    ];
  function aa() {
    (Bn = new Set()),
      (Kn = []),
      (Zn = null),
      ($n = 0),
      (ta = {}),
      (ea = new WeakMap()),
      da(window);
  }
  function ra(t) {
    var e = d();
    st(6, e),
      Jn.push({ time: e, mutations: t }),
      Si(oa, 1).then(function () {
        tt(Fn), Io(br)();
      });
  }
  function ia(t, e, n, a) {
    return ht(this, void 0, void 0, function () {
      var r, i, o;
      return pt(this, function (c) {
        switch (c.label) {
          case 0:
            return 0 !== (r = Oi(t)) ? [3, 2] : [4, _i(t)];
          case 1:
            (r = c.sent()), (c.label = 2);
          case 2:
            if (2 === r) return [2];
            switch (
              ((i = e.target),
              (o = u.throttleDom
                ? (function (t, e, n, a) {
                    var r = t.target ? rr(t.target.parentNode) : null;
                    if (r && "HTML" !== r.data.tag) {
                      var i = a > $n,
                        o = rr(t.target),
                        u =
                          o && o.selector
                            ? o.selector.join()
                            : t.target.nodeName,
                        c = [
                          r.selector ? r.selector.join() : "",
                          u,
                          t.attributeName,
                          ua(t.addedNodes),
                          ua(t.removedNodes),
                        ].join();
                      ta[c] = c in ta ? ta[c] : [0, n];
                      var s = ta[c];
                      if (
                        (!1 === i && s[0] >= 10 && ca(s[2], 2, e, a),
                        (s[0] = i ? (s[1] === n ? s[0] : s[0] + 1) : 1),
                        (s[1] = n),
                        s[0] >= 10)
                      )
                        return (
                          (s[2] = t.removedNodes),
                          n > a + 3e3
                            ? t.type
                            : ((Gn[c] = { mutation: t, timestamp: a }),
                              "throttle")
                        );
                    }
                    return t.type;
                  })(e, t, n, a)
                : e.type),
              o && i && i.ownerDocument && Fa(i.ownerDocument),
              o &&
                i &&
                i.nodeType == Node.DOCUMENT_FRAGMENT_NODE &&
                i.host &&
                Fa(i),
              o)
            ) {
              case "attributes":
                na.indexOf(e.attributeName) < 0 && ma(i, 3, a);
                break;
              case "characterData":
                ma(i, 4, a);
                break;
              case "childList":
                ca(e.addedNodes, 1, t, a), ca(e.removedNodes, 2, t, a);
            }
            return [2];
        }
      });
    });
  }
  function oa() {
    return ht(this, void 0, void 0, function () {
      var t, e, n, a, r, i, o, u, c, s, l;
      return pt(this, function (f) {
        switch (f.label) {
          case 0:
            Ei((t = { id: oo(), cost: 3 })), (f.label = 1);
          case 1:
            if (!(Jn.length > 0)) return [3, 7];
            (e = Jn.shift()),
              (n = d()),
              (a = 0),
              (r = e.mutations),
              (f.label = 2);
          case 2:
            return a < r.length
              ? ((i = r[a]), [4, ia(t, i, n, e.time)])
              : [3, 5];
          case 3:
            f.sent(), (f.label = 4);
          case 4:
            return a++, [3, 2];
          case 5:
            return [4, Wn(6, t, e.time)];
          case 6:
            return f.sent(), [3, 1];
          case 7:
            (o = !1), (u = 0), (c = Object.keys(Gn)), (f.label = 8);
          case 8:
            return u < c.length
              ? ((s = c[u]),
                (l = Gn[s]),
                delete Gn[s],
                [4, ia(t, l.mutation, d(), l.timestamp)])
              : [3, 11];
          case 9:
            f.sent(), (o = !0), (f.label = 10);
          case 10:
            return u++, [3, 8];
          case 11:
            return (
              Object.keys(Gn).length > 0 &&
                (function () {
                  Qn && et(Qn);
                  Qn = tt(function () {
                    Si(oa, 1);
                  }, 33);
                })(),
              0 === Object.keys(Gn).length && o ? [4, Wn(6, t, d())] : [3, 13]
            );
          case 12:
            f.sent(), (f.label = 13);
          case 13:
            return (
              (function () {
                var t = d();
                Object.keys(ta).length > 1e4 && ((ta = {}), Z(38));
                for (var e = 0, n = Object.keys(ta); e < n.length; e++) {
                  var a = n[e];
                  t > ta[a][1] + 3e4 && delete ta[a];
                }
              })(),
              Ti(t),
              [2]
            );
        }
      });
    });
  }
  function ua(t) {
    for (var e = [], n = 0; t && n < t.length; n++) e.push(t[n].nodeName);
    return e.join();
  }
  function ca(t, e, n, a) {
    return ht(this, void 0, void 0, function () {
      var r, i, o, u;
      return pt(this, function (c) {
        switch (c.label) {
          case 0:
            (r = t ? t.length : 0), (i = 0), (c.label = 1);
          case 1:
            return i < r
              ? ((o = t[i]), 1 !== e ? [3, 2] : (Vn(o, n, e, a), [3, 5]))
              : [3, 6];
          case 2:
            return 0 !== (u = Oi(n)) ? [3, 4] : [4, _i(n)];
          case 3:
            (u = c.sent()), (c.label = 4);
          case 4:
            if (2 === u) return [3, 6];
            ma(o, e, a), (c.label = 5);
          case 5:
            return i++, [3, 1];
          case 6:
            return [2];
        }
      });
    });
  }
  function sa(t) {
    return (
      Kn.indexOf(t) < 0 && Kn.push(t),
      Zn && et(Zn),
      (Zn = tt(function () {
        !(function () {
          for (var t = 0, e = Kn; t < e.length; t++) {
            var n = e[t];
            if (n) {
              var a = n.nodeType === Node.DOCUMENT_FRAGMENT_NODE;
              if (a && or(n)) continue;
              la(n, a ? "childList" : "characterData");
            }
          }
          Kn = [];
        })();
      }, 33)),
      t
    );
  }
  function la(t, e) {
    Io(ra)([
      {
        addedNodes: [t],
        attributeName: null,
        attributeNamespace: null,
        nextSibling: null,
        oldValue: null,
        previousSibling: null,
        removedNodes: [],
        target: t,
        type: e,
      },
    ]);
  }
  function da(t) {
    if (
      null != t &&
      ((t.clarityOverrides = t.clarityOverrides || {}),
      void 0 === t.clarityOverrides.InsertRule &&
        ((t.clarityOverrides.InsertRule = t.CSSStyleSheet.prototype.insertRule),
        (t.CSSStyleSheet.prototype.insertRule = function () {
          return (
            Jo() && sa(this.ownerNode),
            t.clarityOverrides.InsertRule.apply(this, arguments)
          );
        })),
      "CSSMediaRule" in t &&
        void 0 === t.clarityOverrides.MediaInsertRule &&
        ((t.clarityOverrides.MediaInsertRule =
          t.CSSMediaRule.prototype.insertRule),
        (t.CSSMediaRule.prototype.insertRule = function () {
          return (
            Jo() && sa(this.parentStyleSheet.ownerNode),
            t.clarityOverrides.MediaInsertRule.apply(this, arguments)
          );
        })),
      void 0 === t.clarityOverrides.DeleteRule &&
        ((t.clarityOverrides.DeleteRule = t.CSSStyleSheet.prototype.deleteRule),
        (t.CSSStyleSheet.prototype.deleteRule = function () {
          return (
            Jo() && sa(this.ownerNode),
            t.clarityOverrides.DeleteRule.apply(this, arguments)
          );
        })),
      "CSSMediaRule" in t &&
        void 0 === t.clarityOverrides.MediaDeleteRule &&
        ((t.clarityOverrides.MediaDeleteRule =
          t.CSSMediaRule.prototype.deleteRule),
        (t.CSSMediaRule.prototype.deleteRule = function () {
          return (
            Jo() && sa(this.parentStyleSheet.ownerNode),
            t.clarityOverrides.MediaDeleteRule.apply(this, arguments)
          );
        })),
      void 0 === t.clarityOverrides.AttachShadow)
    ) {
      t.clarityOverrides.AttachShadow = t.Element.prototype.attachShadow;
      try {
        t.Element.prototype.attachShadow = function () {
          return Jo()
            ? sa(t.clarityOverrides.AttachShadow.apply(this, arguments))
            : t.clarityOverrides.AttachShadow.apply(this, arguments);
        };
      } catch (e) {
        t.clarityOverrides.AttachShadow = null;
      }
    }
  }
  var fa = /[^0-9\.]/g;
  function ha(t) {
    for (var e = 0, n = Object.keys(t); e < n.length; e++) {
      var a = n[e],
        r = t[a];
      if ("@type" === a && "string" == typeof r)
        switch (
          (r =
            (r = r.toLowerCase()).indexOf("article") >= 0 ||
            r.indexOf("posting") >= 0
              ? "article"
              : r)
        ) {
          case "article":
          case "recipe":
            Ji(5, t[a]), Ji(8, t.creator), Ji(18, t.headline);
            break;
          case "product":
            Ji(5, t[a]),
              Ji(10, t.name),
              Ji(12, t.sku),
              t.brand && Ji(6, t.brand.name);
            break;
          case "aggregaterating":
            t.ratingValue &&
              ($(11, pa(t.ratingValue, 100)),
              $(18, pa(t.bestRating)),
              $(19, pa(t.worstRating))),
              $(12, pa(t.ratingCount)),
              $(17, pa(t.reviewCount));
            break;
          case "offer":
            Ji(7, t.availability),
              Ji(14, t.itemCondition),
              Ji(13, t.priceCurrency),
              Ji(12, t.sku),
              $(13, pa(t.price));
            break;
          case "brand":
            Ji(6, t.name);
        }
      null !== r && "object" == typeof r && ha(r);
    }
  }
  function pa(t, e) {
    if ((void 0 === e && (e = 1), null !== t))
      switch (typeof t) {
        case "number":
          return Math.round(t * e);
        case "string":
          return Math.round(parseFloat(t.replace(fa, "")) * e);
      }
    return null;
  }
  var va = [
      "title",
      "alt",
      "onload",
      "onfocus",
      "onerror",
      "data-drupal-form-submit-last",
      "aria-label",
    ],
    ga = /[\r\n]+/g;
  function ma(e, n, a) {
    var r,
      i = null;
    if (2 === n && !1 === or(e)) return i;
    0 !== n &&
      e.nodeType === Node.TEXT_NODE &&
      e.parentElement &&
      "STYLE" === e.parentElement.tagName &&
      (e = e.parentNode);
    var o = !1 === or(e) ? "add" : "update",
      u = e.parentElement ? e.parentElement : null,
      c = e.ownerDocument !== document;
    switch (e.nodeType) {
      case Node.DOCUMENT_TYPE_NODE:
        u = c && e.parentNode ? Ka(e.parentNode) : u;
        var s = e,
          l = {
            tag: (c ? "iframe:" : "") + "*D",
            attributes: {
              name: s.name ? s.name : "HTML",
              publicId: s.publicId,
              systemId: s.systemId,
            },
          };
        t[o](e, u, l, n);
        break;
      case Node.DOCUMENT_NODE:
        e === document && Fa(document), yn(e, a), ya(e);
        break;
      case Node.DOCUMENT_FRAGMENT_NODE:
        var d = e;
        if (d.host) {
          if (
            (Fa(d),
            "function" === typeof d.constructor &&
              d.constructor.toString().indexOf("[native code]") >= 0)
          ) {
            ya(d);
            var f = { tag: "*S", attributes: { style: "" } };
            t[o](e, d.host, f, n);
          } else t[o](e, d.host, { tag: "*P", attributes: {} }, n);
          yn(e, a);
        }
        break;
      case Node.TEXT_NODE:
        if (
          ((u = u || e.parentNode),
          "update" === o ||
            (u && or(u) && "STYLE" !== u.tagName && "NOSCRIPT" !== u.tagName))
        ) {
          var h = { tag: "*T", value: e.nodeValue };
          t[o](e, u, h, n);
        }
        break;
      case Node.ELEMENT_NODE:
        var p = e,
          v = p.tagName,
          g = (function (t) {
            var e = {},
              n = t.attributes;
            if (n && n.length > 0)
              for (var a = 0; a < n.length; a++) {
                var r = n[a].name;
                va.indexOf(r) < 0 && (e[r] = n[a].value);
              }
            "INPUT" === t.tagName &&
              !("value" in e) &&
              t.value &&
              (e.value = t.value);
            return e;
          })(p);
        switch (
          ((u = e.parentElement
            ? e.parentElement
            : e.parentNode
            ? e.parentNode
            : null),
          "http://www.w3.org/2000/svg" === p.namespaceURI && (v = "svg:" + v),
          v)
        ) {
          case "HTML":
            u = c && u ? Ka(u) : u;
            var m = { tag: (c ? "iframe:" : "") + v, attributes: g };
            t[o](e, u, m, n);
            break;
          case "SCRIPT":
            if ("type" in g && "application/ld+json" === g.type)
              try {
                ha(JSON.parse(p.text.replace(ga, "")));
              } catch (t) {}
            break;
          case "NOSCRIPT":
            var y = { tag: v, attributes: {}, value: "" };
            t[o](e, u, y, n);
            break;
          case "META":
            var b = "property" in g ? "property" : "name" in g ? "name" : null;
            if (b && "content" in g) {
              var w = g.content;
              switch (g[b]) {
                case "og:title":
                  Ji(20, w);
                  break;
                case "og:type":
                  Ji(19, w);
                  break;
                case "generator":
                  Ji(21, w);
              }
            }
            break;
          case "HEAD":
            var S = { tag: v, attributes: g },
              k =
                c &&
                (null === (r = e.ownerDocument) || void 0 === r
                  ? void 0
                  : r.location)
                  ? e.ownerDocument.location
                  : location;
            (S.attributes["*B"] = k.protocol + "//" + k.host + k.pathname),
              t[o](e, u, S, n);
            break;
          case "BASE":
            var O = rr(e.parentElement);
            if (O) {
              var E = document.createElement("a");
              (E.href = g.href),
                (O.data.attributes["*B"] =
                  E.protocol + "//" + E.host + E.pathname);
            }
            break;
          case "STYLE":
            var T = { tag: v, attributes: g, value: wa(p) };
            t[o](e, u, T, n);
            break;
          case "IFRAME":
            var _ = e,
              N = { tag: v, attributes: g };
            Ga(_) &&
              (!(function (t) {
                !1 === or(t) &&
                  Do(t, "load", la.bind(this, t, "childList"), !0);
              })(_),
              (N.attributes["*O"] = "true"),
              _.contentDocument &&
                _.contentWindow &&
                "loading" !== _.contentDocument.readyState &&
                (i = _.contentDocument)),
              2 === n && ba(_),
              t[o](e, u, N, n);
            break;
          case "LINK":
            if ($i && "stylesheet" === g.rel) {
              for (var M in Object.keys(document.styleSheets)) {
                var x = document.styleSheets[M];
                if (x.ownerNode == p) {
                  var I = { tag: "STYLE", attributes: g, value: Sa(x) };
                  t[o](e, u, I, n);
                  break;
                }
              }
              break;
            }
            var C = { tag: v, attributes: g };
            t[o](e, u, C, n);
            break;
          case "VIDEO":
          case "AUDIO":
          case "SOURCE":
            "src" in g && g.src.startsWith("data:") && (g.src = "");
            var D = { tag: v, attributes: g };
            t[o](e, u, D, n);
            break;
          default:
            !(function (t) {
              var e;
              (null === (e = window.customElements) || void 0 === e
                ? void 0
                : e.get) &&
                window.customElements.get(t) &&
                Xn(t);
            })(p.localName);
            var P = { tag: v, attributes: g };
            p.shadowRoot && (i = p.shadowRoot), t[o](e, u, P, n);
        }
    }
    return i;
  }
  function ya(t) {
    or(t) ||
      Ao(t) ||
      (!(function (t) {
        try {
          var e = c("MutationObserver"),
            n = e in window ? new window[e](Io(ra)) : null;
          n &&
            (n.observe(t, {
              attributes: !0,
              childList: !0,
              characterData: !0,
              subtree: !0,
            }),
            ea.set(t, n),
            Bn.add(n)),
            t.defaultView && da(t.defaultView);
        } catch (t) {
          hi(2, 0, t ? t.name : null);
        }
      })(t),
      on(t));
  }
  function ba(t) {
    Ro(t);
    var e,
      n,
      a = Za(t) || {},
      r = a.doc,
      i = void 0 === r ? null : r,
      o = a.win,
      u = void 0 === o ? null : o;
    u && Ro(u),
      i &&
        (Ro(i),
        (e = i),
        (n = ea.get(e)) && (n.disconnect(), Bn.delete(n), ea.delete(e)),
        Qa(t, i));
  }
  function wa(t) {
    var e = t.textContent ? t.textContent.trim() : "",
      n = t.dataset ? Object.keys(t.dataset).length : 0;
    return (0 === e.length || n > 0 || t.id.length > 0) && (e = Sa(t.sheet)), e;
  }
  function Sa(t) {
    var e = "",
      n = null;
    try {
      n = t ? t.cssRules : [];
    } catch (t) {
      if ((hi(1, 1, t ? t.name : null), t && "SecurityError" !== t.name))
        throw t;
    }
    if (null !== n) for (var a = 0; a < n.length; a++) e += n[a].cssText;
    return e;
  }
  var ka = "load,active,fixed,visible,focus,show,collaps,animat".split(","),
    Oa = {};
  function Ea(t, e) {
    var n = t.attributes,
      a = t.prefix ? t.prefix[e] : null,
      r =
        0 === e
          ? "".concat("~").concat(t.position - 1)
          : ":nth-of-type(".concat(t.position, ")");
    switch (t.tag) {
      case "STYLE":
      case "TITLE":
      case "LINK":
      case "META":
      case "*T":
      case "*D":
        return "";
      case "HTML":
        return "HTML";
      default:
        if (null === a) return "";
        (a = "".concat(a).concat(">")),
          (t.tag =
            0 === t.tag.indexOf("svg:") ? t.tag.substr("svg:".length) : t.tag);
        var i = "".concat(a).concat(t.tag).concat(r),
          o = "id" in n && n.id.length > 0 ? n.id : null,
          u =
            "BODY" !== t.tag && "class" in n && n.class.length > 0
              ? n.class
                  .trim()
                  .split(/\s+/)
                  .filter(function (t) {
                    return Ta(t);
                  })
                  .join(".")
              : null;
        if (u && u.length > 0)
          if (0 === e) {
            var c = ""
              .concat(
                (function (t) {
                  for (var e = t.split(">"), n = 0; n < e.length; n++) {
                    var a = e[n].indexOf("~"),
                      r = e[n].indexOf(".");
                    e[n] = e[n].substring(
                      0,
                      r > 0 ? r : a > 0 ? a : e[n].length
                    );
                  }
                  return e.join(">");
                })(a)
              )
              .concat(t.tag)
              .concat(".")
              .concat(u);
            c in Oa || (Oa[c] = []),
              Oa[c].indexOf(t.id) < 0 && Oa[c].push(t.id),
              (i = "".concat(c).concat("~").concat(Oa[c].indexOf(t.id)));
          } else i = "".concat(a).concat(t.tag, ".").concat(u).concat(r);
        return (
          (i =
            o && Ta(o)
              ? ""
                  .concat(
                    (function (t) {
                      var e = t.lastIndexOf("*S"),
                        n = t.lastIndexOf("".concat("iframe:").concat("HTML")),
                        a = Math.max(e, n);
                      if (a < 0) return "";
                      return t.substring(0, t.indexOf(">", a) + 1);
                    })(a)
                  )
                  .concat("#")
                  .concat(o)
              : i),
          i
        );
    }
  }
  function Ta(t) {
    if (!t) return !1;
    if (
      ka.some(function (e) {
        return t.toLowerCase().indexOf(e) >= 0;
      })
    )
      return !1;
    for (var e = 0; e < t.length; e++) {
      var n = t.charCodeAt(e);
      if (n >= 48 && n <= 57) return !1;
    }
    return !0;
  }
  var _a = 1,
    Na = null,
    Ma = [],
    xa = [],
    Ia = {},
    Ca = [],
    Da = [],
    Pa = [],
    Ra = [],
    Aa = [],
    Ya = [],
    ja = null,
    Xa = null,
    La = null,
    Wa = null,
    za = null;
  function Ha() {
    Ua(), Fa(document, !0);
  }
  function qa() {
    Ua();
  }
  function Ua() {
    (_a = 1),
      (Ma = []),
      (xa = []),
      (Ia = {}),
      (Ca = []),
      (Da = []),
      (Pa = "address,password,contact".split(",")),
      (Ra = "password,secret,pass,social,ssn,code,hidden".split(",")),
      (Aa = "radio,checkbox,range,button,reset,submit".split(",")),
      (Ya = "INPUT,SELECT,TEXTAREA".split(",")),
      (Na = new Map()),
      (ja = new WeakMap()),
      (Xa = new WeakMap()),
      (La = new WeakMap()),
      (Wa = new WeakMap()),
      (za = new WeakMap()),
      (Oa = {});
  }
  function Fa(t, e) {
    void 0 === e && (e = !1);
    try {
      e &&
        u.unmask.forEach(function (t) {
          return t.indexOf("!") < 0 ? Da.push(t) : Ca.push(t.substr(1));
        }),
        "querySelectorAll" in t &&
          (u.regions.forEach(function (e) {
            return t.querySelectorAll(e[1]).forEach(function (t) {
              return mr(t, "".concat(e[0]));
            });
          }),
          u.mask.forEach(function (e) {
            return t.querySelectorAll(e).forEach(function (t) {
              return Wa.set(t, 3);
            });
          }),
          u.checksum.forEach(function (e) {
            return t.querySelectorAll(e[1]).forEach(function (t) {
              return za.set(t, e[0]);
            });
          }),
          Da.forEach(function (e) {
            return t.querySelectorAll(e).forEach(function (t) {
              return Wa.set(t, 0);
            });
          }));
    } catch (t) {
      hi(5, 1, t ? t.name : null);
    }
  }
  function Va(t, e) {
    if ((void 0 === e && (e = !1), null === t)) return null;
    var n = ja.get(t);
    return !n && e && ((n = _a++), ja.set(t, n)), n || null;
  }
  function Ba(t, e, n, a) {
    var r = e ? Va(e) : null;
    if ((e && r) || null != t.host || t.nodeType === Node.DOCUMENT_TYPE_NODE) {
      var i = Va(t, !0),
        o = sr(t),
        c = null,
        s = yr(t) ? i : null,
        l = za.has(t) ? za.get(t) : null,
        d = u.content ? 1 : 3;
      r >= 0 &&
        Ma[r] &&
        ((c = Ma[r]).children.push(i),
        (s = null === s ? c.region : s),
        (l = null === l ? c.metadata.fraud : l),
        (d = c.metadata.privacy)),
        n.attributes &&
          "data-clarity-region" in n.attributes &&
          (mr(t, n.attributes["data-clarity-region"]), (s = i)),
        Na.set(i, t),
        (Ma[i] = {
          id: i,
          parent: r,
          previous: o,
          children: [],
          data: n,
          selector: null,
          hash: null,
          region: s,
          metadata: {
            active: !0,
            suspend: !1,
            privacy: d,
            position: null,
            fraud: l,
            size: null,
          },
        }),
        (function (t, e, n) {
          var a,
            r = e.data,
            i = e.metadata,
            o = i.privacy,
            u = r.attributes || {},
            c = r.tag.toUpperCase();
          switch (!0) {
            case Ya.indexOf(c) >= 0:
              var s = u.type,
                l = "",
                d = ["class", "style"];
              Object.keys(u)
                .filter(function (t) {
                  return !d.includes(t);
                })
                .forEach(function (t) {
                  return (l += u[t].toLowerCase());
                });
              var f = Ra.some(function (t) {
                return l.indexOf(t) >= 0;
              });
              i.privacy = "INPUT" === c && Aa.indexOf(s) >= 0 ? o : f ? 4 : 2;
              break;
            case "data-clarity-mask" in u:
              i.privacy = 3;
              break;
            case "data-clarity-unmask" in u:
              i.privacy = 0;
              break;
            case Wa.has(t):
              i.privacy = Wa.get(t);
              break;
            case za.has(t):
              i.privacy = 2;
              break;
            case "*T" === c:
              var h = n && n.data ? n.data.tag : "",
                p = n && n.selector ? n.selector[1] : "",
                v = ["STYLE", "TITLE", "svg:style"];
              i.privacy =
                v.includes(h) ||
                Ca.some(function (t) {
                  return p.indexOf(t) >= 0;
                })
                  ? 0
                  : o;
              break;
            case 1 === o:
              i.privacy = (function (t, e, n) {
                if (
                  t &&
                  e.some(function (e) {
                    return t.indexOf(e) >= 0;
                  })
                )
                  return 2;
                return n.privacy;
              })(u.class, Pa, i);
              break;
            case "IMG" === c:
              (null === (a = u.src) || void 0 === a
                ? void 0
                : a.startsWith("blob:")) && (i.privacy = 3);
          }
        })(t, Ma[i], c),
        tr(Ma[i]),
        (function (t) {
          if ("IMG" === t.data.tag && 3 === t.metadata.privacy) {
            var e = nr(t.id);
            !e ||
              (e.complete && 0 !== e.naturalWidth) ||
              Do(e, "load", function () {
                e.setAttribute("data-clarity-loaded", "".concat(mo()));
              }),
              (t.metadata.size = []);
          }
        })(Ma[i]),
        lr(i, a);
    }
  }
  function Ja(t, e, n, a) {
    var r = Va(t),
      i = e ? Va(e) : null,
      o = sr(t),
      u = !1,
      c = !1;
    if (r in Ma) {
      var s = Ma[r];
      if (
        ((s.metadata.active = !0),
        s.previous !== o && ((u = !0), (s.previous = o)),
        s.parent !== i)
      ) {
        u = !0;
        var l = s.parent;
        if (((s.parent = i), null !== i && i >= 0)) {
          var d = null === o ? 0 : Ma[i].children.indexOf(o) + 1;
          Ma[i].children.splice(d, 0, r), (s.region = yr(t) ? r : Ma[i].region);
        } else
          !(function (t, e) {
            if (t in Ma) {
              var n = Ma[t];
              (n.metadata.active = !1), (n.parent = null), lr(t, e), cr(t);
            }
          })(r, a);
        if (null !== l && l >= 0) {
          var f = Ma[l].children.indexOf(r);
          f >= 0 && Ma[l].children.splice(f, 1);
        }
        c = !0;
      }
      for (var h in n) $a(s.data, n, h) && ((u = !0), (s.data[h] = n[h]));
      tr(s), lr(r, a, u, c);
    }
  }
  function Ga(t) {
    var e = !1;
    if (t.nodeType === Node.ELEMENT_NODE && "IFRAME" === t.tagName) {
      var n = t;
      try {
        n.contentDocument &&
          (Xa.set(n.contentDocument, n),
          La.set(n, { doc: n.contentDocument, win: n.contentWindow }),
          (e = !0));
      } catch (t) {}
    }
    return e;
  }
  function Ka(t) {
    var e = t.nodeType === Node.DOCUMENT_NODE ? t : null;
    return e && Xa.has(e) ? Xa.get(e) : null;
  }
  function Za(t) {
    return La.has(t) ? La.get(t) : null;
  }
  function Qa(t, e) {
    La.delete(t), Xa.delete(e);
  }
  function $a(t, e, n) {
    if ("object" == typeof t[n] && "object" == typeof e[n]) {
      for (var a in t[n]) if (t[n][a] !== e[n][a]) return !0;
      for (var a in e[n]) if (e[n][a] !== t[n][a]) return !0;
      return !1;
    }
    return t[n] !== e[n];
  }
  function tr(t) {
    var e = t.parent && t.parent in Ma ? Ma[t.parent] : null,
      n = e ? e.selector : null,
      a = t.data,
      r = (function (t, e) {
        e.metadata.position = 1;
        for (var n = t ? t.children.indexOf(e.id) : -1; n-- > 0; ) {
          var a = Ma[t.children[n]];
          if (e.data.tag === a.data.tag) {
            e.metadata.position = a.metadata.position + 1;
            break;
          }
        }
        return e.metadata.position;
      })(e, t),
      i = {
        id: t.id,
        tag: a.tag,
        prefix: n,
        position: r,
        attributes: a.attributes,
      };
    (t.selector = [Ea(i, 0), Ea(i, 1)]),
      (t.hash = t.selector.map(function (t) {
        return t ? h(t) : null;
      })),
      t.hash.forEach(function (e) {
        return (Ia[e] = t.id);
      });
  }
  function er(t) {
    var e = nr(ir(t));
    return null !== e && null !== e.textContent
      ? e.textContent.substr(0, 25)
      : "";
  }
  function nr(t) {
    return Na.has(t) ? Na.get(t) : null;
  }
  function ar(t) {
    return t in Ma ? Ma[t] : null;
  }
  function rr(t) {
    var e = Va(t);
    return e in Ma ? Ma[e] : null;
  }
  function ir(t) {
    return t in Ia ? Ia[t] : null;
  }
  function or(t) {
    return Na.has(Va(t));
  }
  function ur() {
    for (var t = [], e = 0, n = xa; e < n.length; e++) {
      var a = n[e];
      a in Ma && t.push(Ma[a]);
    }
    return (xa = []), t;
  }
  function cr(t) {
    var e = Na.get(t);
    if ((null == e ? void 0 : e.nodeType) !== Node.DOCUMENT_FRAGMENT_NODE) {
      if (
        e &&
        (null == e ? void 0 : e.nodeType) === Node.ELEMENT_NODE &&
        "IFRAME" === e.tagName
      )
        ba(e);
      Na.delete(t);
      var n = t in Ma ? Ma[t] : null;
      if (n && n.children)
        for (var a = 0, r = n.children; a < r.length; a++) {
          cr(r[a]);
        }
    }
  }
  function sr(t) {
    for (var e = null; null === e && t.previousSibling; )
      (e = Va(t.previousSibling)), (t = t.previousSibling);
    return e;
  }
  function lr(t, e, n, a) {
    if (
      (void 0 === n && (n = !0), void 0 === a && (a = !1), !u.lean || !u.lite)
    ) {
      var r = xa.indexOf(t);
      r >= 0 && 1 === e && a
        ? (xa.splice(r, 1), xa.push(t))
        : -1 === r && n && xa.push(t);
    }
  }
  var dr = [],
    fr = null,
    hr = {},
    pr = [],
    vr = !1,
    gr = null;
  function mr(t, e) {
    !1 === fr.has(t) &&
      (fr.set(t, e),
      (gr =
        null === gr && vr
          ? new IntersectionObserver(wr, {
              threshold: [
                0, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1,
              ],
            })
          : gr) &&
        t &&
        t.nodeType === Node.ELEMENT_NODE &&
        gr.observe(t));
  }
  function yr(t) {
    return fr && fr.has(t);
  }
  function br() {
    for (var t = [], e = 0, n = pr; e < n.length; e++) {
      var a = n[e],
        r = Va(a.node);
      r
        ? ((a.state.data.id = r), (hr[r] = a.state.data), dr.push(a.state))
        : t.push(a);
    }
    (pr = t), dr.length > 0 && Wn(7);
  }
  function wr(t) {
    for (var e = 0, n = t; e < n.length; e++) {
      var a = n[e],
        r = a.target,
        i = a.boundingClientRect,
        o = a.intersectionRect,
        u = a.rootBounds;
      if (
        fr.has(r) &&
        i.width + i.height > 0 &&
        u &&
        u.width > 0 &&
        u.height > 0
      ) {
        var c = r ? Va(r) : null,
          s =
            c in hr
              ? hr[c]
              : { id: c, name: fr.get(r), interaction: 16, visibility: 0 },
          l =
            (o ? (o.width * o.height * 1) / (u.width * u.height) : 0) > 0.05 ||
            a.intersectionRatio > 0.8,
          d =
            (l || 10 == s.visibility) && Math.abs(i.top) + u.height > i.height;
        Sr(r, s, s.interaction, d ? 13 : l ? 10 : 0),
          s.visibility >= 13 && gr && gr.unobserve(r);
      }
    }
    dr.length > 0 && Wn(7);
  }
  function Sr(t, e, n, a) {
    var r = n > e.interaction || a > e.visibility;
    (e.interaction = n > e.interaction ? n : e.interaction),
      (e.visibility = a > e.visibility ? a : e.visibility),
      e.id
        ? ((e.id in hr && r) || !(e.id in hr)) &&
          ((hr[e.id] = e), dr.push(kr(e)))
        : pr.push({ node: t, state: kr(e) });
  }
  function kr(t) {
    return {
      time: d(),
      data: {
        id: t.id,
        interaction: t.interaction,
        visibility: t.visibility,
        name: t.name,
      },
    };
  }
  function Or() {
    dr = [];
  }
  function Er(t) {
    var e = t.composed && t.composedPath ? t.composedPath() : null,
      n = e && e.length > 0 ? e[0] : t.target;
    return (
      ($n = d() + 3e3),
      n && n.nodeType === Node.DOCUMENT_NODE ? n.documentElement : n
    );
  }
  function Tr(t, e, n) {
    void 0 === n && (n = null);
    var a = { id: 0, hash: null, privacy: 2 };
    if (t) {
      var r = rr(t);
      if (null !== r) {
        var i = r.metadata;
        (a.id = r.id),
          (a.hash = r.hash),
          (a.privacy = i.privacy),
          r.region &&
            (function (t, e) {
              var n = nr(t),
                a =
                  t in hr
                    ? hr[t]
                    : {
                        id: t,
                        visibility: 0,
                        interaction: 16,
                        name: fr.get(n),
                      },
                r = 16;
              switch (e) {
                case 9:
                  r = 20;
                  break;
                case 27:
                  r = 30;
              }
              Sr(n, a, r, a.visibility);
            })(r.region, e),
          i.fraud && Gt(i.fraud, r.id, n || r.data.value);
      }
    }
    return a;
  }
  function _r(t, e) {
    return (
      void 0 === e && (e = null),
      ht(this, void 0, void 0, function () {
        var n,
          a,
          r,
          i,
          o,
          u,
          c,
          s,
          l,
          f,
          h,
          p,
          v,
          g,
          m,
          y,
          b,
          k,
          O,
          E,
          T,
          _,
          N,
          M,
          x,
          I,
          D,
          R,
          A,
          Y,
          j,
          X,
          L,
          W,
          z,
          H;
        return pt(this, function (q) {
          switch (((n = e || d()), (a = [n, t]), t)) {
            case 13:
            case 14:
            case 12:
            case 15:
            case 16:
            case 17:
            case 18:
            case 19:
            case 20:
              for (r = 0, i = ve; r < i.length; r++)
                (W = i[r]),
                  (o = Tr(W.data.target, W.event)).id > 0 &&
                    ((a = [W.time, W.event]).push(o.id),
                    a.push(W.data.x),
                    a.push(W.data.y),
                    void 0 !== W.data.id &&
                      (a.push(W.data.id),
                      void 0 !== W.data.isPrimary &&
                        a.push(W.data.isPrimary.toString())),
                    ei(a),
                    (void 0 === W.data.isPrimary || W.data.isPrimary) &&
                      C(W.event, W.data.x, W.data.y, W.time));
              Ee();
              break;
            case 9:
            case 48:
              for (u = 0, c = ee; u < c.length; u++)
                (W = c[u]),
                  (s = Tr(W.data.target, W.event, W.data.text)),
                  (a = [W.time, W.event]),
                  (l = s.hash ? s.hash.join(".") : ""),
                  a.push(s.id),
                  a.push(W.data.x),
                  a.push(W.data.y),
                  a.push(W.data.eX),
                  a.push(W.data.eY),
                  a.push(W.data.button),
                  a.push(W.data.reaction),
                  a.push(W.data.context),
                  a.push(w(W.data.text, "click", s.privacy)),
                  a.push(S(W.data.link)),
                  a.push(l),
                  a.push(W.data.trust),
                  a.push(W.data.isFullText),
                  a.push(W.data.w),
                  a.push(W.data.h),
                  ei(a),
                  Ir(
                    W.time,
                    W.event,
                    l,
                    W.data.x,
                    W.data.y,
                    W.data.reaction,
                    W.data.context
                  );
              ie();
              break;
            case 38:
              for (f = 0, h = oe; f < h.length; f++)
                (W = h[f]),
                  (a = [W.time, W.event]),
                  (j = Tr(W.data.target, W.event)).id > 0 &&
                    (a.push(j.id), a.push(W.data.action), ei(a));
              ce();
              break;
            case 11:
              (p = pe),
                a.push(p.width),
                a.push(p.height),
                C(t, p.width, p.height),
                Ce(),
                ei(a);
              break;
            case 26:
              (v = Be), a.push(v.name), a.push(v.persisted), tn(), ei(a);
              break;
            case 27:
              for (g = 0, m = le; g < m.length; g++)
                (W = m[g]),
                  (y = Tr(W.data.target, W.event, W.data.value)),
                  (a = [W.time, W.event]).push(y.id),
                  a.push(w(W.data.value, "input", y.privacy, !1, W.data.type)),
                  a.push(W.data.trust),
                  ei(a);
              he();
              break;
            case 21:
              (b = ze) &&
                ((k = Tr(b.start, t)),
                (O = Tr(b.end, t)),
                a.push(k.id),
                a.push(b.startOffset),
                a.push(O.id),
                a.push(b.endOffset),
                Ve(),
                ei(a));
              break;
            case 10:
              for (E = 0, T = De; E < T.length; E++)
                (W = T[E]),
                  (_ = Tr(W.data.target, W.event)),
                  (N = Tr(W.data.top, W.event)),
                  (M = Tr(W.data.bottom, W.event)),
                  (x = (null == N ? void 0 : N.hash) ? N.hash.join(".") : ""),
                  (I = (null == M ? void 0 : M.hash) ? M.hash.join(".") : ""),
                  _.id > 0 &&
                    ((a = [W.time, W.event]).push(_.id),
                    a.push(W.data.x),
                    a.push(W.data.y),
                    a.push(x),
                    a.push(I),
                    ei(a),
                    C(W.event, W.data.x, W.data.y, W.time));
              (De = []), (Pe = null), (Re = null);
              break;
            case 42:
              for (D = 0, R = Kt; D < R.length; D++)
                (W = R[D]),
                  (a = [W.time, W.event]),
                  (j = Tr(W.data.target, W.event)).id > 0 &&
                    ((a = [W.time, W.event]).push(j.id),
                    a.push(W.data.type),
                    a.push(w(W.data.value, "change", j.privacy)),
                    a.push(w(W.data.checksum, "checksum", j.privacy)),
                    ei(a));
              Qt();
              break;
            case 39:
              for (A = 0, Y = Ke; A < Y.length; A++)
                (W = Y[A]),
                  (a = [W.time, W.event]),
                  (j = Tr(W.data.target, W.event)).id > 0 &&
                    (a.push(j.id), ei(a));
              Qe();
              break;
            case 22:
              for (X = 0, L = Mr; X < L.length; X++)
                (W = L[X]),
                  (a = [W.time, W.event]).push(W.data.type),
                  a.push(W.data.hash),
                  a.push(W.data.x),
                  a.push(W.data.y),
                  a.push(W.data.reaction),
                  a.push(W.data.context),
                  ei(a, !1);
              xr();
              break;
            case 28:
              (z = Je), a.push(z.visible), ei(a), P(n, z.visible), nn();
              break;
            case 50:
              (H = Ge), a.push(H.focused), ei(a, !1), an();
          }
          return [2];
        });
      })
    );
  }
  var Nr = [],
    Mr = [];
  function xr() {
    Mr = [];
  }
  function Ir(t, e, n, a, r, i, o) {
    void 0 === i && (i = 1),
      void 0 === o && (o = 0),
      Nr.push({
        time: t,
        event: 22,
        data: { type: e, hash: n, x: a, y: r, reaction: i, context: o },
      }),
      C(e, a, r, t);
  }
  function Cr(t, e, n) {
    return ""
      .concat(t, "=")
      .concat(w(e, 0 === t.indexOf("data-") ? "data-" : t, n));
  }
  var Dr = [],
    Pr = 1,
    Rr = null;
  function Ar() {
    (Dr = []),
      (function (t) {
        var e = [t];
        for (; e.length > 0; ) {
          for (
            var n = null,
              a = null,
              r = null,
              i = e.shift(),
              o = i.firstChild,
              u = i.parentElement
                ? i.parentElement
                : i.parentNode
                ? i.parentNode
                : null;
            o;

          )
            e.push(o), (o = o.nextSibling);
          switch (i.nodeType) {
            case Node.DOCUMENT_TYPE_NODE:
              var c = i;
              (a = "*D"),
                (n = {
                  name: c.name,
                  publicId: c.publicId,
                  systemId: c.systemId,
                });
              break;
            case Node.TEXT_NODE:
              (r = i.nodeValue), (a = Rr.get(u) ? "*T" : a);
              break;
            case Node.ELEMENT_NODE:
              var s = i;
              (n = Yr(s)),
                (a =
                  ["NOSCRIPT", "SCRIPT", "STYLE"].indexOf(s.tagName) < 0
                    ? s.tagName
                    : a);
          }
          jr(i, u, { tag: a, attributes: n, value: r });
        }
      })(document),
      (function (t) {
        ht(this, void 0, void 0, function () {
          var e, n, a, r, i, o, u, c, s, l, f, h, p;
          return pt(this, function (v) {
            switch (((e = d()), (n = [e, t]), t)) {
              case 8:
                (a = An),
                  n.push(a.width),
                  n.push(a.height),
                  C(t, a.width, a.height),
                  ei(n);
                break;
              case 43:
                if ((r = Dr).length > 0) {
                  for (i = 0, o = r; i < o.length; i++)
                    for (
                      u = o[i],
                        c = u.metadata.privacy,
                        s = u.data,
                        l = 0,
                        f = ["tag", "attributes", "value"];
                      l < f.length;
                      l++
                    )
                      if (s[(h = f[l])])
                        switch (h) {
                          case "tag":
                            n.push(u.id),
                              u.parent && n.push(u.parent),
                              u.previous && n.push(u.previous),
                              n.push(s[h]);
                            break;
                          case "attributes":
                            for (p in s[h])
                              void 0 !== s[h][p] && n.push(Cr(p, s[h][p], c));
                            break;
                          case "value":
                            n.push(w(s[h], s.tag, c));
                        }
                  ei(cn(n), !0);
                }
            }
            return [2];
          });
        });
      })(43);
  }
  function Yr(t) {
    var e = {},
      n = t.attributes;
    if (n && n.length > 0)
      for (var a = 0; a < n.length; a++) e[n[a].name] = n[a].value;
    return e;
  }
  function jr(t, e, n) {
    if (t && n && n.tag) {
      var a = (function (t) {
          return null === t
            ? null
            : Rr.has(t)
            ? Rr.get(t)
            : (Rr.set(t, Pr), Pr++);
        })(t),
        r = e ? Rr.get(e) : null,
        i = t.previousSibling ? Rr.get(t.previousSibling) : null;
      Dr.push({
        id: a,
        parent: r,
        previous: i,
        children: [],
        data: n,
        selector: null,
        hash: null,
        region: null,
        metadata: {
          active: !0,
          suspend: !1,
          privacy: 5,
          position: null,
          fraud: null,
          size: null,
        },
      });
    }
  }
  var Xr = [],
    Lr = !1,
    Wr = null;
  function zr(t) {
    Lr && "function" == typeof t && Xr.push(t);
  }
  function Hr(t) {
    if (Lr) {
      var e = t ? t.split(" ") : [""],
        n = e.length > 1 ? parseInt(e[1], 10) : null;
      (n && Wr.has(n)) ||
        (!(function (t) {
          try {
            var e = document.createElement("script");
            (e.src = t), (e.async = !0), document.head.appendChild(e);
          } catch (t) {}
        })(e[0]),
        n && (Wr.add(n), R(Wr)));
    }
  }
  var qr,
    Ur,
    Fr,
    Vr,
    Br,
    Jr = Object.freeze({
      __proto__: null,
      event: Hr,
      register: zr,
      start: function () {
        (Lr = !0), (Wr = new Set());
      },
      stop: function () {
        Xr.reverse().forEach(function (t) {
          try {
            t();
          } catch (t) {}
        }),
          (Xr = []),
          (Lr = !1);
      },
    }),
    Gr = 0,
    Kr = 0,
    Zr = null,
    Qr = 0,
    $r = !1;
  function ti() {
    (Vr = !0),
      (Gr = 0),
      (Kr = 0),
      ($r = !1),
      (Qr = 0),
      (qr = []),
      (Ur = []),
      (Fr = {}),
      (Br = null);
  }
  function ei(t, e) {
    if ((void 0 === e && (e = !0), Vr)) {
      var n = d(),
        a = t.length > 1 ? t[1] : null,
        r = JSON.stringify(t);
      switch (
        (u.lean
          ? !$r && Kr + r.length > 10485760 && (hi(10, 0), ($r = !0))
          : ($r = !1),
        a)
      ) {
        case 5:
          if ($r) break;
          Gr += r.length;
        case 37:
        case 6:
        case 43:
        case 45:
        case 46:
        case 44:
        case 51:
          if ($r) break;
          (Kr += r.length), qr.push(r);
          break;
        default:
          Ur.push(r);
      }
      Z(25);
      var i = (function () {
        var t = !1 === u.lean && Gr > 0 ? 100 : Eo.sequence * u.delay;
        return "string" == typeof u.upload
          ? Math.max(Math.min(t, 3e4), 100)
          : u.delay;
      })();
      n - Qr > 2 * i && (et(Zr), (Zr = null)),
        e &&
          null === Zr &&
          (25 !== a && it(), (Zr = tt(ai, i)), (Qr = n), Li(Kr));
    }
  }
  function ni() {
    et(Zr),
      ai(!0),
      (Gr = 0),
      (Kr = 0),
      ($r = !1),
      (Qr = 0),
      (qr = []),
      (Ur = []),
      (Fr = {}),
      (Br = null),
      (Vr = !1);
  }
  function ai(t) {
    return (
      void 0 === t && (t = !1),
      ht(this, void 0, void 0, function () {
        var e, n, a, r, i, o, c, s;
        return pt(this, function (l) {
          switch (l.label) {
            case 0:
              return Vr
                ? ((Zr = null),
                  (e =
                    !1 === u.lean &&
                    Kr > 0 &&
                    (Kr < 1048576 || Eo.sequence > 0)) && $(1, 1),
                  br(),
                  (function () {
                    if (Eo) {
                      var t = [];
                      Mr = [];
                      for (
                        var e = (Eo.start || 0) + (Eo.duration || 0),
                          n = Math.max(e - 2e3, 0),
                          a = 0,
                          r = Nr;
                        a < r.length;
                        a++
                      ) {
                        var i = r[a];
                        i.time >= n && (i.time <= e && Mr.push(i), t.push(i));
                      }
                      (Nr = t), _r(22);
                    }
                  })(),
                  Vt(),
                  (function () {
                    for (var t = 0, e = pn; t < e.length; t++) {
                      var n = e[t],
                        a = n == document ? -1 : Va(n);
                      yn(n, a in hn ? hn[a] : null);
                    }
                  })(),
                  (n = !0 === t),
                  Eo
                    ? ((a = JSON.stringify(No(n))),
                      (r = "[".concat(Ur.join(), "]")),
                      (i = e ? "[".concat(qr.join(), "]") : ""),
                      n &&
                        i.length > 0 &&
                        a.length + r.length + i.length > 65536 &&
                        (i = ""),
                      (o = (function (t) {
                        return t.p.length > 0
                          ? '{"e":'
                              .concat(t.e, ',"a":')
                              .concat(t.a, ',"p":')
                              .concat(t.p, "}")
                          : '{"e":'.concat(t.e, ',"a":').concat(t.a, "}");
                      })({ e: a, a: r, p: i })),
                      n ? ((s = null), [3, 3]) : [3, 1])
                    : [2])
                : [2];
            case 1:
              return [4, gt(o)];
            case 2:
              (s = l.sent()), (l.label = 3);
            case 3:
              return (
                Q(2, (c = s) ? c.length : o.length),
                ri(o, c, Eo.sequence, n),
                (Ur = []),
                e && ((qr = []), (Kr = 0), (Gr = 0), ($r = !1)),
                [2]
              );
          }
        });
      })
    );
  }
  function ri(t, e, n, a) {
    if ((void 0 === a && (a = !1), "string" == typeof u.upload)) {
      var r = u.upload,
        i = !1;
      if (a && navigator && navigator.sendBeacon)
        try {
          (i = navigator.sendBeacon.bind(navigator)(r, t)) && oi(n);
        } catch (t) {}
      if (!1 === i) {
        n in Fr ? Fr[n].attempts++ : (Fr[n] = { data: t, attempts: 1 });
        var o = new XMLHttpRequest();
        o.open("POST", r, !0),
          (o.timeout = 15e3),
          (o.ontimeout = function () {
            xo(new Error("".concat("Timeout", " : ").concat(r)));
          }),
          null !== n &&
            (o.onreadystatechange = function () {
              Io(ii)(o, n);
            }),
          (o.withCredentials = !0),
          e
            ? (o.setRequestHeader("Accept", "application/x-clarity-gzip"),
              o.send(e))
            : o.send(t);
      }
    } else if (u.upload) {
      (0, u.upload)(t), oi(n);
    }
  }
  function ii(t, e) {
    var n = Fr[e];
    t &&
      4 === t.readyState &&
      n &&
      ((t.status < 200 || t.status > 208) && n.attempts <= 1
        ? t.status >= 400 && t.status < 500
          ? Wi(6)
          : (0 === t.status && (u.upload = u.fallback ? u.fallback : u.upload),
            (Br = { sequence: e, attempts: n.attempts, status: t.status }),
            ji(2),
            ri(n.data, null, e))
        : ((Br = { sequence: e, attempts: n.attempts, status: t.status }),
          n.attempts > 1 && ji(2),
          200 === t.status &&
            t.responseText &&
            (function (t) {
              for (
                var e = t && t.length > 0 ? t.split("\n") : [], n = 0, a = e;
                n < a.length;
                n++
              ) {
                var r = a[n],
                  i = r && r.length > 0 ? r.split(/ (.*)/) : [""];
                switch (i[0]) {
                  case "END":
                    Wi(6);
                    break;
                  case "UPGRADE":
                    Ai("Auto");
                    break;
                  case "ACTION":
                    u.action && i.length > 1 && u.action(i[1]);
                    break;
                  case "EXTRACT":
                    i.length > 1 && Pt(i[1]);
                    break;
                  case "SIGNAL":
                    i.length > 1 && Ht(i[1]);
                    break;
                  case "MODULE":
                    i.length > 1 && Hr(i[1]);
                    break;
                  case "SNAPSHOT":
                    (u.lean = !1), Ar();
                }
              }
            })(t.responseText),
          0 === t.status && (ri(n.data, null, e, !0), Wi(3)),
          t.status >= 200 && t.status <= 208 && oi(e),
          delete Fr[e]));
  }
  function oi(t) {
    1 === t && (po(), ho());
  }
  var ui,
    ci = {};
  function si(t) {
    var e = t.error || t;
    return (
      e.message in ci || (ci[e.message] = 0),
      ci[e.message]++ >= 5 ||
        (e &&
          e.message &&
          ((ui = {
            message: e.message,
            line: t.lineno,
            column: t.colno,
            stack: e.stack,
            source: t.filename,
          }),
          li(31))),
      !0
    );
  }
  function li(t) {
    return ht(this, void 0, void 0, function () {
      var e;
      return pt(this, function (n) {
        switch (((e = [d(), t]), t)) {
          case 31:
            e.push(ui.message),
              e.push(ui.line),
              e.push(ui.column),
              e.push(ui.stack),
              e.push(S(ui.source)),
              ei(e);
            break;
          case 33:
            di &&
              (e.push(di.code),
              e.push(di.name),
              e.push(di.message),
              e.push(di.stack),
              e.push(di.severity),
              ei(e, !1));
            break;
          case 41:
            Bt &&
              (e.push(Bt.id),
              e.push(Bt.target),
              e.push(Bt.checksum),
              ei(e, !1));
        }
        return [2];
      });
    });
  }
  var di,
    fi = {};
  function hi(t, e, n, a, r) {
    void 0 === n && (n = null),
      void 0 === a && (a = null),
      void 0 === r && (r = null);
    var i = n ? "".concat(n, "|").concat(a) : "";
    (t in fi && fi[t].indexOf(i) >= 0) ||
      ((di = { code: t, name: n, message: a, stack: r, severity: e }),
      t in fi ? fi[t].push(i) : (fi[t] = [i]),
      li(33));
  }
  var pi = 5e3,
    vi = {},
    gi = [],
    mi = null,
    yi = null,
    bi = null;
  function wi() {
    (vi = {}), (gi = []), (mi = null), (yi = null);
  }
  function Si(t, e) {
    return (
      void 0 === e && (e = 0),
      ht(this, void 0, void 0, function () {
        var n, a, r;
        return pt(this, function (i) {
          for (n = 0, a = gi; n < a.length; n++)
            if (a[n].task === t) return [2];
          return (
            (r = new Promise(function (n) {
              gi[1 === e ? "unshift" : "push"]({
                task: t,
                resolve: n,
                id: oo(),
              });
            })),
            null === mi && null === yi && ki(),
            [2, r]
          );
        });
      })
    );
  }
  function ki() {
    var t = gi.shift();
    t &&
      ((mi = t),
      t
        .task()
        .then(function () {
          t.id === oo() && (t.resolve(), (mi = null), ki());
        })
        .catch(function (e) {
          t.id === oo() &&
            (e && hi(0, 1, e.name, e.message, e.stack), (mi = null), ki());
        }));
  }
  function Oi(t) {
    var e = Ni(t);
    return e in vi
      ? performance.now() - vi[e].start > vi[e].yield
        ? 0
        : 1
      : 2;
  }
  function Ei(t) {
    vi[Ni(t)] = { start: performance.now(), calls: 0, yield: 30 };
  }
  function Ti(t) {
    var e = performance.now(),
      n = Ni(t),
      a = e - vi[n].start;
    Q(t.cost, a), Z(5), vi[n].calls > 0 && Q(4, a);
  }
  function _i(t) {
    var e;
    return ht(this, void 0, void 0, function () {
      var n, a;
      return pt(this, function (r) {
        switch (r.label) {
          case 0:
            return (n = Ni(t)) in vi ? (Ti(t), (a = vi[n]), [4, Mi()]) : [3, 2];
          case 1:
            (a.yield =
              (null === (e = r.sent()) || void 0 === e
                ? void 0
                : e.timeRemaining()) || 30),
              (function (t) {
                var e = Ni(t);
                if (vi && vi[e]) {
                  var n = vi[e].calls,
                    a = vi[e].yield;
                  Ei(t), (vi[e].calls = n + 1), (vi[e].yield = a);
                }
              })(t),
              (r.label = 2);
          case 2:
            return [2, n in vi ? 1 : 2];
        }
      });
    });
  }
  function Ni(t) {
    return "".concat(t.id, ".").concat(t.cost);
  }
  function Mi() {
    return ht(this, void 0, void 0, function () {
      return pt(this, function (t) {
        switch (t.label) {
          case 0:
            return yi ? [4, yi] : [3, 2];
          case 1:
            t.sent(), (t.label = 2);
          case 2:
            return [
              2,
              new Promise(function (t) {
                xi(t, { timeout: pi });
              }),
            ];
        }
      });
    });
  }
  var xi =
    window.requestIdleCallback ||
    function (t, e) {
      var n = performance.now(),
        a = new MessageChannel(),
        r = a.port1,
        i = a.port2;
      (r.onmessage = function (a) {
        var r = performance.now(),
          o = r - n,
          u = r - a.data;
        if (u > 30 && o < e.timeout)
          requestAnimationFrame(function () {
            i.postMessage(r);
          });
        else {
          var c = o > e.timeout;
          t({
            didTimeout: c,
            timeRemaining: function () {
              return c ? 30 : Math.max(0, 30 - u);
            },
          });
        }
      }),
        requestAnimationFrame(function () {
          i.postMessage(performance.now());
        });
    };
  function Ii() {
    Si(Ci, 1).then(function () {
      Io(Fn)(), Io(br)(), Io(We)();
    });
  }
  function Ci() {
    return ht(this, void 0, void 0, function () {
      var t, e;
      return pt(this, function (n) {
        switch (n.label) {
          case 0:
            return (
              (t = d()),
              Ei((e = { id: oo(), cost: 3 })),
              [4, Vn(document, e, 0, t)]
            );
          case 1:
            return n.sent(), yn(document, t), [4, Wn(5, e, t)];
          case 2:
            return n.sent(), Ti(e), [2];
        }
      });
    });
  }
  var Di,
    Pi = null;
  function Ri() {
    !u.lean && u.upgrade && u.upgrade("Config"), (Pi = null);
  }
  function Ai(t) {
    Jo() &&
      u.lean &&
      ((u.lean = !1),
      (Pi = { key: t }),
      ho(),
      po(),
      u.upgrade && u.upgrade(t),
      ji(3),
      u.lite && (Ii(), mn()));
  }
  function Yi() {
    Pi = null;
  }
  function ji(t) {
    var e = [d(), t];
    switch (t) {
      case 4:
        var n = N;
        n &&
          n.data &&
          ((e = [n.time, n.event]).push(n.data.visible),
          e.push(n.data.docWidth),
          e.push(n.data.docHeight),
          e.push(n.data.screenWidth),
          e.push(n.data.screenHeight),
          e.push(n.data.scrollX),
          e.push(n.data.scrollY),
          e.push(n.data.pointerX),
          e.push(n.data.pointerY),
          e.push(n.data.activityTime),
          e.push(n.data.scrollTime),
          e.push(n.data.pointerTime),
          e.push(n.data.moveX),
          e.push(n.data.moveY),
          e.push(n.data.moveTime),
          e.push(n.data.downX),
          e.push(n.data.downY),
          e.push(n.data.downTime),
          e.push(n.data.upX),
          e.push(n.data.upY),
          e.push(n.data.upTime),
          e.push(n.data.pointerPrevX),
          e.push(n.data.pointerPrevY),
          e.push(n.data.pointerPrevTime),
          e.push(n.data.modules),
          ei(e, !1)),
          I();
        break;
      case 25:
        e.push(J.gap), ei(e);
        break;
      case 35:
        e.push(Di.check), ei(e, !1);
        break;
      case 3:
        e.push(Pi.key), ei(e);
        break;
      case 2:
        e.push(Br.sequence), e.push(Br.attempts), e.push(Br.status), ei(e, !1);
        break;
      case 24:
        V.key && e.push(V.key), e.push(V.value), ei(e);
        break;
      case 34:
        var a = Object.keys(yt);
        if (a.length > 0) {
          for (var r = 0, i = a; r < i.length; r++) {
            var o = i[r];
            e.push(o), e.push(yt[o]);
          }
          Ot(), ei(e, !1);
        }
        break;
      case 0:
        var u = Object.keys(K);
        if (u.length > 0) {
          for (var c = 0, s = u; c < s.length; c++) {
            var l = s[c],
              f = parseInt(l, 10);
            e.push(f), e.push(Math.round(K[l]));
          }
          (K = {}), ei(e, !1);
        }
        break;
      case 1:
        var h = Object.keys(Ui);
        if (h.length > 0) {
          for (var p = 0, v = h; p < v.length; p++) {
            var g = v[p];
            f = parseInt(g, 10);
            e.push(f), e.push(Ui[g]);
          }
          Ki(), ei(e, !1);
        }
        break;
      case 36:
        var m = Object.keys(ct);
        if (m.length > 0) {
          for (var y = 0, b = m; y < b.length; y++) {
            var w = b[y];
            f = parseInt(w, 10);
            e.push(f), e.push([].concat.apply([], ct[w]));
          }
          dt(), ei(e, !1);
        }
        break;
      case 40:
        Mt.forEach(function (t) {
          e.push(t);
          var n = [];
          for (var a in Nt[t]) {
            var r = parseInt(a, 10);
            n.push(r), n.push(Nt[t][a]);
          }
          e.push(n);
        }),
          Yt(),
          ei(e, !1);
        break;
      case 47:
        e.push(j.source),
          e.push(j.ad_Storage),
          e.push(j.analytics_Storage),
          ei(e, !1);
    }
  }
  function Xi() {
    Di = { check: 0 };
  }
  function Li(t) {
    if (0 === Di.check) {
      var e = Di.check;
      (e = Eo.sequence >= 128 ? 1 : e),
        (e = Eo.pageNum >= 128 ? 7 : e),
        (e = d() > 72e5 ? 2 : e),
        (e = t > 10485760 ? 2 : e) !== Di.check && Wi(e);
    }
  }
  function Wi(t) {
    (Di.check = t), 5 !== t && (fo(), bu());
  }
  function zi() {
    0 !== Di.check && ji(35);
  }
  function Hi() {
    Di = null;
  }
  var qi = null,
    Ui = null,
    Fi = !1;
  function Vi() {
    (qi = {}), (Ui = {}), (Fi = !1);
  }
  function Bi() {
    (qi = {}), (Ui = {}), (Fi = !1);
  }
  function Ji(t, e) {
    if (
      e &&
      ((e = "".concat(e)), t in qi || (qi[t] = []), qi[t].indexOf(e) < 0)
    ) {
      if (qi[t].length > 128) return void (Fi || ((Fi = !0), Wi(5)));
      qi[t].push(e), t in Ui || (Ui[t] = []), Ui[t].push(e);
    }
  }
  function Gi() {
    ji(1);
  }
  function Ki() {
    (Ui = {}), (Fi = !1);
  }
  var Zi = null,
    Qi = [],
    $i = 0,
    to = null,
    eo = null,
    no = { ad_Storage: "denied", analytics_Storage: "denied" };
  function ao() {
    var t, e, n;
    to = null;
    var a = navigator && "userAgent" in navigator ? navigator.userAgent : "",
      r =
        null !==
          (n =
            "undefined" != typeof Intl &&
            (null ===
              (e =
                null ===
                  (t =
                    null === Intl || void 0 === Intl
                      ? void 0
                      : Intl.DateTimeFormat()) || void 0 === t
                  ? void 0
                  : t.resolvedOptions()) || void 0 === e
              ? void 0
              : e.timeZone)) && void 0 !== n
          ? n
          : "",
      i = new Date().getTimezoneOffset().toString(),
      o = window.location.ancestorOrigins
        ? Array.from(window.location.ancestorOrigins).toString()
        : "",
      c = document && document.title ? document.title : "";
    $i = a.indexOf("Electron") > 0 ? 1 : 0;
    var s = (function () {
        var t = {
            session: mo(),
            ts: Math.round(Date.now()),
            count: 1,
            upgrade: null,
            upload: "",
          },
          e = wo("_clsk", !u.includeSubdomains);
        if (e) {
          var n = e.includes("^") ? e.split("^") : e.split("|");
          n.length >= 5 &&
            t.ts - yo(n[1]) < 18e5 &&
            ((t.session = n[0]),
            (t.count = yo(n[2]) + 1),
            (t.upgrade = yo(n[3])),
            (t.upload =
              n.length >= 6
                ? "".concat("https://").concat(n[5], "/").concat(n[4])
                : "".concat("https://").concat(n[4])));
        }
        return t;
      })(),
      l = bo(),
      d = u.projectId || h(location.host);
    (Zi = {
      projectId: d,
      userId: l.id,
      sessionId: s.session,
      pageNum: s.count,
    }),
      (u.lean = u.track && null !== s.upgrade ? 0 === s.upgrade : u.lean),
      (u.upload =
        u.track &&
        "string" == typeof u.upload &&
        s.upload &&
        s.upload.length > "https://".length
          ? s.upload
          : u.upload),
      Ji(0, a),
      Ji(3, c),
      Ji(1, S(location.href, !!$i)),
      Ji(2, document.referrer),
      Ji(
        15,
        (function () {
          var t = mo();
          if (u.track && vo(window, "sessionStorage")) {
            var e = sessionStorage.getItem("_cltk");
            (t = e || t), sessionStorage.setItem("_cltk", t);
          }
          return t;
        })()
      ),
      Ji(16, document.documentElement.lang),
      Ji(17, document.dir),
      Ji(26, "".concat(window.devicePixelRatio)),
      Ji(28, l.dob.toString()),
      Ji(29, l.version.toString()),
      Ji(33, o),
      Ji(34, r),
      Ji(35, i),
      $(0, s.ts),
      $(1, 0),
      $(35, $i);
    var f,
      p = null === window || void 0 === window ? void 0 : window.Zone;
    p && "__symbol__" in p && $(39, 1),
      navigator &&
        (Ji(9, navigator.language),
        $(33, navigator.hardwareConcurrency),
        $(32, navigator.maxTouchPoints),
        $(34, Math.round(navigator.deviceMemory)),
        (f = navigator.userAgentData) && f.getHighEntropyValues
          ? f
              .getHighEntropyValues([
                "model",
                "platform",
                "platformVersion",
                "uaFullVersion",
              ])
              .then(function (t) {
                var e;
                Ji(22, t.platform),
                  Ji(23, t.platformVersion),
                  null === (e = t.brands) ||
                    void 0 === e ||
                    e.forEach(function (t) {
                      Ji(24, t.name + "~" + t.version);
                    }),
                  Ji(25, t.model),
                  $(27, t.mobile ? 1 : 0);
              })
          : Ji(22, navigator.platform)),
      screen &&
        ($(14, Math.round(screen.width)),
        $(15, Math.round(screen.height)),
        $(16, Math.round(screen.colorDepth)));
    for (var v = 0, g = u.cookies; v < g.length; v++) {
      var m = g[v],
        y = wo(m);
      y && bt(m, y);
    }
    null === eo &&
      (eo = {
        ad_Storage: u.track ? "granted" : "denied",
        analytics_Storage: u.track ? "granted" : "denied",
      }),
      W(so(eo, 0)),
      go(l);
  }
  function ro() {
    (to = null),
      (Zi = null),
      Qi.forEach(function (t) {
        t.called = !1;
      });
  }
  function io(t, e, n, a) {
    void 0 === e && (e = !0),
      void 0 === n && (n = !1),
      void 0 === a && (a = !1);
    var r = u.lean ? 0 : 1,
      i = !1;
    Zi && (r || !1 === e) && (t(Zi, !u.lean, a ? eo : void 0), (i = !0)),
      (!n && i) ||
        Qi.push({ callback: t, wait: e, recall: n, called: i, consentInfo: a });
  }
  function oo() {
    return Zi ? [Zi.userId, Zi.sessionId, Zi.pageNum].join(".") : "";
  }
  function uo(t) {
    void 0 === t && (t = !0),
      t
        ? (co({ ad_Storage: "granted", analytics_Storage: "granted" }), z())
        : co();
  }
  function co(t, e) {
    void 0 === t && (t = no), void 0 === e && (e = 1);
    var n = {
      ad_Storage: lo(t.ad_Storage),
      analytics_Storage: lo(t.analytics_Storage),
    };
    if (
      !eo ||
      n.ad_Storage !== eo.ad_Storage ||
      n.analytics_Storage !== eo.analytics_Storage
    ) {
      (eo = n), ho(!0);
      var a = so(eo, e);
      if (!a.analytics_Storage && u.track)
        return (
          (u.track = !1),
          ko("_clsk", "", -Number.MAX_VALUE),
          ko("_clck", "", -Number.MAX_VALUE),
          bu(),
          void window.setTimeout(yu, 250)
        );
      Jo() && a.analytics_Storage && ((u.track = !0), go(bo(), 1), po()),
        q(a),
        z();
    }
  }
  function so(t, e) {
    return {
      source: e,
      ad_Storage: "granted" === t.ad_Storage ? 1 : 0,
      analytics_Storage: "granted" === t.analytics_Storage ? 1 : 0,
    };
  }
  function lo(t) {
    return "string" == typeof t ? t.toLowerCase() : "denied";
  }
  function fo() {
    ko("_clsk", "", 0);
  }
  function ho(t) {
    void 0 === t && (t = !1),
      (function (t, e) {
        void 0 === e && (e = !1);
        if (Qi.length > 0)
          for (var n = 0; n < Qi.length; n++) {
            var a = Qi[n];
            a.callback &&
              ((!a.called && !e) || (a.consentInfo && e)) &&
              (!a.wait || t) &&
              (a.callback(Zi, !u.lean, a.consentInfo ? eo : void 0),
              (a.called = !0),
              a.recall || (Qi.splice(n, 1), n--));
          }
      })(u.lean ? 0 : 1, t);
  }
  function po() {
    if (Zi && u.track) {
      var t = Math.round(Date.now()),
        e =
          u.upload && "string" == typeof u.upload
            ? u.upload.replace("https://", "")
            : "",
        n = u.lean ? 0 : 1;
      ko("_clsk", [Zi.sessionId, t, Zi.pageNum, n, e].join("^"), 1);
    }
  }
  function vo(t, e) {
    try {
      return !!t[e];
    } catch (t) {
      return !1;
    }
  }
  function go(t, e) {
    void 0 === e && (e = null), (e = null === e ? t.consent : e);
    var n = Math.ceil((Date.now() + 31536e6) / 864e5),
      a = 0 === t.dob ? (null === u.dob ? 0 : u.dob) : t.dob;
    (null === t.expiry ||
      Math.abs(n - t.expiry) >= 1 ||
      t.consent !== e ||
      t.dob !== a) &&
      ko("_clck", [Zi.userId, 2, n.toString(36), e, a].join("^"), 365);
  }
  function mo() {
    var t = Math.floor(Math.random() * Math.pow(2, 32));
    return (
      window &&
        window.crypto &&
        window.crypto.getRandomValues &&
        Uint32Array &&
        (t = window.crypto.getRandomValues(new Uint32Array(1))[0]),
      t.toString(36)
    );
  }
  function yo(t, e) {
    return void 0 === e && (e = 10), parseInt(t, e);
  }
  function bo() {
    var t = { id: mo(), version: 0, expiry: null, consent: 0, dob: 0 },
      e = wo("_clck", !u.includeSubdomains);
    if (e && e.length > 0) {
      var n = e.includes("^") ? e.split("^") : e.split("|");
      n.length > 1 && (t.version = yo(n[1])),
        n.length > 2 && (t.expiry = yo(n[2], 36)),
        n.length > 3 && 1 === yo(n[3]) && (t.consent = 1),
        n.length > 4 && yo(n[1]) > 1 && (t.dob = yo(n[4])),
        (u.track = u.track || 1 === t.consent),
        (t.id = u.track ? n[0] : t.id);
    }
    return t;
  }
  function wo(t, e) {
    var n;
    if ((void 0 === e && (e = !1), vo(document, "cookie"))) {
      var a = document.cookie.split(";");
      if (a)
        for (var r = 0; r < a.length; r++) {
          var i = a[r].split("=");
          if (i.length > 1 && i[0] && i[0].trim() === t) {
            for (var o = So(i[1]), u = o[0], c = o[1]; u; )
              (u = (n = So(c))[0]), (c = n[1]);
            return e
              ? c.endsWith("".concat("~", "1"))
                ? c.substring(0, c.length - 2)
                : null
              : c;
          }
        }
    }
    return null;
  }
  function So(t) {
    try {
      var e = decodeURIComponent(t);
      return [e != t, e];
    } catch (t) {}
    return [!1, t];
  }
  function ko(t, e, n) {
    if (
      (u.track || "" == e) &&
      ((navigator && navigator.cookieEnabled) || vo(document, "cookie"))
    ) {
      var a = (function (t) {
          return encodeURIComponent(t);
        })(e),
        r = new Date();
      r.setDate(r.getDate() + n);
      var i = r ? "expires=" + r.toUTCString() : "",
        o = "".concat(t, "=").concat(a).concat(";").concat(i).concat(";path=/");
      try {
        if (null === to) {
          for (
            var c = location.hostname ? location.hostname.split(".") : [],
              s = c.length - 1;
            s >= 0;
            s--
          )
            if (
              ((to = ".".concat(c[s]).concat(to || "")),
              s < c.length - 1 &&
                ((document.cookie = ""
                  .concat(o)
                  .concat(";")
                  .concat("domain=")
                  .concat(to)),
                wo(t) === e))
            )
              return;
          to = "";
        }
      } catch (t) {
        to = "";
      }
      document.cookie = to
        ? "".concat(o).concat(";").concat("domain=").concat(to)
        : o;
    }
  }
  var Oo,
    Eo = null;
  function To() {
    var t = Zi;
    Eo = {
      version: f,
      sequence: 0,
      start: 0,
      duration: 0,
      projectId: t.projectId,
      userId: t.userId,
      sessionId: t.sessionId,
      pageNum: t.pageNum,
      upload: 0,
      end: 0,
      applicationPlatform: 0,
      url: "",
    };
  }
  function _o() {
    Eo = null;
  }
  function No(t) {
    return (
      (Eo.start = Eo.start + Eo.duration),
      (Eo.duration = d() - Eo.start),
      Eo.sequence++,
      (Eo.upload = t && "sendBeacon" in navigator ? 1 : 0),
      (Eo.end = t ? 1 : 0),
      (Eo.applicationPlatform = 0),
      (Eo.url = S(location.href, !1, !0)),
      [
        Eo.version,
        Eo.sequence,
        Eo.start,
        Eo.duration,
        Eo.projectId,
        Eo.userId,
        Eo.sessionId,
        Eo.pageNum,
        Eo.upload,
        Eo.end,
        Eo.applicationPlatform,
        Eo.url,
      ]
    );
  }
  function Mo() {
    Oo = [];
  }
  function xo(t) {
    if (Oo && -1 === Oo.indexOf(t.message)) {
      var e = u.report;
      if (e && e.length > 0 && Eo) {
        var n = {
          v: Eo.version,
          p: Eo.projectId,
          u: Eo.userId,
          s: Eo.sessionId,
          n: Eo.pageNum,
        };
        t.message && (n.m = t.message), t.stack && (n.e = t.stack);
        var a = new XMLHttpRequest();
        a.open("POST", e, !0), a.send(JSON.stringify(n)), Oo.push(t.message);
      }
    }
    return t;
  }
  function Io(t) {
    return function () {
      var e = performance.now();
      try {
        t.apply(this, arguments);
      } catch (t) {
        throw xo(t);
      }
      var n = performance.now() - e;
      Q(4, n),
        n > 30 &&
          (Z(7), $(6, n), t.dn && hi(9, 0, "".concat(t.dn, "-").concat(n)));
    };
  }
  var Co = new Map();
  function Do(t, e, n, a, r) {
    void 0 === a && (a = !1), void 0 === r && (r = !0), (n = Io(n));
    try {
      t[c("addEventListener")](e, n, { capture: a, passive: r }),
        Ao(t) || Co.set(t, []),
        Co.get(t).push({
          event: e,
          listener: n,
          options: { capture: a, passive: r },
        });
    } catch (t) {}
  }
  function Po() {
    Co.forEach(function (t, e) {
      Yo(t, e);
    }),
      (Co = new Map());
  }
  function Ro(t) {
    Ao(t) && Yo(Co.get(t), t);
  }
  function Ao(t) {
    return Co.has(t);
  }
  function Yo(t, e) {
    t.forEach(function (t) {
      try {
        e[c("removeEventListener")](t.event, t.listener, {
          capture: t.options.capture,
          passive: t.options.passive,
        });
      } catch (t) {}
    }),
      Co.delete(e);
  }
  var jo = null,
    Xo = null,
    Lo = null,
    Wo = 0;
  function zo() {
    return !(Wo++ > 20) || (hi(4, 0), !1);
  }
  function Ho() {
    (Wo = 0), Lo !== Uo() && (bu(), window.setTimeout(qo, 250));
  }
  function qo() {
    yu(), $(29, 1);
  }
  function Uo() {
    return location.href
      ? location.href.replace(location.hash, "")
      : location.href;
  }
  var Fo = !1;
  function Vo() {
    (Fo = !0),
      (s = l()),
      wi(),
      Po(),
      Mo(),
      (Lo = Uo()),
      (Wo = 0),
      Do(window, "popstate", Ho),
      null === jo &&
        ((jo = history.pushState),
        (history.pushState = function () {
          jo.apply(this, arguments), Jo() && zo() && Ho();
        })),
      null === Xo &&
        ((Xo = history.replaceState),
        (history.replaceState = function () {
          Xo.apply(this, arguments), Jo() && zo() && Ho();
        }));
  }
  function Bo() {
    (Lo = null), (Wo = 0), Mo(), Po(), wi(), (s = 0), (Fo = !1);
  }
  function Jo() {
    return Fo;
  }
  function Go() {
    yu(), B("clarity", "restart");
  }
  var Ko = Object.freeze({
    __proto__: null,
    start: function () {
      !(function () {
        (Jt = []), $(26, navigator.webdriver ? 1 : 0);
        try {
          $(31, window.top == window.self || window.top == window ? 1 : 2);
        } catch (t) {
          $(31, 0);
        }
      })(),
        Do(window, "error", si),
        (ci = {}),
        (fi = {});
    },
    stop: function () {
      fi = {};
    },
  });
  var Zo = Object.freeze({
    __proto__: null,
    hashText: er,
    start: function () {
      var t;
      Un(),
        Fn(),
        Or(),
        (gr = null),
        (fr = new WeakMap()),
        (hr = {}),
        (pr = []),
        (vr = !!window.IntersectionObserver),
        Ha(),
        u.delayDom
          ? Do(window, "load", function () {
              aa();
            })
          : aa(),
        Ii(),
        mn(),
        (function () {
          if (
            window.Animation &&
            window.Animation.prototype &&
            window.KeyframeEffect &&
            window.KeyframeEffect.prototype &&
            window.KeyframeEffect.prototype.getKeyframes &&
            window.KeyframeEffect.prototype.getTiming &&
            (Cn(),
            Pn(On, "play"),
            Pn(En, "pause"),
            Pn(Tn, "commitStyles"),
            Pn(_n, "cancel"),
            Pn(Nn, "finish"),
            null === kn &&
              ((kn = Element.prototype.animate),
              (Element.prototype.animate = function () {
                var t = kn.apply(this, arguments);
                return Rn(t, "play"), t;
              })),
            document.getAnimations)
          )
            for (var t = 0, e = document.getAnimations(); t < e.length; t++) {
              var n = e[t];
              "finished" === n.playState
                ? Rn(n, "finish")
                : "paused" === n.playState || "idle" === n.playState
                ? Rn(n, "pause")
                : "running" === n.playState && Rn(n, "play");
            }
        })(),
        (window.clarityOverrides = window.clarityOverrides || {}),
        (null === (t = window.customElements) || void 0 === t
          ? void 0
          : t.define) &&
          !window.clarityOverrides.define &&
          ((window.clarityOverrides.define = window.customElements.define),
          (window.customElements.define = function () {
            return (
              Jo() && Xn(arguments[0]),
              window.clarityOverrides.define.apply(this, arguments)
            );
          }));
    },
    stop: function () {
      Or(),
        (fr = null),
        (hr = {}),
        (pr = []),
        gr && (gr.disconnect(), (gr = null)),
        (vr = !1),
        qa(),
        (function () {
          for (var t = 0, e = Array.from(Bn); t < e.length; t++) {
            var n = e[t];
            n && n.disconnect();
          }
          (Bn = new Set()),
            (ta = {}),
            (Jn = []),
            (Gn = {}),
            (Kn = []),
            ($n = 0),
            (Zn = null),
            (ea = new WeakMap());
        })(),
        Un(),
        (fn = {}),
        (hn = {}),
        (pn = []),
        (vn = []),
        bn(),
        Cn(),
        Ln(),
        jn.clear();
    },
  });
  var Qo = null;
  function $o() {
    Qo = null;
  }
  function tu(t) {
    (Qo = {
      fetchStart: Math.round(t.fetchStart),
      connectStart: Math.round(t.connectStart),
      connectEnd: Math.round(t.connectEnd),
      requestStart: Math.round(t.requestStart),
      responseStart: Math.round(t.responseStart),
      responseEnd: Math.round(t.responseEnd),
      domInteractive: Math.round(t.domInteractive),
      domComplete: Math.round(t.domComplete),
      loadEventStart: Math.round(t.loadEventStart),
      loadEventEnd: Math.round(t.loadEventEnd),
      redirectCount: Math.round(t.redirectCount),
      size: t.transferSize ? t.transferSize : 0,
      type: t.type,
      protocol: t.nextHopProtocol,
      encodedSize: t.encodedBodySize ? t.encodedBodySize : 0,
      decodedSize: t.decodedBodySize ? t.decodedBodySize : 0,
    }),
      (function (t) {
        ht(this, void 0, void 0, function () {
          var e, n;
          return pt(this, function (a) {
            return (
              (e = d()),
              (n = [e, t]),
              29 === t &&
                (n.push(Qo.fetchStart),
                n.push(Qo.connectStart),
                n.push(Qo.connectEnd),
                n.push(Qo.requestStart),
                n.push(Qo.responseStart),
                n.push(Qo.responseEnd),
                n.push(Qo.domInteractive),
                n.push(Qo.domComplete),
                n.push(Qo.loadEventStart),
                n.push(Qo.loadEventEnd),
                n.push(Qo.redirectCount),
                n.push(Qo.size),
                n.push(Qo.type),
                n.push(Qo.protocol),
                n.push(Qo.encodedSize),
                n.push(Qo.decodedSize),
                $o(),
                ei(n)),
              [2]
            );
          });
        });
      })(29);
  }
  var eu,
    nu = 0,
    au = 1 / 0,
    ru = 0,
    iu = 0,
    ou = [],
    uu = new Map(),
    cu = function () {
      return nu || 0;
    },
    su = function () {
      if (!ou.length) return -1;
      var t = Math.min(ou.length - 1, Math.floor((cu() - iu) / 50));
      return ou[t].latency;
    },
    lu = function () {
      (iu = cu()), (ou.length = 0), uu.clear();
    },
    du = function (t) {
      if (t.interactionId && !(t.duration < 40)) {
        !(function (t) {
          "interactionCount" in performance
            ? (nu = performance.interactionCount)
            : t.interactionId &&
              ((au = Math.min(au, t.interactionId)),
              (ru = Math.max(ru, t.interactionId)),
              (nu = ru ? (ru - au) / 7 + 1 : 0));
        })(t);
        var e = ou[ou.length - 1],
          n = uu.get(t.interactionId);
        if (
          n ||
          ou.length < 10 ||
          t.duration > (null == e ? void 0 : e.latency)
        ) {
          if (n) t.duration > n.latency && (n.latency = t.duration);
          else {
            var a = { id: t.interactionId, latency: t.duration };
            uu.set(a.id, a), ou.push(a);
          }
          ou.sort(function (t, e) {
            return e.latency - t.latency;
          }),
            ou.length > 10 &&
              ou.splice(10).forEach(function (t) {
                return uu.delete(t.id);
              });
        }
      }
    },
    fu = [
      "navigation",
      "resource",
      "longtask",
      "first-input",
      "layout-shift",
      "largest-contentful-paint",
      "event",
    ];
  function hu() {
    try {
      eu && eu.disconnect(), (eu = new PerformanceObserver(Io(pu)));
      for (var t = 0, e = fu; t < e.length; t++) {
        var n = e[t];
        PerformanceObserver.supportedEntryTypes.indexOf(n) >= 0 &&
          ("layout-shift" === n && Q(9, 0),
          eu.observe({ type: n, buffered: !0 }));
      }
    } catch (t) {
      hi(3, 1);
    }
  }
  function pu(t) {
    !(function (t) {
      for (
        var e =
            !("visibilityState" in document) ||
            "visible" === document.visibilityState,
          n = 0;
        n < t.length;
        n++
      ) {
        var a = t[n];
        switch (a.entryType) {
          case "navigation":
            tu(a);
            break;
          case "resource":
            var r = a.name;
            Ji(4, gu(r)),
              (r !== u.upload && r !== u.fallback) || $(28, a.duration);
            break;
          case "longtask":
            Z(7);
            break;
          case "first-input":
            e && $(10, a.processingStart - a.startTime);
            break;
          case "event":
            e &&
              "PerformanceEventTiming" in window &&
              "interactionId" in PerformanceEventTiming.prototype &&
              (du(a), Ji(37, su().toString()));
            break;
          case "layout-shift":
            e && !a.hadRecentInput && Q(9, 1e3 * a.value);
            break;
          case "largest-contentful-paint":
            e && $(8, a.startTime);
        }
      }
    })(t.getEntries());
  }
  var vu = null;
  function gu(t) {
    return vu || (vu = document.createElement("a")), (vu.href = t), vu.host;
  }
  var mu = [
    Ko,
    Zo,
    un,
    Object.freeze({
      __proto__: null,
      start: function () {
        $o(),
          (function () {
            navigator &&
              navigator.connection &&
              Ji(27, navigator.connection.effectiveType),
              window.PerformanceObserver &&
              PerformanceObserver.supportedEntryTypes
                ? "complete" !== document.readyState
                  ? Do(window, "load", tt.bind(this, hu, 0))
                  : hu()
                : hi(3, 0);
          })();
      },
      stop: function () {
        eu && eu.disconnect(), (eu = null), lu(), (vu = null), $o();
      },
    }),
    Jr,
  ];
  function yu(t) {
    void 0 === t && (t = null),
      (function () {
        try {
          var t =
            navigator &&
            "globalPrivacyControl" in navigator &&
            1 == navigator.globalPrivacyControl;
          return (
            !1 === Fo &&
            "undefined" != typeof Promise &&
            window.MutationObserver &&
            document.createTreeWalker &&
            "now" in Date &&
            "now" in performance &&
            "undefined" != typeof WeakMap &&
            !t
          );
        } catch (t) {
          return !1;
        }
      })() &&
        (!(function (t) {
          if (null === t || Fo) return !1;
          for (var e in t) e in u && (u[e] = t[e]);
        })(t),
        Vo(),
        Ut(),
        mu.forEach(function (t) {
          return Io(t.start)();
        }),
        null === t && Ou());
  }
  function bu() {
    Jo() &&
      (mu
        .slice()
        .reverse()
        .forEach(function (t) {
          return Io(t.stop)();
        }),
      Ft(),
      Bo(),
      void 0 !== Su &&
        (Su[ku] = function () {
          (Su[ku].q = Su[ku].q || []).push(arguments),
            "start" === arguments[0] &&
              Su[ku].q.unshift(Su[ku].q.pop()) &&
              Ou();
        }));
  }
  var wu = Object.freeze({
      __proto__: null,
      consent: uo,
      consentv2: co,
      dlog: Ji,
      event: B,
      hashText: er,
      identify: wt,
      maxMetric: $,
      measure: Io,
      metadata: io,
      pause: function () {
        Jo() &&
          (B("clarity", "pause"),
          null === yi &&
            (yi = new Promise(function (t) {
              bi = t;
            })));
      },
      queue: ei,
      register: zr,
      resume: function () {
        Jo() &&
          (yi && (bi(), (yi = null), null === mi && ki()),
          B("clarity", "resume"));
      },
      schedule: Si,
      set: bt,
      signal: function (t) {
        zt = t;
      },
      start: yu,
      stop: bu,
      time: d,
      upgrade: Ai,
      version: f,
    }),
    Su = window,
    ku = "clarity";
  function Ou() {
    if (void 0 !== Su) {
      if (Su[ku] && Su[ku].v)
        return console.warn("Error CL001: Multiple Clarity tags detected.");
      var t = (Su[ku] && Su[ku].q) || [];
      for (
        Su[ku] = function (t) {
          for (var e = [], n = 1; n < arguments.length; n++)
            e[n - 1] = arguments[n];
          return wu[t].apply(wu, e);
        },
          Su[ku].v = f;
        t.length > 0;

      )
        Su[ku].apply(Su, t.shift());
    }
  }
  Ou();
})();
