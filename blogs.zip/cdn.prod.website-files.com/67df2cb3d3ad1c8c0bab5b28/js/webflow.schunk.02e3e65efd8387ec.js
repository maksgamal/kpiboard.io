(self.webpackChunk = self.webpackChunk || []).push([
  ["999"],
  {
    5487: function () {
      "use strict";
      window.tram = (function (e) {
        function t(e, t) {
          return new F.Bare().init(e, t);
        }
        function n(e) {
          var t = parseInt(e.slice(1), 16);
          return [(t >> 16) & 255, (t >> 8) & 255, 255 & t];
        }
        function a(e, t, n) {
          return (
            "#" + (0x1000000 | (e << 16) | (t << 8) | n).toString(16).slice(1)
          );
        }
        function i() {}
        function o(e, t, n) {
          if ((void 0 !== t && (n = t), void 0 === e)) return n;
          var a = n;
          return (
            Y.test(e) || !$.test(e)
              ? (a = parseInt(e, 10))
              : $.test(e) && (a = 1e3 * parseFloat(e)),
            0 > a && (a = 0),
            a == a ? a : n
          );
        }
        function l(e) {
          W.debug && window && window.console.warn(e);
        }
        var c,
          r,
          d,
          s = (function (e, t, n) {
            function a(e) {
              return "object" == typeof e;
            }
            function i(e) {
              return "function" == typeof e;
            }
            function o() {}
            return function l(c, r) {
              function d() {
                var e = new s();
                return i(e.init) && e.init.apply(e, arguments), e;
              }
              function s() {}
              r === n && ((r = c), (c = Object)), (d.Bare = s);
              var u,
                f = (o[e] = c[e]),
                p = (s[e] = d[e] = new o());
              return (
                (p.constructor = d),
                (d.mixin = function (t) {
                  return (s[e] = d[e] = l(d, t)[e]), d;
                }),
                (d.open = function (e) {
                  if (
                    ((u = {}),
                    i(e) ? (u = e.call(d, p, f, d, c)) : a(e) && (u = e),
                    a(u))
                  )
                    for (var n in u) t.call(u, n) && (p[n] = u[n]);
                  return i(p.init) || (p.init = c), d;
                }),
                d.open(r)
              );
            };
          })("prototype", {}.hasOwnProperty),
          u = {
            ease: [
              "ease",
              function (e, t, n, a) {
                var i = (e /= a) * e,
                  o = i * e;
                return (
                  t +
                  n *
                    (-2.75 * o * i + 11 * i * i + -15.5 * o + 8 * i + 0.25 * e)
                );
              },
            ],
            "ease-in": [
              "ease-in",
              function (e, t, n, a) {
                var i = (e /= a) * e,
                  o = i * e;
                return t + n * (-1 * o * i + 3 * i * i + -3 * o + 2 * i);
              },
            ],
            "ease-out": [
              "ease-out",
              function (e, t, n, a) {
                var i = (e /= a) * e,
                  o = i * e;
                return (
                  t +
                  n *
                    (0.3 * o * i + -1.6 * i * i + 2.2 * o + -1.8 * i + 1.9 * e)
                );
              },
            ],
            "ease-in-out": [
              "ease-in-out",
              function (e, t, n, a) {
                var i = (e /= a) * e,
                  o = i * e;
                return t + n * (2 * o * i + -5 * i * i + 2 * o + 2 * i);
              },
            ],
            linear: [
              "linear",
              function (e, t, n, a) {
                return (n * e) / a + t;
              },
            ],
            "ease-in-quad": [
              "cubic-bezier(0.550, 0.085, 0.680, 0.530)",
              function (e, t, n, a) {
                return n * (e /= a) * e + t;
              },
            ],
            "ease-out-quad": [
              "cubic-bezier(0.250, 0.460, 0.450, 0.940)",
              function (e, t, n, a) {
                return -n * (e /= a) * (e - 2) + t;
              },
            ],
            "ease-in-out-quad": [
              "cubic-bezier(0.455, 0.030, 0.515, 0.955)",
              function (e, t, n, a) {
                return (e /= a / 2) < 1
                  ? (n / 2) * e * e + t
                  : (-n / 2) * (--e * (e - 2) - 1) + t;
              },
            ],
            "ease-in-cubic": [
              "cubic-bezier(0.550, 0.055, 0.675, 0.190)",
              function (e, t, n, a) {
                return n * (e /= a) * e * e + t;
              },
            ],
            "ease-out-cubic": [
              "cubic-bezier(0.215, 0.610, 0.355, 1)",
              function (e, t, n, a) {
                return n * ((e = e / a - 1) * e * e + 1) + t;
              },
            ],
            "ease-in-out-cubic": [
              "cubic-bezier(0.645, 0.045, 0.355, 1)",
              function (e, t, n, a) {
                return (e /= a / 2) < 1
                  ? (n / 2) * e * e * e + t
                  : (n / 2) * ((e -= 2) * e * e + 2) + t;
              },
            ],
            "ease-in-quart": [
              "cubic-bezier(0.895, 0.030, 0.685, 0.220)",
              function (e, t, n, a) {
                return n * (e /= a) * e * e * e + t;
              },
            ],
            "ease-out-quart": [
              "cubic-bezier(0.165, 0.840, 0.440, 1)",
              function (e, t, n, a) {
                return -n * ((e = e / a - 1) * e * e * e - 1) + t;
              },
            ],
            "ease-in-out-quart": [
              "cubic-bezier(0.770, 0, 0.175, 1)",
              function (e, t, n, a) {
                return (e /= a / 2) < 1
                  ? (n / 2) * e * e * e * e + t
                  : (-n / 2) * ((e -= 2) * e * e * e - 2) + t;
              },
            ],
            "ease-in-quint": [
              "cubic-bezier(0.755, 0.050, 0.855, 0.060)",
              function (e, t, n, a) {
                return n * (e /= a) * e * e * e * e + t;
              },
            ],
            "ease-out-quint": [
              "cubic-bezier(0.230, 1, 0.320, 1)",
              function (e, t, n, a) {
                return n * ((e = e / a - 1) * e * e * e * e + 1) + t;
              },
            ],
            "ease-in-out-quint": [
              "cubic-bezier(0.860, 0, 0.070, 1)",
              function (e, t, n, a) {
                return (e /= a / 2) < 1
                  ? (n / 2) * e * e * e * e * e + t
                  : (n / 2) * ((e -= 2) * e * e * e * e + 2) + t;
              },
            ],
            "ease-in-sine": [
              "cubic-bezier(0.470, 0, 0.745, 0.715)",
              function (e, t, n, a) {
                return -n * Math.cos((e / a) * (Math.PI / 2)) + n + t;
              },
            ],
            "ease-out-sine": [
              "cubic-bezier(0.390, 0.575, 0.565, 1)",
              function (e, t, n, a) {
                return n * Math.sin((e / a) * (Math.PI / 2)) + t;
              },
            ],
            "ease-in-out-sine": [
              "cubic-bezier(0.445, 0.050, 0.550, 0.950)",
              function (e, t, n, a) {
                return (-n / 2) * (Math.cos((Math.PI * e) / a) - 1) + t;
              },
            ],
            "ease-in-expo": [
              "cubic-bezier(0.950, 0.050, 0.795, 0.035)",
              function (e, t, n, a) {
                return 0 === e ? t : n * Math.pow(2, 10 * (e / a - 1)) + t;
              },
            ],
            "ease-out-expo": [
              "cubic-bezier(0.190, 1, 0.220, 1)",
              function (e, t, n, a) {
                return e === a
                  ? t + n
                  : n * (-Math.pow(2, (-10 * e) / a) + 1) + t;
              },
            ],
            "ease-in-out-expo": [
              "cubic-bezier(1, 0, 0, 1)",
              function (e, t, n, a) {
                return 0 === e
                  ? t
                  : e === a
                  ? t + n
                  : (e /= a / 2) < 1
                  ? (n / 2) * Math.pow(2, 10 * (e - 1)) + t
                  : (n / 2) * (-Math.pow(2, -10 * --e) + 2) + t;
              },
            ],
            "ease-in-circ": [
              "cubic-bezier(0.600, 0.040, 0.980, 0.335)",
              function (e, t, n, a) {
                return -n * (Math.sqrt(1 - (e /= a) * e) - 1) + t;
              },
            ],
            "ease-out-circ": [
              "cubic-bezier(0.075, 0.820, 0.165, 1)",
              function (e, t, n, a) {
                return n * Math.sqrt(1 - (e = e / a - 1) * e) + t;
              },
            ],
            "ease-in-out-circ": [
              "cubic-bezier(0.785, 0.135, 0.150, 0.860)",
              function (e, t, n, a) {
                return (e /= a / 2) < 1
                  ? (-n / 2) * (Math.sqrt(1 - e * e) - 1) + t
                  : (n / 2) * (Math.sqrt(1 - (e -= 2) * e) + 1) + t;
              },
            ],
            "ease-in-back": [
              "cubic-bezier(0.600, -0.280, 0.735, 0.045)",
              function (e, t, n, a, i) {
                return (
                  void 0 === i && (i = 1.70158),
                  n * (e /= a) * e * ((i + 1) * e - i) + t
                );
              },
            ],
            "ease-out-back": [
              "cubic-bezier(0.175, 0.885, 0.320, 1.275)",
              function (e, t, n, a, i) {
                return (
                  void 0 === i && (i = 1.70158),
                  n * ((e = e / a - 1) * e * ((i + 1) * e + i) + 1) + t
                );
              },
            ],
            "ease-in-out-back": [
              "cubic-bezier(0.680, -0.550, 0.265, 1.550)",
              function (e, t, n, a, i) {
                return (
                  void 0 === i && (i = 1.70158),
                  (e /= a / 2) < 1
                    ? (n / 2) * e * e * (((i *= 1.525) + 1) * e - i) + t
                    : (n / 2) *
                        ((e -= 2) * e * (((i *= 1.525) + 1) * e + i) + 2) +
                      t
                );
              },
            ],
          },
          f = {
            "ease-in-back": "cubic-bezier(0.600, 0, 0.735, 0.045)",
            "ease-out-back": "cubic-bezier(0.175, 0.885, 0.320, 1)",
            "ease-in-out-back": "cubic-bezier(0.680, 0, 0.265, 1)",
          },
          p = window,
          E = "bkwld-tram",
          b = /[\-\.0-9]/g,
          I = /[A-Z]/,
          y = "number",
          m = /^(rgb|#)/,
          g = /(em|cm|mm|in|pt|pc|px)$/,
          T = /(em|cm|mm|in|pt|pc|px|%)$/,
          O = /(deg|rad|turn)$/,
          _ = "unitless",
          v = /(all|none) 0s ease 0s/,
          h = /^(width|height)$/,
          R = document.createElement("a"),
          A = ["Webkit", "Moz", "O", "ms"],
          N = ["-webkit-", "-moz-", "-o-", "-ms-"],
          L = function (e) {
            if (e in R.style) return { dom: e, css: e };
            var t,
              n,
              a = "",
              i = e.split("-");
            for (t = 0; t < i.length; t++)
              a += i[t].charAt(0).toUpperCase() + i[t].slice(1);
            for (t = 0; t < A.length; t++)
              if ((n = A[t] + a) in R.style) return { dom: n, css: N[t] + e };
          },
          S = (t.support = {
            bind: Function.prototype.bind,
            transform: L("transform"),
            transition: L("transition"),
            backface: L("backface-visibility"),
            timing: L("transition-timing-function"),
          });
        if (S.transition) {
          var C = S.timing.dom;
          if (((R.style[C] = u["ease-in-back"][0]), !R.style[C]))
            for (var w in f) u[w][0] = f[w];
        }
        var M = (t.frame =
            (c =
              p.requestAnimationFrame ||
              p.webkitRequestAnimationFrame ||
              p.mozRequestAnimationFrame ||
              p.oRequestAnimationFrame ||
              p.msRequestAnimationFrame) && S.bind
              ? c.bind(p)
              : function (e) {
                  p.setTimeout(e, 16);
                }),
          P = (t.now =
            (d =
              (r = p.performance) &&
              (r.now || r.webkitNow || r.msNow || r.mozNow)) && S.bind
              ? d.bind(r)
              : Date.now ||
                function () {
                  return +new Date();
                }),
          G = s(function (t) {
            function n(e, t) {
              var n = (function (e) {
                  for (var t = -1, n = e ? e.length : 0, a = []; ++t < n; ) {
                    var i = e[t];
                    i && a.push(i);
                  }
                  return a;
                })(("" + e).split(" ")),
                a = n[0];
              t = t || {};
              var i = H[a];
              if (!i) return l("Unsupported property: " + a);
              if (!t.weak || !this.props[a]) {
                var o = i[0],
                  c = this.props[a];
                return (
                  c || (c = this.props[a] = new o.Bare()),
                  c.init(this.$el, n, i, t),
                  c
                );
              }
            }
            function a(e, t, a) {
              if (e) {
                var l = typeof e;
                if (
                  (t ||
                    (this.timer && this.timer.destroy(),
                    (this.queue = []),
                    (this.active = !1)),
                  "number" == l && t)
                )
                  return (
                    (this.timer = new B({
                      duration: e,
                      context: this,
                      complete: i,
                    })),
                    void (this.active = !0)
                  );
                if ("string" == l && t) {
                  switch (e) {
                    case "hide":
                      r.call(this);
                      break;
                    case "stop":
                      c.call(this);
                      break;
                    case "redraw":
                      d.call(this);
                      break;
                    default:
                      n.call(this, e, a && a[1]);
                  }
                  return i.call(this);
                }
                if ("function" == l) return void e.call(this, this);
                if ("object" == l) {
                  var f = 0;
                  u.call(
                    this,
                    e,
                    function (e, t) {
                      e.span > f && (f = e.span), e.stop(), e.animate(t);
                    },
                    function (e) {
                      "wait" in e && (f = o(e.wait, 0));
                    }
                  ),
                    s.call(this),
                    f > 0 &&
                      ((this.timer = new B({ duration: f, context: this })),
                      (this.active = !0),
                      t && (this.timer.complete = i));
                  var p = this,
                    E = !1,
                    b = {};
                  M(function () {
                    u.call(p, e, function (e) {
                      e.active && ((E = !0), (b[e.name] = e.nextStyle));
                    }),
                      E && p.$el.css(b);
                  });
                }
              }
            }
            function i() {
              if (
                (this.timer && this.timer.destroy(),
                (this.active = !1),
                this.queue.length)
              ) {
                var e = this.queue.shift();
                a.call(this, e.options, !0, e.args);
              }
            }
            function c(e) {
              var t;
              this.timer && this.timer.destroy(),
                (this.queue = []),
                (this.active = !1),
                "string" == typeof e
                  ? ((t = {})[e] = 1)
                  : (t = "object" == typeof e && null != e ? e : this.props),
                u.call(this, t, f),
                s.call(this);
            }
            function r() {
              c.call(this), (this.el.style.display = "none");
            }
            function d() {
              this.el.offsetHeight;
            }
            function s() {
              var e,
                t,
                n = [];
              for (e in (this.upstream && n.push(this.upstream), this.props))
                (t = this.props[e]).active && n.push(t.string);
              (n = n.join(",")),
                this.style !== n &&
                  ((this.style = n), (this.el.style[S.transition.dom] = n));
            }
            function u(e, t, a) {
              var i,
                o,
                l,
                c,
                r = t !== f,
                d = {};
              for (i in e)
                (l = e[i]),
                  i in q
                    ? (d.transform || (d.transform = {}), (d.transform[i] = l))
                    : (I.test(i) &&
                        (i = i.replace(/[A-Z]/g, function (e) {
                          return "-" + e.toLowerCase();
                        })),
                      i in H ? (d[i] = l) : (c || (c = {}), (c[i] = l)));
              for (i in d) {
                if (((l = d[i]), !(o = this.props[i]))) {
                  if (!r) continue;
                  o = n.call(this, i);
                }
                t.call(this, o, l);
              }
              a && c && a.call(this, c);
            }
            function f(e) {
              e.stop();
            }
            function p(e, t) {
              e.set(t);
            }
            function b(e) {
              this.$el.css(e);
            }
            function y(e, n) {
              t[e] = function () {
                return this.children
                  ? m.call(this, n, arguments)
                  : (this.el && n.apply(this, arguments), this);
              };
            }
            function m(e, t) {
              var n,
                a = this.children.length;
              for (n = 0; a > n; n++) e.apply(this.children[n], t);
              return this;
            }
            (t.init = function (t) {
              if (
                ((this.$el = e(t)),
                (this.el = this.$el[0]),
                (this.props = {}),
                (this.queue = []),
                (this.style = ""),
                (this.active = !1),
                W.keepInherited && !W.fallback)
              ) {
                var n = Q(this.el, "transition");
                n && !v.test(n) && (this.upstream = n);
              }
              S.backface &&
                W.hideBackface &&
                j(this.el, S.backface.css, "hidden");
            }),
              y("add", n),
              y("start", a),
              y("wait", function (e) {
                (e = o(e, 0)),
                  this.active
                    ? this.queue.push({ options: e })
                    : ((this.timer = new B({
                        duration: e,
                        context: this,
                        complete: i,
                      })),
                      (this.active = !0));
              }),
              y("then", function (e) {
                return this.active
                  ? (this.queue.push({ options: e, args: arguments }),
                    void (this.timer.complete = i))
                  : l(
                      "No active transition timer. Use start() or wait() before then()."
                    );
              }),
              y("next", i),
              y("stop", c),
              y("set", function (e) {
                c.call(this, e), u.call(this, e, p, b);
              }),
              y("show", function (e) {
                "string" != typeof e && (e = "block"),
                  (this.el.style.display = e);
              }),
              y("hide", r),
              y("redraw", d),
              y("destroy", function () {
                c.call(this),
                  e.removeData(this.el, E),
                  (this.$el = this.el = null);
              });
          }),
          F = s(G, function (t) {
            function n(t, n) {
              var a = e.data(t, E) || e.data(t, E, new G.Bare());
              return a.el || a.init(t), n ? a.start(n) : a;
            }
            t.init = function (t, a) {
              var i = e(t);
              if (!i.length) return this;
              if (1 === i.length) return n(i[0], a);
              var o = [];
              return (
                i.each(function (e, t) {
                  o.push(n(t, a));
                }),
                (this.children = o),
                this
              );
            };
          }),
          U = s(function (e) {
            function t() {
              var e = this.get();
              this.update("auto");
              var t = this.get();
              return this.update(e), t;
            }
            (e.init = function (e, t, n, a) {
              (this.$el = e), (this.el = e[0]);
              var i,
                l,
                c,
                r = t[0];
              n[2] && (r = n[2]),
                z[r] && (r = z[r]),
                (this.name = r),
                (this.type = n[1]),
                (this.duration = o(t[1], this.duration, 500)),
                (this.ease =
                  ((i = t[2]),
                  (l = this.ease),
                  (c = "ease"),
                  void 0 !== l && (c = l),
                  i in u ? i : c)),
                (this.delay = o(t[3], this.delay, 0)),
                (this.span = this.duration + this.delay),
                (this.active = !1),
                (this.nextStyle = null),
                (this.auto = h.test(this.name)),
                (this.unit = a.unit || this.unit || W.defaultUnit),
                (this.angle = a.angle || this.angle || W.defaultAngle),
                W.fallback || a.fallback
                  ? (this.animate = this.fallback)
                  : ((this.animate = this.transition),
                    (this.string =
                      this.name +
                      " " +
                      this.duration +
                      "ms" +
                      ("ease" != this.ease ? " " + u[this.ease][0] : "") +
                      (this.delay ? " " + this.delay + "ms" : "")));
            }),
              (e.set = function (e) {
                (e = this.convert(e, this.type)), this.update(e), this.redraw();
              }),
              (e.transition = function (e) {
                (this.active = !0),
                  (e = this.convert(e, this.type)),
                  this.auto &&
                    ("auto" == this.el.style[this.name] &&
                      (this.update(this.get()), this.redraw()),
                    "auto" == e && (e = t.call(this))),
                  (this.nextStyle = e);
              }),
              (e.fallback = function (e) {
                var n =
                  this.el.style[this.name] ||
                  this.convert(this.get(), this.type);
                (e = this.convert(e, this.type)),
                  this.auto &&
                    ("auto" == n && (n = this.convert(this.get(), this.type)),
                    "auto" == e && (e = t.call(this))),
                  (this.tween = new V({
                    from: n,
                    to: e,
                    duration: this.duration,
                    delay: this.delay,
                    ease: this.ease,
                    update: this.update,
                    context: this,
                  }));
              }),
              (e.get = function () {
                return Q(this.el, this.name);
              }),
              (e.update = function (e) {
                j(this.el, this.name, e);
              }),
              (e.stop = function () {
                (this.active || this.nextStyle) &&
                  ((this.active = !1),
                  (this.nextStyle = null),
                  j(this.el, this.name, this.get()));
                var e = this.tween;
                e && e.context && e.destroy();
              }),
              (e.convert = function (e, t) {
                if ("auto" == e && this.auto) return e;
                var n,
                  i,
                  o = "number" == typeof e,
                  c = "string" == typeof e;
                switch (t) {
                  case y:
                    if (o) return e;
                    if (c && "" === e.replace(b, "")) return +e;
                    i = "number(unitless)";
                    break;
                  case m:
                    if (c) {
                      if ("" === e && this.original) return this.original;
                      if (t.test(e))
                        return "#" == e.charAt(0) && 7 == e.length
                          ? e
                          : ((n = /rgba?\((\d+),\s*(\d+),\s*(\d+)/.exec(e))
                              ? a(n[1], n[2], n[3])
                              : e
                            ).replace(/#(\w)(\w)(\w)$/, "#$1$1$2$2$3$3");
                    }
                    i = "hex or rgb string";
                    break;
                  case g:
                    if (o) return e + this.unit;
                    if (c && t.test(e)) return e;
                    i = "number(px) or string(unit)";
                    break;
                  case T:
                    if (o) return e + this.unit;
                    if (c && t.test(e)) return e;
                    i = "number(px) or string(unit or %)";
                    break;
                  case O:
                    if (o) return e + this.angle;
                    if (c && t.test(e)) return e;
                    i = "number(deg) or string(angle)";
                    break;
                  case _:
                    if (o || (c && T.test(e))) return e;
                    i = "number(unitless) or string(unit or %)";
                }
                return (
                  l(
                    "Type warning: Expected: [" +
                      i +
                      "] Got: [" +
                      typeof e +
                      "] " +
                      e
                  ),
                  e
                );
              }),
              (e.redraw = function () {
                this.el.offsetHeight;
              });
          }),
          x = s(U, function (e, t) {
            e.init = function () {
              t.init.apply(this, arguments),
                this.original || (this.original = this.convert(this.get(), m));
            };
          }),
          k = s(U, function (e, t) {
            (e.init = function () {
              t.init.apply(this, arguments), (this.animate = this.fallback);
            }),
              (e.get = function () {
                return this.$el[this.name]();
              }),
              (e.update = function (e) {
                this.$el[this.name](e);
              });
          }),
          D = s(U, function (e, t) {
            function n(e, t) {
              var n, a, i, o, l;
              for (n in e)
                (i = (o = q[n])[0]),
                  (a = o[1] || n),
                  (l = this.convert(e[n], i)),
                  t.call(this, a, l, i);
            }
            (e.init = function () {
              t.init.apply(this, arguments),
                this.current ||
                  ((this.current = {}),
                  q.perspective &&
                    W.perspective &&
                    ((this.current.perspective = W.perspective),
                    j(this.el, this.name, this.style(this.current)),
                    this.redraw()));
            }),
              (e.set = function (e) {
                n.call(this, e, function (e, t) {
                  this.current[e] = t;
                }),
                  j(this.el, this.name, this.style(this.current)),
                  this.redraw();
              }),
              (e.transition = function (e) {
                var t = this.values(e);
                this.tween = new X({
                  current: this.current,
                  values: t,
                  duration: this.duration,
                  delay: this.delay,
                  ease: this.ease,
                });
                var n,
                  a = {};
                for (n in this.current) a[n] = n in t ? t[n] : this.current[n];
                (this.active = !0), (this.nextStyle = this.style(a));
              }),
              (e.fallback = function (e) {
                var t = this.values(e);
                this.tween = new X({
                  current: this.current,
                  values: t,
                  duration: this.duration,
                  delay: this.delay,
                  ease: this.ease,
                  update: this.update,
                  context: this,
                });
              }),
              (e.update = function () {
                j(this.el, this.name, this.style(this.current));
              }),
              (e.style = function (e) {
                var t,
                  n = "";
                for (t in e) n += t + "(" + e[t] + ") ";
                return n;
              }),
              (e.values = function (e) {
                var t,
                  a = {};
                return (
                  n.call(this, e, function (e, n, i) {
                    (a[e] = n),
                      void 0 === this.current[e] &&
                        ((t = 0),
                        ~e.indexOf("scale") && (t = 1),
                        (this.current[e] = this.convert(t, i)));
                  }),
                  a
                );
              });
          }),
          V = s(function (t) {
            function o() {
              var e,
                t,
                n,
                a = r.length;
              if (a)
                for (M(o), t = P(), e = a; e--; ) (n = r[e]) && n.render(t);
            }
            var c = { ease: u.ease[1], from: 0, to: 1 };
            (t.init = function (e) {
              (this.duration = e.duration || 0), (this.delay = e.delay || 0);
              var t = e.ease || c.ease;
              u[t] && (t = u[t][1]),
                "function" != typeof t && (t = c.ease),
                (this.ease = t),
                (this.update = e.update || i),
                (this.complete = e.complete || i),
                (this.context = e.context || this),
                (this.name = e.name);
              var n = e.from,
                a = e.to;
              void 0 === n && (n = c.from),
                void 0 === a && (a = c.to),
                (this.unit = e.unit || ""),
                "number" == typeof n && "number" == typeof a
                  ? ((this.begin = n), (this.change = a - n))
                  : this.format(a, n),
                (this.value = this.begin + this.unit),
                (this.start = P()),
                !1 !== e.autoplay && this.play();
            }),
              (t.play = function () {
                this.active ||
                  (this.start || (this.start = P()),
                  (this.active = !0),
                  1 === r.push(this) && M(o));
              }),
              (t.stop = function () {
                var t, n;
                this.active &&
                  ((this.active = !1),
                  (n = e.inArray(this, r)) >= 0 &&
                    ((t = r.slice(n + 1)),
                    (r.length = n),
                    t.length && (r = r.concat(t))));
              }),
              (t.render = function (e) {
                var t,
                  n = e - this.start;
                if (this.delay) {
                  if (n <= this.delay) return;
                  n -= this.delay;
                }
                if (n < this.duration) {
                  var i,
                    o,
                    l = this.ease(n, 0, 1, this.duration);
                  return (
                    (t = this.startRGB
                      ? ((i = this.startRGB),
                        (o = this.endRGB),
                        a(
                          i[0] + l * (o[0] - i[0]),
                          i[1] + l * (o[1] - i[1]),
                          i[2] + l * (o[2] - i[2])
                        ))
                      : Math.round((this.begin + l * this.change) * d) / d),
                    (this.value = t + this.unit),
                    void this.update.call(this.context, this.value)
                  );
                }
                (t = this.endHex || this.begin + this.change),
                  (this.value = t + this.unit),
                  this.update.call(this.context, this.value),
                  this.complete.call(this.context),
                  this.destroy();
              }),
              (t.format = function (e, t) {
                if (((t += ""), "#" == (e += "").charAt(0)))
                  return (
                    (this.startRGB = n(t)),
                    (this.endRGB = n(e)),
                    (this.endHex = e),
                    (this.begin = 0),
                    void (this.change = 1)
                  );
                if (!this.unit) {
                  var a = t.replace(b, "");
                  a !== e.replace(b, "") &&
                    l("Units do not match [tween]: " + t + ", " + e),
                    (this.unit = a);
                }
                (t = parseFloat(t)),
                  (e = parseFloat(e)),
                  (this.begin = this.value = t),
                  (this.change = e - t);
              }),
              (t.destroy = function () {
                this.stop(),
                  (this.context = null),
                  (this.ease = this.update = this.complete = i);
              });
            var r = [],
              d = 1e3;
          }),
          B = s(V, function (e) {
            (e.init = function (e) {
              (this.duration = e.duration || 0),
                (this.complete = e.complete || i),
                (this.context = e.context),
                this.play();
            }),
              (e.render = function (e) {
                e - this.start < this.duration ||
                  (this.complete.call(this.context), this.destroy());
              });
          }),
          X = s(V, function (e, t) {
            (e.init = function (e) {
              var t, n;
              for (t in ((this.context = e.context),
              (this.update = e.update),
              (this.tweens = []),
              (this.current = e.current),
              e.values))
                (n = e.values[t]),
                  this.current[t] !== n &&
                    this.tweens.push(
                      new V({
                        name: t,
                        from: this.current[t],
                        to: n,
                        duration: e.duration,
                        delay: e.delay,
                        ease: e.ease,
                        autoplay: !1,
                      })
                    );
              this.play();
            }),
              (e.render = function (e) {
                var t,
                  n,
                  a = this.tweens.length,
                  i = !1;
                for (t = a; t--; )
                  (n = this.tweens[t]).context &&
                    (n.render(e), (this.current[n.name] = n.value), (i = !0));
                return i
                  ? void (this.update && this.update.call(this.context))
                  : this.destroy();
              }),
              (e.destroy = function () {
                if ((t.destroy.call(this), this.tweens)) {
                  var e;
                  for (e = this.tweens.length; e--; ) this.tweens[e].destroy();
                  (this.tweens = null), (this.current = null);
                }
              });
          }),
          W = (t.config = {
            debug: !1,
            defaultUnit: "px",
            defaultAngle: "deg",
            keepInherited: !1,
            hideBackface: !1,
            perspective: "",
            fallback: !S.transition,
            agentTests: [],
          });
        (t.fallback = function (e) {
          if (!S.transition) return (W.fallback = !0);
          W.agentTests.push("(" + e + ")");
          var t = RegExp(W.agentTests.join("|"), "i");
          W.fallback = t.test(navigator.userAgent);
        }),
          t.fallback("6.0.[2-5] Safari"),
          (t.tween = function (e) {
            return new V(e);
          }),
          (t.delay = function (e, t, n) {
            return new B({ complete: t, duration: e, context: n });
          }),
          (e.fn.tram = function (e) {
            return t.call(null, this, e);
          });
        var j = e.style,
          Q = e.css,
          z = { transform: S.transform && S.transform.css },
          H = {
            color: [x, m],
            background: [x, m, "background-color"],
            "outline-color": [x, m],
            "border-color": [x, m],
            "border-top-color": [x, m],
            "border-right-color": [x, m],
            "border-bottom-color": [x, m],
            "border-left-color": [x, m],
            "border-width": [U, g],
            "border-top-width": [U, g],
            "border-right-width": [U, g],
            "border-bottom-width": [U, g],
            "border-left-width": [U, g],
            "border-spacing": [U, g],
            "letter-spacing": [U, g],
            margin: [U, g],
            "margin-top": [U, g],
            "margin-right": [U, g],
            "margin-bottom": [U, g],
            "margin-left": [U, g],
            padding: [U, g],
            "padding-top": [U, g],
            "padding-right": [U, g],
            "padding-bottom": [U, g],
            "padding-left": [U, g],
            "outline-width": [U, g],
            opacity: [U, y],
            top: [U, T],
            right: [U, T],
            bottom: [U, T],
            left: [U, T],
            "font-size": [U, T],
            "text-indent": [U, T],
            "word-spacing": [U, T],
            width: [U, T],
            "min-width": [U, T],
            "max-width": [U, T],
            height: [U, T],
            "min-height": [U, T],
            "max-height": [U, T],
            "line-height": [U, _],
            "scroll-top": [k, y, "scrollTop"],
            "scroll-left": [k, y, "scrollLeft"],
          },
          q = {};
        S.transform &&
          ((H.transform = [D]),
          (q = {
            x: [T, "translateX"],
            y: [T, "translateY"],
            rotate: [O],
            rotateX: [O],
            rotateY: [O],
            scale: [y],
            scaleX: [y],
            scaleY: [y],
            skew: [O],
            skewX: [O],
            skewY: [O],
          })),
          S.transform &&
            S.backface &&
            ((q.z = [T, "translateZ"]),
            (q.rotateZ = [O]),
            (q.scaleZ = [y]),
            (q.perspective = [g]));
        var Y = /ms/,
          $ = /s|\./;
        return (e.tram = t);
      })(window.jQuery);
    },
    5756: function (e, t, n) {
      "use strict";
      var a,
        i,
        o,
        l,
        c,
        r,
        d,
        s,
        u,
        f,
        p,
        E,
        b,
        I,
        y,
        m,
        g,
        T,
        O,
        _,
        v = window.$,
        h = n(5487) && v.tram;
      ((a = {}).VERSION = "1.6.0-Webflow"),
        (i = {}),
        (o = Array.prototype),
        (l = Object.prototype),
        (c = Function.prototype),
        o.push,
        (r = o.slice),
        o.concat,
        l.toString,
        (d = l.hasOwnProperty),
        (s = o.forEach),
        (u = o.map),
        o.reduce,
        o.reduceRight,
        (f = o.filter),
        o.every,
        (p = o.some),
        (E = o.indexOf),
        o.lastIndexOf,
        (b = Object.keys),
        c.bind,
        (I =
          a.each =
          a.forEach =
            function (e, t, n) {
              if (null == e) return e;
              if (s && e.forEach === s) e.forEach(t, n);
              else if (e.length === +e.length) {
                for (var o = 0, l = e.length; o < l; o++)
                  if (t.call(n, e[o], o, e) === i) return;
              } else
                for (var c = a.keys(e), o = 0, l = c.length; o < l; o++)
                  if (t.call(n, e[c[o]], c[o], e) === i) return;
              return e;
            }),
        (a.map = a.collect =
          function (e, t, n) {
            var a = [];
            return null == e
              ? a
              : u && e.map === u
              ? e.map(t, n)
              : (I(e, function (e, i, o) {
                  a.push(t.call(n, e, i, o));
                }),
                a);
          }),
        (a.find = a.detect =
          function (e, t, n) {
            var a;
            return (
              y(e, function (e, i, o) {
                if (t.call(n, e, i, o)) return (a = e), !0;
              }),
              a
            );
          }),
        (a.filter = a.select =
          function (e, t, n) {
            var a = [];
            return null == e
              ? a
              : f && e.filter === f
              ? e.filter(t, n)
              : (I(e, function (e, i, o) {
                  t.call(n, e, i, o) && a.push(e);
                }),
                a);
          }),
        (y =
          a.some =
          a.any =
            function (e, t, n) {
              t || (t = a.identity);
              var o = !1;
              return null == e
                ? o
                : p && e.some === p
                ? e.some(t, n)
                : (I(e, function (e, a, l) {
                    if (o || (o = t.call(n, e, a, l))) return i;
                  }),
                  !!o);
            }),
        (a.contains = a.include =
          function (e, t) {
            return (
              null != e &&
              (E && e.indexOf === E
                ? -1 != e.indexOf(t)
                : y(e, function (e) {
                    return e === t;
                  }))
            );
          }),
        (a.delay = function (e, t) {
          var n = r.call(arguments, 2);
          return setTimeout(function () {
            return e.apply(null, n);
          }, t);
        }),
        (a.defer = function (e) {
          return a.delay.apply(a, [e, 1].concat(r.call(arguments, 1)));
        }),
        (a.throttle = function (e) {
          var t, n, a;
          return function () {
            t ||
              ((t = !0),
              (n = arguments),
              (a = this),
              h.frame(function () {
                (t = !1), e.apply(a, n);
              }));
          };
        }),
        (a.debounce = function (e, t, n) {
          var i,
            o,
            l,
            c,
            r,
            d = function () {
              var s = a.now() - c;
              s < t
                ? (i = setTimeout(d, t - s))
                : ((i = null), n || ((r = e.apply(l, o)), (l = o = null)));
            };
          return function () {
            (l = this), (o = arguments), (c = a.now());
            var s = n && !i;
            return (
              i || (i = setTimeout(d, t)),
              s && ((r = e.apply(l, o)), (l = o = null)),
              r
            );
          };
        }),
        (a.defaults = function (e) {
          if (!a.isObject(e)) return e;
          for (var t = 1, n = arguments.length; t < n; t++) {
            var i = arguments[t];
            for (var o in i) void 0 === e[o] && (e[o] = i[o]);
          }
          return e;
        }),
        (a.keys = function (e) {
          if (!a.isObject(e)) return [];
          if (b) return b(e);
          var t = [];
          for (var n in e) a.has(e, n) && t.push(n);
          return t;
        }),
        (a.has = function (e, t) {
          return d.call(e, t);
        }),
        (a.isObject = function (e) {
          return e === Object(e);
        }),
        (a.now =
          Date.now ||
          function () {
            return new Date().getTime();
          }),
        (a.templateSettings = {
          evaluate: /<%([\s\S]+?)%>/g,
          interpolate: /<%=([\s\S]+?)%>/g,
          escape: /<%-([\s\S]+?)%>/g,
        }),
        (m = /(.)^/),
        (g = {
          "'": "'",
          "\\": "\\",
          "\r": "r",
          "\n": "n",
          "\u2028": "u2028",
          "\u2029": "u2029",
        }),
        (T = /\\|'|\r|\n|\u2028|\u2029/g),
        (O = function (e) {
          return "\\" + g[e];
        }),
        (_ = /^\s*(\w|\$)+\s*$/),
        (a.template = function (e, t, n) {
          !t && n && (t = n);
          var i,
            o = RegExp(
              [
                ((t = a.defaults({}, t, a.templateSettings)).escape || m)
                  .source,
                (t.interpolate || m).source,
                (t.evaluate || m).source,
              ].join("|") + "|$",
              "g"
            ),
            l = 0,
            c = "__p+='";
          e.replace(o, function (t, n, a, i, o) {
            return (
              (c += e.slice(l, o).replace(T, O)),
              (l = o + t.length),
              n
                ? (c += "'+\n((__t=(" + n + "))==null?'':_.escape(__t))+\n'")
                : a
                ? (c += "'+\n((__t=(" + a + "))==null?'':__t)+\n'")
                : i && (c += "';\n" + i + "\n__p+='"),
              t
            );
          }),
            (c += "';\n");
          var r = t.variable;
          if (r) {
            if (!_.test(r))
              throw Error("variable is not a bare identifier: " + r);
          } else (c = "with(obj||{}){\n" + c + "}\n"), (r = "obj");
          c =
            "var __t,__p='',__j=Array.prototype.join,print=function(){__p+=__j.call(arguments,'');};\n" +
            c +
            "return __p;\n";
          try {
            i = Function(t.variable || "obj", "_", c);
          } catch (e) {
            throw ((e.source = c), e);
          }
          var d = function (e) {
            return i.call(this, e, a);
          };
          return (d.source = "function(" + r + "){\n" + c + "}"), d;
        }),
        (e.exports = a);
    },
    9461: function (e, t, n) {
      "use strict";
      var a = n(3949);
      a.define(
        "brand",
        (e.exports = function (e) {
          var t,
            n = {},
            i = document,
            o = e("html"),
            l = e("body"),
            c = window.location,
            r = /PhantomJS/i.test(navigator.userAgent),
            d =
              "fullscreenchange webkitfullscreenchange mozfullscreenchange msfullscreenchange";
          function s() {
            var n =
              i.fullScreen ||
              i.mozFullScreen ||
              i.webkitIsFullScreen ||
              i.msFullscreenElement ||
              !!i.webkitFullscreenElement;
            e(t).attr("style", n ? "display: none !important;" : "");
          }
          function u() {
            var e = l.children(".w-webflow-badge"),
              n = e.length && e.get(0) === t,
              i = a.env("editor");
            if (n) {
              i && e.remove();
              return;
            }
            e.length && e.remove(), i || l.append(t);
          }
          return (
            (n.ready = function () {
              var n,
                a,
                l,
                f = o.attr("data-wf-status"),
                p = o.attr("data-wf-domain") || "";
              /\.webflow\.io$/i.test(p) && c.hostname !== p && (f = !0),
                f &&
                  !r &&
                  ((t =
                    t ||
                    ((n = e('<a class="w-webflow-badge"></a>').attr(
                      "href",
                      "https://webflow.com?utm_campaign=brandjs"
                    )),
                    (a = e("<img>")
                      .attr(
                        "src",
                        "https://d3e54v103j8qbb.cloudfront.net/img/webflow-badge-icon-d2.89e12c322e.svg"
                      )
                      .attr("alt", "")
                      .css({ marginRight: "4px", width: "26px" })),
                    (l = e("<img>")
                      .attr(
                        "src",
                        "https://d3e54v103j8qbb.cloudfront.net/img/webflow-badge-text-d2.c82cec3b78.svg"
                      )
                      .attr("alt", "Made in Webflow")),
                    n.append(a, l),
                    n[0])),
                  u(),
                  setTimeout(u, 500),
                  e(i).off(d, s).on(d, s));
            }),
            n
          );
        })
      );
    },
    322: function (e, t, n) {
      "use strict";
      var a = n(3949);
      a.define(
        "edit",
        (e.exports = function (e, t, n) {
          if (
            ((n = n || {}),
            (a.env("test") || a.env("frame")) &&
              !n.fixture &&
              !(function () {
                try {
                  return !!(window.top.__Cypress__ || window.PLAYWRIGHT_TEST);
                } catch (e) {
                  return !1;
                }
              })())
          )
            return { exit: 1 };
          var i,
            o = e(window),
            l = e(document.documentElement),
            c = document.location,
            r = "hashchange",
            d =
              n.load ||
              function () {
                var t, n, a;
                (i = !0),
                  (window.WebflowEditor = !0),
                  o.off(r, u),
                  (t = function (t) {
                    var n;
                    e.ajax({
                      url: p("https://editor-api.webflow.com/api/editor/view"),
                      data: { siteId: l.attr("data-wf-site") },
                      xhrFields: { withCredentials: !0 },
                      dataType: "json",
                      crossDomain: !0,
                      success:
                        ((n = t),
                        function (t) {
                          var a, i, o;
                          if (!t)
                            return void console.error(
                              "Could not load editor data"
                            );
                          (t.thirdPartyCookiesSupported = n),
                            (i =
                              (a = t.scriptPath).indexOf("//") >= 0
                                ? a
                                : p("https://editor-api.webflow.com" + a)),
                            (o = function () {
                              window.WebflowEditor(t);
                            }),
                            e
                              .ajax({
                                type: "GET",
                                url: i,
                                dataType: "script",
                                cache: !0,
                              })
                              .then(o, f);
                        }),
                    });
                  }),
                  ((n = window.document.createElement("iframe")).src =
                    "https://webflow.com/site/third-party-cookie-check.html"),
                  (n.style.display = "none"),
                  (n.sandbox = "allow-scripts allow-same-origin"),
                  (a = function (e) {
                    "WF_third_party_cookies_unsupported" === e.data
                      ? (E(n, a), t(!1))
                      : "WF_third_party_cookies_supported" === e.data &&
                        (E(n, a), t(!0));
                  }),
                  (n.onerror = function () {
                    E(n, a), t(!1);
                  }),
                  window.addEventListener("message", a, !1),
                  window.document.body.appendChild(n);
              },
            s = !1;
          try {
            s =
              localStorage &&
              localStorage.getItem &&
              localStorage.getItem("WebflowEditor");
          } catch (e) {}
          function u() {
            !i && /\?edit/.test(c.hash) && d();
          }
          function f(e, t, n) {
            throw (console.error("Could not load editor script: " + t), n);
          }
          function p(e) {
            return e.replace(/([^:])\/\//g, "$1/");
          }
          function E(e, t) {
            window.removeEventListener("message", t, !1), e.remove();
          }
          return (
            s
              ? d()
              : c.search
              ? (/[?&](edit)(?:[=&?]|$)/.test(c.search) ||
                  /\?edit$/.test(c.href)) &&
                d()
              : o.on(r, u).triggerHandler(r),
            {}
          );
        })
      );
    },
    2338: function (e, t, n) {
      "use strict";
      n(3949).define(
        "focus-visible",
        (e.exports = function () {
          return {
            ready: function () {
              if ("undefined" != typeof document)
                try {
                  document.querySelector(":focus-visible");
                } catch (e) {
                  !(function (e) {
                    var t = !0,
                      n = !1,
                      a = null,
                      i = {
                        text: !0,
                        search: !0,
                        url: !0,
                        tel: !0,
                        email: !0,
                        password: !0,
                        number: !0,
                        date: !0,
                        month: !0,
                        week: !0,
                        time: !0,
                        datetime: !0,
                        "datetime-local": !0,
                      };
                    function o(e) {
                      return (
                        !!e &&
                        e !== document &&
                        "HTML" !== e.nodeName &&
                        "BODY" !== e.nodeName &&
                        "classList" in e &&
                        "contains" in e.classList
                      );
                    }
                    function l(e) {
                      e.getAttribute("data-wf-focus-visible") ||
                        e.setAttribute("data-wf-focus-visible", "true");
                    }
                    function c() {
                      t = !1;
                    }
                    function r() {
                      document.addEventListener("mousemove", d),
                        document.addEventListener("mousedown", d),
                        document.addEventListener("mouseup", d),
                        document.addEventListener("pointermove", d),
                        document.addEventListener("pointerdown", d),
                        document.addEventListener("pointerup", d),
                        document.addEventListener("touchmove", d),
                        document.addEventListener("touchstart", d),
                        document.addEventListener("touchend", d);
                    }
                    function d(e) {
                      (e.target.nodeName &&
                        "html" === e.target.nodeName.toLowerCase()) ||
                        ((t = !1),
                        document.removeEventListener("mousemove", d),
                        document.removeEventListener("mousedown", d),
                        document.removeEventListener("mouseup", d),
                        document.removeEventListener("pointermove", d),
                        document.removeEventListener("pointerdown", d),
                        document.removeEventListener("pointerup", d),
                        document.removeEventListener("touchmove", d),
                        document.removeEventListener("touchstart", d),
                        document.removeEventListener("touchend", d));
                    }
                    document.addEventListener(
                      "keydown",
                      function (n) {
                        n.metaKey ||
                          n.altKey ||
                          n.ctrlKey ||
                          (o(e.activeElement) && l(e.activeElement), (t = !0));
                      },
                      !0
                    ),
                      document.addEventListener("mousedown", c, !0),
                      document.addEventListener("pointerdown", c, !0),
                      document.addEventListener("touchstart", c, !0),
                      document.addEventListener(
                        "visibilitychange",
                        function () {
                          "hidden" === document.visibilityState &&
                            (n && (t = !0), r());
                        },
                        !0
                      ),
                      r(),
                      e.addEventListener(
                        "focus",
                        function (e) {
                          if (o(e.target)) {
                            var n, a, c;
                            (t ||
                              ((a = (n = e.target).type),
                              ("INPUT" === (c = n.tagName) &&
                                i[a] &&
                                !n.readOnly) ||
                                ("TEXTAREA" === c && !n.readOnly) ||
                                n.isContentEditable ||
                                0)) &&
                              l(e.target);
                          }
                        },
                        !0
                      ),
                      e.addEventListener(
                        "blur",
                        function (e) {
                          if (
                            o(e.target) &&
                            e.target.hasAttribute("data-wf-focus-visible")
                          ) {
                            var t;
                            (n = !0),
                              window.clearTimeout(a),
                              (a = window.setTimeout(function () {
                                n = !1;
                              }, 100)),
                              (t = e.target).getAttribute(
                                "data-wf-focus-visible"
                              ) && t.removeAttribute("data-wf-focus-visible");
                          }
                        },
                        !0
                      );
                  })(document);
                }
            },
          };
        })
      );
    },
    8334: function (e, t, n) {
      "use strict";
      var a = n(3949);
      a.define(
        "focus",
        (e.exports = function () {
          var e = [],
            t = !1;
          function n(n) {
            t &&
              (n.preventDefault(),
              n.stopPropagation(),
              n.stopImmediatePropagation(),
              e.unshift(n));
          }
          function i(n) {
            var a, i;
            (i = (a = n.target).tagName),
              ((/^a$/i.test(i) && null != a.href) ||
                (/^(button|textarea)$/i.test(i) && !0 !== a.disabled) ||
                (/^input$/i.test(i) &&
                  /^(button|reset|submit|radio|checkbox)$/i.test(a.type) &&
                  !a.disabled) ||
                (!/^(button|input|textarea|select|a)$/i.test(i) &&
                  !Number.isNaN(Number.parseFloat(a.tabIndex))) ||
                /^audio$/i.test(i) ||
                (/^video$/i.test(i) && !0 === a.controls)) &&
                ((t = !0),
                setTimeout(() => {
                  for (t = !1, n.target.focus(); e.length > 0; ) {
                    var a = e.pop();
                    a.target.dispatchEvent(new MouseEvent(a.type, a));
                  }
                }, 0));
          }
          return {
            ready: function () {
              "undefined" != typeof document &&
                document.body.hasAttribute("data-wf-focus-within") &&
                a.env.safari &&
                (document.addEventListener("mousedown", i, !0),
                document.addEventListener("mouseup", n, !0),
                document.addEventListener("click", n, !0));
            },
          };
        })
      );
    },
    7199: function (e) {
      "use strict";
      var t = window.jQuery,
        n = {},
        a = [],
        i = ".w-ix",
        o = {
          reset: function (e, t) {
            t.__wf_intro = null;
          },
          intro: function (e, a) {
            a.__wf_intro ||
              ((a.__wf_intro = !0), t(a).triggerHandler(n.types.INTRO));
          },
          outro: function (e, a) {
            a.__wf_intro &&
              ((a.__wf_intro = null), t(a).triggerHandler(n.types.OUTRO));
          },
        };
      (n.triggers = {}),
        (n.types = { INTRO: "w-ix-intro" + i, OUTRO: "w-ix-outro" + i }),
        (n.init = function () {
          for (var e = a.length, i = 0; i < e; i++) {
            var l = a[i];
            l[0](0, l[1]);
          }
          (a = []), t.extend(n.triggers, o);
        }),
        (n.async = function () {
          for (var e in o) {
            var t = o[e];
            o.hasOwnProperty(e) &&
              (n.triggers[e] = function (e, n) {
                a.push([t, n]);
              });
          }
        }),
        n.async(),
        (e.exports = n);
    },
    5134: function (e, t, n) {
      "use strict";
      var a = n(7199);
      function i(e, t) {
        var n = document.createEvent("CustomEvent");
        n.initCustomEvent(t, !0, !0, null), e.dispatchEvent(n);
      }
      var o = window.jQuery,
        l = {},
        c = ".w-ix";
      (l.triggers = {}),
        (l.types = { INTRO: "w-ix-intro" + c, OUTRO: "w-ix-outro" + c }),
        o.extend(l.triggers, {
          reset: function (e, t) {
            a.triggers.reset(e, t);
          },
          intro: function (e, t) {
            a.triggers.intro(e, t), i(t, "COMPONENT_ACTIVE");
          },
          outro: function (e, t) {
            a.triggers.outro(e, t), i(t, "COMPONENT_INACTIVE");
          },
        }),
        (e.exports = l);
    },
    941: function (e, t, n) {
      "use strict";
      var a = n(3949),
        i = n(6011);
      i.setEnv(a.env),
        a.define(
          "ix2",
          (e.exports = function () {
            return i;
          })
        );
    },
    3949: function (e, t, n) {
      "use strict";
      var a,
        i,
        o = {},
        l = {},
        c = [],
        r = window.Webflow || [],
        d = window.jQuery,
        s = d(window),
        u = d(document),
        f = d.isFunction,
        p = (o._ = n(5756)),
        E = (o.tram = n(5487) && d.tram),
        b = !1,
        I = !1;
      function y(e) {
        o.env() &&
          (f(e.design) && s.on("__wf_design", e.design),
          f(e.preview) && s.on("__wf_preview", e.preview)),
          f(e.destroy) && s.on("__wf_destroy", e.destroy),
          e.ready &&
            f(e.ready) &&
            (function (e) {
              if (b) return e.ready();
              p.contains(c, e.ready) || c.push(e.ready);
            })(e);
      }
      function m(e) {
        var t;
        f(e.design) && s.off("__wf_design", e.design),
          f(e.preview) && s.off("__wf_preview", e.preview),
          f(e.destroy) && s.off("__wf_destroy", e.destroy),
          e.ready &&
            f(e.ready) &&
            ((t = e),
            (c = p.filter(c, function (e) {
              return e !== t.ready;
            })));
      }
      (E.config.hideBackface = !1),
        (E.config.keepInherited = !0),
        (o.define = function (e, t, n) {
          l[e] && m(l[e]);
          var a = (l[e] = t(d, p, n) || {});
          return y(a), a;
        }),
        (o.require = function (e) {
          return l[e];
        }),
        (o.push = function (e) {
          if (b) {
            f(e) && e();
            return;
          }
          r.push(e);
        }),
        (o.env = function (e) {
          var t = window.__wf_design,
            n = void 0 !== t;
          return e
            ? "design" === e
              ? n && t
              : "preview" === e
              ? n && !t
              : "slug" === e
              ? n && window.__wf_slug
              : "editor" === e
              ? window.WebflowEditor
              : "test" === e
              ? window.__wf_test
              : "frame" === e
              ? window !== window.top
              : void 0
            : n;
        });
      var g = navigator.userAgent.toLowerCase(),
        T = (o.env.touch =
          "ontouchstart" in window ||
          (window.DocumentTouch && document instanceof window.DocumentTouch)),
        O = (o.env.chrome =
          /chrome/.test(g) &&
          /Google/.test(navigator.vendor) &&
          parseInt(g.match(/chrome\/(\d+)\./)[1], 10)),
        _ = (o.env.ios = /(ipod|iphone|ipad)/.test(g));
      (o.env.safari = /safari/.test(g) && !O && !_),
        T &&
          u.on("touchstart mousedown", function (e) {
            a = e.target;
          }),
        (o.validClick = T
          ? function (e) {
              return e === a || d.contains(e, a);
            }
          : function () {
              return !0;
            });
      var v = "resize.webflow orientationchange.webflow load.webflow",
        h = "scroll.webflow " + v;
      function R(e, t) {
        var n = [],
          a = {};
        return (
          (a.up = p.throttle(function (e) {
            p.each(n, function (t) {
              t(e);
            });
          })),
          e && t && e.on(t, a.up),
          (a.on = function (e) {
            "function" == typeof e && (p.contains(n, e) || n.push(e));
          }),
          (a.off = function (e) {
            if (!arguments.length) {
              n = [];
              return;
            }
            n = p.filter(n, function (t) {
              return t !== e;
            });
          }),
          a
        );
      }
      function A(e) {
        f(e) && e();
      }
      function N() {
        i && (i.reject(), s.off("load", i.resolve)),
          (i = new d.Deferred()),
          s.on("load", i.resolve);
      }
      (o.resize = R(s, v)),
        (o.scroll = R(s, h)),
        (o.redraw = R()),
        (o.location = function (e) {
          window.location = e;
        }),
        o.env() && (o.location = function () {}),
        (o.ready = function () {
          (b = !0),
            I ? ((I = !1), p.each(l, y)) : p.each(c, A),
            p.each(r, A),
            o.resize.up();
        }),
        (o.load = function (e) {
          i.then(e);
        }),
        (o.destroy = function (e) {
          (e = e || {}),
            (I = !0),
            s.triggerHandler("__wf_destroy"),
            null != e.domready && (b = e.domready),
            p.each(l, m),
            o.resize.off(),
            o.scroll.off(),
            o.redraw.off(),
            (c = []),
            (r = []),
            "pending" === i.state() && N();
        }),
        d(o.ready),
        N(),
        (e.exports = window.Webflow = o);
    },
    7624: function (e, t, n) {
      "use strict";
      var a = n(3949);
      a.define(
        "links",
        (e.exports = function (e, t) {
          var n,
            i,
            o,
            l = {},
            c = e(window),
            r = a.env(),
            d = window.location,
            s = document.createElement("a"),
            u = "w--current",
            f = /index\.(html|php)$/,
            p = /\/$/;
          function E() {
            var e = c.scrollTop(),
              n = c.height();
            t.each(i, function (t) {
              if (!t.link.attr("hreflang")) {
                var a = t.link,
                  i = t.sec,
                  o = i.offset().top,
                  l = i.outerHeight(),
                  c = 0.5 * n,
                  r = i.is(":visible") && o + l - c >= e && o + c <= e + n;
                t.active !== r && ((t.active = r), b(a, u, r));
              }
            });
          }
          function b(e, t, n) {
            var a = e.hasClass(t);
            (!n || !a) && (n || a) && (n ? e.addClass(t) : e.removeClass(t));
          }
          return (
            (l.ready =
              l.design =
              l.preview =
                function () {
                  (n = r && a.env("design")),
                    (o = a.env("slug") || d.pathname || ""),
                    a.scroll.off(E),
                    (i = []);
                  for (var t = document.links, l = 0; l < t.length; ++l)
                    !(function (t) {
                      if (!t.getAttribute("hreflang")) {
                        var a =
                          (n && t.getAttribute("href-disabled")) ||
                          t.getAttribute("href");
                        if (((s.href = a), !(a.indexOf(":") >= 0))) {
                          var l = e(t);
                          if (
                            s.hash.length > 1 &&
                            s.host + s.pathname === d.host + d.pathname
                          ) {
                            if (!/^#[a-zA-Z0-9\-\_]+$/.test(s.hash)) return;
                            var c = e(s.hash);
                            c.length && i.push({ link: l, sec: c, active: !1 });
                            return;
                          }
                          "#" !== a &&
                            "" !== a &&
                            b(
                              l,
                              u,
                              (!r && s.href === d.href) ||
                                a === o ||
                                (f.test(a) && p.test(o))
                            );
                        }
                      }
                    })(t[l]);
                  i.length && (a.scroll.on(E), E());
                }),
            l
          );
        })
      );
    },
    286: function (e, t, n) {
      "use strict";
      var a = n(3949);
      a.define(
        "scroll",
        (e.exports = function (e) {
          var t = {
              WF_CLICK_EMPTY: "click.wf-empty-link",
              WF_CLICK_SCROLL: "click.wf-scroll",
            },
            n = window.location,
            i = !(function () {
              try {
                return !!window.frameElement;
              } catch (e) {
                return !0;
              }
            })()
              ? window.history
              : null,
            o = e(window),
            l = e(document),
            c = e(document.body),
            r =
              window.requestAnimationFrame ||
              window.mozRequestAnimationFrame ||
              window.webkitRequestAnimationFrame ||
              function (e) {
                window.setTimeout(e, 15);
              },
            d = a.env("editor") ? ".w-editor-body" : "body",
            s =
              "header, " +
              d +
              " > .header, " +
              d +
              " > .w-nav:not([data-no-scroll])",
            u = 'a[href="#"]',
            f = 'a[href*="#"]:not(.w-tab-link):not(' + u + ")",
            p = document.createElement("style");
          p.appendChild(
            document.createTextNode(
              '.wf-force-outline-none[tabindex="-1"]:focus{outline:none;}'
            )
          );
          var E = /^#[a-zA-Z0-9][\w:.-]*$/;
          let b =
            "function" == typeof window.matchMedia &&
            window.matchMedia("(prefers-reduced-motion: reduce)");
          function I(e, t) {
            var n;
            switch (t) {
              case "add":
                (n = e.attr("tabindex"))
                  ? e.attr("data-wf-tabindex-swap", n)
                  : e.attr("tabindex", "-1");
                break;
              case "remove":
                (n = e.attr("data-wf-tabindex-swap"))
                  ? (e.attr("tabindex", n),
                    e.removeAttr("data-wf-tabindex-swap"))
                  : e.removeAttr("tabindex");
            }
            e.toggleClass("wf-force-outline-none", "add" === t);
          }
          function y(t) {
            var l = t.currentTarget;
            if (
              !(
                a.env("design") ||
                (window.$.mobile && /(?:^|\s)ui-link(?:$|\s)/.test(l.className))
              )
            ) {
              var d =
                E.test(l.hash) && l.host + l.pathname === n.host + n.pathname
                  ? l.hash
                  : "";
              if ("" !== d) {
                var u,
                  f = e(d);
                f.length &&
                  (t && (t.preventDefault(), t.stopPropagation()),
                  (u = d),
                  n.hash !== u &&
                    i &&
                    i.pushState &&
                    !(a.env.chrome && "file:" === n.protocol) &&
                    (i.state && i.state.hash) !== u &&
                    i.pushState({ hash: u }, "", u),
                  window.setTimeout(function () {
                    !(function (t, n) {
                      var a = o.scrollTop(),
                        i = (function (t) {
                          var n = e(s),
                            a =
                              "fixed" === n.css("position")
                                ? n.outerHeight()
                                : 0,
                            i = t.offset().top - a;
                          if ("mid" === t.data("scroll")) {
                            var l = o.height() - a,
                              c = t.outerHeight();
                            c < l && (i -= Math.round((l - c) / 2));
                          }
                          return i;
                        })(t);
                      if (a !== i) {
                        var l = (function (e, t, n) {
                            if (
                              "none" ===
                                document.body.getAttribute(
                                  "data-wf-scroll-motion"
                                ) ||
                              b.matches
                            )
                              return 0;
                            var a = 1;
                            return (
                              c.add(e).each(function (e, t) {
                                var n = parseFloat(
                                  t.getAttribute("data-scroll-time")
                                );
                                !isNaN(n) && n >= 0 && (a = n);
                              }),
                              (472.143 * Math.log(Math.abs(t - n) + 125) -
                                2e3) *
                                a
                            );
                          })(t, a, i),
                          d = Date.now(),
                          u = function () {
                            var e,
                              t,
                              o,
                              c,
                              s,
                              f = Date.now() - d;
                            window.scroll(
                              0,
                              ((e = a),
                              (t = i),
                              (o = f) > (c = l)
                                ? t
                                : e +
                                  (t - e) *
                                    ((s = o / c) < 0.5
                                      ? 4 * s * s * s
                                      : (s - 1) * (2 * s - 2) * (2 * s - 2) +
                                        1))
                            ),
                              f <= l ? r(u) : "function" == typeof n && n();
                          };
                        r(u);
                      }
                    })(f, function () {
                      I(f, "add"),
                        f.get(0).focus({ preventScroll: !0 }),
                        I(f, "remove");
                    });
                  }, 300 * !t));
              }
            }
          }
          return {
            ready: function () {
              var { WF_CLICK_EMPTY: e, WF_CLICK_SCROLL: n } = t;
              l.on(n, f, y),
                l.on(e, u, function (e) {
                  e.preventDefault();
                }),
                document.head.insertBefore(p, document.head.firstChild);
            },
          };
        })
      );
    },
    3695: function (e, t, n) {
      "use strict";
      n(3949).define(
        "touch",
        (e.exports = function (e) {
          var t = {},
            n = window.getSelection;
          function a(t) {
            var a,
              i,
              o = !1,
              l = !1,
              c = Math.min(Math.round(0.04 * window.innerWidth), 40);
            function r(e) {
              var t = e.touches;
              (t && t.length > 1) ||
                ((o = !0),
                t ? ((l = !0), (a = t[0].clientX)) : (a = e.clientX),
                (i = a));
            }
            function d(t) {
              if (o) {
                if (l && "mousemove" === t.type) {
                  t.preventDefault(), t.stopPropagation();
                  return;
                }
                var a,
                  r,
                  d,
                  s,
                  f = t.touches,
                  p = f ? f[0].clientX : t.clientX,
                  E = p - i;
                (i = p),
                  Math.abs(E) > c &&
                    n &&
                    "" === String(n()) &&
                    ((a = "swipe"),
                    (r = t),
                    (d = { direction: E > 0 ? "right" : "left" }),
                    (s = e.Event(a, { originalEvent: r })),
                    e(r.target).trigger(s, d),
                    u());
              }
            }
            function s(e) {
              if (o && ((o = !1), l && "mouseup" === e.type)) {
                e.preventDefault(), e.stopPropagation(), (l = !1);
                return;
              }
            }
            function u() {
              o = !1;
            }
            t.addEventListener("touchstart", r, !1),
              t.addEventListener("touchmove", d, !1),
              t.addEventListener("touchend", s, !1),
              t.addEventListener("touchcancel", u, !1),
              t.addEventListener("mousedown", r, !1),
              t.addEventListener("mousemove", d, !1),
              t.addEventListener("mouseup", s, !1),
              t.addEventListener("mouseout", u, !1),
              (this.destroy = function () {
                t.removeEventListener("touchstart", r, !1),
                  t.removeEventListener("touchmove", d, !1),
                  t.removeEventListener("touchend", s, !1),
                  t.removeEventListener("touchcancel", u, !1),
                  t.removeEventListener("mousedown", r, !1),
                  t.removeEventListener("mousemove", d, !1),
                  t.removeEventListener("mouseup", s, !1),
                  t.removeEventListener("mouseout", u, !1),
                  (t = null);
              });
          }
          return (
            (e.event.special.tap = {
              bindType: "click",
              delegateType: "click",
            }),
            (t.init = function (t) {
              return (t = "string" == typeof t ? e(t).get(0) : t)
                ? new a(t)
                : null;
            }),
            (t.instance = t.init(document)),
            t
          );
        })
      );
    },
    6524: function (e, t) {
      "use strict";
      function n(e, t, n, a, i, o, l, c, r, d, s, u, f) {
        return function (p) {
          e(p);
          var E = p.form,
            b = {
              name: E.attr("data-name") || E.attr("name") || "Untitled Form",
              pageId: E.attr("data-wf-page-id") || "",
              elementId: E.attr("data-wf-element-id") || "",
              domain: u("html").attr("data-wf-domain") || null,
              source: t.href,
              test: n.env(),
              fields: {},
              fileUploads: {},
              dolphin: /pass[\s-_]?(word|code)|secret|login|credentials/i.test(
                E.html()
              ),
              trackingCookies: a(),
            };
          let I = E.attr("data-wf-flow");
          I && (b.wfFlow = I);
          let y = E.attr("data-wf-locale-id");
          y && (b.localeId = y), i(p);
          var m = o(E, b.fields);
          return m
            ? l(m)
            : ((b.fileUploads = c(E)), r(p), d)
            ? void u
                .ajax({
                  url: f,
                  type: "POST",
                  data: b,
                  dataType: "json",
                  crossDomain: !0,
                })
                .done(function (e) {
                  e && 200 === e.code && (p.success = !0), s(p);
                })
                .fail(function () {
                  s(p);
                })
            : void s(p);
        };
      }
      Object.defineProperty(t, "default", {
        enumerable: !0,
        get: function () {
          return n;
        },
      });
    },
    7527: function (e, t, n) {
      "use strict";
      var a = n(3949);
      let i = (e, t, n, a) => {
        let i = document.createElement("div");
        t.appendChild(i),
          turnstile.render(i, {
            sitekey: e,
            callback: function (e) {
              n(e);
            },
            "error-callback": function () {
              a();
            },
          });
      };
      a.define(
        "forms",
        (e.exports = function (e, t) {
          let o,
            l = "TURNSTILE_LOADED";
          var c,
            r,
            d,
            s,
            u,
            f = {},
            p = e(document),
            E = window.location,
            b = window.XDomainRequest && !window.atob,
            I = ".w-form",
            y = /e(-)?mail/i,
            m = /^\S+@\S+$/,
            g = window.alert,
            T = a.env();
          let O = p.find("[data-turnstile-sitekey]").data("turnstile-sitekey");
          var _ = /list-manage[1-9]?.com/i,
            v = t.debounce(function () {
              console.warn(
                "Oops! This page has improperly configured forms. Please contact your website administrator to fix this issue."
              );
            }, 100);
          function h(t, o) {
            var c = e(o),
              d = e.data(o, I);
            d || (d = e.data(o, I, { form: c })), R(d);
            var f = c.closest("div.w-form");
            (d.done = f.find("> .w-form-done")),
              (d.fail = f.find("> .w-form-fail")),
              (d.fileUploads = f.find(".w-file-upload")),
              d.fileUploads.each(function (t) {
                !(function (t, n) {
                  if (n.fileUploads && n.fileUploads[t]) {
                    var a,
                      i = e(n.fileUploads[t]),
                      o = i.find("> .w-file-upload-default"),
                      l = i.find("> .w-file-upload-uploading"),
                      c = i.find("> .w-file-upload-success"),
                      r = i.find("> .w-file-upload-error"),
                      d = o.find(".w-file-upload-input"),
                      s = o.find(".w-file-upload-label"),
                      f = s.children(),
                      p = r.find(".w-file-upload-error-msg"),
                      E = c.find(".w-file-upload-file"),
                      b = c.find(".w-file-remove-link"),
                      I = E.find(".w-file-upload-file-name"),
                      y = p.attr("data-w-size-error"),
                      m = p.attr("data-w-type-error"),
                      g = p.attr("data-w-generic-error");
                    if (
                      (T ||
                        s.on("click keydown", function (e) {
                          ("keydown" !== e.type ||
                            13 === e.which ||
                            32 === e.which) &&
                            (e.preventDefault(), d.click());
                        }),
                      s
                        .find(".w-icon-file-upload-icon")
                        .attr("aria-hidden", "true"),
                      b
                        .find(".w-icon-file-upload-remove")
                        .attr("aria-hidden", "true"),
                      T)
                    )
                      d.on("click", function (e) {
                        e.preventDefault();
                      }),
                        s.on("click", function (e) {
                          e.preventDefault();
                        }),
                        f.on("click", function (e) {
                          e.preventDefault();
                        });
                    else {
                      b.on("click keydown", function (e) {
                        if ("keydown" === e.type) {
                          if (13 !== e.which && 32 !== e.which) return;
                          e.preventDefault();
                        }
                        d.removeAttr("data-value"),
                          d.val(""),
                          I.html(""),
                          o.toggle(!0),
                          c.toggle(!1),
                          s.focus();
                      }),
                        d.on("change", function (i) {
                          var c, d, s;
                          (a =
                            i.target && i.target.files && i.target.files[0]) &&
                            (o.toggle(!1),
                            r.toggle(!1),
                            l.toggle(!0),
                            l.focus(),
                            I.text(a.name),
                            N() || A(n),
                            (n.fileUploads[t].uploading = !0),
                            (c = a),
                            (d = v),
                            (s = new URLSearchParams({
                              name: c.name,
                              size: c.size,
                            })),
                            e
                              .ajax({
                                type: "GET",
                                url: `${u}?${s}`,
                                crossDomain: !0,
                              })
                              .done(function (e) {
                                d(null, e);
                              })
                              .fail(function (e) {
                                d(e);
                              }));
                        });
                      var O = s.outerHeight();
                      d.height(O), d.width(1);
                    }
                  }
                  function _(e) {
                    var a = e.responseJSON && e.responseJSON.msg,
                      i = g;
                    "string" == typeof a &&
                    0 === a.indexOf("InvalidFileTypeError")
                      ? (i = m)
                      : "string" == typeof a &&
                        0 === a.indexOf("MaxFileSizeError") &&
                        (i = y),
                      p.text(i),
                      d.removeAttr("data-value"),
                      d.val(""),
                      l.toggle(!1),
                      o.toggle(!0),
                      r.toggle(!0),
                      r.focus(),
                      (n.fileUploads[t].uploading = !1),
                      N() || R(n);
                  }
                  function v(t, n) {
                    if (t) return _(t);
                    var i = n.fileName,
                      o = n.postData,
                      l = n.fileId,
                      c = n.s3Url;
                    d.attr("data-value", l),
                      (function (t, n, a, i, o) {
                        var l = new FormData();
                        for (var c in n) l.append(c, n[c]);
                        l.append("file", a, i),
                          e
                            .ajax({
                              type: "POST",
                              url: t,
                              data: l,
                              processData: !1,
                              contentType: !1,
                            })
                            .done(function () {
                              o(null);
                            })
                            .fail(function (e) {
                              o(e);
                            });
                      })(c, o, a, i, h);
                  }
                  function h(e) {
                    if (e) return _(e);
                    l.toggle(!1),
                      c.css("display", "inline-block"),
                      c.focus(),
                      (n.fileUploads[t].uploading = !1),
                      N() || R(n);
                  }
                  function N() {
                    return (
                      (n.fileUploads && n.fileUploads.toArray()) ||
                      []
                    ).some(function (e) {
                      return e.uploading;
                    });
                  }
                })(t, d);
              }),
              O &&
                ((function (e) {
                  let t = e.btn || e.form.find(':input[type="submit"]');
                  e.btn || (e.btn = t),
                    t.prop("disabled", !0),
                    t.addClass("w-form-loading");
                })(d),
                N(c, !0),
                p.on(
                  "undefined" != typeof turnstile ? "ready" : l,
                  function () {
                    i(
                      O,
                      o,
                      (e) => {
                        (d.turnstileToken = e), R(d), N(c, !1);
                      },
                      () => {
                        R(d), d.btn && d.btn.prop("disabled", !0), N(c, !1);
                      }
                    );
                  }
                ));
            var b =
              d.form.attr("aria-label") || d.form.attr("data-name") || "Form";
            d.done.attr("aria-label") || d.form.attr("aria-label", b),
              d.done.attr("tabindex", "-1"),
              d.done.attr("role", "region"),
              d.done.attr("aria-label") ||
                d.done.attr("aria-label", b + " success"),
              d.fail.attr("tabindex", "-1"),
              d.fail.attr("role", "region"),
              d.fail.attr("aria-label") ||
                d.fail.attr("aria-label", b + " failure");
            var y = (d.action = c.attr("action"));
            if (
              ((d.handler = null),
              (d.redirect = c.attr("data-redirect")),
              _.test(y))
            ) {
              d.handler = M;
              return;
            }
            if (!y) {
              if (r) {
                d.handler = (0, n(6524).default)(
                  R,
                  E,
                  a,
                  w,
                  G,
                  L,
                  g,
                  S,
                  A,
                  r,
                  P,
                  e,
                  s
                );
                return;
              }
              v();
            }
          }
          function R(e) {
            var t = (e.btn = e.form.find(':input[type="submit"]'));
            (e.wait = e.btn.attr("data-wait") || null), (e.success = !1);
            let n = !!(O && !e.turnstileToken);
            t.prop("disabled", n),
              t.removeClass("w-form-loading"),
              e.label && t.val(e.label);
          }
          function A(e) {
            var t = e.btn,
              n = e.wait;
            t.prop("disabled", !0), n && ((e.label = t.val()), t.val(n));
          }
          function N(e, t) {
            let n = e.closest(".w-form");
            t ? n.addClass("w-form-loading") : n.removeClass("w-form-loading");
          }
          function L(t, n) {
            var a = null;
            return (
              (n = n || {}),
              t
                .find(
                  ':input:not([type="submit"]):not([type="file"]):not([type="button"])'
                )
                .each(function (i, o) {
                  var l,
                    c,
                    r,
                    d,
                    s,
                    u = e(o),
                    f = u.attr("type"),
                    p =
                      u.attr("data-name") ||
                      u.attr("name") ||
                      "Field " + (i + 1);
                  p = encodeURIComponent(p);
                  var E = u.val();
                  if ("checkbox" === f) E = u.is(":checked");
                  else if ("radio" === f) {
                    if (null === n[p] || "string" == typeof n[p]) return;
                    E =
                      t
                        .find('input[name="' + u.attr("name") + '"]:checked')
                        .val() || null;
                  }
                  "string" == typeof E && (E = e.trim(E)),
                    (n[p] = E),
                    (a =
                      a ||
                      ((l = u),
                      (c = f),
                      (r = p),
                      (d = E),
                      (s = null),
                      "password" === c
                        ? (s = "Passwords cannot be submitted.")
                        : l.attr("required")
                        ? d
                          ? y.test(l.attr("type")) &&
                            !m.test(d) &&
                            (s = "Please enter a valid email address for: " + r)
                          : (s = "Please fill out the required field: " + r)
                        : "g-recaptcha-response" !== r ||
                          d ||
                          (s = "Please confirm you're not a robot."),
                      s));
                }),
              a
            );
          }
          function S(t) {
            var n = {};
            return (
              t.find(':input[type="file"]').each(function (t, a) {
                var i = e(a),
                  o =
                    i.attr("data-name") || i.attr("name") || "File " + (t + 1),
                  l = i.attr("data-value");
                "string" == typeof l && (l = e.trim(l)), (n[o] = l);
              }),
              n
            );
          }
          f.ready =
            f.design =
            f.preview =
              function () {
                O &&
                  (((o = document.createElement("script")).src =
                    "https://challenges.cloudflare.com/turnstile/v0/api.js"),
                  document.head.appendChild(o),
                  (o.onload = () => {
                    p.trigger(l);
                  })),
                  (s =
                    "https://webflow.com/api/v1/form/" +
                    (r = e("html").attr("data-wf-site"))),
                  b &&
                    s.indexOf("https://webflow.com") >= 0 &&
                    (s = s.replace(
                      "https://webflow.com",
                      "https://formdata.webflow.com"
                    )),
                  (u = `${s}/signFile`),
                  (c = e(I + " form")).length && c.each(h),
                  (!T || a.env("preview")) &&
                    !d &&
                    (function () {
                      (d = !0),
                        p.on("submit", I + " form", function (t) {
                          var n = e.data(this, I);
                          n.handler && ((n.evt = t), n.handler(n));
                        });
                      let t = ".w-checkbox-input",
                        n = ".w-radio-input",
                        a = "w--redirected-checked",
                        i = "w--redirected-focus",
                        o = "w--redirected-focus-visible",
                        l = [
                          ["checkbox", t],
                          ["radio", n],
                        ];
                      p.on(
                        "change",
                        I + ' form input[type="checkbox"]:not(' + t + ")",
                        (n) => {
                          e(n.target).siblings(t).toggleClass(a);
                        }
                      ),
                        p.on("change", I + ' form input[type="radio"]', (i) => {
                          e(`input[name="${i.target.name}"]:not(${t})`).map(
                            (t, i) => e(i).siblings(n).removeClass(a)
                          );
                          let o = e(i.target);
                          o.hasClass("w-radio-input") ||
                            o.siblings(n).addClass(a);
                        }),
                        l.forEach(([t, n]) => {
                          p.on(
                            "focus",
                            I + ` form input[type="${t}"]:not(` + n + ")",
                            (t) => {
                              e(t.target).siblings(n).addClass(i),
                                e(t.target)
                                  .filter(
                                    ":focus-visible, [data-wf-focus-visible]"
                                  )
                                  .siblings(n)
                                  .addClass(o);
                            }
                          ),
                            p.on(
                              "blur",
                              I + ` form input[type="${t}"]:not(` + n + ")",
                              (t) => {
                                e(t.target)
                                  .siblings(n)
                                  .removeClass(`${i} ${o}`);
                              }
                            );
                        });
                    })();
              };
          let C = { _mkto_trk: "marketo" };
          function w() {
            return document.cookie.split("; ").reduce(function (e, t) {
              let n = t.split("="),
                a = n[0];
              if (a in C) {
                let t = C[a],
                  i = n.slice(1).join("=");
                e[t] = i;
              }
              return e;
            }, {});
          }
          function M(n) {
            R(n);
            var a,
              i = n.form,
              o = {};
            if (/^https/.test(E.href) && !/^https/.test(n.action))
              return void i.attr("method", "post");
            G(n);
            var l = L(i, o);
            if (l) return g(l);
            A(n),
              t.each(o, function (e, t) {
                y.test(t) && (o.EMAIL = e),
                  /^((full[ _-]?)?name)$/i.test(t) && (a = e),
                  /^(first[ _-]?name)$/i.test(t) && (o.FNAME = e),
                  /^(last[ _-]?name)$/i.test(t) && (o.LNAME = e);
              }),
              a &&
                !o.FNAME &&
                ((o.FNAME = (a = a.split(" "))[0]),
                (o.LNAME = o.LNAME || a[1]));
            var c = n.action.replace("/post?", "/post-json?") + "&c=?",
              r = c.indexOf("u=") + 2;
            r = c.substring(r, c.indexOf("&", r));
            var d = c.indexOf("id=") + 3;
            (o["b_" + r + "_" + (d = c.substring(d, c.indexOf("&", d)))] = ""),
              e
                .ajax({ url: c, data: o, dataType: "jsonp" })
                .done(function (e) {
                  (n.success = "success" === e.result || /already/.test(e.msg)),
                    n.success || console.info("MailChimp error: " + e.msg),
                    P(n);
                })
                .fail(function () {
                  P(n);
                });
          }
          function P(e) {
            var t = e.form,
              n = e.redirect,
              i = e.success;
            if (i && n) return void a.location(n);
            e.done.toggle(i),
              e.fail.toggle(!i),
              i ? e.done.focus() : e.fail.focus(),
              t.toggle(!i),
              R(e);
          }
          function G(e) {
            e.evt && e.evt.preventDefault(), (e.evt = null);
          }
          return f;
        })
      );
    },
    1655: function (e, t, n) {
      "use strict";
      var a = n(3949),
        i = n(5134);
      let o = {
        ARROW_LEFT: 37,
        ARROW_UP: 38,
        ARROW_RIGHT: 39,
        ARROW_DOWN: 40,
        ESCAPE: 27,
        SPACE: 32,
        ENTER: 13,
        HOME: 36,
        END: 35,
      };
      a.define(
        "navbar",
        (e.exports = function (e, t) {
          var n,
            l,
            c,
            r,
            d = {},
            s = e.tram,
            u = e(window),
            f = e(document),
            p = t.debounce,
            E = a.env(),
            b = ".w-nav",
            I = "w--open",
            y = "w--nav-dropdown-open",
            m = "w--nav-dropdown-toggle-open",
            g = "w--nav-dropdown-list-open",
            T = "w--nav-link-open",
            O = i.triggers,
            _ = e();
          function v() {
            a.resize.off(h);
          }
          function h() {
            l.each(G);
          }
          function R(n, a) {
            var i,
              l,
              d,
              s,
              p,
              E = e(a),
              I = e.data(a, b);
            I ||
              (I = e.data(a, b, {
                open: !1,
                el: E,
                config: {},
                selectedIdx: -1,
              })),
              (I.menu = E.find(".w-nav-menu")),
              (I.links = I.menu.find(".w-nav-link")),
              (I.dropdowns = I.menu.find(".w-dropdown")),
              (I.dropdownToggle = I.menu.find(".w-dropdown-toggle")),
              (I.dropdownList = I.menu.find(".w-dropdown-list")),
              (I.button = E.find(".w-nav-button")),
              (I.container = E.find(".w-container")),
              (I.overlayContainerId = "w-nav-overlay-" + n),
              (I.outside =
                ((i = I).outside && f.off("click" + b, i.outside),
                function (t) {
                  var n = e(t.target);
                  (r && n.closest(".w-editor-bem-EditorOverlay").length) ||
                    P(i, n);
                }));
            var y = E.find(".w-nav-brand");
            y &&
              "/" === y.attr("href") &&
              null == y.attr("aria-label") &&
              y.attr("aria-label", "home"),
              I.button.attr("style", "-webkit-user-select: text;"),
              null == I.button.attr("aria-label") &&
                I.button.attr("aria-label", "menu"),
              I.button.attr("role", "button"),
              I.button.attr("tabindex", "0"),
              I.button.attr("aria-controls", I.overlayContainerId),
              I.button.attr("aria-haspopup", "menu"),
              I.button.attr("aria-expanded", "false"),
              I.el.off(b),
              I.button.off(b),
              I.menu.off(b),
              L(I),
              c
                ? (N(I),
                  I.el.on(
                    "setting" + b,
                    ((l = I),
                    function (e, n) {
                      n = n || {};
                      var a = u.width();
                      L(l),
                        !0 === n.open && k(l, !0),
                        !1 === n.open && V(l, !0),
                        l.open &&
                          t.defer(function () {
                            a !== u.width() && C(l);
                          });
                    })
                  ))
                : ((d = I).overlay ||
                    ((d.overlay = e(
                      '<div class="w-nav-overlay" data-wf-ignore />'
                    ).appendTo(d.el)),
                    d.overlay.attr("id", d.overlayContainerId),
                    (d.parent = d.menu.parent()),
                    V(d, !0)),
                  I.button.on("click" + b, w(I)),
                  I.menu.on("click" + b, "a", M(I)),
                  I.button.on(
                    "keydown" + b,
                    ((s = I),
                    function (e) {
                      switch (e.keyCode) {
                        case o.SPACE:
                        case o.ENTER:
                          return (
                            w(s)(), e.preventDefault(), e.stopPropagation()
                          );
                        case o.ESCAPE:
                          return V(s), e.preventDefault(), e.stopPropagation();
                        case o.ARROW_RIGHT:
                        case o.ARROW_DOWN:
                        case o.HOME:
                        case o.END:
                          if (!s.open)
                            return e.preventDefault(), e.stopPropagation();
                          return (
                            e.keyCode === o.END
                              ? (s.selectedIdx = s.links.length - 1)
                              : (s.selectedIdx = 0),
                            S(s),
                            e.preventDefault(),
                            e.stopPropagation()
                          );
                      }
                    })
                  ),
                  I.el.on(
                    "keydown" + b,
                    ((p = I),
                    function (e) {
                      if (p.open)
                        switch (
                          ((p.selectedIdx = p.links.index(
                            document.activeElement
                          )),
                          e.keyCode)
                        ) {
                          case o.HOME:
                          case o.END:
                            return (
                              e.keyCode === o.END
                                ? (p.selectedIdx = p.links.length - 1)
                                : (p.selectedIdx = 0),
                              S(p),
                              e.preventDefault(),
                              e.stopPropagation()
                            );
                          case o.ESCAPE:
                            return (
                              V(p),
                              p.button.focus(),
                              e.preventDefault(),
                              e.stopPropagation()
                            );
                          case o.ARROW_LEFT:
                          case o.ARROW_UP:
                            return (
                              (p.selectedIdx = Math.max(-1, p.selectedIdx - 1)),
                              S(p),
                              e.preventDefault(),
                              e.stopPropagation()
                            );
                          case o.ARROW_RIGHT:
                          case o.ARROW_DOWN:
                            return (
                              (p.selectedIdx = Math.min(
                                p.links.length - 1,
                                p.selectedIdx + 1
                              )),
                              S(p),
                              e.preventDefault(),
                              e.stopPropagation()
                            );
                        }
                    })
                  )),
              G(n, a);
          }
          function A(t, n) {
            var a = e.data(n, b);
            a && (N(a), e.removeData(n, b));
          }
          function N(e) {
            e.overlay && (V(e, !0), e.overlay.remove(), (e.overlay = null));
          }
          function L(e) {
            var n = {},
              a = e.config || {},
              i = (n.animation = e.el.attr("data-animation") || "default");
            (n.animOver = /^over/.test(i)),
              (n.animDirect = /left$/.test(i) ? -1 : 1),
              a.animation !== i && e.open && t.defer(C, e),
              (n.easing = e.el.attr("data-easing") || "ease"),
              (n.easing2 = e.el.attr("data-easing2") || "ease");
            var o = e.el.attr("data-duration");
            (n.duration = null != o ? Number(o) : 400),
              (n.docHeight = e.el.attr("data-doc-height")),
              (e.config = n);
          }
          function S(e) {
            if (e.links[e.selectedIdx]) {
              var t = e.links[e.selectedIdx];
              t.focus(), M(t);
            }
          }
          function C(e) {
            e.open && (V(e, !0), k(e, !0));
          }
          function w(e) {
            return p(function () {
              e.open ? V(e) : k(e);
            });
          }
          function M(t) {
            return function (n) {
              var i = e(this).attr("href");
              if (!a.validClick(n.currentTarget))
                return void n.preventDefault();
              i && 0 === i.indexOf("#") && t.open && V(t);
            };
          }
          (d.ready =
            d.design =
            d.preview =
              function () {
                (c = E && a.env("design")),
                  (r = a.env("editor")),
                  (n = e(document.body)),
                  (l = f.find(b)).length && (l.each(R), v(), a.resize.on(h));
              }),
            (d.destroy = function () {
              (_ = e()), v(), l && l.length && l.each(A);
            });
          var P = p(function (e, t) {
            if (e.open) {
              var n = t.closest(".w-nav-menu");
              e.menu.is(n) || V(e);
            }
          });
          function G(t, n) {
            var a = e.data(n, b),
              i = (a.collapsed = "none" !== a.button.css("display"));
            if ((!a.open || i || c || V(a, !0), a.container.length)) {
              var o,
                l =
                  ("none" === (o = a.container.css(F)) && (o = ""),
                  function (t, n) {
                    (n = e(n)).css(F, ""), "none" === n.css(F) && n.css(F, o);
                  });
              a.links.each(l), a.dropdowns.each(l);
            }
            a.open && D(a);
          }
          var F = "max-width";
          function U(e, t) {
            t.setAttribute("data-nav-menu-open", "");
          }
          function x(e, t) {
            t.removeAttribute("data-nav-menu-open");
          }
          function k(e, t) {
            if (!e.open) {
              (e.open = !0),
                e.menu.each(U),
                e.links.addClass(T),
                e.dropdowns.addClass(y),
                e.dropdownToggle.addClass(m),
                e.dropdownList.addClass(g),
                e.button.addClass(I);
              var n = e.config;
              ("none" === n.animation ||
                !s.support.transform ||
                n.duration <= 0) &&
                (t = !0);
              var i = D(e),
                o = e.menu.outerHeight(!0),
                l = e.menu.outerWidth(!0),
                r = e.el.height(),
                d = e.el[0];
              if (
                (G(0, d),
                O.intro(0, d),
                a.redraw.up(),
                c || f.on("click" + b, e.outside),
                t)
              )
                return void p();
              var u = "transform " + n.duration + "ms " + n.easing;
              if (
                (e.overlay &&
                  ((_ = e.menu.prev()), e.overlay.show().append(e.menu)),
                n.animOver)
              ) {
                s(e.menu)
                  .add(u)
                  .set({ x: n.animDirect * l, height: i })
                  .start({ x: 0 })
                  .then(p),
                  e.overlay && e.overlay.width(l);
                return;
              }
              s(e.menu)
                .add(u)
                .set({ y: -(r + o) })
                .start({ y: 0 })
                .then(p);
            }
            function p() {
              e.button.attr("aria-expanded", "true");
            }
          }
          function D(e) {
            var t = e.config,
              a = t.docHeight ? f.height() : n.height();
            return (
              t.animOver
                ? e.menu.height(a)
                : "fixed" !== e.el.css("position") &&
                  (a -= e.el.outerHeight(!0)),
              e.overlay && e.overlay.height(a),
              a
            );
          }
          function V(e, t) {
            if (e.open) {
              (e.open = !1), e.button.removeClass(I);
              var n = e.config;
              if (
                (("none" === n.animation ||
                  !s.support.transform ||
                  n.duration <= 0) &&
                  (t = !0),
                O.outro(0, e.el[0]),
                f.off("click" + b, e.outside),
                t)
              ) {
                s(e.menu).stop(), c();
                return;
              }
              var a = "transform " + n.duration + "ms " + n.easing2,
                i = e.menu.outerHeight(!0),
                o = e.menu.outerWidth(!0),
                l = e.el.height();
              if (n.animOver)
                return void s(e.menu)
                  .add(a)
                  .start({ x: o * n.animDirect })
                  .then(c);
              s(e.menu)
                .add(a)
                .start({ y: -(l + i) })
                .then(c);
            }
            function c() {
              e.menu.height(""),
                s(e.menu).set({ x: 0, y: 0 }),
                e.menu.each(x),
                e.links.removeClass(T),
                e.dropdowns.removeClass(y),
                e.dropdownToggle.removeClass(m),
                e.dropdownList.removeClass(g),
                e.overlay &&
                  e.overlay.children().length &&
                  (_.length
                    ? e.menu.insertAfter(_)
                    : e.menu.prependTo(e.parent),
                  e.overlay.attr("style", "").hide()),
                e.el.triggerHandler("w-close"),
                e.button.attr("aria-expanded", "false");
            }
          }
          return d;
        })
      );
    },
    3946: function (e, t, n) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var a = {
        actionListPlaybackChanged: function () {
          return Q;
        },
        animationFrameChanged: function () {
          return D;
        },
        clearRequested: function () {
          return F;
        },
        elementStateChanged: function () {
          return j;
        },
        eventListenerAdded: function () {
          return U;
        },
        eventStateChanged: function () {
          return k;
        },
        instanceAdded: function () {
          return B;
        },
        instanceRemoved: function () {
          return W;
        },
        instanceStarted: function () {
          return X;
        },
        mediaQueriesDefined: function () {
          return H;
        },
        parameterChanged: function () {
          return V;
        },
        playbackRequested: function () {
          return P;
        },
        previewRequested: function () {
          return M;
        },
        rawDataImported: function () {
          return L;
        },
        sessionInitialized: function () {
          return S;
        },
        sessionStarted: function () {
          return C;
        },
        sessionStopped: function () {
          return w;
        },
        stopRequested: function () {
          return G;
        },
        testFrameRendered: function () {
          return x;
        },
        viewportWidthChanged: function () {
          return z;
        },
      };
      for (var i in a)
        Object.defineProperty(t, i, { enumerable: !0, get: a[i] });
      let o = n(7087),
        l = n(9468),
        {
          IX2_RAW_DATA_IMPORTED: c,
          IX2_SESSION_INITIALIZED: r,
          IX2_SESSION_STARTED: d,
          IX2_SESSION_STOPPED: s,
          IX2_PREVIEW_REQUESTED: u,
          IX2_PLAYBACK_REQUESTED: f,
          IX2_STOP_REQUESTED: p,
          IX2_CLEAR_REQUESTED: E,
          IX2_EVENT_LISTENER_ADDED: b,
          IX2_TEST_FRAME_RENDERED: I,
          IX2_EVENT_STATE_CHANGED: y,
          IX2_ANIMATION_FRAME_CHANGED: m,
          IX2_PARAMETER_CHANGED: g,
          IX2_INSTANCE_ADDED: T,
          IX2_INSTANCE_STARTED: O,
          IX2_INSTANCE_REMOVED: _,
          IX2_ELEMENT_STATE_CHANGED: v,
          IX2_ACTION_LIST_PLAYBACK_CHANGED: h,
          IX2_VIEWPORT_WIDTH_CHANGED: R,
          IX2_MEDIA_QUERIES_DEFINED: A,
        } = o.IX2EngineActionTypes,
        { reifyState: N } = l.IX2VanillaUtils,
        L = (e) => ({ type: c, payload: { ...N(e) } }),
        S = ({ hasBoundaryNodes: e, reducedMotion: t }) => ({
          type: r,
          payload: { hasBoundaryNodes: e, reducedMotion: t },
        }),
        C = () => ({ type: d }),
        w = () => ({ type: s }),
        M = ({ rawData: e, defer: t }) => ({
          type: u,
          payload: { defer: t, rawData: e },
        }),
        P = ({
          actionTypeId: e = o.ActionTypeConsts.GENERAL_START_ACTION,
          actionListId: t,
          actionItemId: n,
          eventId: a,
          allowEvents: i,
          immediate: l,
          testManual: c,
          verbose: r,
          rawData: d,
        }) => ({
          type: f,
          payload: {
            actionTypeId: e,
            actionListId: t,
            actionItemId: n,
            testManual: c,
            eventId: a,
            allowEvents: i,
            immediate: l,
            verbose: r,
            rawData: d,
          },
        }),
        G = (e) => ({ type: p, payload: { actionListId: e } }),
        F = () => ({ type: E }),
        U = (e, t) => ({ type: b, payload: { target: e, listenerParams: t } }),
        x = (e = 1) => ({ type: I, payload: { step: e } }),
        k = (e, t) => ({ type: y, payload: { stateKey: e, newState: t } }),
        D = (e, t) => ({ type: m, payload: { now: e, parameters: t } }),
        V = (e, t) => ({ type: g, payload: { key: e, value: t } }),
        B = (e) => ({ type: T, payload: { ...e } }),
        X = (e, t) => ({ type: O, payload: { instanceId: e, time: t } }),
        W = (e) => ({ type: _, payload: { instanceId: e } }),
        j = (e, t, n, a) => ({
          type: v,
          payload: { elementId: e, actionTypeId: t, current: n, actionItem: a },
        }),
        Q = ({ actionListId: e, isPlaying: t }) => ({
          type: h,
          payload: { actionListId: e, isPlaying: t },
        }),
        z = ({ width: e, mediaQueries: t }) => ({
          type: R,
          payload: { width: e, mediaQueries: t },
        }),
        H = () => ({ type: A });
    },
    6011: function (e, t, n) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var a,
        i = {
          actions: function () {
            return d;
          },
          destroy: function () {
            return E;
          },
          init: function () {
            return p;
          },
          setEnv: function () {
            return f;
          },
          store: function () {
            return u;
          },
        };
      for (var o in i)
        Object.defineProperty(t, o, { enumerable: !0, get: i[o] });
      let l = n(9516),
        c = (a = n(7243)) && a.__esModule ? a : { default: a },
        r = n(1970),
        d = (function (e, t) {
          if (e && e.__esModule) return e;
          if (null === e || ("object" != typeof e && "function" != typeof e))
            return { default: e };
          var n = s(t);
          if (n && n.has(e)) return n.get(e);
          var a = { __proto__: null },
            i = Object.defineProperty && Object.getOwnPropertyDescriptor;
          for (var o in e)
            if ("default" !== o && Object.prototype.hasOwnProperty.call(e, o)) {
              var l = i ? Object.getOwnPropertyDescriptor(e, o) : null;
              l && (l.get || l.set)
                ? Object.defineProperty(a, o, l)
                : (a[o] = e[o]);
            }
          return (a.default = e), n && n.set(e, a), a;
        })(n(3946));
      function s(e) {
        if ("function" != typeof WeakMap) return null;
        var t = new WeakMap(),
          n = new WeakMap();
        return (s = function (e) {
          return e ? n : t;
        })(e);
      }
      let u = (0, l.createStore)(c.default);
      function f(e) {
        e() && (0, r.observeRequests)(u);
      }
      function p(e) {
        E(), (0, r.startEngine)({ store: u, rawData: e, allowEvents: !0 });
      }
      function E() {
        (0, r.stopEngine)(u);
      }
    },
    5012: function (e, t, n) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var a = {
        elementContains: function () {
          return g;
        },
        getChildElements: function () {
          return O;
        },
        getClosestElement: function () {
          return v;
        },
        getProperty: function () {
          return E;
        },
        getQuerySelector: function () {
          return I;
        },
        getRefType: function () {
          return h;
        },
        getSiblingElements: function () {
          return _;
        },
        getStyle: function () {
          return p;
        },
        getValidDocument: function () {
          return y;
        },
        isSiblingNode: function () {
          return T;
        },
        matchSelector: function () {
          return b;
        },
        queryDocument: function () {
          return m;
        },
        setStyle: function () {
          return f;
        },
      };
      for (var i in a)
        Object.defineProperty(t, i, { enumerable: !0, get: a[i] });
      let o = n(9468),
        l = n(7087),
        { ELEMENT_MATCHES: c } = o.IX2BrowserSupport,
        {
          IX2_ID_DELIMITER: r,
          HTML_ELEMENT: d,
          PLAIN_OBJECT: s,
          WF_PAGE: u,
        } = l.IX2EngineConstants;
      function f(e, t, n) {
        e.style[t] = n;
      }
      function p(e, t) {
        return t.startsWith("--")
          ? window
              .getComputedStyle(document.documentElement)
              .getPropertyValue(t)
          : e.style instanceof CSSStyleDeclaration
          ? e.style[t]
          : void 0;
      }
      function E(e, t) {
        return e[t];
      }
      function b(e) {
        return (t) => t[c](e);
      }
      function I({ id: e, selector: t }) {
        if (e) {
          let t = e;
          if (-1 !== e.indexOf(r)) {
            let n = e.split(r),
              a = n[0];
            if (((t = n[1]), a !== document.documentElement.getAttribute(u)))
              return null;
          }
          return `[data-w-id="${t}"], [data-w-id^="${t}_instance"]`;
        }
        return t;
      }
      function y(e) {
        return null == e || e === document.documentElement.getAttribute(u)
          ? document
          : null;
      }
      function m(e, t) {
        return Array.prototype.slice.call(
          document.querySelectorAll(t ? e + " " + t : e)
        );
      }
      function g(e, t) {
        return e.contains(t);
      }
      function T(e, t) {
        return e !== t && e.parentNode === t.parentNode;
      }
      function O(e) {
        let t = [];
        for (let n = 0, { length: a } = e || []; n < a; n++) {
          let { children: a } = e[n],
            { length: i } = a;
          if (i) for (let e = 0; e < i; e++) t.push(a[e]);
        }
        return t;
      }
      function _(e = []) {
        let t = [],
          n = [];
        for (let a = 0, { length: i } = e; a < i; a++) {
          let { parentNode: i } = e[a];
          if (!i || !i.children || !i.children.length || -1 !== n.indexOf(i))
            continue;
          n.push(i);
          let o = i.firstElementChild;
          for (; null != o; )
            -1 === e.indexOf(o) && t.push(o), (o = o.nextElementSibling);
        }
        return t;
      }
      let v = Element.prototype.closest
        ? (e, t) => (document.documentElement.contains(e) ? e.closest(t) : null)
        : (e, t) => {
            if (!document.documentElement.contains(e)) return null;
            let n = e;
            do {
              if (n[c] && n[c](t)) return n;
              n = n.parentNode;
            } while (null != n);
            return null;
          };
      function h(e) {
        return null != e && "object" == typeof e
          ? e instanceof Element
            ? d
            : s
          : null;
      }
    },
    1970: function (e, t, n) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var a = {
        observeRequests: function () {
          return K;
        },
        startActionGroup: function () {
          return eE;
        },
        startEngine: function () {
          return ea;
        },
        stopActionGroup: function () {
          return ep;
        },
        stopAllActionGroups: function () {
          return ef;
        },
        stopEngine: function () {
          return ei;
        },
      };
      for (var i in a)
        Object.defineProperty(t, i, { enumerable: !0, get: a[i] });
      let o = m(n(9777)),
        l = m(n(4738)),
        c = m(n(4659)),
        r = m(n(3452)),
        d = m(n(6633)),
        s = m(n(3729)),
        u = m(n(2397)),
        f = m(n(5082)),
        p = n(7087),
        E = n(9468),
        b = n(3946),
        I = (function (e, t) {
          if (e && e.__esModule) return e;
          if (null === e || ("object" != typeof e && "function" != typeof e))
            return { default: e };
          var n = g(t);
          if (n && n.has(e)) return n.get(e);
          var a = { __proto__: null },
            i = Object.defineProperty && Object.getOwnPropertyDescriptor;
          for (var o in e)
            if ("default" !== o && Object.prototype.hasOwnProperty.call(e, o)) {
              var l = i ? Object.getOwnPropertyDescriptor(e, o) : null;
              l && (l.get || l.set)
                ? Object.defineProperty(a, o, l)
                : (a[o] = e[o]);
            }
          return (a.default = e), n && n.set(e, a), a;
        })(n(5012)),
        y = m(n(8955));
      function m(e) {
        return e && e.__esModule ? e : { default: e };
      }
      function g(e) {
        if ("function" != typeof WeakMap) return null;
        var t = new WeakMap(),
          n = new WeakMap();
        return (g = function (e) {
          return e ? n : t;
        })(e);
      }
      let T = Object.keys(p.QuickEffectIds),
        O = (e) => T.includes(e),
        {
          COLON_DELIMITER: _,
          BOUNDARY_SELECTOR: v,
          HTML_ELEMENT: h,
          RENDER_GENERAL: R,
          W_MOD_IX: A,
        } = p.IX2EngineConstants,
        {
          getAffectedElements: N,
          getElementId: L,
          getDestinationValues: S,
          observeStore: C,
          getInstanceId: w,
          renderHTMLElement: M,
          clearAllStyles: P,
          getMaxDurationItemIndex: G,
          getComputedStyle: F,
          getInstanceOrigin: U,
          reduceListToGroup: x,
          shouldNamespaceEventParameter: k,
          getNamespacedParameterId: D,
          shouldAllowMediaQuery: V,
          cleanupHTMLElement: B,
          clearObjectCache: X,
          stringifyTarget: W,
          mediaQueriesEqual: j,
          shallowEqual: Q,
        } = E.IX2VanillaUtils,
        {
          isPluginType: z,
          createPluginInstance: H,
          getPluginDuration: q,
        } = E.IX2VanillaPlugins,
        Y = navigator.userAgent,
        $ = Y.match(/iPad/i) || Y.match(/iPhone/);
      function K(e) {
        C({ store: e, select: ({ ixRequest: e }) => e.preview, onChange: Z }),
          C({
            store: e,
            select: ({ ixRequest: e }) => e.playback,
            onChange: ee,
          }),
          C({ store: e, select: ({ ixRequest: e }) => e.stop, onChange: et }),
          C({ store: e, select: ({ ixRequest: e }) => e.clear, onChange: en });
      }
      function Z({ rawData: e, defer: t }, n) {
        let a = () => {
          ea({ store: n, rawData: e, allowEvents: !0 }), J();
        };
        t ? setTimeout(a, 0) : a();
      }
      function J() {
        document.dispatchEvent(new CustomEvent("IX2_PAGE_UPDATE"));
      }
      function ee(e, t) {
        let {
            actionTypeId: n,
            actionListId: a,
            actionItemId: i,
            eventId: o,
            allowEvents: l,
            immediate: c,
            testManual: r,
            verbose: d = !0,
          } = e,
          { rawData: s } = e;
        if (a && i && s && c) {
          let e = s.actionLists[a];
          e && (s = x({ actionList: e, actionItemId: i, rawData: s }));
        }
        if (
          (ea({ store: t, rawData: s, allowEvents: l, testManual: r }),
          (a && n === p.ActionTypeConsts.GENERAL_START_ACTION) || O(n))
        ) {
          ep({ store: t, actionListId: a }),
            eu({ store: t, actionListId: a, eventId: o });
          let e = eE({
            store: t,
            eventId: o,
            actionListId: a,
            immediate: c,
            verbose: d,
          });
          d &&
            e &&
            t.dispatch(
              (0, b.actionListPlaybackChanged)({
                actionListId: a,
                isPlaying: !c,
              })
            );
        }
      }
      function et({ actionListId: e }, t) {
        e ? ep({ store: t, actionListId: e }) : ef({ store: t }), ei(t);
      }
      function en(e, t) {
        ei(t), P({ store: t, elementApi: I });
      }
      function ea({ store: e, rawData: t, allowEvents: n, testManual: a }) {
        let { ixSession: i } = e.getState();
        if ((t && e.dispatch((0, b.rawDataImported)(t)), !i.active)) {
          (e.dispatch(
            (0, b.sessionInitialized)({
              hasBoundaryNodes: !!document.querySelector(v),
              reducedMotion:
                document.body.hasAttribute("data-wf-ix-vacation") &&
                window.matchMedia("(prefers-reduced-motion)").matches,
            })
          ),
          n) &&
            ((function (e) {
              let { ixData: t } = e.getState(),
                { eventTypeMap: n } = t;
              ec(e),
                (0, u.default)(n, (t, n) => {
                  let a = y.default[n];
                  if (!a)
                    return void console.warn(
                      `IX2 event type not configured: ${n}`
                    );
                  !(function ({ logic: e, store: t, events: n }) {
                    !(function (e) {
                      if (!$) return;
                      let t = {},
                        n = "";
                      for (let a in e) {
                        let { eventTypeId: i, target: o } = e[a],
                          l = I.getQuerySelector(o);
                        t[l] ||
                          ((i === p.EventTypeConsts.MOUSE_CLICK ||
                            i === p.EventTypeConsts.MOUSE_SECOND_CLICK) &&
                            ((t[l] = !0),
                            (n +=
                              l +
                              "{cursor: pointer;touch-action: manipulation;}")));
                      }
                      if (n) {
                        let e = document.createElement("style");
                        (e.textContent = n), document.body.appendChild(e);
                      }
                    })(n);
                    let { types: a, handler: i } = e,
                      { ixData: r } = t.getState(),
                      { actionLists: d } = r,
                      s = er(n, es);
                    if (!(0, c.default)(s)) return;
                    (0, u.default)(s, (e, a) => {
                      let i = n[a],
                        {
                          action: c,
                          id: s,
                          mediaQueries: u = r.mediaQueryKeys,
                        } = i,
                        { actionListId: f } = c.config;
                      j(u, r.mediaQueryKeys) ||
                        t.dispatch((0, b.mediaQueriesDefined)()),
                        c.actionTypeId ===
                          p.ActionTypeConsts.GENERAL_CONTINUOUS_ACTION &&
                          (Array.isArray(i.config)
                            ? i.config
                            : [i.config]
                          ).forEach((n) => {
                            let { continuousParameterGroupId: a } = n,
                              i = (0, l.default)(
                                d,
                                `${f}.continuousParameterGroups`,
                                []
                              ),
                              c = (0, o.default)(i, ({ id: e }) => e === a),
                              r = (n.smoothing || 0) / 100,
                              u = (n.restingState || 0) / 100;
                            c &&
                              e.forEach((e, a) => {
                                !(function ({
                                  store: e,
                                  eventStateKey: t,
                                  eventTarget: n,
                                  eventId: a,
                                  eventConfig: i,
                                  actionListId: o,
                                  parameterGroup: c,
                                  smoothing: r,
                                  restingValue: d,
                                }) {
                                  let { ixData: s, ixSession: u } =
                                      e.getState(),
                                    { events: f } = s,
                                    E = f[a],
                                    { eventTypeId: b } = E,
                                    y = {},
                                    m = {},
                                    g = [],
                                    { continuousActionGroups: T } = c,
                                    { id: O } = c;
                                  k(b, i) && (O = D(t, O));
                                  let h =
                                    u.hasBoundaryNodes && n
                                      ? I.getClosestElement(n, v)
                                      : null;
                                  T.forEach((e) => {
                                    let { keyframe: t, actionItems: a } = e;
                                    a.forEach((e) => {
                                      let { actionTypeId: a } = e,
                                        { target: i } = e.config;
                                      if (!i) return;
                                      let o = i.boundaryMode ? h : null,
                                        l = W(i) + _ + a;
                                      if (
                                        ((m[l] = (function (e = [], t, n) {
                                          let a,
                                            i = [...e];
                                          return (
                                            i.some(
                                              (e, n) =>
                                                e.keyframe === t &&
                                                ((a = n), !0)
                                            ),
                                            null == a &&
                                              ((a = i.length),
                                              i.push({
                                                keyframe: t,
                                                actionItems: [],
                                              })),
                                            i[a].actionItems.push(n),
                                            i
                                          );
                                        })(m[l], t, e)),
                                        !y[l])
                                      ) {
                                        y[l] = !0;
                                        let { config: t } = e;
                                        N({
                                          config: t,
                                          event: E,
                                          eventTarget: n,
                                          elementRoot: o,
                                          elementApi: I,
                                        }).forEach((e) => {
                                          g.push({ element: e, key: l });
                                        });
                                      }
                                    });
                                  }),
                                    g.forEach(({ element: t, key: n }) => {
                                      let i = m[n],
                                        c = (0, l.default)(
                                          i,
                                          "[0].actionItems[0]",
                                          {}
                                        ),
                                        { actionTypeId: s } = c,
                                        u = (
                                          s === p.ActionTypeConsts.PLUGIN_RIVE
                                            ? 0 ===
                                              (
                                                c.config?.target
                                                  ?.selectorGuids || []
                                              ).length
                                            : z(s)
                                        )
                                          ? H(s)?.(t, c)
                                          : null,
                                        f = S(
                                          {
                                            element: t,
                                            actionItem: c,
                                            elementApi: I,
                                          },
                                          u
                                        );
                                      eb({
                                        store: e,
                                        element: t,
                                        eventId: a,
                                        actionListId: o,
                                        actionItem: c,
                                        destination: f,
                                        continuous: !0,
                                        parameterId: O,
                                        actionGroups: i,
                                        smoothing: r,
                                        restingValue: d,
                                        pluginInstance: u,
                                      });
                                    });
                                })({
                                  store: t,
                                  eventStateKey: s + _ + a,
                                  eventTarget: e,
                                  eventId: s,
                                  eventConfig: n,
                                  actionListId: f,
                                  parameterGroup: c,
                                  smoothing: r,
                                  restingValue: u,
                                });
                              });
                          }),
                        (c.actionTypeId ===
                          p.ActionTypeConsts.GENERAL_START_ACTION ||
                          O(c.actionTypeId)) &&
                          eu({ store: t, actionListId: f, eventId: s });
                    });
                    let E = (e) => {
                        let { ixSession: a } = t.getState();
                        ed(s, (o, l, c) => {
                          let d = n[l],
                            s = a.eventState[c],
                            { action: u, mediaQueries: f = r.mediaQueryKeys } =
                              d;
                          if (!V(f, a.mediaQueryKey)) return;
                          let E = (n = {}) => {
                            let a = i(
                              {
                                store: t,
                                element: o,
                                event: d,
                                eventConfig: n,
                                nativeEvent: e,
                                eventStateKey: c,
                              },
                              s
                            );
                            Q(a, s) ||
                              t.dispatch((0, b.eventStateChanged)(c, a));
                          };
                          u.actionTypeId ===
                          p.ActionTypeConsts.GENERAL_CONTINUOUS_ACTION
                            ? (Array.isArray(d.config)
                                ? d.config
                                : [d.config]
                              ).forEach(E)
                            : E();
                        });
                      },
                      y = (0, f.default)(E, 12),
                      m = ({ target: e = document, types: n, throttle: a }) => {
                        n.split(" ")
                          .filter(Boolean)
                          .forEach((n) => {
                            let i = a ? y : E;
                            e.addEventListener(n, i),
                              t.dispatch((0, b.eventListenerAdded)(e, [n, i]));
                          });
                      };
                    Array.isArray(a)
                      ? a.forEach(m)
                      : "string" == typeof a && m(e);
                  })({ logic: a, store: e, events: t });
                });
              let { ixSession: a } = e.getState();
              a.eventListeners.length &&
                (function (e) {
                  let t = () => {
                    ec(e);
                  };
                  el.forEach((n) => {
                    window.addEventListener(n, t),
                      e.dispatch((0, b.eventListenerAdded)(window, [n, t]));
                  }),
                    t();
                })(e);
            })(e),
            (function () {
              let { documentElement: e } = document;
              -1 === e.className.indexOf(A) && (e.className += ` ${A}`);
            })(),
            e.getState().ixSession.hasDefinedMediaQueries &&
              C({
                store: e,
                select: ({ ixSession: e }) => e.mediaQueryKey,
                onChange: () => {
                  ei(e),
                    P({ store: e, elementApi: I }),
                    ea({ store: e, allowEvents: !0 }),
                    J();
                },
              }));
          e.dispatch((0, b.sessionStarted)()),
            (function (e, t) {
              let n = (a) => {
                let { ixSession: i, ixParameters: o } = e.getState();
                if (i.active)
                  if ((e.dispatch((0, b.animationFrameChanged)(a, o)), t)) {
                    let t = C({
                      store: e,
                      select: ({ ixSession: e }) => e.tick,
                      onChange: (e) => {
                        n(e), t();
                      },
                    });
                  } else requestAnimationFrame(n);
              };
              n(window.performance.now());
            })(e, a);
        }
      }
      function ei(e) {
        let { ixSession: t } = e.getState();
        if (t.active) {
          let { eventListeners: n } = t;
          n.forEach(eo), X(), e.dispatch((0, b.sessionStopped)());
        }
      }
      function eo({ target: e, listenerParams: t }) {
        e.removeEventListener.apply(e, t);
      }
      let el = ["resize", "orientationchange"];
      function ec(e) {
        let { ixSession: t, ixData: n } = e.getState(),
          a = window.innerWidth;
        if (a !== t.viewportWidth) {
          let { mediaQueries: t } = n;
          e.dispatch(
            (0, b.viewportWidthChanged)({ width: a, mediaQueries: t })
          );
        }
      }
      let er = (e, t) => (0, r.default)((0, s.default)(e, t), d.default),
        ed = (e, t) => {
          (0, u.default)(e, (e, n) => {
            e.forEach((e, a) => {
              t(e, n, n + _ + a);
            });
          });
        },
        es = (e) =>
          N({
            config: { target: e.target, targets: e.targets },
            elementApi: I,
          });
      function eu({ store: e, actionListId: t, eventId: n }) {
        let { ixData: a, ixSession: i } = e.getState(),
          { actionLists: o, events: c } = a,
          r = c[n],
          d = o[t];
        if (d && d.useFirstGroupAsInitialState) {
          let o = (0, l.default)(d, "actionItemGroups[0].actionItems", []);
          if (
            !V(
              (0, l.default)(r, "mediaQueries", a.mediaQueryKeys),
              i.mediaQueryKey
            )
          )
            return;
          o.forEach((a) => {
            let { config: i, actionTypeId: o } = a,
              l = N({
                config:
                  i?.target?.useEventTarget === !0 &&
                  i?.target?.objectId == null
                    ? { target: r.target, targets: r.targets }
                    : i,
                event: r,
                elementApi: I,
              }),
              c = z(o);
            l.forEach((i) => {
              let l = c ? H(o)?.(i, a) : null;
              eb({
                destination: S({ element: i, actionItem: a, elementApi: I }, l),
                immediate: !0,
                store: e,
                element: i,
                eventId: n,
                actionItem: a,
                actionListId: t,
                pluginInstance: l,
              });
            });
          });
        }
      }
      function ef({ store: e }) {
        let { ixInstances: t } = e.getState();
        (0, u.default)(t, (t) => {
          if (!t.continuous) {
            let { actionListId: n, verbose: a } = t;
            eI(t, e),
              a &&
                e.dispatch(
                  (0, b.actionListPlaybackChanged)({
                    actionListId: n,
                    isPlaying: !1,
                  })
                );
          }
        });
      }
      function ep({
        store: e,
        eventId: t,
        eventTarget: n,
        eventStateKey: a,
        actionListId: i,
      }) {
        let { ixInstances: o, ixSession: c } = e.getState(),
          r = c.hasBoundaryNodes && n ? I.getClosestElement(n, v) : null;
        (0, u.default)(o, (n) => {
          let o = (0, l.default)(n, "actionItem.config.target.boundaryMode"),
            c = !a || n.eventStateKey === a;
          if (n.actionListId === i && n.eventId === t && c) {
            if (r && o && !I.elementContains(r, n.element)) return;
            eI(n, e),
              n.verbose &&
                e.dispatch(
                  (0, b.actionListPlaybackChanged)({
                    actionListId: i,
                    isPlaying: !1,
                  })
                );
          }
        });
      }
      function eE({
        store: e,
        eventId: t,
        eventTarget: n,
        eventStateKey: a,
        actionListId: i,
        groupIndex: o = 0,
        immediate: c,
        verbose: r,
      }) {
        let { ixData: d, ixSession: s } = e.getState(),
          { events: u } = d,
          f = u[t] || {},
          { mediaQueries: p = d.mediaQueryKeys } = f,
          { actionItemGroups: E, useFirstGroupAsInitialState: b } = (0,
          l.default)(d, `actionLists.${i}`, {});
        if (!E || !E.length) return !1;
        o >= E.length && (0, l.default)(f, "config.loop") && (o = 0),
          0 === o && b && o++;
        let y =
            (0 === o || (1 === o && b)) && O(f.action?.actionTypeId)
              ? f.config.delay
              : void 0,
          m = (0, l.default)(E, [o, "actionItems"], []);
        if (!m.length || !V(p, s.mediaQueryKey)) return !1;
        let g = s.hasBoundaryNodes && n ? I.getClosestElement(n, v) : null,
          T = G(m),
          _ = !1;
        return (
          m.forEach((l, d) => {
            let { config: s, actionTypeId: u } = l,
              p = z(u),
              { target: E } = s;
            E &&
              N({
                config: s,
                event: f,
                eventTarget: n,
                elementRoot: E.boundaryMode ? g : null,
                elementApi: I,
              }).forEach((s, f) => {
                let E = p ? H(u)?.(s, l) : null,
                  b = p ? q(u)(s, l) : null;
                _ = !0;
                let m = F({ element: s, actionItem: l }),
                  g = S({ element: s, actionItem: l, elementApi: I }, E);
                eb({
                  store: e,
                  element: s,
                  actionItem: l,
                  eventId: t,
                  eventTarget: n,
                  eventStateKey: a,
                  actionListId: i,
                  groupIndex: o,
                  isCarrier: T === d && 0 === f,
                  computedStyle: m,
                  destination: g,
                  immediate: c,
                  verbose: r,
                  pluginInstance: E,
                  pluginDuration: b,
                  instanceDelay: y,
                });
              });
          }),
          _
        );
      }
      function eb(e) {
        let t,
          { store: n, computedStyle: a, ...i } = e,
          {
            element: o,
            actionItem: l,
            immediate: c,
            pluginInstance: r,
            continuous: d,
            restingValue: s,
            eventId: u,
          } = i,
          f = w(),
          { ixElements: E, ixSession: y, ixData: m } = n.getState(),
          g = L(E, o),
          { refState: T } = E[g] || {},
          O = I.getRefType(o),
          _ = y.reducedMotion && p.ReducedMotionTypes[l.actionTypeId];
        if (_ && d)
          switch (m.events[u]?.eventTypeId) {
            case p.EventTypeConsts.MOUSE_MOVE:
            case p.EventTypeConsts.MOUSE_MOVE_IN_VIEWPORT:
              t = s;
              break;
            default:
              t = 0.5;
          }
        let v = U(o, T, a, l, I, r);
        if (
          (n.dispatch(
            (0, b.instanceAdded)({
              instanceId: f,
              elementId: g,
              origin: v,
              refType: O,
              skipMotion: _,
              skipToValue: t,
              ...i,
            })
          ),
          ey(document.body, "ix2-animation-started", f),
          c)
        )
          return void (function (e, t) {
            let { ixParameters: n } = e.getState();
            e.dispatch((0, b.instanceStarted)(t, 0)),
              e.dispatch((0, b.animationFrameChanged)(performance.now(), n));
            let { ixInstances: a } = e.getState();
            em(a[t], e);
          })(n, f);
        C({ store: n, select: ({ ixInstances: e }) => e[f], onChange: em }),
          d || n.dispatch((0, b.instanceStarted)(f, y.tick));
      }
      function eI(e, t) {
        ey(document.body, "ix2-animation-stopping", {
          instanceId: e.id,
          state: t.getState(),
        });
        let { elementId: n, actionItem: a } = e,
          { ixElements: i } = t.getState(),
          { ref: o, refType: l } = i[n] || {};
        l === h && B(o, a, I), t.dispatch((0, b.instanceRemoved)(e.id));
      }
      function ey(e, t, n) {
        let a = document.createEvent("CustomEvent");
        a.initCustomEvent(t, !0, !0, n), e.dispatchEvent(a);
      }
      function em(e, t) {
        let {
            active: n,
            continuous: a,
            complete: i,
            elementId: o,
            actionItem: l,
            actionTypeId: c,
            renderType: r,
            current: d,
            groupIndex: s,
            eventId: u,
            eventTarget: f,
            eventStateKey: p,
            actionListId: E,
            isCarrier: y,
            styleProp: m,
            verbose: g,
            pluginInstance: T,
          } = e,
          { ixData: O, ixSession: _ } = t.getState(),
          { events: v } = O,
          { mediaQueries: A = O.mediaQueryKeys } = v && v[u] ? v[u] : {};
        if (V(A, _.mediaQueryKey) && (a || n || i)) {
          if (d || (r === R && i)) {
            t.dispatch((0, b.elementStateChanged)(o, c, d, l));
            let { ixElements: e } = t.getState(),
              { ref: n, refType: a, refState: i } = e[o] || {},
              s = i && i[c];
            (a === h || z(c)) && M(n, i, s, u, l, m, I, r, T);
          }
          if (i) {
            if (y) {
              let e = eE({
                store: t,
                eventId: u,
                eventTarget: f,
                eventStateKey: p,
                actionListId: E,
                groupIndex: s + 1,
                verbose: g,
              });
              g &&
                !e &&
                t.dispatch(
                  (0, b.actionListPlaybackChanged)({
                    actionListId: E,
                    isPlaying: !1,
                  })
                );
            }
            eI(e, t);
          }
        }
      }
    },
    8955: function (e, t, n) {
      "use strict";
      let a;
      Object.defineProperty(t, "__esModule", { value: !0 }),
        Object.defineProperty(t, "default", {
          enumerable: !0,
          get: function () {
            return ep;
          },
        });
      let i = u(n(5801)),
        o = u(n(4738)),
        l = u(n(3789)),
        c = n(7087),
        r = n(1970),
        d = n(3946),
        s = n(9468);
      function u(e) {
        return e && e.__esModule ? e : { default: e };
      }
      let {
          MOUSE_CLICK: f,
          MOUSE_SECOND_CLICK: p,
          MOUSE_DOWN: E,
          MOUSE_UP: b,
          MOUSE_OVER: I,
          MOUSE_OUT: y,
          DROPDOWN_CLOSE: m,
          DROPDOWN_OPEN: g,
          SLIDER_ACTIVE: T,
          SLIDER_INACTIVE: O,
          TAB_ACTIVE: _,
          TAB_INACTIVE: v,
          NAVBAR_CLOSE: h,
          NAVBAR_OPEN: R,
          MOUSE_MOVE: A,
          PAGE_SCROLL_DOWN: N,
          SCROLL_INTO_VIEW: L,
          SCROLL_OUT_OF_VIEW: S,
          PAGE_SCROLL_UP: C,
          SCROLLING_IN_VIEW: w,
          PAGE_FINISH: M,
          ECOMMERCE_CART_CLOSE: P,
          ECOMMERCE_CART_OPEN: G,
          PAGE_START: F,
          PAGE_SCROLL: U,
        } = c.EventTypeConsts,
        x = "COMPONENT_ACTIVE",
        k = "COMPONENT_INACTIVE",
        { COLON_DELIMITER: D } = c.IX2EngineConstants,
        { getNamespacedParameterId: V } = s.IX2VanillaUtils,
        B = (e) => (t) => !!("object" == typeof t && e(t)) || t,
        X = B(({ element: e, nativeEvent: t }) => e === t.target),
        W = B(({ element: e, nativeEvent: t }) => e.contains(t.target)),
        j = (0, i.default)([X, W]),
        Q = (e, t) => {
          if (t) {
            let { ixData: n } = e.getState(),
              { events: a } = n,
              i = a[t];
            if (i && !ee[i.eventTypeId]) return i;
          }
          return null;
        },
        z = ({ store: e, event: t }) => {
          let { action: n } = t,
            { autoStopEventId: a } = n.config;
          return !!Q(e, a);
        },
        H = ({ store: e, event: t, element: n, eventStateKey: a }, i) => {
          let { action: l, id: c } = t,
            { actionListId: d, autoStopEventId: s } = l.config,
            u = Q(e, s);
          return (
            u &&
              (0, r.stopActionGroup)({
                store: e,
                eventId: s,
                eventTarget: n,
                eventStateKey: s + D + a.split(D)[1],
                actionListId: (0, o.default)(u, "action.config.actionListId"),
              }),
            (0, r.stopActionGroup)({
              store: e,
              eventId: c,
              eventTarget: n,
              eventStateKey: a,
              actionListId: d,
            }),
            (0, r.startActionGroup)({
              store: e,
              eventId: c,
              eventTarget: n,
              eventStateKey: a,
              actionListId: d,
            }),
            i
          );
        },
        q = (e, t) => (n, a) => !0 === e(n, a) ? t(n, a) : a,
        Y = { handler: q(j, H) },
        $ = { ...Y, types: [x, k].join(" ") },
        K = [
          { target: window, types: "resize orientationchange", throttle: !0 },
          {
            target: document,
            types: "scroll wheel readystatechange IX2_PAGE_UPDATE",
            throttle: !0,
          },
        ],
        Z = "mouseover mouseout",
        J = { types: K },
        ee = { PAGE_START: F, PAGE_FINISH: M },
        et = (() => {
          let e = void 0 !== window.pageXOffset,
            t =
              "CSS1Compat" === document.compatMode
                ? document.documentElement
                : document.body;
          return () => ({
            scrollLeft: e ? window.pageXOffset : t.scrollLeft,
            scrollTop: e ? window.pageYOffset : t.scrollTop,
            stiffScrollTop: (0, l.default)(
              e ? window.pageYOffset : t.scrollTop,
              0,
              t.scrollHeight - window.innerHeight
            ),
            scrollWidth: t.scrollWidth,
            scrollHeight: t.scrollHeight,
            clientWidth: t.clientWidth,
            clientHeight: t.clientHeight,
            innerWidth: window.innerWidth,
            innerHeight: window.innerHeight,
          });
        })(),
        en = (e, t) =>
          !(
            e.left > t.right ||
            e.right < t.left ||
            e.top > t.bottom ||
            e.bottom < t.top
          ),
        ea = ({ element: e, nativeEvent: t }) => {
          let { type: n, target: a, relatedTarget: i } = t,
            o = e.contains(a);
          if ("mouseover" === n && o) return !0;
          let l = e.contains(i);
          return "mouseout" === n && !!o && !!l;
        },
        ei = (e) => {
          let {
              element: t,
              event: { config: n },
            } = e,
            { clientWidth: a, clientHeight: i } = et(),
            o = n.scrollOffsetValue,
            l = "PX" === n.scrollOffsetUnit ? o : (i * (o || 0)) / 100;
          return en(t.getBoundingClientRect(), {
            left: 0,
            top: l,
            right: a,
            bottom: i - l,
          });
        },
        eo = (e) => (t, n) => {
          let { type: a } = t.nativeEvent,
            i = -1 !== [x, k].indexOf(a) ? a === x : n.isActive,
            o = { ...n, isActive: i };
          return ((!n || o.isActive !== n.isActive) && e(t, o)) || o;
        },
        el = (e) => (t, n) => {
          let a = { elementHovered: ea(t) };
          return (
            ((n ? a.elementHovered !== n.elementHovered : a.elementHovered) &&
              e(t, a)) ||
            a
          );
        },
        ec =
          (e) =>
          (t, n = {}) => {
            let a,
              i,
              { stiffScrollTop: o, scrollHeight: l, innerHeight: c } = et(),
              {
                event: { config: r, eventTypeId: d },
              } = t,
              { scrollOffsetValue: s, scrollOffsetUnit: u } = r,
              f = l - c,
              p = Number((o / f).toFixed(2));
            if (n && n.percentTop === p) return n;
            let E = ("PX" === u ? s : (c * (s || 0)) / 100) / f,
              b = 0;
            n &&
              ((a = p > n.percentTop),
              (b = (i = n.scrollingDown !== a) ? p : n.anchorTop));
            let I = d === N ? p >= b + E : p <= b - E,
              y = {
                ...n,
                percentTop: p,
                inBounds: I,
                anchorTop: b,
                scrollingDown: a,
              };
            return (n && I && (i || y.inBounds !== n.inBounds) && e(t, y)) || y;
          },
        er = (e, t) =>
          e.left > t.left &&
          e.left < t.right &&
          e.top > t.top &&
          e.top < t.bottom,
        ed =
          (e) =>
          (t, n = { clickCount: 0 }) => {
            let a = { clickCount: (n.clickCount % 2) + 1 };
            return (a.clickCount !== n.clickCount && e(t, a)) || a;
          },
        es = (e = !0) => ({
          ...$,
          handler: q(
            e ? j : X,
            eo((e, t) => (t.isActive ? Y.handler(e, t) : t))
          ),
        }),
        eu = (e = !0) => ({
          ...$,
          handler: q(
            e ? j : X,
            eo((e, t) => (t.isActive ? t : Y.handler(e, t)))
          ),
        }),
        ef = {
          ...J,
          handler:
            ((a = (e, t) => {
              let { elementVisible: n } = t,
                { event: a, store: i } = e,
                { ixData: o } = i.getState(),
                { events: l } = o;
              return !l[a.action.config.autoStopEventId] && t.triggered
                ? t
                : (a.eventTypeId === L) === n
                ? (H(e), { ...t, triggered: !0 })
                : t;
            }),
            (e, t) => {
              let n = { ...t, elementVisible: ei(e) };
              return (
                ((t
                  ? n.elementVisible !== t.elementVisible
                  : n.elementVisible) &&
                  a(e, n)) ||
                n
              );
            }),
        },
        ep = {
          [T]: es(),
          [O]: eu(),
          [g]: es(),
          [m]: eu(),
          [R]: es(!1),
          [h]: eu(!1),
          [_]: es(),
          [v]: eu(),
          [G]: { types: "ecommerce-cart-open", handler: q(j, H) },
          [P]: { types: "ecommerce-cart-close", handler: q(j, H) },
          [f]: {
            types: "click",
            handler: q(
              j,
              ed((e, { clickCount: t }) => {
                z(e) ? 1 === t && H(e) : H(e);
              })
            ),
          },
          [p]: {
            types: "click",
            handler: q(
              j,
              ed((e, { clickCount: t }) => {
                2 === t && H(e);
              })
            ),
          },
          [E]: { ...Y, types: "mousedown" },
          [b]: { ...Y, types: "mouseup" },
          [I]: {
            types: Z,
            handler: q(
              j,
              el((e, t) => {
                t.elementHovered && H(e);
              })
            ),
          },
          [y]: {
            types: Z,
            handler: q(
              j,
              el((e, t) => {
                t.elementHovered || H(e);
              })
            ),
          },
          [A]: {
            types: "mousemove mouseout scroll",
            handler: (
              {
                store: e,
                element: t,
                eventConfig: n,
                nativeEvent: a,
                eventStateKey: i,
              },
              o = { clientX: 0, clientY: 0, pageX: 0, pageY: 0 }
            ) => {
              let {
                  basedOn: l,
                  selectedAxis: r,
                  continuousParameterGroupId: s,
                  reverse: u,
                  restingState: f = 0,
                } = n,
                {
                  clientX: p = o.clientX,
                  clientY: E = o.clientY,
                  pageX: b = o.pageX,
                  pageY: I = o.pageY,
                } = a,
                y = "X_AXIS" === r,
                m = "mouseout" === a.type,
                g = f / 100,
                T = s,
                O = !1;
              switch (l) {
                case c.EventBasedOn.VIEWPORT:
                  g = y
                    ? Math.min(p, window.innerWidth) / window.innerWidth
                    : Math.min(E, window.innerHeight) / window.innerHeight;
                  break;
                case c.EventBasedOn.PAGE: {
                  let {
                    scrollLeft: e,
                    scrollTop: t,
                    scrollWidth: n,
                    scrollHeight: a,
                  } = et();
                  g = y ? Math.min(e + b, n) / n : Math.min(t + I, a) / a;
                  break;
                }
                case c.EventBasedOn.ELEMENT:
                default: {
                  T = V(i, s);
                  let e = 0 === a.type.indexOf("mouse");
                  if (e && !0 !== j({ element: t, nativeEvent: a })) break;
                  let n = t.getBoundingClientRect(),
                    { left: o, top: l, width: c, height: r } = n;
                  if (!e && !er({ left: p, top: E }, n)) break;
                  (O = !0), (g = y ? (p - o) / c : (E - l) / r);
                }
              }
              return (
                m && (g > 0.95 || g < 0.05) && (g = Math.round(g)),
                (l !== c.EventBasedOn.ELEMENT || O || O !== o.elementHovered) &&
                  ((g = u ? 1 - g : g),
                  e.dispatch((0, d.parameterChanged)(T, g))),
                {
                  elementHovered: O,
                  clientX: p,
                  clientY: E,
                  pageX: b,
                  pageY: I,
                }
              );
            },
          },
          [U]: {
            types: K,
            handler: ({ store: e, eventConfig: t }) => {
              let { continuousParameterGroupId: n, reverse: a } = t,
                { scrollTop: i, scrollHeight: o, clientHeight: l } = et(),
                c = i / (o - l);
              (c = a ? 1 - c : c), e.dispatch((0, d.parameterChanged)(n, c));
            },
          },
          [w]: {
            types: K,
            handler: (
              { element: e, store: t, eventConfig: n, eventStateKey: a },
              i = { scrollPercent: 0 }
            ) => {
              let {
                  scrollLeft: o,
                  scrollTop: l,
                  scrollWidth: r,
                  scrollHeight: s,
                  clientHeight: u,
                } = et(),
                {
                  basedOn: f,
                  selectedAxis: p,
                  continuousParameterGroupId: E,
                  startsEntering: b,
                  startsExiting: I,
                  addEndOffset: y,
                  addStartOffset: m,
                  addOffsetValue: g = 0,
                  endOffsetValue: T = 0,
                } = n;
              if (f === c.EventBasedOn.VIEWPORT) {
                let e = "X_AXIS" === p ? o / r : l / s;
                return (
                  e !== i.scrollPercent &&
                    t.dispatch((0, d.parameterChanged)(E, e)),
                  { scrollPercent: e }
                );
              }
              {
                let n = V(a, E),
                  o = e.getBoundingClientRect(),
                  l = (m ? g : 0) / 100,
                  c = (y ? T : 0) / 100;
                (l = b ? l : 1 - l), (c = I ? c : 1 - c);
                let r = o.top + Math.min(o.height * l, u),
                  f = Math.min(u + (o.top + o.height * c - r), s),
                  p = Math.min(Math.max(0, u - r), f) / f;
                return (
                  p !== i.scrollPercent &&
                    t.dispatch((0, d.parameterChanged)(n, p)),
                  { scrollPercent: p }
                );
              }
            },
          },
          [L]: ef,
          [S]: ef,
          [N]: {
            ...J,
            handler: ec((e, t) => {
              t.scrollingDown && H(e);
            }),
          },
          [C]: {
            ...J,
            handler: ec((e, t) => {
              t.scrollingDown || H(e);
            }),
          },
          [M]: {
            types: "readystatechange IX2_PAGE_UPDATE",
            handler: q(X, (e, t) => {
              let n = { finished: "complete" === document.readyState };
              return n.finished && !(t && t.finshed) && H(e), n;
            }),
          },
          [F]: {
            types: "readystatechange IX2_PAGE_UPDATE",
            handler: q(X, (e, t) => (t || H(e), { started: !0 })),
          },
        };
    },
    4609: function (e, t, n) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 }),
        Object.defineProperty(t, "ixData", {
          enumerable: !0,
          get: function () {
            return i;
          },
        });
      let { IX2_RAW_DATA_IMPORTED: a } = n(7087).IX2EngineActionTypes,
        i = (e = Object.freeze({}), t) =>
          t.type === a ? t.payload.ixData || Object.freeze({}) : e;
    },
    7718: function (e, t, n) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 }),
        Object.defineProperty(t, "ixInstances", {
          enumerable: !0,
          get: function () {
            return O;
          },
        });
      let a = n(7087),
        i = n(9468),
        o = n(1185),
        {
          IX2_RAW_DATA_IMPORTED: l,
          IX2_SESSION_STOPPED: c,
          IX2_INSTANCE_ADDED: r,
          IX2_INSTANCE_STARTED: d,
          IX2_INSTANCE_REMOVED: s,
          IX2_ANIMATION_FRAME_CHANGED: u,
        } = a.IX2EngineActionTypes,
        {
          optimizeFloat: f,
          applyEasing: p,
          createBezierEasing: E,
        } = i.IX2EasingUtils,
        { RENDER_GENERAL: b } = a.IX2EngineConstants,
        {
          getItemConfigByKey: I,
          getRenderType: y,
          getStyleProp: m,
        } = i.IX2VanillaUtils,
        g = (e, t) => {
          let n,
            a,
            i,
            l,
            {
              position: c,
              parameterId: r,
              actionGroups: d,
              destinationKeys: s,
              smoothing: u,
              restingValue: E,
              actionTypeId: b,
              customEasingFn: y,
              skipMotion: m,
              skipToValue: g,
            } = e,
            { parameters: T } = t.payload,
            O = Math.max(1 - u, 0.01),
            _ = T[r];
          null == _ && ((O = 1), (_ = E));
          let v = f((Math.max(_, 0) || 0) - c),
            h = m ? g : f(c + v * O),
            R = 100 * h;
          if (h === c && e.current) return e;
          for (let e = 0, { length: t } = d; e < t; e++) {
            let { keyframe: t, actionItems: o } = d[e];
            if ((0 === e && (n = o[0]), R >= t)) {
              n = o[0];
              let c = d[e + 1],
                r = c && R !== t;
              (a = r ? c.actionItems[0] : null),
                r && ((i = t / 100), (l = (c.keyframe - t) / 100));
            }
          }
          let A = {};
          if (n && !a)
            for (let e = 0, { length: t } = s; e < t; e++) {
              let t = s[e];
              A[t] = I(b, t, n.config);
            }
          else if (n && a && void 0 !== i && void 0 !== l) {
            let e = (h - i) / l,
              t = p(n.config.easing, e, y);
            for (let e = 0, { length: i } = s; e < i; e++) {
              let i = s[e],
                o = I(b, i, n.config),
                l = (I(b, i, a.config) - o) * t + o;
              A[i] = l;
            }
          }
          return (0, o.merge)(e, { position: h, current: A });
        },
        T = (e, t) => {
          let {
              active: n,
              origin: a,
              start: i,
              immediate: l,
              renderType: c,
              verbose: r,
              actionItem: d,
              destination: s,
              destinationKeys: u,
              pluginDuration: E,
              instanceDelay: I,
              customEasingFn: y,
              skipMotion: m,
            } = e,
            g = d.config.easing,
            { duration: T, delay: O } = d.config;
          null != E && (T = E),
            (O = null != I ? I : O),
            c === b ? (T = 0) : (l || m) && (T = O = 0);
          let { now: _ } = t.payload;
          if (n && a) {
            let t = _ - (i + O);
            if (r) {
              let t = T + O,
                n = f(Math.min(Math.max(0, (_ - i) / t), 1));
              e = (0, o.set)(e, "verboseTimeElapsed", t * n);
            }
            if (t < 0) return e;
            let n = f(Math.min(Math.max(0, t / T), 1)),
              l = p(g, n, y),
              c = {},
              d = null;
            return (
              u.length &&
                (d = u.reduce((e, t) => {
                  let n = s[t],
                    i = parseFloat(a[t]) || 0,
                    o = parseFloat(n) - i;
                  return (e[t] = o * l + i), e;
                }, {})),
              (c.current = d),
              (c.position = n),
              1 === n && ((c.active = !1), (c.complete = !0)),
              (0, o.merge)(e, c)
            );
          }
          return e;
        },
        O = (e = Object.freeze({}), t) => {
          switch (t.type) {
            case l:
              return t.payload.ixInstances || Object.freeze({});
            case c:
              return Object.freeze({});
            case r: {
              let {
                  instanceId: n,
                  elementId: a,
                  actionItem: i,
                  eventId: l,
                  eventTarget: c,
                  eventStateKey: r,
                  actionListId: d,
                  groupIndex: s,
                  isCarrier: u,
                  origin: f,
                  destination: p,
                  immediate: b,
                  verbose: I,
                  continuous: g,
                  parameterId: T,
                  actionGroups: O,
                  smoothing: _,
                  restingValue: v,
                  pluginInstance: h,
                  pluginDuration: R,
                  instanceDelay: A,
                  skipMotion: N,
                  skipToValue: L,
                } = t.payload,
                { actionTypeId: S } = i,
                C = y(S),
                w = m(C, S),
                M = Object.keys(p).filter(
                  (e) => null != p[e] && "string" != typeof p[e]
                ),
                { easing: P } = i.config;
              return (0, o.set)(e, n, {
                id: n,
                elementId: a,
                active: !1,
                position: 0,
                start: 0,
                origin: f,
                destination: p,
                destinationKeys: M,
                immediate: b,
                verbose: I,
                current: null,
                actionItem: i,
                actionTypeId: S,
                eventId: l,
                eventTarget: c,
                eventStateKey: r,
                actionListId: d,
                groupIndex: s,
                renderType: C,
                isCarrier: u,
                styleProp: w,
                continuous: g,
                parameterId: T,
                actionGroups: O,
                smoothing: _,
                restingValue: v,
                pluginInstance: h,
                pluginDuration: R,
                instanceDelay: A,
                skipMotion: N,
                skipToValue: L,
                customEasingFn:
                  Array.isArray(P) && 4 === P.length ? E(P) : void 0,
              });
            }
            case d: {
              let { instanceId: n, time: a } = t.payload;
              return (0, o.mergeIn)(e, [n], {
                active: !0,
                complete: !1,
                start: a,
              });
            }
            case s: {
              let { instanceId: n } = t.payload;
              if (!e[n]) return e;
              let a = {},
                i = Object.keys(e),
                { length: o } = i;
              for (let t = 0; t < o; t++) {
                let o = i[t];
                o !== n && (a[o] = e[o]);
              }
              return a;
            }
            case u: {
              let n = e,
                a = Object.keys(e),
                { length: i } = a;
              for (let l = 0; l < i; l++) {
                let i = a[l],
                  c = e[i],
                  r = c.continuous ? g : T;
                n = (0, o.set)(n, i, r(c, t));
              }
              return n;
            }
            default:
              return e;
          }
        };
    },
    1540: function (e, t, n) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 }),
        Object.defineProperty(t, "ixParameters", {
          enumerable: !0,
          get: function () {
            return l;
          },
        });
      let {
          IX2_RAW_DATA_IMPORTED: a,
          IX2_SESSION_STOPPED: i,
          IX2_PARAMETER_CHANGED: o,
        } = n(7087).IX2EngineActionTypes,
        l = (e = {}, t) => {
          switch (t.type) {
            case a:
              return t.payload.ixParameters || {};
            case i:
              return {};
            case o: {
              let { key: n, value: a } = t.payload;
              return (e[n] = a), e;
            }
            default:
              return e;
          }
        };
    },
    7243: function (e, t, n) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 }),
        Object.defineProperty(t, "default", {
          enumerable: !0,
          get: function () {
            return u;
          },
        });
      let a = n(9516),
        i = n(4609),
        o = n(628),
        l = n(5862),
        c = n(9468),
        r = n(7718),
        d = n(1540),
        { ixElements: s } = c.IX2ElementsReducer,
        u = (0, a.combineReducers)({
          ixData: i.ixData,
          ixRequest: o.ixRequest,
          ixSession: l.ixSession,
          ixElements: s,
          ixInstances: r.ixInstances,
          ixParameters: d.ixParameters,
        });
    },
    628: function (e, t, n) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 }),
        Object.defineProperty(t, "ixRequest", {
          enumerable: !0,
          get: function () {
            return u;
          },
        });
      let a = n(7087),
        i = n(1185),
        {
          IX2_PREVIEW_REQUESTED: o,
          IX2_PLAYBACK_REQUESTED: l,
          IX2_STOP_REQUESTED: c,
          IX2_CLEAR_REQUESTED: r,
        } = a.IX2EngineActionTypes,
        d = { preview: {}, playback: {}, stop: {}, clear: {} },
        s = Object.create(null, {
          [o]: { value: "preview" },
          [l]: { value: "playback" },
          [c]: { value: "stop" },
          [r]: { value: "clear" },
        }),
        u = (e = d, t) => {
          if (t.type in s) {
            let n = [s[t.type]];
            return (0, i.setIn)(e, [n], { ...t.payload });
          }
          return e;
        };
    },
    5862: function (e, t, n) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 }),
        Object.defineProperty(t, "ixSession", {
          enumerable: !0,
          get: function () {
            return I;
          },
        });
      let a = n(7087),
        i = n(1185),
        {
          IX2_SESSION_INITIALIZED: o,
          IX2_SESSION_STARTED: l,
          IX2_TEST_FRAME_RENDERED: c,
          IX2_SESSION_STOPPED: r,
          IX2_EVENT_LISTENER_ADDED: d,
          IX2_EVENT_STATE_CHANGED: s,
          IX2_ANIMATION_FRAME_CHANGED: u,
          IX2_ACTION_LIST_PLAYBACK_CHANGED: f,
          IX2_VIEWPORT_WIDTH_CHANGED: p,
          IX2_MEDIA_QUERIES_DEFINED: E,
        } = a.IX2EngineActionTypes,
        b = {
          active: !1,
          tick: 0,
          eventListeners: [],
          eventState: {},
          playbackState: {},
          viewportWidth: 0,
          mediaQueryKey: null,
          hasBoundaryNodes: !1,
          hasDefinedMediaQueries: !1,
          reducedMotion: !1,
        },
        I = (e = b, t) => {
          switch (t.type) {
            case o: {
              let { hasBoundaryNodes: n, reducedMotion: a } = t.payload;
              return (0, i.merge)(e, { hasBoundaryNodes: n, reducedMotion: a });
            }
            case l:
              return (0, i.set)(e, "active", !0);
            case c: {
              let {
                payload: { step: n = 20 },
              } = t;
              return (0, i.set)(e, "tick", e.tick + n);
            }
            case r:
              return b;
            case u: {
              let {
                payload: { now: n },
              } = t;
              return (0, i.set)(e, "tick", n);
            }
            case d: {
              let n = (0, i.addLast)(e.eventListeners, t.payload);
              return (0, i.set)(e, "eventListeners", n);
            }
            case s: {
              let { stateKey: n, newState: a } = t.payload;
              return (0, i.setIn)(e, ["eventState", n], a);
            }
            case f: {
              let { actionListId: n, isPlaying: a } = t.payload;
              return (0, i.setIn)(e, ["playbackState", n], a);
            }
            case p: {
              let { width: n, mediaQueries: a } = t.payload,
                o = a.length,
                l = null;
              for (let e = 0; e < o; e++) {
                let { key: t, min: i, max: o } = a[e];
                if (n >= i && n <= o) {
                  l = t;
                  break;
                }
              }
              return (0, i.merge)(e, { viewportWidth: n, mediaQueryKey: l });
            }
            case E:
              return (0, i.set)(e, "hasDefinedMediaQueries", !0);
            default:
              return e;
          }
        };
    },
    7377: function (e, t) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var n = {
        clearPlugin: function () {
          return s;
        },
        createPluginInstance: function () {
          return r;
        },
        getPluginConfig: function () {
          return i;
        },
        getPluginDestination: function () {
          return c;
        },
        getPluginDuration: function () {
          return o;
        },
        getPluginOrigin: function () {
          return l;
        },
        renderPlugin: function () {
          return d;
        },
      };
      for (var a in n)
        Object.defineProperty(t, a, { enumerable: !0, get: n[a] });
      let i = (e) => e.value,
        o = (e, t) => {
          if ("auto" !== t.config.duration) return null;
          let n = parseFloat(e.getAttribute("data-duration"));
          return n > 0
            ? 1e3 * n
            : 1e3 * parseFloat(e.getAttribute("data-default-duration"));
        },
        l = (e) => e || { value: 0 },
        c = (e) => ({ value: e.value }),
        r = (e) => {
          let t = window.Webflow.require("lottie");
          if (!t) return null;
          let n = t.createInstance(e);
          return n.stop(), n.setSubframe(!0), n;
        },
        d = (e, t, n) => {
          if (!e) return;
          let a = t[n.actionTypeId].value / 100;
          e.goToFrame(e.frames * a);
        },
        s = (e) => {
          let t = window.Webflow.require("lottie");
          t && t.createInstance(e).stop();
        };
    },
    2570: function (e, t) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var n = {
        clearPlugin: function () {
          return E;
        },
        createPluginInstance: function () {
          return f;
        },
        getPluginConfig: function () {
          return r;
        },
        getPluginDestination: function () {
          return u;
        },
        getPluginDuration: function () {
          return d;
        },
        getPluginOrigin: function () {
          return s;
        },
        renderPlugin: function () {
          return p;
        },
      };
      for (var a in n)
        Object.defineProperty(t, a, { enumerable: !0, get: n[a] });
      let i = "--wf-rive-fit",
        o = "--wf-rive-alignment",
        l = (e) => document.querySelector(`[data-w-id="${e}"]`),
        c = () => window.Webflow.require("rive"),
        r = (e, t) => e.value.inputs[t],
        d = () => null,
        s = (e, t) => {
          if (e) return e;
          let n = {},
            { inputs: a = {} } = t.config.value;
          for (let e in a) null == a[e] && (n[e] = 0);
          return n;
        },
        u = (e) => e.value.inputs ?? {},
        f = (e, t) => {
          if ((t.config?.target?.selectorGuids || []).length > 0) return e;
          let n = t?.config?.target?.pluginElement;
          return n ? l(n) : null;
        },
        p = (e, { PLUGIN_RIVE: t }, n) => {
          let a = c();
          if (!a) return;
          let l = a.getInstance(e),
            r = a.rive.StateMachineInputType,
            { name: d, inputs: s = {} } = n.config.value || {};
          function u(e) {
            if (e.loaded) n();
            else {
              let t = () => {
                n(), e?.off("load", t);
              };
              e?.on("load", t);
            }
            function n() {
              let n = e.stateMachineInputs(d);
              if (null != n) {
                if ((e.isPlaying || e.play(d, !1), i in s || o in s)) {
                  let t = e.layout,
                    n = s[i] ?? t.fit,
                    a = s[o] ?? t.alignment;
                  (n !== t.fit || a !== t.alignment) &&
                    (e.layout = t.copyWith({ fit: n, alignment: a }));
                }
                for (let e in s) {
                  if (e === i || e === o) continue;
                  let a = n.find((t) => t.name === e);
                  if (null != a)
                    switch (a.type) {
                      case r.Boolean:
                        null != s[e] && (a.value = !!s[e]);
                        break;
                      case r.Number: {
                        let n = t[e];
                        null != n && (a.value = n);
                        break;
                      }
                      case r.Trigger:
                        s[e] && a.fire();
                    }
                }
              }
            }
          }
          l?.rive ? u(l.rive) : a.setLoadHandler(e, u);
        },
        E = (e, t) => null;
    },
    2866: function (e, t) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var n = {
        clearPlugin: function () {
          return E;
        },
        createPluginInstance: function () {
          return f;
        },
        getPluginConfig: function () {
          return c;
        },
        getPluginDestination: function () {
          return u;
        },
        getPluginDuration: function () {
          return r;
        },
        getPluginOrigin: function () {
          return s;
        },
        renderPlugin: function () {
          return p;
        },
      };
      for (var a in n)
        Object.defineProperty(t, a, { enumerable: !0, get: n[a] });
      let i = (e) => document.querySelector(`[data-w-id="${e}"]`),
        o = () => window.Webflow.require("spline"),
        l = (e, t) => e.filter((e) => !t.includes(e)),
        c = (e, t) => e.value[t],
        r = () => null,
        d = Object.freeze({
          positionX: 0,
          positionY: 0,
          positionZ: 0,
          rotationX: 0,
          rotationY: 0,
          rotationZ: 0,
          scaleX: 1,
          scaleY: 1,
          scaleZ: 1,
        }),
        s = (e, t) => {
          let n = Object.keys(t.config.value);
          if (e) {
            let t = l(n, Object.keys(e));
            return t.length ? t.reduce((e, t) => ((e[t] = d[t]), e), e) : e;
          }
          return n.reduce((e, t) => ((e[t] = d[t]), e), {});
        },
        u = (e) => e.value,
        f = (e, t) => {
          let n = t?.config?.target?.pluginElement;
          return n ? i(n) : null;
        },
        p = (e, t, n) => {
          let a = o();
          if (!a) return;
          let i = a.getInstance(e),
            l = n.config.target.objectId,
            c = (e) => {
              if (!e) throw Error("Invalid spline app passed to renderSpline");
              let n = l && e.findObjectById(l);
              if (!n) return;
              let { PLUGIN_SPLINE: a } = t;
              null != a.positionX && (n.position.x = a.positionX),
                null != a.positionY && (n.position.y = a.positionY),
                null != a.positionZ && (n.position.z = a.positionZ),
                null != a.rotationX && (n.rotation.x = a.rotationX),
                null != a.rotationY && (n.rotation.y = a.rotationY),
                null != a.rotationZ && (n.rotation.z = a.rotationZ),
                null != a.scaleX && (n.scale.x = a.scaleX),
                null != a.scaleY && (n.scale.y = a.scaleY),
                null != a.scaleZ && (n.scale.z = a.scaleZ);
            };
          i ? c(i.spline) : a.setLoadHandler(e, c);
        },
        E = () => null;
    },
    1407: function (e, t, n) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var a = {
        clearPlugin: function () {
          return p;
        },
        createPluginInstance: function () {
          return s;
        },
        getPluginConfig: function () {
          return l;
        },
        getPluginDestination: function () {
          return d;
        },
        getPluginDuration: function () {
          return c;
        },
        getPluginOrigin: function () {
          return r;
        },
        renderPlugin: function () {
          return f;
        },
      };
      for (var i in a)
        Object.defineProperty(t, i, { enumerable: !0, get: a[i] });
      let o = n(380),
        l = (e, t) => e.value[t],
        c = () => null,
        r = (e, t) => {
          if (e) return e;
          let n = t.config.value,
            a = t.config.target.objectId,
            i = getComputedStyle(document.documentElement).getPropertyValue(a);
          return null != n.size
            ? { size: parseInt(i, 10) }
            : "%" === n.unit || "-" === n.unit
            ? { size: parseFloat(i) }
            : null != n.red && null != n.green && null != n.blue
            ? (0, o.normalizeColor)(i)
            : void 0;
        },
        d = (e) => e.value,
        s = () => null,
        u = {
          color: {
            match: ({ red: e, green: t, blue: n, alpha: a }) =>
              [e, t, n, a].every((e) => null != e),
            getValue: ({ red: e, green: t, blue: n, alpha: a }) =>
              `rgba(${e}, ${t}, ${n}, ${a})`,
          },
          size: {
            match: ({ size: e }) => null != e,
            getValue: ({ size: e }, t) => ("-" === t ? e : `${e}${t}`),
          },
        },
        f = (e, t, n) => {
          let {
              target: { objectId: a },
              value: { unit: i },
            } = n.config,
            o = t.PLUGIN_VARIABLE,
            l = Object.values(u).find((e) => e.match(o, i));
          l && document.documentElement.style.setProperty(a, l.getValue(o, i));
        },
        p = (e, t) => {
          let n = t.config.target.objectId;
          document.documentElement.style.removeProperty(n);
        };
    },
    3690: function (e, t, n) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 }),
        Object.defineProperty(t, "pluginMethodMap", {
          enumerable: !0,
          get: function () {
            return s;
          },
        });
      let a = n(7087),
        i = d(n(7377)),
        o = d(n(2866)),
        l = d(n(2570)),
        c = d(n(1407));
      function r(e) {
        if ("function" != typeof WeakMap) return null;
        var t = new WeakMap(),
          n = new WeakMap();
        return (r = function (e) {
          return e ? n : t;
        })(e);
      }
      function d(e, t) {
        if (!t && e && e.__esModule) return e;
        if (null === e || ("object" != typeof e && "function" != typeof e))
          return { default: e };
        var n = r(t);
        if (n && n.has(e)) return n.get(e);
        var a = { __proto__: null },
          i = Object.defineProperty && Object.getOwnPropertyDescriptor;
        for (var o in e)
          if ("default" !== o && Object.prototype.hasOwnProperty.call(e, o)) {
            var l = i ? Object.getOwnPropertyDescriptor(e, o) : null;
            l && (l.get || l.set)
              ? Object.defineProperty(a, o, l)
              : (a[o] = e[o]);
          }
        return (a.default = e), n && n.set(e, a), a;
      }
      let s = new Map([
        [a.ActionTypeConsts.PLUGIN_LOTTIE, { ...i }],
        [a.ActionTypeConsts.PLUGIN_SPLINE, { ...o }],
        [a.ActionTypeConsts.PLUGIN_RIVE, { ...l }],
        [a.ActionTypeConsts.PLUGIN_VARIABLE, { ...c }],
      ]);
    },
    8023: function (e, t) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var n = {
        IX2_ACTION_LIST_PLAYBACK_CHANGED: function () {
          return T;
        },
        IX2_ANIMATION_FRAME_CHANGED: function () {
          return E;
        },
        IX2_CLEAR_REQUESTED: function () {
          return u;
        },
        IX2_ELEMENT_STATE_CHANGED: function () {
          return g;
        },
        IX2_EVENT_LISTENER_ADDED: function () {
          return f;
        },
        IX2_EVENT_STATE_CHANGED: function () {
          return p;
        },
        IX2_INSTANCE_ADDED: function () {
          return I;
        },
        IX2_INSTANCE_REMOVED: function () {
          return m;
        },
        IX2_INSTANCE_STARTED: function () {
          return y;
        },
        IX2_MEDIA_QUERIES_DEFINED: function () {
          return _;
        },
        IX2_PARAMETER_CHANGED: function () {
          return b;
        },
        IX2_PLAYBACK_REQUESTED: function () {
          return d;
        },
        IX2_PREVIEW_REQUESTED: function () {
          return r;
        },
        IX2_RAW_DATA_IMPORTED: function () {
          return i;
        },
        IX2_SESSION_INITIALIZED: function () {
          return o;
        },
        IX2_SESSION_STARTED: function () {
          return l;
        },
        IX2_SESSION_STOPPED: function () {
          return c;
        },
        IX2_STOP_REQUESTED: function () {
          return s;
        },
        IX2_TEST_FRAME_RENDERED: function () {
          return v;
        },
        IX2_VIEWPORT_WIDTH_CHANGED: function () {
          return O;
        },
      };
      for (var a in n)
        Object.defineProperty(t, a, { enumerable: !0, get: n[a] });
      let i = "IX2_RAW_DATA_IMPORTED",
        o = "IX2_SESSION_INITIALIZED",
        l = "IX2_SESSION_STARTED",
        c = "IX2_SESSION_STOPPED",
        r = "IX2_PREVIEW_REQUESTED",
        d = "IX2_PLAYBACK_REQUESTED",
        s = "IX2_STOP_REQUESTED",
        u = "IX2_CLEAR_REQUESTED",
        f = "IX2_EVENT_LISTENER_ADDED",
        p = "IX2_EVENT_STATE_CHANGED",
        E = "IX2_ANIMATION_FRAME_CHANGED",
        b = "IX2_PARAMETER_CHANGED",
        I = "IX2_INSTANCE_ADDED",
        y = "IX2_INSTANCE_STARTED",
        m = "IX2_INSTANCE_REMOVED",
        g = "IX2_ELEMENT_STATE_CHANGED",
        T = "IX2_ACTION_LIST_PLAYBACK_CHANGED",
        O = "IX2_VIEWPORT_WIDTH_CHANGED",
        _ = "IX2_MEDIA_QUERIES_DEFINED",
        v = "IX2_TEST_FRAME_RENDERED";
    },
    2686: function (e, t) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var n = {
        ABSTRACT_NODE: function () {
          return et;
        },
        AUTO: function () {
          return j;
        },
        BACKGROUND: function () {
          return k;
        },
        BACKGROUND_COLOR: function () {
          return x;
        },
        BAR_DELIMITER: function () {
          return H;
        },
        BORDER_COLOR: function () {
          return D;
        },
        BOUNDARY_SELECTOR: function () {
          return r;
        },
        CHILDREN: function () {
          return q;
        },
        COLON_DELIMITER: function () {
          return z;
        },
        COLOR: function () {
          return V;
        },
        COMMA_DELIMITER: function () {
          return Q;
        },
        CONFIG_UNIT: function () {
          return I;
        },
        CONFIG_VALUE: function () {
          return f;
        },
        CONFIG_X_UNIT: function () {
          return p;
        },
        CONFIG_X_VALUE: function () {
          return d;
        },
        CONFIG_Y_UNIT: function () {
          return E;
        },
        CONFIG_Y_VALUE: function () {
          return s;
        },
        CONFIG_Z_UNIT: function () {
          return b;
        },
        CONFIG_Z_VALUE: function () {
          return u;
        },
        DISPLAY: function () {
          return B;
        },
        FILTER: function () {
          return P;
        },
        FLEX: function () {
          return X;
        },
        FONT_VARIATION_SETTINGS: function () {
          return G;
        },
        HEIGHT: function () {
          return U;
        },
        HTML_ELEMENT: function () {
          return J;
        },
        IMMEDIATE_CHILDREN: function () {
          return Y;
        },
        IX2_ID_DELIMITER: function () {
          return i;
        },
        OPACITY: function () {
          return M;
        },
        PARENT: function () {
          return K;
        },
        PLAIN_OBJECT: function () {
          return ee;
        },
        PRESERVE_3D: function () {
          return Z;
        },
        RENDER_GENERAL: function () {
          return ea;
        },
        RENDER_PLUGIN: function () {
          return eo;
        },
        RENDER_STYLE: function () {
          return ei;
        },
        RENDER_TRANSFORM: function () {
          return en;
        },
        ROTATE_X: function () {
          return A;
        },
        ROTATE_Y: function () {
          return N;
        },
        ROTATE_Z: function () {
          return L;
        },
        SCALE_3D: function () {
          return R;
        },
        SCALE_X: function () {
          return _;
        },
        SCALE_Y: function () {
          return v;
        },
        SCALE_Z: function () {
          return h;
        },
        SIBLINGS: function () {
          return $;
        },
        SKEW: function () {
          return S;
        },
        SKEW_X: function () {
          return C;
        },
        SKEW_Y: function () {
          return w;
        },
        TRANSFORM: function () {
          return y;
        },
        TRANSLATE_3D: function () {
          return O;
        },
        TRANSLATE_X: function () {
          return m;
        },
        TRANSLATE_Y: function () {
          return g;
        },
        TRANSLATE_Z: function () {
          return T;
        },
        WF_PAGE: function () {
          return o;
        },
        WIDTH: function () {
          return F;
        },
        WILL_CHANGE: function () {
          return W;
        },
        W_MOD_IX: function () {
          return c;
        },
        W_MOD_JS: function () {
          return l;
        },
      };
      for (var a in n)
        Object.defineProperty(t, a, { enumerable: !0, get: n[a] });
      let i = "|",
        o = "data-wf-page",
        l = "w-mod-js",
        c = "w-mod-ix",
        r = ".w-dyn-item",
        d = "xValue",
        s = "yValue",
        u = "zValue",
        f = "value",
        p = "xUnit",
        E = "yUnit",
        b = "zUnit",
        I = "unit",
        y = "transform",
        m = "translateX",
        g = "translateY",
        T = "translateZ",
        O = "translate3d",
        _ = "scaleX",
        v = "scaleY",
        h = "scaleZ",
        R = "scale3d",
        A = "rotateX",
        N = "rotateY",
        L = "rotateZ",
        S = "skew",
        C = "skewX",
        w = "skewY",
        M = "opacity",
        P = "filter",
        G = "font-variation-settings",
        F = "width",
        U = "height",
        x = "backgroundColor",
        k = "background",
        D = "borderColor",
        V = "color",
        B = "display",
        X = "flex",
        W = "willChange",
        j = "AUTO",
        Q = ",",
        z = ":",
        H = "|",
        q = "CHILDREN",
        Y = "IMMEDIATE_CHILDREN",
        $ = "SIBLINGS",
        K = "PARENT",
        Z = "preserve-3d",
        J = "HTML_ELEMENT",
        ee = "PLAIN_OBJECT",
        et = "ABSTRACT_NODE",
        en = "RENDER_TRANSFORM",
        ea = "RENDER_GENERAL",
        ei = "RENDER_STYLE",
        eo = "RENDER_PLUGIN";
    },
    262: function (e, t) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var n = {
        ActionAppliesTo: function () {
          return o;
        },
        ActionTypeConsts: function () {
          return i;
        },
      };
      for (var a in n)
        Object.defineProperty(t, a, { enumerable: !0, get: n[a] });
      let i = {
          TRANSFORM_MOVE: "TRANSFORM_MOVE",
          TRANSFORM_SCALE: "TRANSFORM_SCALE",
          TRANSFORM_ROTATE: "TRANSFORM_ROTATE",
          TRANSFORM_SKEW: "TRANSFORM_SKEW",
          STYLE_OPACITY: "STYLE_OPACITY",
          STYLE_SIZE: "STYLE_SIZE",
          STYLE_FILTER: "STYLE_FILTER",
          STYLE_FONT_VARIATION: "STYLE_FONT_VARIATION",
          STYLE_BACKGROUND_COLOR: "STYLE_BACKGROUND_COLOR",
          STYLE_BORDER: "STYLE_BORDER",
          STYLE_TEXT_COLOR: "STYLE_TEXT_COLOR",
          OBJECT_VALUE: "OBJECT_VALUE",
          PLUGIN_LOTTIE: "PLUGIN_LOTTIE",
          PLUGIN_SPLINE: "PLUGIN_SPLINE",
          PLUGIN_RIVE: "PLUGIN_RIVE",
          PLUGIN_VARIABLE: "PLUGIN_VARIABLE",
          GENERAL_DISPLAY: "GENERAL_DISPLAY",
          GENERAL_START_ACTION: "GENERAL_START_ACTION",
          GENERAL_CONTINUOUS_ACTION: "GENERAL_CONTINUOUS_ACTION",
          GENERAL_COMBO_CLASS: "GENERAL_COMBO_CLASS",
          GENERAL_STOP_ACTION: "GENERAL_STOP_ACTION",
          GENERAL_LOOP: "GENERAL_LOOP",
          STYLE_BOX_SHADOW: "STYLE_BOX_SHADOW",
        },
        o = {
          ELEMENT: "ELEMENT",
          ELEMENT_CLASS: "ELEMENT_CLASS",
          TRIGGER_ELEMENT: "TRIGGER_ELEMENT",
        };
    },
    7087: function (e, t, n) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var a = {
        ActionTypeConsts: function () {
          return l.ActionTypeConsts;
        },
        IX2EngineActionTypes: function () {
          return c;
        },
        IX2EngineConstants: function () {
          return r;
        },
        QuickEffectIds: function () {
          return o.QuickEffectIds;
        },
      };
      for (var i in a)
        Object.defineProperty(t, i, { enumerable: !0, get: a[i] });
      let o = d(n(1833), t),
        l = d(n(262), t);
      d(n(8704), t), d(n(3213), t);
      let c = u(n(8023)),
        r = u(n(2686));
      function d(e, t) {
        return (
          Object.keys(e).forEach(function (n) {
            "default" === n ||
              Object.prototype.hasOwnProperty.call(t, n) ||
              Object.defineProperty(t, n, {
                enumerable: !0,
                get: function () {
                  return e[n];
                },
              });
          }),
          e
        );
      }
      function s(e) {
        if ("function" != typeof WeakMap) return null;
        var t = new WeakMap(),
          n = new WeakMap();
        return (s = function (e) {
          return e ? n : t;
        })(e);
      }
      function u(e, t) {
        if (!t && e && e.__esModule) return e;
        if (null === e || ("object" != typeof e && "function" != typeof e))
          return { default: e };
        var n = s(t);
        if (n && n.has(e)) return n.get(e);
        var a = { __proto__: null },
          i = Object.defineProperty && Object.getOwnPropertyDescriptor;
        for (var o in e)
          if ("default" !== o && Object.prototype.hasOwnProperty.call(e, o)) {
            var l = i ? Object.getOwnPropertyDescriptor(e, o) : null;
            l && (l.get || l.set)
              ? Object.defineProperty(a, o, l)
              : (a[o] = e[o]);
          }
        return (a.default = e), n && n.set(e, a), a;
      }
    },
    3213: function (e, t, n) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 }),
        Object.defineProperty(t, "ReducedMotionTypes", {
          enumerable: !0,
          get: function () {
            return s;
          },
        });
      let {
          TRANSFORM_MOVE: a,
          TRANSFORM_SCALE: i,
          TRANSFORM_ROTATE: o,
          TRANSFORM_SKEW: l,
          STYLE_SIZE: c,
          STYLE_FILTER: r,
          STYLE_FONT_VARIATION: d,
        } = n(262).ActionTypeConsts,
        s = { [a]: !0, [i]: !0, [o]: !0, [l]: !0, [c]: !0, [r]: !0, [d]: !0 };
    },
    1833: function (e, t) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var n = {
        EventAppliesTo: function () {
          return o;
        },
        EventBasedOn: function () {
          return l;
        },
        EventContinuousMouseAxes: function () {
          return c;
        },
        EventLimitAffectedElements: function () {
          return r;
        },
        EventTypeConsts: function () {
          return i;
        },
        QuickEffectDirectionConsts: function () {
          return s;
        },
        QuickEffectIds: function () {
          return d;
        },
      };
      for (var a in n)
        Object.defineProperty(t, a, { enumerable: !0, get: n[a] });
      let i = {
          NAVBAR_OPEN: "NAVBAR_OPEN",
          NAVBAR_CLOSE: "NAVBAR_CLOSE",
          TAB_ACTIVE: "TAB_ACTIVE",
          TAB_INACTIVE: "TAB_INACTIVE",
          SLIDER_ACTIVE: "SLIDER_ACTIVE",
          SLIDER_INACTIVE: "SLIDER_INACTIVE",
          DROPDOWN_OPEN: "DROPDOWN_OPEN",
          DROPDOWN_CLOSE: "DROPDOWN_CLOSE",
          MOUSE_CLICK: "MOUSE_CLICK",
          MOUSE_SECOND_CLICK: "MOUSE_SECOND_CLICK",
          MOUSE_DOWN: "MOUSE_DOWN",
          MOUSE_UP: "MOUSE_UP",
          MOUSE_OVER: "MOUSE_OVER",
          MOUSE_OUT: "MOUSE_OUT",
          MOUSE_MOVE: "MOUSE_MOVE",
          MOUSE_MOVE_IN_VIEWPORT: "MOUSE_MOVE_IN_VIEWPORT",
          SCROLL_INTO_VIEW: "SCROLL_INTO_VIEW",
          SCROLL_OUT_OF_VIEW: "SCROLL_OUT_OF_VIEW",
          SCROLLING_IN_VIEW: "SCROLLING_IN_VIEW",
          ECOMMERCE_CART_OPEN: "ECOMMERCE_CART_OPEN",
          ECOMMERCE_CART_CLOSE: "ECOMMERCE_CART_CLOSE",
          PAGE_START: "PAGE_START",
          PAGE_FINISH: "PAGE_FINISH",
          PAGE_SCROLL_UP: "PAGE_SCROLL_UP",
          PAGE_SCROLL_DOWN: "PAGE_SCROLL_DOWN",
          PAGE_SCROLL: "PAGE_SCROLL",
        },
        o = { ELEMENT: "ELEMENT", CLASS: "CLASS", PAGE: "PAGE" },
        l = { ELEMENT: "ELEMENT", VIEWPORT: "VIEWPORT" },
        c = { X_AXIS: "X_AXIS", Y_AXIS: "Y_AXIS" },
        r = {
          CHILDREN: "CHILDREN",
          SIBLINGS: "SIBLINGS",
          IMMEDIATE_CHILDREN: "IMMEDIATE_CHILDREN",
        },
        d = {
          FADE_EFFECT: "FADE_EFFECT",
          SLIDE_EFFECT: "SLIDE_EFFECT",
          GROW_EFFECT: "GROW_EFFECT",
          SHRINK_EFFECT: "SHRINK_EFFECT",
          SPIN_EFFECT: "SPIN_EFFECT",
          FLY_EFFECT: "FLY_EFFECT",
          POP_EFFECT: "POP_EFFECT",
          FLIP_EFFECT: "FLIP_EFFECT",
          JIGGLE_EFFECT: "JIGGLE_EFFECT",
          PULSE_EFFECT: "PULSE_EFFECT",
          DROP_EFFECT: "DROP_EFFECT",
          BLINK_EFFECT: "BLINK_EFFECT",
          BOUNCE_EFFECT: "BOUNCE_EFFECT",
          FLIP_LEFT_TO_RIGHT_EFFECT: "FLIP_LEFT_TO_RIGHT_EFFECT",
          FLIP_RIGHT_TO_LEFT_EFFECT: "FLIP_RIGHT_TO_LEFT_EFFECT",
          RUBBER_BAND_EFFECT: "RUBBER_BAND_EFFECT",
          JELLO_EFFECT: "JELLO_EFFECT",
          GROW_BIG_EFFECT: "GROW_BIG_EFFECT",
          SHRINK_BIG_EFFECT: "SHRINK_BIG_EFFECT",
          PLUGIN_LOTTIE_EFFECT: "PLUGIN_LOTTIE_EFFECT",
        },
        s = {
          LEFT: "LEFT",
          RIGHT: "RIGHT",
          BOTTOM: "BOTTOM",
          TOP: "TOP",
          BOTTOM_LEFT: "BOTTOM_LEFT",
          BOTTOM_RIGHT: "BOTTOM_RIGHT",
          TOP_RIGHT: "TOP_RIGHT",
          TOP_LEFT: "TOP_LEFT",
          CLOCKWISE: "CLOCKWISE",
          COUNTER_CLOCKWISE: "COUNTER_CLOCKWISE",
        };
    },
    8704: function (e, t) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 }),
        Object.defineProperty(t, "InteractionTypeConsts", {
          enumerable: !0,
          get: function () {
            return n;
          },
        });
      let n = {
        MOUSE_CLICK_INTERACTION: "MOUSE_CLICK_INTERACTION",
        MOUSE_HOVER_INTERACTION: "MOUSE_HOVER_INTERACTION",
        MOUSE_MOVE_INTERACTION: "MOUSE_MOVE_INTERACTION",
        SCROLL_INTO_VIEW_INTERACTION: "SCROLL_INTO_VIEW_INTERACTION",
        SCROLLING_IN_VIEW_INTERACTION: "SCROLLING_IN_VIEW_INTERACTION",
        MOUSE_MOVE_IN_VIEWPORT_INTERACTION:
          "MOUSE_MOVE_IN_VIEWPORT_INTERACTION",
        PAGE_IS_SCROLLING_INTERACTION: "PAGE_IS_SCROLLING_INTERACTION",
        PAGE_LOAD_INTERACTION: "PAGE_LOAD_INTERACTION",
        PAGE_SCROLLED_INTERACTION: "PAGE_SCROLLED_INTERACTION",
        NAVBAR_INTERACTION: "NAVBAR_INTERACTION",
        DROPDOWN_INTERACTION: "DROPDOWN_INTERACTION",
        ECOMMERCE_CART_INTERACTION: "ECOMMERCE_CART_INTERACTION",
        TAB_INTERACTION: "TAB_INTERACTION",
        SLIDER_INTERACTION: "SLIDER_INTERACTION",
      };
    },
    380: function (e, t) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 }),
        Object.defineProperty(t, "normalizeColor", {
          enumerable: !0,
          get: function () {
            return a;
          },
        });
      let n = {
        aliceblue: "#F0F8FF",
        antiquewhite: "#FAEBD7",
        aqua: "#00FFFF",
        aquamarine: "#7FFFD4",
        azure: "#F0FFFF",
        beige: "#F5F5DC",
        bisque: "#FFE4C4",
        black: "#000000",
        blanchedalmond: "#FFEBCD",
        blue: "#0000FF",
        blueviolet: "#8A2BE2",
        brown: "#A52A2A",
        burlywood: "#DEB887",
        cadetblue: "#5F9EA0",
        chartreuse: "#7FFF00",
        chocolate: "#D2691E",
        coral: "#FF7F50",
        cornflowerblue: "#6495ED",
        cornsilk: "#FFF8DC",
        crimson: "#DC143C",
        cyan: "#00FFFF",
        darkblue: "#00008B",
        darkcyan: "#008B8B",
        darkgoldenrod: "#B8860B",
        darkgray: "#A9A9A9",
        darkgreen: "#006400",
        darkgrey: "#A9A9A9",
        darkkhaki: "#BDB76B",
        darkmagenta: "#8B008B",
        darkolivegreen: "#556B2F",
        darkorange: "#FF8C00",
        darkorchid: "#9932CC",
        darkred: "#8B0000",
        darksalmon: "#E9967A",
        darkseagreen: "#8FBC8F",
        darkslateblue: "#483D8B",
        darkslategray: "#2F4F4F",
        darkslategrey: "#2F4F4F",
        darkturquoise: "#00CED1",
        darkviolet: "#9400D3",
        deeppink: "#FF1493",
        deepskyblue: "#00BFFF",
        dimgray: "#696969",
        dimgrey: "#696969",
        dodgerblue: "#1E90FF",
        firebrick: "#B22222",
        floralwhite: "#FFFAF0",
        forestgreen: "#228B22",
        fuchsia: "#FF00FF",
        gainsboro: "#DCDCDC",
        ghostwhite: "#F8F8FF",
        gold: "#FFD700",
        goldenrod: "#DAA520",
        gray: "#808080",
        green: "#008000",
        greenyellow: "#ADFF2F",
        grey: "#808080",
        honeydew: "#F0FFF0",
        hotpink: "#FF69B4",
        indianred: "#CD5C5C",
        indigo: "#4B0082",
        ivory: "#FFFFF0",
        khaki: "#F0E68C",
        lavender: "#E6E6FA",
        lavenderblush: "#FFF0F5",
        lawngreen: "#7CFC00",
        lemonchiffon: "#FFFACD",
        lightblue: "#ADD8E6",
        lightcoral: "#F08080",
        lightcyan: "#E0FFFF",
        lightgoldenrodyellow: "#FAFAD2",
        lightgray: "#D3D3D3",
        lightgreen: "#90EE90",
        lightgrey: "#D3D3D3",
        lightpink: "#FFB6C1",
        lightsalmon: "#FFA07A",
        lightseagreen: "#20B2AA",
        lightskyblue: "#87CEFA",
        lightslategray: "#778899",
        lightslategrey: "#778899",
        lightsteelblue: "#B0C4DE",
        lightyellow: "#FFFFE0",
        lime: "#00FF00",
        limegreen: "#32CD32",
        linen: "#FAF0E6",
        magenta: "#FF00FF",
        maroon: "#800000",
        mediumaquamarine: "#66CDAA",
        mediumblue: "#0000CD",
        mediumorchid: "#BA55D3",
        mediumpurple: "#9370DB",
        mediumseagreen: "#3CB371",
        mediumslateblue: "#7B68EE",
        mediumspringgreen: "#00FA9A",
        mediumturquoise: "#48D1CC",
        mediumvioletred: "#C71585",
        midnightblue: "#191970",
        mintcream: "#F5FFFA",
        mistyrose: "#FFE4E1",
        moccasin: "#FFE4B5",
        navajowhite: "#FFDEAD",
        navy: "#000080",
        oldlace: "#FDF5E6",
        olive: "#808000",
        olivedrab: "#6B8E23",
        orange: "#FFA500",
        orangered: "#FF4500",
        orchid: "#DA70D6",
        palegoldenrod: "#EEE8AA",
        palegreen: "#98FB98",
        paleturquoise: "#AFEEEE",
        palevioletred: "#DB7093",
        papayawhip: "#FFEFD5",
        peachpuff: "#FFDAB9",
        peru: "#CD853F",
        pink: "#FFC0CB",
        plum: "#DDA0DD",
        powderblue: "#B0E0E6",
        purple: "#800080",
        rebeccapurple: "#663399",
        red: "#FF0000",
        rosybrown: "#BC8F8F",
        royalblue: "#4169E1",
        saddlebrown: "#8B4513",
        salmon: "#FA8072",
        sandybrown: "#F4A460",
        seagreen: "#2E8B57",
        seashell: "#FFF5EE",
        sienna: "#A0522D",
        silver: "#C0C0C0",
        skyblue: "#87CEEB",
        slateblue: "#6A5ACD",
        slategray: "#708090",
        slategrey: "#708090",
        snow: "#FFFAFA",
        springgreen: "#00FF7F",
        steelblue: "#4682B4",
        tan: "#D2B48C",
        teal: "#008080",
        thistle: "#D8BFD8",
        tomato: "#FF6347",
        turquoise: "#40E0D0",
        violet: "#EE82EE",
        wheat: "#F5DEB3",
        white: "#FFFFFF",
        whitesmoke: "#F5F5F5",
        yellow: "#FFFF00",
        yellowgreen: "#9ACD32",
      };
      function a(e) {
        let t,
          a,
          i,
          o = 1,
          l = e.replace(/\s/g, "").toLowerCase(),
          c = ("string" == typeof n[l] ? n[l].toLowerCase() : null) || l;
        if (c.startsWith("#")) {
          let e = c.substring(1);
          3 === e.length || 4 === e.length
            ? ((t = parseInt(e[0] + e[0], 16)),
              (a = parseInt(e[1] + e[1], 16)),
              (i = parseInt(e[2] + e[2], 16)),
              4 === e.length && (o = parseInt(e[3] + e[3], 16) / 255))
            : (6 === e.length || 8 === e.length) &&
              ((t = parseInt(e.substring(0, 2), 16)),
              (a = parseInt(e.substring(2, 4), 16)),
              (i = parseInt(e.substring(4, 6), 16)),
              8 === e.length && (o = parseInt(e.substring(6, 8), 16) / 255));
        } else if (c.startsWith("rgba")) {
          let e = c.match(/rgba\(([^)]+)\)/)[1].split(",");
          (t = parseInt(e[0], 10)),
            (a = parseInt(e[1], 10)),
            (i = parseInt(e[2], 10)),
            (o = parseFloat(e[3]));
        } else if (c.startsWith("rgb")) {
          let e = c.match(/rgb\(([^)]+)\)/)[1].split(",");
          (t = parseInt(e[0], 10)),
            (a = parseInt(e[1], 10)),
            (i = parseInt(e[2], 10));
        } else if (c.startsWith("hsla")) {
          let e,
            n,
            l,
            r = c.match(/hsla\(([^)]+)\)/)[1].split(","),
            d = parseFloat(r[0]),
            s = parseFloat(r[1].replace("%", "")) / 100,
            u = parseFloat(r[2].replace("%", "")) / 100;
          o = parseFloat(r[3]);
          let f = (1 - Math.abs(2 * u - 1)) * s,
            p = f * (1 - Math.abs(((d / 60) % 2) - 1)),
            E = u - f / 2;
          d >= 0 && d < 60
            ? ((e = f), (n = p), (l = 0))
            : d >= 60 && d < 120
            ? ((e = p), (n = f), (l = 0))
            : d >= 120 && d < 180
            ? ((e = 0), (n = f), (l = p))
            : d >= 180 && d < 240
            ? ((e = 0), (n = p), (l = f))
            : d >= 240 && d < 300
            ? ((e = p), (n = 0), (l = f))
            : ((e = f), (n = 0), (l = p)),
            (t = Math.round((e + E) * 255)),
            (a = Math.round((n + E) * 255)),
            (i = Math.round((l + E) * 255));
        } else if (c.startsWith("hsl")) {
          let e,
            n,
            o,
            l = c.match(/hsl\(([^)]+)\)/)[1].split(","),
            r = parseFloat(l[0]),
            d = parseFloat(l[1].replace("%", "")) / 100,
            s = parseFloat(l[2].replace("%", "")) / 100,
            u = (1 - Math.abs(2 * s - 1)) * d,
            f = u * (1 - Math.abs(((r / 60) % 2) - 1)),
            p = s - u / 2;
          r >= 0 && r < 60
            ? ((e = u), (n = f), (o = 0))
            : r >= 60 && r < 120
            ? ((e = f), (n = u), (o = 0))
            : r >= 120 && r < 180
            ? ((e = 0), (n = u), (o = f))
            : r >= 180 && r < 240
            ? ((e = 0), (n = f), (o = u))
            : r >= 240 && r < 300
            ? ((e = f), (n = 0), (o = u))
            : ((e = u), (n = 0), (o = f)),
            (t = Math.round((e + p) * 255)),
            (a = Math.round((n + p) * 255)),
            (i = Math.round((o + p) * 255));
        }
        if (Number.isNaN(t) || Number.isNaN(a) || Number.isNaN(i))
          throw Error(
            `Invalid color in [ix2/shared/utils/normalizeColor.js] '${e}'`
          );
        return { red: t, green: a, blue: i, alpha: o };
      }
    },
    9468: function (e, t, n) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var a = {
        IX2BrowserSupport: function () {
          return o;
        },
        IX2EasingUtils: function () {
          return c;
        },
        IX2Easings: function () {
          return l;
        },
        IX2ElementsReducer: function () {
          return r;
        },
        IX2VanillaPlugins: function () {
          return d;
        },
        IX2VanillaUtils: function () {
          return s;
        },
      };
      for (var i in a)
        Object.defineProperty(t, i, { enumerable: !0, get: a[i] });
      let o = f(n(2662)),
        l = f(n(8686)),
        c = f(n(3767)),
        r = f(n(5861)),
        d = f(n(1799)),
        s = f(n(4124));
      function u(e) {
        if ("function" != typeof WeakMap) return null;
        var t = new WeakMap(),
          n = new WeakMap();
        return (u = function (e) {
          return e ? n : t;
        })(e);
      }
      function f(e, t) {
        if (!t && e && e.__esModule) return e;
        if (null === e || ("object" != typeof e && "function" != typeof e))
          return { default: e };
        var n = u(t);
        if (n && n.has(e)) return n.get(e);
        var a = { __proto__: null },
          i = Object.defineProperty && Object.getOwnPropertyDescriptor;
        for (var o in e)
          if ("default" !== o && Object.prototype.hasOwnProperty.call(e, o)) {
            var l = i ? Object.getOwnPropertyDescriptor(e, o) : null;
            l && (l.get || l.set)
              ? Object.defineProperty(a, o, l)
              : (a[o] = e[o]);
          }
        return (a.default = e), n && n.set(e, a), a;
      }
    },
    2662: function (e, t, n) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var a,
        i = {
          ELEMENT_MATCHES: function () {
            return d;
          },
          FLEX_PREFIXED: function () {
            return s;
          },
          IS_BROWSER_ENV: function () {
            return c;
          },
          TRANSFORM_PREFIXED: function () {
            return u;
          },
          TRANSFORM_STYLE_PREFIXED: function () {
            return p;
          },
          withBrowser: function () {
            return r;
          },
        };
      for (var o in i)
        Object.defineProperty(t, o, { enumerable: !0, get: i[o] });
      let l = (a = n(9777)) && a.__esModule ? a : { default: a },
        c = "undefined" != typeof window,
        r = (e, t) => (c ? e() : t),
        d = r(() =>
          (0, l.default)(
            [
              "matches",
              "matchesSelector",
              "mozMatchesSelector",
              "msMatchesSelector",
              "oMatchesSelector",
              "webkitMatchesSelector",
            ],
            (e) => e in Element.prototype
          )
        ),
        s = r(() => {
          let e = document.createElement("i"),
            t = [
              "flex",
              "-webkit-flex",
              "-ms-flexbox",
              "-moz-box",
              "-webkit-box",
            ];
          try {
            let { length: n } = t;
            for (let a = 0; a < n; a++) {
              let n = t[a];
              if (((e.style.display = n), e.style.display === n)) return n;
            }
            return "";
          } catch (e) {
            return "";
          }
        }, "flex"),
        u = r(() => {
          let e = document.createElement("i");
          if (null == e.style.transform) {
            let t = ["Webkit", "Moz", "ms"],
              { length: n } = t;
            for (let a = 0; a < n; a++) {
              let n = t[a] + "Transform";
              if (void 0 !== e.style[n]) return n;
            }
          }
          return "transform";
        }, "transform"),
        f = u.split("transform")[0],
        p = f ? f + "TransformStyle" : "transformStyle";
    },
    3767: function (e, t, n) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var a,
        i = {
          applyEasing: function () {
            return u;
          },
          createBezierEasing: function () {
            return s;
          },
          optimizeFloat: function () {
            return d;
          },
        };
      for (var o in i)
        Object.defineProperty(t, o, { enumerable: !0, get: i[o] });
      let l = (function (e, t) {
          if (e && e.__esModule) return e;
          if (null === e || ("object" != typeof e && "function" != typeof e))
            return { default: e };
          var n = r(t);
          if (n && n.has(e)) return n.get(e);
          var a = { __proto__: null },
            i = Object.defineProperty && Object.getOwnPropertyDescriptor;
          for (var o in e)
            if ("default" !== o && Object.prototype.hasOwnProperty.call(e, o)) {
              var l = i ? Object.getOwnPropertyDescriptor(e, o) : null;
              l && (l.get || l.set)
                ? Object.defineProperty(a, o, l)
                : (a[o] = e[o]);
            }
          return (a.default = e), n && n.set(e, a), a;
        })(n(8686)),
        c = (a = n(1361)) && a.__esModule ? a : { default: a };
      function r(e) {
        if ("function" != typeof WeakMap) return null;
        var t = new WeakMap(),
          n = new WeakMap();
        return (r = function (e) {
          return e ? n : t;
        })(e);
      }
      function d(e, t = 5, n = 10) {
        let a = Math.pow(n, t),
          i = Number(Math.round(e * a) / a);
        return Math.abs(i) > 1e-4 ? i : 0;
      }
      function s(e) {
        return (0, c.default)(...e);
      }
      function u(e, t, n) {
        return 0 === t
          ? 0
          : 1 === t
          ? 1
          : n
          ? d(t > 0 ? n(t) : t)
          : d(t > 0 && e && l[e] ? l[e](t) : t);
      }
    },
    8686: function (e, t, n) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var a,
        i = {
          bounce: function () {
            return X;
          },
          bouncePast: function () {
            return W;
          },
          ease: function () {
            return c;
          },
          easeIn: function () {
            return r;
          },
          easeInOut: function () {
            return s;
          },
          easeOut: function () {
            return d;
          },
          inBack: function () {
            return P;
          },
          inCirc: function () {
            return S;
          },
          inCubic: function () {
            return E;
          },
          inElastic: function () {
            return U;
          },
          inExpo: function () {
            return A;
          },
          inOutBack: function () {
            return F;
          },
          inOutCirc: function () {
            return w;
          },
          inOutCubic: function () {
            return I;
          },
          inOutElastic: function () {
            return k;
          },
          inOutExpo: function () {
            return L;
          },
          inOutQuad: function () {
            return p;
          },
          inOutQuart: function () {
            return g;
          },
          inOutQuint: function () {
            return _;
          },
          inOutSine: function () {
            return R;
          },
          inQuad: function () {
            return u;
          },
          inQuart: function () {
            return y;
          },
          inQuint: function () {
            return T;
          },
          inSine: function () {
            return v;
          },
          outBack: function () {
            return G;
          },
          outBounce: function () {
            return M;
          },
          outCirc: function () {
            return C;
          },
          outCubic: function () {
            return b;
          },
          outElastic: function () {
            return x;
          },
          outExpo: function () {
            return N;
          },
          outQuad: function () {
            return f;
          },
          outQuart: function () {
            return m;
          },
          outQuint: function () {
            return O;
          },
          outSine: function () {
            return h;
          },
          swingFrom: function () {
            return V;
          },
          swingFromTo: function () {
            return D;
          },
          swingTo: function () {
            return B;
          },
        };
      for (var o in i)
        Object.defineProperty(t, o, { enumerable: !0, get: i[o] });
      let l = (a = n(1361)) && a.__esModule ? a : { default: a },
        c = (0, l.default)(0.25, 0.1, 0.25, 1),
        r = (0, l.default)(0.42, 0, 1, 1),
        d = (0, l.default)(0, 0, 0.58, 1),
        s = (0, l.default)(0.42, 0, 0.58, 1);
      function u(e) {
        return Math.pow(e, 2);
      }
      function f(e) {
        return -(Math.pow(e - 1, 2) - 1);
      }
      function p(e) {
        return (e /= 0.5) < 1
          ? 0.5 * Math.pow(e, 2)
          : -0.5 * ((e -= 2) * e - 2);
      }
      function E(e) {
        return Math.pow(e, 3);
      }
      function b(e) {
        return Math.pow(e - 1, 3) + 1;
      }
      function I(e) {
        return (e /= 0.5) < 1
          ? 0.5 * Math.pow(e, 3)
          : 0.5 * (Math.pow(e - 2, 3) + 2);
      }
      function y(e) {
        return Math.pow(e, 4);
      }
      function m(e) {
        return -(Math.pow(e - 1, 4) - 1);
      }
      function g(e) {
        return (e /= 0.5) < 1
          ? 0.5 * Math.pow(e, 4)
          : -0.5 * ((e -= 2) * Math.pow(e, 3) - 2);
      }
      function T(e) {
        return Math.pow(e, 5);
      }
      function O(e) {
        return Math.pow(e - 1, 5) + 1;
      }
      function _(e) {
        return (e /= 0.5) < 1
          ? 0.5 * Math.pow(e, 5)
          : 0.5 * (Math.pow(e - 2, 5) + 2);
      }
      function v(e) {
        return -Math.cos((Math.PI / 2) * e) + 1;
      }
      function h(e) {
        return Math.sin((Math.PI / 2) * e);
      }
      function R(e) {
        return -0.5 * (Math.cos(Math.PI * e) - 1);
      }
      function A(e) {
        return 0 === e ? 0 : Math.pow(2, 10 * (e - 1));
      }
      function N(e) {
        return 1 === e ? 1 : -Math.pow(2, -10 * e) + 1;
      }
      function L(e) {
        return 0 === e
          ? 0
          : 1 === e
          ? 1
          : (e /= 0.5) < 1
          ? 0.5 * Math.pow(2, 10 * (e - 1))
          : 0.5 * (-Math.pow(2, -10 * --e) + 2);
      }
      function S(e) {
        return -(Math.sqrt(1 - e * e) - 1);
      }
      function C(e) {
        return Math.sqrt(1 - Math.pow(e - 1, 2));
      }
      function w(e) {
        return (e /= 0.5) < 1
          ? -0.5 * (Math.sqrt(1 - e * e) - 1)
          : 0.5 * (Math.sqrt(1 - (e -= 2) * e) + 1);
      }
      function M(e) {
        return e < 1 / 2.75
          ? 7.5625 * e * e
          : e < 2 / 2.75
          ? 7.5625 * (e -= 1.5 / 2.75) * e + 0.75
          : e < 2.5 / 2.75
          ? 7.5625 * (e -= 2.25 / 2.75) * e + 0.9375
          : 7.5625 * (e -= 2.625 / 2.75) * e + 0.984375;
      }
      function P(e) {
        return e * e * (2.70158 * e - 1.70158);
      }
      function G(e) {
        return (e -= 1) * e * (2.70158 * e + 1.70158) + 1;
      }
      function F(e) {
        let t = 1.70158;
        return (e /= 0.5) < 1
          ? 0.5 * (e * e * (((t *= 1.525) + 1) * e - t))
          : 0.5 * ((e -= 2) * e * (((t *= 1.525) + 1) * e + t) + 2);
      }
      function U(e) {
        let t = 1.70158,
          n = 0,
          a = 1;
        return 0 === e
          ? 0
          : 1 === e
          ? 1
          : (n || (n = 0.3),
            a < 1
              ? ((a = 1), (t = n / 4))
              : (t = (n / (2 * Math.PI)) * Math.asin(1 / a)),
            -(
              a *
              Math.pow(2, 10 * (e -= 1)) *
              Math.sin((2 * Math.PI * (e - t)) / n)
            ));
      }
      function x(e) {
        let t = 1.70158,
          n = 0,
          a = 1;
        return 0 === e
          ? 0
          : 1 === e
          ? 1
          : (n || (n = 0.3),
            a < 1
              ? ((a = 1), (t = n / 4))
              : (t = (n / (2 * Math.PI)) * Math.asin(1 / a)),
            a * Math.pow(2, -10 * e) * Math.sin((2 * Math.PI * (e - t)) / n) +
              1);
      }
      function k(e) {
        let t = 1.70158,
          n = 0,
          a = 1;
        return 0 === e
          ? 0
          : 2 == (e /= 0.5)
          ? 1
          : (n || (n = 0.3 * 1.5),
            a < 1
              ? ((a = 1), (t = n / 4))
              : (t = (n / (2 * Math.PI)) * Math.asin(1 / a)),
            e < 1)
          ? -0.5 *
            (a *
              Math.pow(2, 10 * (e -= 1)) *
              Math.sin((2 * Math.PI * (e - t)) / n))
          : a *
              Math.pow(2, -10 * (e -= 1)) *
              Math.sin((2 * Math.PI * (e - t)) / n) *
              0.5 +
            1;
      }
      function D(e) {
        let t = 1.70158;
        return (e /= 0.5) < 1
          ? 0.5 * (e * e * (((t *= 1.525) + 1) * e - t))
          : 0.5 * ((e -= 2) * e * (((t *= 1.525) + 1) * e + t) + 2);
      }
      function V(e) {
        return e * e * (2.70158 * e - 1.70158);
      }
      function B(e) {
        return (e -= 1) * e * (2.70158 * e + 1.70158) + 1;
      }
      function X(e) {
        return e < 1 / 2.75
          ? 7.5625 * e * e
          : e < 2 / 2.75
          ? 7.5625 * (e -= 1.5 / 2.75) * e + 0.75
          : e < 2.5 / 2.75
          ? 7.5625 * (e -= 2.25 / 2.75) * e + 0.9375
          : 7.5625 * (e -= 2.625 / 2.75) * e + 0.984375;
      }
      function W(e) {
        return e < 1 / 2.75
          ? 7.5625 * e * e
          : e < 2 / 2.75
          ? 2 - (7.5625 * (e -= 1.5 / 2.75) * e + 0.75)
          : e < 2.5 / 2.75
          ? 2 - (7.5625 * (e -= 2.25 / 2.75) * e + 0.9375)
          : 2 - (7.5625 * (e -= 2.625 / 2.75) * e + 0.984375);
      }
    },
    1799: function (e, t, n) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var a = {
        clearPlugin: function () {
          return b;
        },
        createPluginInstance: function () {
          return p;
        },
        getPluginConfig: function () {
          return d;
        },
        getPluginDestination: function () {
          return f;
        },
        getPluginDuration: function () {
          return u;
        },
        getPluginOrigin: function () {
          return s;
        },
        isPluginType: function () {
          return c;
        },
        renderPlugin: function () {
          return E;
        },
      };
      for (var i in a)
        Object.defineProperty(t, i, { enumerable: !0, get: a[i] });
      let o = n(2662),
        l = n(3690);
      function c(e) {
        return l.pluginMethodMap.has(e);
      }
      let r = (e) => (t) => {
          if (!o.IS_BROWSER_ENV) return () => null;
          let n = l.pluginMethodMap.get(t);
          if (!n) throw Error(`IX2 no plugin configured for: ${t}`);
          let a = n[e];
          if (!a) throw Error(`IX2 invalid plugin method: ${e}`);
          return a;
        },
        d = r("getPluginConfig"),
        s = r("getPluginOrigin"),
        u = r("getPluginDuration"),
        f = r("getPluginDestination"),
        p = r("createPluginInstance"),
        E = r("renderPlugin"),
        b = r("clearPlugin");
    },
    4124: function (e, t, n) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var a = {
        cleanupHTMLElement: function () {
          return eQ;
        },
        clearAllStyles: function () {
          return eX;
        },
        clearObjectCache: function () {
          return eu;
        },
        getActionListProgress: function () {
          return eY;
        },
        getAffectedElements: function () {
          return eT;
        },
        getComputedStyle: function () {
          return eO;
        },
        getDestinationValues: function () {
          return eS;
        },
        getElementId: function () {
          return eb;
        },
        getInstanceId: function () {
          return ep;
        },
        getInstanceOrigin: function () {
          return eR;
        },
        getItemConfigByKey: function () {
          return eL;
        },
        getMaxDurationItemIndex: function () {
          return eq;
        },
        getNamespacedParameterId: function () {
          return eZ;
        },
        getRenderType: function () {
          return eC;
        },
        getStyleProp: function () {
          return ew;
        },
        mediaQueriesEqual: function () {
          return e0;
        },
        observeStore: function () {
          return em;
        },
        reduceListToGroup: function () {
          return e$;
        },
        reifyState: function () {
          return eI;
        },
        renderHTMLElement: function () {
          return eM;
        },
        shallowEqual: function () {
          return s.default;
        },
        shouldAllowMediaQuery: function () {
          return eJ;
        },
        shouldNamespaceEventParameter: function () {
          return eK;
        },
        stringifyTarget: function () {
          return e1;
        },
      };
      for (var i in a)
        Object.defineProperty(t, i, { enumerable: !0, get: a[i] });
      let o = b(n(4075)),
        l = b(n(1455)),
        c = b(n(5720)),
        r = n(1185),
        d = n(7087),
        s = b(n(7164)),
        u = n(3767),
        f = n(380),
        p = n(1799),
        E = n(2662);
      function b(e) {
        return e && e.__esModule ? e : { default: e };
      }
      let {
          BACKGROUND: I,
          TRANSFORM: y,
          TRANSLATE_3D: m,
          SCALE_3D: g,
          ROTATE_X: T,
          ROTATE_Y: O,
          ROTATE_Z: _,
          SKEW: v,
          PRESERVE_3D: h,
          FLEX: R,
          OPACITY: A,
          FILTER: N,
          FONT_VARIATION_SETTINGS: L,
          WIDTH: S,
          HEIGHT: C,
          BACKGROUND_COLOR: w,
          BORDER_COLOR: M,
          COLOR: P,
          CHILDREN: G,
          IMMEDIATE_CHILDREN: F,
          SIBLINGS: U,
          PARENT: x,
          DISPLAY: k,
          WILL_CHANGE: D,
          AUTO: V,
          COMMA_DELIMITER: B,
          COLON_DELIMITER: X,
          BAR_DELIMITER: W,
          RENDER_TRANSFORM: j,
          RENDER_GENERAL: Q,
          RENDER_STYLE: z,
          RENDER_PLUGIN: H,
        } = d.IX2EngineConstants,
        {
          TRANSFORM_MOVE: q,
          TRANSFORM_SCALE: Y,
          TRANSFORM_ROTATE: $,
          TRANSFORM_SKEW: K,
          STYLE_OPACITY: Z,
          STYLE_FILTER: J,
          STYLE_FONT_VARIATION: ee,
          STYLE_SIZE: et,
          STYLE_BACKGROUND_COLOR: en,
          STYLE_BORDER: ea,
          STYLE_TEXT_COLOR: ei,
          GENERAL_DISPLAY: eo,
          OBJECT_VALUE: el,
        } = d.ActionTypeConsts,
        ec = (e) => e.trim(),
        er = Object.freeze({ [en]: w, [ea]: M, [ei]: P }),
        ed = Object.freeze({
          [E.TRANSFORM_PREFIXED]: y,
          [w]: I,
          [A]: A,
          [N]: N,
          [S]: S,
          [C]: C,
          [L]: L,
        }),
        es = new Map();
      function eu() {
        es.clear();
      }
      let ef = 1;
      function ep() {
        return "i" + ef++;
      }
      let eE = 1;
      function eb(e, t) {
        for (let n in e) {
          let a = e[n];
          if (a && a.ref === t) return a.id;
        }
        return "e" + eE++;
      }
      function eI({ events: e, actionLists: t, site: n } = {}) {
        let a = (0, l.default)(
            e,
            (e, t) => {
              let { eventTypeId: n } = t;
              return e[n] || (e[n] = {}), (e[n][t.id] = t), e;
            },
            {}
          ),
          i = n && n.mediaQueries,
          o = [];
        return (
          i
            ? (o = i.map((e) => e.key))
            : ((i = []), console.warn("IX2 missing mediaQueries in site data")),
          {
            ixData: {
              events: e,
              actionLists: t,
              eventTypeMap: a,
              mediaQueries: i,
              mediaQueryKeys: o,
            },
          }
        );
      }
      let ey = (e, t) => e === t;
      function em({ store: e, select: t, onChange: n, comparator: a = ey }) {
        let { getState: i, subscribe: o } = e,
          l = o(function () {
            let o = t(i());
            if (null == o) return void l();
            a(o, c) || n((c = o), e);
          }),
          c = t(i());
        return l;
      }
      function eg(e) {
        let t = typeof e;
        if ("string" === t) return { id: e };
        if (null != e && "object" === t) {
          let {
            id: t,
            objectId: n,
            selector: a,
            selectorGuids: i,
            appliesTo: o,
            useEventTarget: l,
          } = e;
          return {
            id: t,
            objectId: n,
            selector: a,
            selectorGuids: i,
            appliesTo: o,
            useEventTarget: l,
          };
        }
        return {};
      }
      function eT({
        config: e,
        event: t,
        eventTarget: n,
        elementRoot: a,
        elementApi: i,
      }) {
        let o, l, c;
        if (!i) throw Error("IX2 missing elementApi");
        let { targets: r } = e;
        if (Array.isArray(r) && r.length > 0)
          return r.reduce(
            (e, o) =>
              e.concat(
                eT({
                  config: { target: o },
                  event: t,
                  eventTarget: n,
                  elementRoot: a,
                  elementApi: i,
                })
              ),
            []
          );
        let {
            getValidDocument: s,
            getQuerySelector: u,
            queryDocument: f,
            getChildElements: p,
            getSiblingElements: b,
            matchSelector: I,
            elementContains: y,
            isSiblingNode: m,
          } = i,
          { target: g } = e;
        if (!g) return [];
        let {
          id: T,
          objectId: O,
          selector: _,
          selectorGuids: v,
          appliesTo: h,
          useEventTarget: R,
        } = eg(g);
        if (O) return [es.has(O) ? es.get(O) : es.set(O, {}).get(O)];
        if (h === d.EventAppliesTo.PAGE) {
          let e = s(T);
          return e ? [e] : [];
        }
        let A = (t?.action?.config?.affectedElements ?? {})[T || _] || {},
          N = !!(A.id || A.selector),
          L = t && u(eg(t.target));
        if (
          (N
            ? ((o = A.limitAffectedElements), (l = L), (c = u(A)))
            : (l = c = u({ id: T, selector: _, selectorGuids: v })),
          t && R)
        ) {
          let e = n && (c || !0 === R) ? [n] : f(L);
          if (c) {
            if (R === x) return f(c).filter((t) => e.some((e) => y(t, e)));
            if (R === G) return f(c).filter((t) => e.some((e) => y(e, t)));
            if (R === U) return f(c).filter((t) => e.some((e) => m(e, t)));
          }
          return e;
        }
        return null == l || null == c
          ? []
          : E.IS_BROWSER_ENV && a
          ? f(c).filter((e) => a.contains(e))
          : o === G
          ? f(l, c)
          : o === F
          ? p(f(l)).filter(I(c))
          : o === U
          ? b(f(l)).filter(I(c))
          : f(c);
      }
      function eO({ element: e, actionItem: t }) {
        if (!E.IS_BROWSER_ENV) return {};
        let { actionTypeId: n } = t;
        switch (n) {
          case et:
          case en:
          case ea:
          case ei:
          case eo:
            return window.getComputedStyle(e);
          default:
            return {};
        }
      }
      let e_ = /px/,
        ev = (e, t) =>
          t.reduce(
            (e, t) => (null == e[t.type] && (e[t.type] = eG[t.type]), e),
            e || {}
          ),
        eh = (e, t) =>
          t.reduce(
            (e, t) => (
              null == e[t.type] &&
                (e[t.type] = eF[t.type] || t.defaultValue || 0),
              e
            ),
            e || {}
          );
      function eR(e, t = {}, n = {}, a, i) {
        let { getStyle: l } = i,
          { actionTypeId: c } = a;
        if ((0, p.isPluginType)(c)) return (0, p.getPluginOrigin)(c)(t[c], a);
        switch (a.actionTypeId) {
          case q:
          case Y:
          case $:
          case K:
            return t[a.actionTypeId] || eP[a.actionTypeId];
          case J:
            return ev(t[a.actionTypeId], a.config.filters);
          case ee:
            return eh(t[a.actionTypeId], a.config.fontVariations);
          case Z:
            return { value: (0, o.default)(parseFloat(l(e, A)), 1) };
          case et: {
            let t,
              i = l(e, S),
              c = l(e, C);
            return {
              widthValue:
                a.config.widthUnit === V
                  ? e_.test(i)
                    ? parseFloat(i)
                    : parseFloat(n.width)
                  : (0, o.default)(parseFloat(i), parseFloat(n.width)),
              heightValue:
                a.config.heightUnit === V
                  ? e_.test(c)
                    ? parseFloat(c)
                    : parseFloat(n.height)
                  : (0, o.default)(parseFloat(c), parseFloat(n.height)),
            };
          }
          case en:
          case ea:
          case ei:
            return (function ({
              element: e,
              actionTypeId: t,
              computedStyle: n,
              getStyle: a,
            }) {
              let i = er[t],
                l = a(e, i),
                c = (function (e, t) {
                  let n = e.exec(t);
                  return n ? n[1] : "";
                })(eD, ek.test(l) ? l : n[i]).split(B);
              return {
                rValue: (0, o.default)(parseInt(c[0], 10), 255),
                gValue: (0, o.default)(parseInt(c[1], 10), 255),
                bValue: (0, o.default)(parseInt(c[2], 10), 255),
                aValue: (0, o.default)(parseFloat(c[3]), 1),
              };
            })({
              element: e,
              actionTypeId: a.actionTypeId,
              computedStyle: n,
              getStyle: l,
            });
          case eo:
            return { value: (0, o.default)(l(e, k), n.display) };
          case el:
            return t[a.actionTypeId] || { value: 0 };
          default:
            return;
        }
      }
      let eA = (e, t) => (t && (e[t.type] = t.value || 0), e),
        eN = (e, t) => (t && (e[t.type] = t.value || 0), e),
        eL = (e, t, n) => {
          if ((0, p.isPluginType)(e)) return (0, p.getPluginConfig)(e)(n, t);
          switch (e) {
            case J: {
              let e = (0, c.default)(n.filters, ({ type: e }) => e === t);
              return e ? e.value : 0;
            }
            case ee: {
              let e = (0, c.default)(
                n.fontVariations,
                ({ type: e }) => e === t
              );
              return e ? e.value : 0;
            }
            default:
              return n[t];
          }
        };
      function eS({ element: e, actionItem: t, elementApi: n }) {
        if ((0, p.isPluginType)(t.actionTypeId))
          return (0, p.getPluginDestination)(t.actionTypeId)(t.config);
        switch (t.actionTypeId) {
          case q:
          case Y:
          case $:
          case K: {
            let { xValue: e, yValue: n, zValue: a } = t.config;
            return { xValue: e, yValue: n, zValue: a };
          }
          case et: {
            let { getStyle: a, setStyle: i, getProperty: o } = n,
              { widthUnit: l, heightUnit: c } = t.config,
              { widthValue: r, heightValue: d } = t.config;
            if (!E.IS_BROWSER_ENV) return { widthValue: r, heightValue: d };
            if (l === V) {
              let t = a(e, S);
              i(e, S, ""), (r = o(e, "offsetWidth")), i(e, S, t);
            }
            if (c === V) {
              let t = a(e, C);
              i(e, C, ""), (d = o(e, "offsetHeight")), i(e, C, t);
            }
            return { widthValue: r, heightValue: d };
          }
          case en:
          case ea:
          case ei: {
            let {
              rValue: a,
              gValue: i,
              bValue: o,
              aValue: l,
              globalSwatchId: c,
            } = t.config;
            if (c && c.startsWith("--")) {
              let { getStyle: t } = n,
                a = t(e, c),
                i = (0, f.normalizeColor)(a);
              return {
                rValue: i.red,
                gValue: i.green,
                bValue: i.blue,
                aValue: i.alpha,
              };
            }
            return { rValue: a, gValue: i, bValue: o, aValue: l };
          }
          case J:
            return t.config.filters.reduce(eA, {});
          case ee:
            return t.config.fontVariations.reduce(eN, {});
          default: {
            let { value: e } = t.config;
            return { value: e };
          }
        }
      }
      function eC(e) {
        return /^TRANSFORM_/.test(e)
          ? j
          : /^STYLE_/.test(e)
          ? z
          : /^GENERAL_/.test(e)
          ? Q
          : /^PLUGIN_/.test(e)
          ? H
          : void 0;
      }
      function ew(e, t) {
        return e === z ? t.replace("STYLE_", "").toLowerCase() : null;
      }
      function eM(e, t, n, a, i, o, c, r, d) {
        switch (r) {
          case j:
            var s = e,
              u = t,
              f = n,
              b = i,
              I = c;
            let y = ex
                .map((e) => {
                  let t = eP[e],
                    {
                      xValue: n = t.xValue,
                      yValue: a = t.yValue,
                      zValue: i = t.zValue,
                      xUnit: o = "",
                      yUnit: l = "",
                      zUnit: c = "",
                    } = u[e] || {};
                  switch (e) {
                    case q:
                      return `${m}(${n}${o}, ${a}${l}, ${i}${c})`;
                    case Y:
                      return `${g}(${n}${o}, ${a}${l}, ${i}${c})`;
                    case $:
                      return `${T}(${n}${o}) ${O}(${a}${l}) ${_}(${i}${c})`;
                    case K:
                      return `${v}(${n}${o}, ${a}${l})`;
                    default:
                      return "";
                  }
                })
                .join(" "),
              { setStyle: A } = I;
            eV(s, E.TRANSFORM_PREFIXED, I),
              A(s, E.TRANSFORM_PREFIXED, y),
              (function (
                { actionTypeId: e },
                { xValue: t, yValue: n, zValue: a }
              ) {
                return (
                  (e === q && void 0 !== a) ||
                  (e === Y && void 0 !== a) ||
                  (e === $ && (void 0 !== t || void 0 !== n))
                );
              })(b, f) && A(s, E.TRANSFORM_STYLE_PREFIXED, h);
            return;
          case z:
            return (function (e, t, n, a, i, o) {
              let { setStyle: c } = o;
              switch (a.actionTypeId) {
                case et: {
                  let { widthUnit: t = "", heightUnit: i = "" } = a.config,
                    { widthValue: l, heightValue: r } = n;
                  void 0 !== l &&
                    (t === V && (t = "px"), eV(e, S, o), c(e, S, l + t)),
                    void 0 !== r &&
                      (i === V && (i = "px"), eV(e, C, o), c(e, C, r + i));
                  break;
                }
                case J:
                  var r = a.config;
                  let d = (0, l.default)(
                      n,
                      (e, t, n) => `${e} ${n}(${t}${eU(n, r)})`,
                      ""
                    ),
                    { setStyle: s } = o;
                  eV(e, N, o), s(e, N, d);
                  break;
                case ee:
                  a.config;
                  let u = (0, l.default)(
                      n,
                      (e, t, n) => (e.push(`"${n}" ${t}`), e),
                      []
                    ).join(", "),
                    { setStyle: f } = o;
                  eV(e, L, o), f(e, L, u);
                  break;
                case en:
                case ea:
                case ei: {
                  let t = er[a.actionTypeId],
                    i = Math.round(n.rValue),
                    l = Math.round(n.gValue),
                    r = Math.round(n.bValue),
                    d = n.aValue;
                  eV(e, t, o),
                    c(
                      e,
                      t,
                      d >= 1
                        ? `rgb(${i},${l},${r})`
                        : `rgba(${i},${l},${r},${d})`
                    );
                  break;
                }
                default: {
                  let { unit: t = "" } = a.config;
                  eV(e, i, o), c(e, i, n.value + t);
                }
              }
            })(e, 0, n, i, o, c);
          case Q:
            var w = e,
              M = i,
              P = c;
            let { setStyle: G } = P;
            if (M.actionTypeId === eo) {
              let { value: e } = M.config;
              G(w, k, e === R && E.IS_BROWSER_ENV ? E.FLEX_PREFIXED : e);
            }
            return;
          case H: {
            let { actionTypeId: e } = i;
            if ((0, p.isPluginType)(e)) return (0, p.renderPlugin)(e)(d, t, i);
          }
        }
      }
      let eP = {
          [q]: Object.freeze({ xValue: 0, yValue: 0, zValue: 0 }),
          [Y]: Object.freeze({ xValue: 1, yValue: 1, zValue: 1 }),
          [$]: Object.freeze({ xValue: 0, yValue: 0, zValue: 0 }),
          [K]: Object.freeze({ xValue: 0, yValue: 0 }),
        },
        eG = Object.freeze({
          blur: 0,
          "hue-rotate": 0,
          invert: 0,
          grayscale: 0,
          saturate: 100,
          sepia: 0,
          contrast: 100,
          brightness: 100,
        }),
        eF = Object.freeze({ wght: 0, opsz: 0, wdth: 0, slnt: 0 }),
        eU = (e, t) => {
          let n = (0, c.default)(t.filters, ({ type: t }) => t === e);
          if (n && n.unit) return n.unit;
          switch (e) {
            case "blur":
              return "px";
            case "hue-rotate":
              return "deg";
            default:
              return "%";
          }
        },
        ex = Object.keys(eP),
        ek = /^rgb/,
        eD = RegExp("rgba?\\(([^)]+)\\)");
      function eV(e, t, n) {
        if (!E.IS_BROWSER_ENV) return;
        let a = ed[t];
        if (!a) return;
        let { getStyle: i, setStyle: o } = n,
          l = i(e, D);
        if (!l) return void o(e, D, a);
        let c = l.split(B).map(ec);
        -1 === c.indexOf(a) && o(e, D, c.concat(a).join(B));
      }
      function eB(e, t, n) {
        if (!E.IS_BROWSER_ENV) return;
        let a = ed[t];
        if (!a) return;
        let { getStyle: i, setStyle: o } = n,
          l = i(e, D);
        l &&
          -1 !== l.indexOf(a) &&
          o(
            e,
            D,
            l
              .split(B)
              .map(ec)
              .filter((e) => e !== a)
              .join(B)
          );
      }
      function eX({ store: e, elementApi: t }) {
        let { ixData: n } = e.getState(),
          { events: a = {}, actionLists: i = {} } = n;
        Object.keys(a).forEach((e) => {
          let n = a[e],
            { config: o } = n.action,
            { actionListId: l } = o,
            c = i[l];
          c && eW({ actionList: c, event: n, elementApi: t });
        }),
          Object.keys(i).forEach((e) => {
            eW({ actionList: i[e], elementApi: t });
          });
      }
      function eW({ actionList: e = {}, event: t, elementApi: n }) {
        let { actionItemGroups: a, continuousParameterGroups: i } = e;
        a &&
          a.forEach((e) => {
            ej({ actionGroup: e, event: t, elementApi: n });
          }),
          i &&
            i.forEach((e) => {
              let { continuousActionGroups: a } = e;
              a.forEach((e) => {
                ej({ actionGroup: e, event: t, elementApi: n });
              });
            });
      }
      function ej({ actionGroup: e, event: t, elementApi: n }) {
        let { actionItems: a } = e;
        a.forEach((e) => {
          let a,
            { actionTypeId: i, config: o } = e;
          (a = (0, p.isPluginType)(i)
            ? (t) => (0, p.clearPlugin)(i)(t, e)
            : ez({ effect: eH, actionTypeId: i, elementApi: n })),
            eT({ config: o, event: t, elementApi: n }).forEach(a);
        });
      }
      function eQ(e, t, n) {
        let { setStyle: a, getStyle: i } = n,
          { actionTypeId: o } = t;
        if (o === et) {
          let { config: n } = t;
          n.widthUnit === V && a(e, S, ""), n.heightUnit === V && a(e, C, "");
        }
        i(e, D) && ez({ effect: eB, actionTypeId: o, elementApi: n })(e);
      }
      let ez =
        ({ effect: e, actionTypeId: t, elementApi: n }) =>
        (a) => {
          switch (t) {
            case q:
            case Y:
            case $:
            case K:
              e(a, E.TRANSFORM_PREFIXED, n);
              break;
            case J:
              e(a, N, n);
              break;
            case ee:
              e(a, L, n);
              break;
            case Z:
              e(a, A, n);
              break;
            case et:
              e(a, S, n), e(a, C, n);
              break;
            case en:
            case ea:
            case ei:
              e(a, er[t], n);
              break;
            case eo:
              e(a, k, n);
          }
        };
      function eH(e, t, n) {
        let { setStyle: a } = n;
        eB(e, t, n),
          a(e, t, ""),
          t === E.TRANSFORM_PREFIXED && a(e, E.TRANSFORM_STYLE_PREFIXED, "");
      }
      function eq(e) {
        let t = 0,
          n = 0;
        return (
          e.forEach((e, a) => {
            let { config: i } = e,
              o = i.delay + i.duration;
            o >= t && ((t = o), (n = a));
          }),
          n
        );
      }
      function eY(e, t) {
        let { actionItemGroups: n, useFirstGroupAsInitialState: a } = e,
          { actionItem: i, verboseTimeElapsed: o = 0 } = t,
          l = 0,
          c = 0;
        return (
          n.forEach((e, t) => {
            if (a && 0 === t) return;
            let { actionItems: n } = e,
              r = n[eq(n)],
              { config: d, actionTypeId: s } = r;
            i.id === r.id && (c = l + o);
            let u = eC(s) === Q ? 0 : d.duration;
            l += d.delay + u;
          }),
          l > 0 ? (0, u.optimizeFloat)(c / l) : 0
        );
      }
      function e$({ actionList: e, actionItemId: t, rawData: n }) {
        let { actionItemGroups: a, continuousParameterGroups: i } = e,
          o = [],
          l = (e) => (
            o.push((0, r.mergeIn)(e, ["config"], { delay: 0, duration: 0 })),
            e.id === t
          );
        return (
          a && a.some(({ actionItems: e }) => e.some(l)),
          i &&
            i.some((e) => {
              let { continuousActionGroups: t } = e;
              return t.some(({ actionItems: e }) => e.some(l));
            }),
          (0, r.setIn)(n, ["actionLists"], {
            [e.id]: { id: e.id, actionItemGroups: [{ actionItems: o }] },
          })
        );
      }
      function eK(e, { basedOn: t }) {
        return (
          (e === d.EventTypeConsts.SCROLLING_IN_VIEW &&
            (t === d.EventBasedOn.ELEMENT || null == t)) ||
          (e === d.EventTypeConsts.MOUSE_MOVE && t === d.EventBasedOn.ELEMENT)
        );
      }
      function eZ(e, t) {
        return e + X + t;
      }
      function eJ(e, t) {
        return null == t || -1 !== e.indexOf(t);
      }
      function e0(e, t) {
        return (0, s.default)(e && e.sort(), t && t.sort());
      }
      function e1(e) {
        if ("string" == typeof e) return e;
        if (e.pluginElement && e.objectId)
          return e.pluginElement + W + e.objectId;
        if (e.objectId) return e.objectId;
        let { id: t = "", selector: n = "", useEventTarget: a = "" } = e;
        return t + W + n + W + a;
      }
    },
    7164: function (e, t) {
      "use strict";
      function n(e, t) {
        return e === t
          ? 0 !== e || 0 !== t || 1 / e == 1 / t
          : e != e && t != t;
      }
      Object.defineProperty(t, "__esModule", { value: !0 }),
        Object.defineProperty(t, "default", {
          enumerable: !0,
          get: function () {
            return a;
          },
        });
      let a = function (e, t) {
        if (n(e, t)) return !0;
        if (
          "object" != typeof e ||
          null === e ||
          "object" != typeof t ||
          null === t
        )
          return !1;
        let a = Object.keys(e),
          i = Object.keys(t);
        if (a.length !== i.length) return !1;
        for (let i = 0; i < a.length; i++)
          if (!Object.hasOwn(t, a[i]) || !n(e[a[i]], t[a[i]])) return !1;
        return !0;
      };
    },
    5861: function (e, t, n) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var a = {
        createElementState: function () {
          return v;
        },
        ixElements: function () {
          return _;
        },
        mergeActionState: function () {
          return h;
        },
      };
      for (var i in a)
        Object.defineProperty(t, i, { enumerable: !0, get: a[i] });
      let o = n(1185),
        l = n(7087),
        {
          HTML_ELEMENT: c,
          PLAIN_OBJECT: r,
          ABSTRACT_NODE: d,
          CONFIG_X_VALUE: s,
          CONFIG_Y_VALUE: u,
          CONFIG_Z_VALUE: f,
          CONFIG_VALUE: p,
          CONFIG_X_UNIT: E,
          CONFIG_Y_UNIT: b,
          CONFIG_Z_UNIT: I,
          CONFIG_UNIT: y,
        } = l.IX2EngineConstants,
        {
          IX2_SESSION_STOPPED: m,
          IX2_INSTANCE_ADDED: g,
          IX2_ELEMENT_STATE_CHANGED: T,
        } = l.IX2EngineActionTypes,
        O = {},
        _ = (e = O, t = {}) => {
          switch (t.type) {
            case m:
              return O;
            case g: {
              let {
                  elementId: n,
                  element: a,
                  origin: i,
                  actionItem: l,
                  refType: c,
                } = t.payload,
                { actionTypeId: r } = l,
                d = e;
              return (
                (0, o.getIn)(d, [n, a]) !== a && (d = v(d, a, c, n, l)),
                h(d, n, r, i, l)
              );
            }
            case T: {
              let {
                elementId: n,
                actionTypeId: a,
                current: i,
                actionItem: o,
              } = t.payload;
              return h(e, n, a, i, o);
            }
            default:
              return e;
          }
        };
      function v(e, t, n, a, i) {
        let l =
          n === r ? (0, o.getIn)(i, ["config", "target", "objectId"]) : null;
        return (0, o.mergeIn)(e, [a], { id: a, ref: t, refId: l, refType: n });
      }
      function h(e, t, n, a, i) {
        let l = (function (e) {
          let { config: t } = e;
          return R.reduce((e, n) => {
            let a = n[0],
              i = n[1],
              o = t[a],
              l = t[i];
            return null != o && null != l && (e[i] = l), e;
          }, {});
        })(i);
        return (0, o.mergeIn)(e, [t, "refState", n], a, l);
      }
      let R = [
        [s, E],
        [u, b],
        [f, I],
        [p, y],
      ];
    },
    7315: function () {
      Webflow.require("ix2").init({
        events: {
          "e-22": {
            id: "e-22",
            name: "",
            animationType: "custom",
            eventTypeId: "PAGE_FINISH",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-3",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-21",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f",
              appliesTo: "PAGE",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f",
                appliesTo: "PAGE",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !0,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19537ffadd4,
          },
          "e-52": {
            id: "e-52",
            name: "",
            animationType: "custom",
            eventTypeId: "PAGE_FINISH",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-6",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-51",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f",
              appliesTo: "PAGE",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f",
                appliesTo: "PAGE",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !0,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1953d385b25,
          },
          "e-54": {
            id: "e-54",
            name: "",
            animationType: "custom",
            eventTypeId: "PAGE_FINISH",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-7",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-53",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f",
              appliesTo: "PAGE",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f",
                appliesTo: "PAGE",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !0,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1953d4002bc,
          },
          "e-56": {
            id: "e-56",
            name: "",
            animationType: "custom",
            eventTypeId: "PAGE_FINISH",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-8",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-55",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f",
              appliesTo: "PAGE",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f",
                appliesTo: "PAGE",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !0,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1953d45c29c,
          },
          "e-58": {
            id: "e-58",
            name: "",
            animationType: "custom",
            eventTypeId: "PAGE_FINISH",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-9",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-57",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f",
              appliesTo: "PAGE",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f",
                appliesTo: "PAGE",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !0,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1953d4c0818,
          },
          "e-60": {
            id: "e-60",
            name: "",
            animationType: "custom",
            eventTypeId: "PAGE_FINISH",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-11",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-59",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f",
              appliesTo: "PAGE",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f",
                appliesTo: "PAGE",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !0,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1953db05b0b,
          },
          "e-62": {
            id: "e-62",
            name: "",
            animationType: "custom",
            eventTypeId: "PAGE_FINISH",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-10",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-61",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f",
              appliesTo: "PAGE",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f",
                appliesTo: "PAGE",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !0,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1953db2fdf6,
          },
          "e-64": {
            id: "e-64",
            name: "",
            animationType: "custom",
            eventTypeId: "PAGE_FINISH",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-12",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-63",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f",
              appliesTo: "PAGE",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f",
                appliesTo: "PAGE",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !0,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1953db4949e,
          },
          "e-65": {
            id: "e-65",
            name: "",
            animationType: "custom",
            eventTypeId: "PAGE_START",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-14",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-66",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f",
              appliesTo: "PAGE",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f",
                appliesTo: "PAGE",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !0,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1953db77767,
          },
          "e-68": {
            id: "e-68",
            name: "",
            animationType: "custom",
            eventTypeId: "PAGE_FINISH",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-13",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-67",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f",
              appliesTo: "PAGE",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f",
                appliesTo: "PAGE",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !0,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1953db9a9ee,
          },
          "e-70": {
            id: "e-70",
            name: "",
            animationType: "custom",
            eventTypeId: "PAGE_FINISH",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-15",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-69",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f",
              appliesTo: "PAGE",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f",
                appliesTo: "PAGE",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !0,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1953dbb67b1,
          },
          "e-72": {
            id: "e-72",
            name: "",
            animationType: "custom",
            eventTypeId: "PAGE_FINISH",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-16",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-71",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f",
              appliesTo: "PAGE",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f",
                appliesTo: "PAGE",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !0,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1953dbcd3cf,
          },
          "e-74": {
            id: "e-74",
            name: "",
            animationType: "custom",
            eventTypeId: "PAGE_FINISH",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-17",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-73",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f",
              appliesTo: "PAGE",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f",
                appliesTo: "PAGE",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !0,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1953dbeabef,
          },
          "e-76": {
            id: "e-76",
            name: "",
            animationType: "custom",
            eventTypeId: "PAGE_FINISH",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-18",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-75",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f",
              appliesTo: "PAGE",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f",
                appliesTo: "PAGE",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !0,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1953dc0d51f,
          },
          "e-78": {
            id: "e-78",
            name: "",
            animationType: "custom",
            eventTypeId: "PAGE_FINISH",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-19",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-77",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f",
              appliesTo: "PAGE",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f",
                appliesTo: "PAGE",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !0,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1953dc245cb,
          },
          "e-80": {
            id: "e-80",
            name: "",
            animationType: "custom",
            eventTypeId: "PAGE_FINISH",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-20",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-79",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f",
              appliesTo: "PAGE",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f",
                appliesTo: "PAGE",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !0,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1953dc41c13,
          },
          "e-82": {
            id: "e-82",
            name: "",
            animationType: "custom",
            eventTypeId: "PAGE_FINISH",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-21",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-81",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f",
              appliesTo: "PAGE",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f",
                appliesTo: "PAGE",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !0,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1953dc56af4,
          },
          "e-84": {
            id: "e-84",
            name: "",
            animationType: "custom",
            eventTypeId: "PAGE_FINISH",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-22",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-83",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f",
              appliesTo: "PAGE",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f",
                appliesTo: "PAGE",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !0,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1953dc6d3eb,
          },
          "e-86": {
            id: "e-86",
            name: "",
            animationType: "custom",
            eventTypeId: "PAGE_FINISH",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-24",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-85",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f",
              appliesTo: "PAGE",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f",
                appliesTo: "PAGE",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !0,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1953dc816f9,
          },
          "e-88": {
            id: "e-88",
            name: "",
            animationType: "custom",
            eventTypeId: "PAGE_FINISH",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-25",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-87",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f",
              appliesTo: "PAGE",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f",
                appliesTo: "PAGE",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !0,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1953dca9b24,
          },
          "e-90": {
            id: "e-90",
            name: "",
            animationType: "custom",
            eventTypeId: "PAGE_FINISH",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-26",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-89",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f",
              appliesTo: "PAGE",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f",
                appliesTo: "PAGE",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !0,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1953dcc1875,
          },
          "e-92": {
            id: "e-92",
            name: "",
            animationType: "custom",
            eventTypeId: "PAGE_FINISH",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-23",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-91",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f",
              appliesTo: "PAGE",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f",
                appliesTo: "PAGE",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !0,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1953dd0fb12,
          },
          "e-93": {
            id: "e-93",
            name: "",
            animationType: "custom",
            eventTypeId: "MOUSE_CLICK",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-27",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-94",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "a16937af-4e7b-8135-5cfd-a7bcaa841e69",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "a16937af-4e7b-8135-5cfd-a7bcaa841e69",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1953e393e5d,
          },
          "e-94": {
            id: "e-94",
            name: "",
            animationType: "custom",
            eventTypeId: "MOUSE_SECOND_CLICK",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-28",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-93",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "a16937af-4e7b-8135-5cfd-a7bcaa841e69",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "a16937af-4e7b-8135-5cfd-a7bcaa841e69",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1953e393e5f,
          },
          "e-95": {
            id: "e-95",
            name: "",
            animationType: "custom",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-29",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-96",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              selector: ".footer_link-wrap",
              originalId: "b075d494-ae73-b72f-c648-70da08a9d1a4",
              appliesTo: "CLASS",
            },
            targets: [
              {
                selector: ".footer_link-wrap",
                originalId: "b075d494-ae73-b72f-c648-70da08a9d1a4",
                appliesTo: "CLASS",
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19541b3b559,
          },
          "e-96": {
            id: "e-96",
            name: "",
            animationType: "custom",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-30",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-95",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              selector: ".footer_link-wrap",
              originalId: "b075d494-ae73-b72f-c648-70da08a9d1a4",
              appliesTo: "CLASS",
            },
            targets: [
              {
                selector: ".footer_link-wrap",
                originalId: "b075d494-ae73-b72f-c648-70da08a9d1a4",
                appliesTo: "CLASS",
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19541b3b55b,
          },
          "e-97": {
            id: "e-97",
            name: "",
            animationType: "preset",
            eventTypeId: "SCROLL_INTO_VIEW",
            action: {
              id: "",
              actionTypeId: "SLIDE_EFFECT",
              instant: !1,
              config: {
                actionListId: "slideInBottom",
                autoStopEventId: "e-98",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              selector: ".slide_bottom-000",
              originalId:
                "67df2cb3d3ad1c8c0bab5b1f|1d66ce77-0bc6-71af-8763-153555fbd780",
              appliesTo: "CLASS",
            },
            targets: [
              {
                selector: ".slide_bottom-000",
                originalId:
                  "67df2cb3d3ad1c8c0bab5b1f|1d66ce77-0bc6-71af-8763-153555fbd780",
                appliesTo: "CLASS",
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: 10,
              scrollOffsetUnit: "%",
              delay: 0,
              direction: "BOTTOM",
              effectIn: !0,
            },
            createdOn: 0x195533aaf19,
          },
          "e-99": {
            id: "e-99",
            name: "",
            animationType: "preset",
            eventTypeId: "SCROLL_INTO_VIEW",
            action: {
              id: "",
              actionTypeId: "SLIDE_EFFECT",
              instant: !1,
              config: {
                actionListId: "slideInBottom",
                autoStopEventId: "e-100",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              selector: ".slide_bottom-200",
              originalId:
                "67df2cb3d3ad1c8c0bab5b1f|2787285c-db41-8538-e67c-05cc57608dc1",
              appliesTo: "CLASS",
            },
            targets: [
              {
                selector: ".slide_bottom-200",
                originalId:
                  "67df2cb3d3ad1c8c0bab5b1f|2787285c-db41-8538-e67c-05cc57608dc1",
                appliesTo: "CLASS",
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: 10,
              scrollOffsetUnit: "%",
              delay: 200,
              direction: "BOTTOM",
              effectIn: !0,
            },
            createdOn: 0x195533ba486,
          },
          "e-101": {
            id: "e-101",
            name: "",
            animationType: "preset",
            eventTypeId: "SCROLL_INTO_VIEW",
            action: {
              id: "",
              actionTypeId: "SLIDE_EFFECT",
              instant: !1,
              config: {
                actionListId: "slideInBottom",
                autoStopEventId: "e-102",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              selector: ".slide_bottom-400",
              originalId:
                "67df2cb3d3ad1c8c0bab5b1f|4b1edd0b-bd2f-29d8-504e-288cd22cb5df",
              appliesTo: "CLASS",
            },
            targets: [
              {
                selector: ".slide_bottom-400",
                originalId:
                  "67df2cb3d3ad1c8c0bab5b1f|4b1edd0b-bd2f-29d8-504e-288cd22cb5df",
                appliesTo: "CLASS",
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: 10,
              scrollOffsetUnit: "%",
              delay: 400,
              direction: "BOTTOM",
              effectIn: !0,
            },
            createdOn: 0x195533c2bf7,
          },
          "e-103": {
            id: "e-103",
            name: "",
            animationType: "preset",
            eventTypeId: "SCROLL_INTO_VIEW",
            action: {
              id: "",
              actionTypeId: "SLIDE_EFFECT",
              instant: !1,
              config: {
                actionListId: "slideInBottom",
                autoStopEventId: "e-104",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              selector: ".slide_bottom-600",
              originalId:
                "67df2cb3d3ad1c8c0bab5b1f|b660229c-1465-df40-058b-c80189569e80",
              appliesTo: "CLASS",
            },
            targets: [
              {
                selector: ".slide_bottom-600",
                originalId:
                  "67df2cb3d3ad1c8c0bab5b1f|b660229c-1465-df40-058b-c80189569e80",
                appliesTo: "CLASS",
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: 10,
              scrollOffsetUnit: "%",
              delay: 600,
              direction: "BOTTOM",
              effectIn: !0,
            },
            createdOn: 0x195533c8143,
          },
          "e-105": {
            id: "e-105",
            name: "",
            animationType: "preset",
            eventTypeId: "SCROLL_INTO_VIEW",
            action: {
              id: "",
              actionTypeId: "SLIDE_EFFECT",
              instant: !1,
              config: {
                actionListId: "slideInBottom",
                autoStopEventId: "e-106",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              selector: ".slide_b-200",
              originalId:
                "67df2cb3d3ad1c8c0bab5b1f|61f1cc64-06dd-7c4f-a8c4-1b428f327ace",
              appliesTo: "CLASS",
            },
            targets: [
              {
                selector: ".slide_b-200",
                originalId:
                  "67df2cb3d3ad1c8c0bab5b1f|61f1cc64-06dd-7c4f-a8c4-1b428f327ace",
                appliesTo: "CLASS",
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: 0,
              scrollOffsetUnit: "%",
              delay: 200,
              direction: "BOTTOM",
              effectIn: !0,
            },
            createdOn: 0x195533e3101,
          },
          "e-107": {
            id: "e-107",
            name: "",
            animationType: "preset",
            eventTypeId: "SCROLL_INTO_VIEW",
            action: {
              id: "",
              actionTypeId: "SLIDE_EFFECT",
              instant: !1,
              config: {
                actionListId: "slideInBottom",
                autoStopEventId: "e-108",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              selector: ".slide_b-400",
              originalId:
                "67df2cb3d3ad1c8c0bab5b1f|7c0e159a-7cf2-83a6-319f-70530f44f9ec",
              appliesTo: "CLASS",
            },
            targets: [
              {
                selector: ".slide_b-400",
                originalId:
                  "67df2cb3d3ad1c8c0bab5b1f|7c0e159a-7cf2-83a6-319f-70530f44f9ec",
                appliesTo: "CLASS",
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: 0,
              scrollOffsetUnit: "%",
              delay: 400,
              direction: "BOTTOM",
              effectIn: !0,
            },
            createdOn: 0x195533e6f95,
          },
          "e-109": {
            id: "e-109",
            name: "",
            animationType: "preset",
            eventTypeId: "SCROLL_INTO_VIEW",
            action: {
              id: "",
              actionTypeId: "SLIDE_EFFECT",
              instant: !1,
              config: {
                actionListId: "slideInBottom",
                autoStopEventId: "e-110",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              selector: ".slide_b-600",
              originalId:
                "67df2cb3d3ad1c8c0bab5b1f|067c9112-aee0-830d-fdbb-0f4fa27c0c24",
              appliesTo: "CLASS",
            },
            targets: [
              {
                selector: ".slide_b-600",
                originalId:
                  "67df2cb3d3ad1c8c0bab5b1f|067c9112-aee0-830d-fdbb-0f4fa27c0c24",
                appliesTo: "CLASS",
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: 0,
              scrollOffsetUnit: "%",
              delay: 600,
              direction: "BOTTOM",
              effectIn: !0,
            },
            createdOn: 0x195533ec0a2,
          },
          "e-111": {
            id: "e-111",
            name: "",
            animationType: "preset",
            eventTypeId: "SCROLL_INTO_VIEW",
            action: {
              id: "",
              actionTypeId: "SLIDE_EFFECT",
              instant: !1,
              config: { actionListId: "slideInLeft", autoStopEventId: "e-112" },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              selector: ".slide_left",
              originalId:
                "67df2cb3d3ad1c8c0bab5b1f|497aef89-e6e6-f5c0-fe74-065fa942e2b9",
              appliesTo: "CLASS",
            },
            targets: [
              {
                selector: ".slide_left",
                originalId:
                  "67df2cb3d3ad1c8c0bab5b1f|497aef89-e6e6-f5c0-fe74-065fa942e2b9",
                appliesTo: "CLASS",
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: 10,
              scrollOffsetUnit: "%",
              delay: 0,
              direction: "LEFT",
              effectIn: !0,
            },
            createdOn: 0x195534eacea,
          },
          "e-113": {
            id: "e-113",
            name: "",
            animationType: "preset",
            eventTypeId: "SCROLL_INTO_VIEW",
            action: {
              id: "",
              actionTypeId: "SLIDE_EFFECT",
              instant: !1,
              config: { actionListId: "slideInLeft", autoStopEventId: "e-114" },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              selector: ".slide_left-0",
              originalId:
                "67df2cb3d3ad1c8c0bab5b1f|f92461d4-f12a-b2fc-de42-ad27e56cd8e6",
              appliesTo: "CLASS",
            },
            targets: [
              {
                selector: ".slide_left-0",
                originalId:
                  "67df2cb3d3ad1c8c0bab5b1f|f92461d4-f12a-b2fc-de42-ad27e56cd8e6",
                appliesTo: "CLASS",
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: 0,
              scrollOffsetUnit: "%",
              delay: 200,
              direction: "LEFT",
              effectIn: !0,
            },
            createdOn: 0x195534f8646,
          },
          "e-115": {
            id: "e-115",
            name: "",
            animationType: "preset",
            eventTypeId: "SCROLL_INTO_VIEW",
            action: {
              id: "",
              actionTypeId: "SLIDE_EFFECT",
              instant: !1,
              config: {
                actionListId: "slideInRight",
                autoStopEventId: "e-116",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              selector: ".slide_right",
              originalId:
                "67df2cb3d3ad1c8c0bab5b1f|983288d3-4845-af22-30d3-b91697a9a183",
              appliesTo: "CLASS",
            },
            targets: [
              {
                selector: ".slide_right",
                originalId:
                  "67df2cb3d3ad1c8c0bab5b1f|983288d3-4845-af22-30d3-b91697a9a183",
                appliesTo: "CLASS",
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: 10,
              scrollOffsetUnit: "%",
              delay: 0,
              direction: "RIGHT",
              effectIn: !0,
            },
            createdOn: 0x195534ff9ac,
          },
          "e-117": {
            id: "e-117",
            name: "",
            animationType: "preset",
            eventTypeId: "SCROLL_INTO_VIEW",
            action: {
              id: "",
              actionTypeId: "SLIDE_EFFECT",
              instant: !1,
              config: {
                actionListId: "slideInRight",
                autoStopEventId: "e-118",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              selector: ".slide_right-0",
              originalId:
                "67df2cb3d3ad1c8c0bab5b1f|e9f4e482-dc32-0f54-13c7-dd97b45c81fc",
              appliesTo: "CLASS",
            },
            targets: [
              {
                selector: ".slide_right-0",
                originalId:
                  "67df2cb3d3ad1c8c0bab5b1f|e9f4e482-dc32-0f54-13c7-dd97b45c81fc",
                appliesTo: "CLASS",
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: 0,
              scrollOffsetUnit: "%",
              delay: 0,
              direction: "RIGHT",
              effectIn: !0,
            },
            createdOn: 0x1955350dfdf,
          },
          "e-120": {
            id: "e-120",
            name: "",
            animationType: "custom",
            eventTypeId: "PAGE_FINISH",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-31",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-119",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f",
              appliesTo: "PAGE",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f",
                appliesTo: "PAGE",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !0,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19553e48712,
          },
          "e-121": {
            id: "e-121",
            name: "",
            animationType: "custom",
            eventTypeId: "MOUSE_CLICK",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-122",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              selector: ".choose_card.slide_bottom-000",
              originalId:
                "67df2cb3d3ad1c8c0bab5b1f|60865716-bdc1-586b-3bd1-d40990f2d334",
              appliesTo: "CLASS",
            },
            targets: [
              {
                selector: ".choose_card.slide_bottom-000",
                originalId:
                  "67df2cb3d3ad1c8c0bab5b1f|60865716-bdc1-586b-3bd1-d40990f2d334",
                appliesTo: "CLASS",
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1955e0a468d,
          },
          "e-122": {
            id: "e-122",
            name: "",
            animationType: "custom",
            eventTypeId: "MOUSE_SECOND_CLICK",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-2",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-121",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              selector: ".choose_card.slide_bottom-000",
              originalId:
                "67df2cb3d3ad1c8c0bab5b1f|60865716-bdc1-586b-3bd1-d40990f2d334",
              appliesTo: "CLASS",
            },
            targets: [
              {
                selector: ".choose_card.slide_bottom-000",
                originalId:
                  "67df2cb3d3ad1c8c0bab5b1f|60865716-bdc1-586b-3bd1-d40990f2d334",
                appliesTo: "CLASS",
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1955e0a4692,
          },
          "e-123": {
            id: "e-123",
            name: "",
            animationType: "custom",
            eventTypeId: "MOUSE_CLICK",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-32",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-124",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              selector: ".choose_card.slide_bottom-200",
              originalId:
                "67df2cb3d3ad1c8c0bab5b1f|ae064081-41de-4f6c-6901-65c554d39b55",
              appliesTo: "CLASS",
            },
            targets: [
              {
                selector: ".choose_card.slide_bottom-200",
                originalId:
                  "67df2cb3d3ad1c8c0bab5b1f|ae064081-41de-4f6c-6901-65c554d39b55",
                appliesTo: "CLASS",
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1955e0d85ee,
          },
          "e-124": {
            id: "e-124",
            name: "",
            animationType: "custom",
            eventTypeId: "MOUSE_SECOND_CLICK",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-33",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-123",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              selector: ".choose_card.slide_bottom-200",
              originalId:
                "67df2cb3d3ad1c8c0bab5b1f|ae064081-41de-4f6c-6901-65c554d39b55",
              appliesTo: "CLASS",
            },
            targets: [
              {
                selector: ".choose_card.slide_bottom-200",
                originalId:
                  "67df2cb3d3ad1c8c0bab5b1f|ae064081-41de-4f6c-6901-65c554d39b55",
                appliesTo: "CLASS",
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1955e0d85f0,
          },
          "e-125": {
            id: "e-125",
            animationType: "custom",
            eventTypeId: "MOUSE_CLICK",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-34",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-126",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              selector: ".faq-question-wrap",
              originalId:
                "67c62cfa88b39e747f224399|1382ed25-8c8b-6d9b-e158-51c51c2579b3",
              appliesTo: "CLASS",
            },
            targets: [
              {
                selector: ".faq-question-wrap",
                originalId:
                  "67c62cfa88b39e747f224399|1382ed25-8c8b-6d9b-e158-51c51c2579b3",
                appliesTo: "CLASS",
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1682d6505ee,
          },
          "e-126": {
            id: "e-126",
            animationType: "custom",
            eventTypeId: "MOUSE_SECOND_CLICK",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-35",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-125",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              selector: ".faq-question-wrap",
              originalId:
                "67c62cfa88b39e747f224399|1382ed25-8c8b-6d9b-e158-51c51c2579b3",
              appliesTo: "CLASS",
            },
            targets: [
              {
                selector: ".faq-question-wrap",
                originalId:
                  "67c62cfa88b39e747f224399|1382ed25-8c8b-6d9b-e158-51c51c2579b3",
                appliesTo: "CLASS",
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1682d6505ee,
          },
          "e-155": {
            id: "e-155",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_OPEN",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-36",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-156",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa92b6",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa92b6",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560ec32c7,
          },
          "e-156": {
            id: "e-156",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_CLOSE",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-37",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-155",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa92b6",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa92b6",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560ec32c7,
          },
          "e-157": {
            id: "e-157",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_OPEN",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-36",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-158",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa92c0",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa92c0",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560ec32c7,
          },
          "e-158": {
            id: "e-158",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_CLOSE",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-37",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-157",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa92c0",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa92c0",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560ec32c7,
          },
          "e-159": {
            id: "e-159",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_OPEN",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-36",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-160",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa92ca",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa92ca",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560ec32c7,
          },
          "e-160": {
            id: "e-160",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_CLOSE",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-37",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-159",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa92ca",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa92ca",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560ec32c7,
          },
          "e-161": {
            id: "e-161",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_OPEN",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-36",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-162",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa92d4",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa92d4",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560ec32c7,
          },
          "e-162": {
            id: "e-162",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_CLOSE",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-37",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-161",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa92d4",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa92d4",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560ec32c7,
          },
          "e-163": {
            id: "e-163",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_OPEN",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-36",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-164",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa92de",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa92de",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560ec32c7,
          },
          "e-164": {
            id: "e-164",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_CLOSE",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-37",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-163",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa92de",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa92de",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560ec32c7,
          },
          "e-165": {
            id: "e-165",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_OPEN",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-36",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-166",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa92e8",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa92e8",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560ec32c7,
          },
          "e-166": {
            id: "e-166",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_CLOSE",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-37",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-165",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa92e8",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa92e8",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560ec32c7,
          },
          "e-167": {
            id: "e-167",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_OPEN",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-36",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-168",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa92f2",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa92f2",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560ec32c7,
          },
          "e-168": {
            id: "e-168",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_CLOSE",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-37",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-167",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa92f2",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa92f2",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560ec32c7,
          },
          "e-169": {
            id: "e-169",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_OPEN",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-36",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-170",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa92fc",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa92fc",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560ec32c7,
          },
          "e-170": {
            id: "e-170",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_CLOSE",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-37",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-169",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa92fc",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa92fc",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560ec32c7,
          },
          "e-171": {
            id: "e-171",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_OPEN",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-36",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-172",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa9306",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa9306",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560ec32c7,
          },
          "e-172": {
            id: "e-172",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_CLOSE",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-37",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-171",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa9306",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa9306",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560ec32c7,
          },
          "e-173": {
            id: "e-173",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_OPEN",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-36",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-174",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa9310",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa9310",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560ec32c7,
          },
          "e-174": {
            id: "e-174",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_CLOSE",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-37",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-173",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa9310",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa9310",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560ec32c7,
          },
          "e-175": {
            id: "e-175",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_OPEN",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-36",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-176",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa931a",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa931a",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560ec32c7,
          },
          "e-176": {
            id: "e-176",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_CLOSE",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-37",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-175",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa931a",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa931a",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560ec32c7,
          },
          "e-177": {
            id: "e-177",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_OPEN",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-36",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-178",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa9324",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa9324",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560ec32c7,
          },
          "e-178": {
            id: "e-178",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_CLOSE",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-37",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-177",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa9324",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa9324",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560ec32c7,
          },
          "e-179": {
            id: "e-179",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_OPEN",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-36",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-180",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa932e",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa932e",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560ec32c7,
          },
          "e-180": {
            id: "e-180",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_CLOSE",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-37",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-179",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa932e",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa932e",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560ec32c7,
          },
          "e-181": {
            id: "e-181",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_OPEN",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-36",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-182",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa9338",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa9338",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560ec32c7,
          },
          "e-182": {
            id: "e-182",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_CLOSE",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-37",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-181",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa9338",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|fd557001-b2d9-57b2-8735-77eac3aa9338",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560ec32c7,
          },
          "e-183": {
            id: "e-183",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_OPEN",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-36",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-184",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc9010",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc9010",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560fd8e04,
          },
          "e-184": {
            id: "e-184",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_CLOSE",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-37",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-183",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc9010",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc9010",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560fd8e04,
          },
          "e-185": {
            id: "e-185",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_OPEN",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-36",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-186",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc901a",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc901a",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560fd8e04,
          },
          "e-186": {
            id: "e-186",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_CLOSE",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-37",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-185",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc901a",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc901a",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560fd8e04,
          },
          "e-187": {
            id: "e-187",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_OPEN",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-36",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-188",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc9024",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc9024",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560fd8e04,
          },
          "e-188": {
            id: "e-188",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_CLOSE",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-37",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-187",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc9024",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc9024",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560fd8e04,
          },
          "e-189": {
            id: "e-189",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_OPEN",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-36",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-190",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc902e",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc902e",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560fd8e04,
          },
          "e-190": {
            id: "e-190",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_CLOSE",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-37",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-189",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc902e",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc902e",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560fd8e04,
          },
          "e-191": {
            id: "e-191",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_OPEN",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-36",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-192",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc9038",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc9038",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560fd8e04,
          },
          "e-192": {
            id: "e-192",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_CLOSE",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-37",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-191",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc9038",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc9038",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560fd8e04,
          },
          "e-193": {
            id: "e-193",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_OPEN",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-36",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-194",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc9042",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc9042",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560fd8e04,
          },
          "e-194": {
            id: "e-194",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_CLOSE",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-37",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-193",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc9042",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc9042",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560fd8e04,
          },
          "e-195": {
            id: "e-195",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_OPEN",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-36",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-196",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc904c",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc904c",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560fd8e04,
          },
          "e-196": {
            id: "e-196",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_CLOSE",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-37",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-195",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc904c",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc904c",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560fd8e04,
          },
          "e-197": {
            id: "e-197",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_OPEN",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-36",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-198",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc9056",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc9056",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560fd8e04,
          },
          "e-198": {
            id: "e-198",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_CLOSE",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-37",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-197",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc9056",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc9056",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560fd8e04,
          },
          "e-199": {
            id: "e-199",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_OPEN",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-36",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-200",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc9060",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc9060",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560fd8e04,
          },
          "e-200": {
            id: "e-200",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_CLOSE",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-37",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-199",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc9060",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc9060",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560fd8e04,
          },
          "e-201": {
            id: "e-201",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_OPEN",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-36",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-202",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc906a",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc906a",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560fd8e04,
          },
          "e-202": {
            id: "e-202",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_CLOSE",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-37",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-201",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc906a",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc906a",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560fd8e04,
          },
          "e-203": {
            id: "e-203",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_OPEN",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-36",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-204",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc9074",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc9074",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560fd8e04,
          },
          "e-204": {
            id: "e-204",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_CLOSE",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-37",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-203",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc9074",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc9074",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560fd8e04,
          },
          "e-205": {
            id: "e-205",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_OPEN",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-36",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-206",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc907e",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc907e",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560fd8e04,
          },
          "e-206": {
            id: "e-206",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_CLOSE",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-37",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-205",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc907e",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc907e",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560fd8e04,
          },
          "e-207": {
            id: "e-207",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_OPEN",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-36",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-208",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc9088",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc9088",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560fd8e04,
          },
          "e-208": {
            id: "e-208",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_CLOSE",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-37",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-207",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc9088",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc9088",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560fd8e04,
          },
          "e-209": {
            id: "e-209",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_OPEN",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-36",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-210",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc9092",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc9092",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560fd8e04,
          },
          "e-210": {
            id: "e-210",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_CLOSE",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-37",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-209",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc9092",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc9092",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19560fd8e04,
          },
          "e-211": {
            id: "e-211",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_OPEN",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-36",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-212",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|4eb9671f-c63f-1af9-caf0-66749c3ab0ad",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|4eb9671f-c63f-1af9-caf0-66749c3ab0ad",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1956838f2d9,
          },
          "e-212": {
            id: "e-212",
            name: "",
            animationType: "preset",
            eventTypeId: "DROPDOWN_CLOSE",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-37",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-211",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|4eb9671f-c63f-1af9-caf0-66749c3ab0ad",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|4eb9671f-c63f-1af9-caf0-66749c3ab0ad",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1956838f2d9,
          },
          "e-213": {
            id: "e-213",
            name: "",
            animationType: "custom",
            eventTypeId: "MOUSE_CLICK",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-38",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-214",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              selector: ".popup-show",
              originalId:
                "67df2cb3d3ad1c8c0bab5b1f|5108c063-938b-2378-d5ac-1ca62c49f6d9",
              appliesTo: "CLASS",
            },
            targets: [
              {
                selector: ".popup-show",
                originalId:
                  "67df2cb3d3ad1c8c0bab5b1f|5108c063-938b-2378-d5ac-1ca62c49f6d9",
                appliesTo: "CLASS",
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19586ec754b,
          },
          "e-215": {
            id: "e-215",
            name: "",
            animationType: "custom",
            eventTypeId: "MOUSE_CLICK",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-39",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-216",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "203f4772-d277-8229-0ac3-267e96570dc5",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "203f4772-d277-8229-0ac3-267e96570dc5",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19586ed7ef0,
          },
          "e-217": {
            id: "e-217",
            name: "",
            animationType: "custom",
            eventTypeId: "MOUSE_CLICK",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-38",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-218",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|8f97d2b2-28b8-1cde-02d5-1c17932e608d",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|8f97d2b2-28b8-1cde-02d5-1c17932e608d",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19586eed55d,
          },
          "e-219": {
            id: "e-219",
            name: "",
            animationType: "custom",
            eventTypeId: "MOUSE_CLICK",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-38",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-220",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "a16937af-4e7b-8135-5cfd-a7bcaa841e5f",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "a16937af-4e7b-8135-5cfd-a7bcaa841e5f",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19586ef0032,
          },
          "e-221": {
            id: "e-221",
            name: "",
            animationType: "custom",
            eventTypeId: "MOUSE_CLICK",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-39",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-222",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "53b14e07-f00b-545f-71a2-f65e6cd9a2f6",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "53b14e07-f00b-545f-71a2-f65e6cd9a2f6",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1958b7897dd,
          },
          "e-223": {
            id: "e-223",
            name: "",
            animationType: "custom",
            eventTypeId: "MOUSE_CLICK",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-40",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-224",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|22ec5988-b6db-500b-ede6-51a72d266bc1",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|22ec5988-b6db-500b-ede6-51a72d266bc1",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x195b4d8353e,
          },
          "e-225": {
            id: "e-225",
            name: "",
            animationType: "custom",
            eventTypeId: "MOUSE_CLICK",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-41",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-226",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|1063afdd-4575-a086-b09c-0d0690ad4505",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|1063afdd-4575-a086-b09c-0d0690ad4505",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x195b4d9caf8,
          },
          "e-227": {
            id: "e-227",
            name: "",
            animationType: "custom",
            eventTypeId: "MOUSE_CLICK",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-42",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-228",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|490f6cb9-0f9f-ac91-afeb-72e9e4697fe9",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|490f6cb9-0f9f-ac91-afeb-72e9e4697fe9",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x195b4dab163,
          },
          "e-229": {
            id: "e-229",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_CLICK",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-38",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-230",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|a67d5332-547c-9e74-164c-2ec1af86afb4",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|a67d5332-547c-9e74-164c-2ec1af86afb4",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19629944893,
          },
          "e-233": {
            id: "e-233",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_CLICK",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-38",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-234",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|9ca70562-9d32-fd17-7609-3d731a0ad82f",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|9ca70562-9d32-fd17-7609-3d731a0ad82f",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1962994e99f,
          },
          "e-235": {
            id: "e-235",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_CLICK",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-38",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-236",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|0983f0d7-1fe7-76a1-f86a-0d45845c82c2",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|0983f0d7-1fe7-76a1-f86a-0d45845c82c2",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1962995c576,
          },
          "e-237": {
            id: "e-237",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_CLICK",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-38",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-238",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|1d8346b9-d204-0869-481f-f19b45b79fe5",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|1d8346b9-d204-0869-481f-f19b45b79fe5",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1962995ccb6,
          },
          "e-239": {
            id: "e-239",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_CLICK",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-38",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-240",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|8d4d81f3-0359-5852-cea0-07213798c074",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|8d4d81f3-0359-5852-cea0-07213798c074",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x1962995d35a,
          },
          "e-241": {
            id: "e-241",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_CLICK",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-38",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-242",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|11234e1b-662c-7f65-ae7d-089e68008be8",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|11234e1b-662c-7f65-ae7d-089e68008be8",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19629976efa,
          },
          "e-243": {
            id: "e-243",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_CLICK",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-38",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-244",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|21eeabbf-40a8-a5f9-ed5e-d393b0c03ff4",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|21eeabbf-40a8-a5f9-ed5e-d393b0c03ff4",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19629980453,
          },
          "e-245": {
            id: "e-245",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_CLICK",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-38",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-246",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|c0f35a14-ebfd-1993-22ea-f2f632b8e280",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|c0f35a14-ebfd-1993-22ea-f2f632b8e280",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x196828b3a1f,
          },
          "e-247": {
            id: "e-247",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_CLICK",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-38",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-248",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|4acead20-ea22-a6ce-33b9-aef5f1f0ce0b",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|4acead20-ea22-a6ce-33b9-aef5f1f0ce0b",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x196828b50af,
          },
          "e-249": {
            id: "e-249",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_CLICK",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-38",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-250",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|9e759081-4766-56b4-f3ae-facbd2f76148",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|9e759081-4766-56b4-f3ae-facbd2f76148",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x196828b5ceb,
          },
          "e-251": {
            id: "e-251",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_CLICK",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-38",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-252",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|9a309597-8db2-ef4a-903e-82e85b5ad950",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|9a309597-8db2-ef4a-903e-82e85b5ad950",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x196828b6a69,
          },
          "e-253": {
            id: "e-253",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_CLICK",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-38",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-254",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|3f5ed3b2-65d7-f0ea-9476-a7507d007b8a",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|3f5ed3b2-65d7-f0ea-9476-a7507d007b8a",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x196828b7863,
          },
          "e-255": {
            id: "e-255",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_CLICK",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-38",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-256",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|90b720db-fb91-360b-2c12-86d0e4c48ea6",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|90b720db-fb91-360b-2c12-86d0e4c48ea6",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x196828b876c,
          },
          "e-257": {
            id: "e-257",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_CLICK",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-38",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-258",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|6a8fc8df-4152-9edb-213a-1560faf0592a",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|6a8fc8df-4152-9edb-213a-1560faf0592a",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x196828b93c7,
          },
          "e-259": {
            id: "e-259",
            name: "",
            animationType: "preset",
            eventTypeId: "MOUSE_CLICK",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-38",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-260",
              },
            },
            mediaQueries: ["main", "medium", "small", "tiny"],
            target: {
              id: "67df2cb3d3ad1c8c0bab5b1f|c3f57aee-4666-e568-08d9-9f3292e7f699",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "67df2cb3d3ad1c8c0bab5b1f|c3f57aee-4666-e568-08d9-9f3292e7f699",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x196828b9daf,
          },
        },
        actionLists: {
          "a-3": {
            id: "a-3",
            title: "\uD83D\uDC46marquee",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-3-n",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 12e3,
                      target: {
                        id: "67df2cb3d3ad1c8c0bab5b1f|86f484b5-09ff-20fc-b8d4-f4aac5fcd896",
                      },
                      xValue: -1185,
                      xUnit: "px",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-3-n-2",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 0,
                      target: {
                        id: "67df2cb3d3ad1c8c0bab5b1f|86f484b5-09ff-20fc-b8d4-f4aac5fcd896",
                      },
                      xValue: 0,
                      xUnit: "px",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !1,
            createdOn: 0x19537ffbb67,
          },
          "a-6": {
            id: "a-6",
            title: "\uD83D\uDC46Marquee-1",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-6-n",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 1e4,
                      target: {
                        id: "67df2cb3d3ad1c8c0bab5b1f|53ab835e-15a4-080c-fb50-f0a488f7443b",
                      },
                      xValue: -193.5,
                      xUnit: "%",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-6-n-2",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 0,
                      target: {
                        id: "67df2cb3d3ad1c8c0bab5b1f|53ab835e-15a4-080c-fb50-f0a488f7443b",
                      },
                      xValue: 0,
                      xUnit: "%",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !1,
            createdOn: 0x1953d386fca,
          },
          "a-7": {
            id: "a-7",
            title: "\uD83D\uDC46Marquee-2",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-7-n",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 1e4,
                      target: {
                        id: "67df2cb3d3ad1c8c0bab5b1f|44e4d384-2f74-bc84-4616-4f5060338fd0",
                      },
                      xValue: -175,
                      xUnit: "%",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-7-n-2",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 1e4,
                      target: {
                        id: "67df2cb3d3ad1c8c0bab5b1f|44e4d384-2f74-bc84-4616-4f5060338fd0",
                      },
                      xValue: 0,
                      xUnit: "%",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-7-n-3",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 0,
                      target: {
                        id: "67df2cb3d3ad1c8c0bab5b1f|44e4d384-2f74-bc84-4616-4f5060338fd0",
                      },
                      xValue: -175,
                      xUnit: "%",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !0,
            createdOn: 0x1953d386fca,
          },
          "a-8": {
            id: "a-8",
            title: "\uD83D\uDC46Marquee-3",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-8-n",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 1e4,
                      target: {
                        id: "67df2cb3d3ad1c8c0bab5b1f|69559475-7b7a-9a56-259e-032cf0895771",
                      },
                      xValue: -201.5,
                      xUnit: "%",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-8-n-2",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 0,
                      target: {
                        id: "67df2cb3d3ad1c8c0bab5b1f|69559475-7b7a-9a56-259e-032cf0895771",
                      },
                      xValue: 0,
                      xUnit: "%",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !1,
            createdOn: 0x1953d386fca,
          },
          "a-9": {
            id: "a-9",
            title: "\uD83D\uDC46Marquee-4",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-9-n",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 1e4,
                      target: {
                        selector: ".marquee_slide._4",
                        selectorGuids: [
                          "cfbe16e2-26c5-7498-d686-6acec1f942b8",
                          "fc21908d-7b41-82cb-d22f-83f174e45493",
                        ],
                      },
                      xValue: -173,
                      xUnit: "%",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-9-n-2",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 0,
                      target: {
                        selector: ".marquee_slide._4",
                        selectorGuids: [
                          "cfbe16e2-26c5-7498-d686-6acec1f942b8",
                          "fc21908d-7b41-82cb-d22f-83f174e45493",
                        ],
                      },
                      xValue: 0,
                      xUnit: "%",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !1,
            createdOn: 0x1953d386fca,
          },
          "a-11": {
            id: "a-11",
            title: "\uD83D\uDC46Marquee-5",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-11-n",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 1e4,
                      target: {
                        selector: ".marquee_slide._5",
                        selectorGuids: [
                          "cfbe16e2-26c5-7498-d686-6acec1f942b8",
                          "e0ebb03a-c00d-d462-c245-923a3eec4c46",
                        ],
                      },
                      xValue: -162,
                      xUnit: "%",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-11-n-2",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 1e4,
                      target: {
                        selector: ".marquee_slide._5",
                        selectorGuids: [
                          "cfbe16e2-26c5-7498-d686-6acec1f942b8",
                          "e0ebb03a-c00d-d462-c245-923a3eec4c46",
                        ],
                      },
                      xValue: 0,
                      xUnit: "%",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-11-n-3",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 0,
                      target: {
                        selector: ".marquee_slide._5",
                        selectorGuids: [
                          "cfbe16e2-26c5-7498-d686-6acec1f942b8",
                          "e0ebb03a-c00d-d462-c245-923a3eec4c46",
                        ],
                      },
                      xValue: -162,
                      xUnit: "%",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !0,
            createdOn: 0x1953d386fca,
          },
          "a-10": {
            id: "a-10",
            title: "\uD83D\uDC46Marquee-6",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-10-n",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 1e4,
                      target: {
                        selector: ".marquee_slide._6",
                        selectorGuids: [
                          "cfbe16e2-26c5-7498-d686-6acec1f942b8",
                          "f7c58182-e740-8835-ec1d-b2b6b6607714",
                        ],
                      },
                      xValue: -153.5,
                      xUnit: "%",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-10-n-2",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 0,
                      target: {
                        selector: ".marquee_slide._6",
                        selectorGuids: [
                          "cfbe16e2-26c5-7498-d686-6acec1f942b8",
                          "f7c58182-e740-8835-ec1d-b2b6b6607714",
                        ],
                      },
                      xValue: 0,
                      xUnit: "%",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !1,
            createdOn: 0x1953d386fca,
          },
          "a-12": {
            id: "a-12",
            title: "\uD83D\uDC46Marquee-7",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-12-n",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 1e4,
                      target: {
                        selector: ".marquee_slide._7",
                        selectorGuids: [
                          "cfbe16e2-26c5-7498-d686-6acec1f942b8",
                          "d532443f-f823-c26c-0aef-c4931bcbe0bc",
                        ],
                      },
                      xValue: -134.5,
                      xUnit: "%",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-12-n-2",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 0,
                      target: {
                        selector: ".marquee_slide._7",
                        selectorGuids: [
                          "cfbe16e2-26c5-7498-d686-6acec1f942b8",
                          "d532443f-f823-c26c-0aef-c4931bcbe0bc",
                        ],
                      },
                      xValue: 0,
                      xUnit: "%",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !1,
            createdOn: 0x1953d386fca,
          },
          "a-14": {
            id: "a-14",
            title: "\uD83D\uDC46Marquee-8",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-14-n",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 1e4,
                      target: {
                        selector: ".marquee_slide._8",
                        selectorGuids: [
                          "cfbe16e2-26c5-7498-d686-6acec1f942b8",
                          "0eba3c24-4129-61c5-d750-eaf59a3271c0",
                        ],
                      },
                      xValue: -152,
                      xUnit: "%",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-14-n-2",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 1e4,
                      target: {
                        selector: ".marquee_slide._8",
                        selectorGuids: [
                          "cfbe16e2-26c5-7498-d686-6acec1f942b8",
                          "0eba3c24-4129-61c5-d750-eaf59a3271c0",
                        ],
                      },
                      xValue: 0,
                      xUnit: "%",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-14-n-3",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 0,
                      target: {
                        selector: ".marquee_slide._8",
                        selectorGuids: [
                          "cfbe16e2-26c5-7498-d686-6acec1f942b8",
                          "0eba3c24-4129-61c5-d750-eaf59a3271c0",
                        ],
                      },
                      xValue: -152,
                      xUnit: "%",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !0,
            createdOn: 0x1953d386fca,
          },
          "a-13": {
            id: "a-13",
            title: "\uD83D\uDC46Marquee-9",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-13-n",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 1e4,
                      target: {
                        selector: ".marquee_slide._9",
                        selectorGuids: [
                          "cfbe16e2-26c5-7498-d686-6acec1f942b8",
                          "e5a347c3-91c8-9608-2de9-aae9064885b4",
                        ],
                      },
                      xValue: -167,
                      xUnit: "%",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-13-n-2",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 0,
                      target: {
                        selector: ".marquee_slide._9",
                        selectorGuids: [
                          "cfbe16e2-26c5-7498-d686-6acec1f942b8",
                          "e5a347c3-91c8-9608-2de9-aae9064885b4",
                        ],
                      },
                      xValue: 0,
                      xUnit: "%",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !1,
            createdOn: 0x1953d386fca,
          },
          "a-15": {
            id: "a-15",
            title: "\uD83D\uDC46Marquee-10",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-15-n",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 1e4,
                      target: {
                        selector: ".marquee_slide._10",
                        selectorGuids: [
                          "cfbe16e2-26c5-7498-d686-6acec1f942b8",
                          "6308a710-9cb1-20ae-1812-e76ddfb7a2a8",
                        ],
                      },
                      xValue: -203,
                      xUnit: "%",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-15-n-2",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 0,
                      target: {
                        selector: ".marquee_slide._10",
                        selectorGuids: [
                          "cfbe16e2-26c5-7498-d686-6acec1f942b8",
                          "6308a710-9cb1-20ae-1812-e76ddfb7a2a8",
                        ],
                      },
                      xValue: 0,
                      xUnit: "%",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !1,
            createdOn: 0x1953d386fca,
          },
          "a-16": {
            id: "a-16",
            title: "\uD83D\uDC46Marquee-11",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-16-n",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 1e4,
                      target: {
                        selector: ".marquee_slide._11",
                        selectorGuids: [
                          "cfbe16e2-26c5-7498-d686-6acec1f942b8",
                          "2dbe7172-c1e3-b1e2-d5a9-578cf4cd9617",
                        ],
                      },
                      xValue: -142,
                      xUnit: "%",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-16-n-2",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 1e4,
                      target: {
                        selector: ".marquee_slide._11",
                        selectorGuids: [
                          "cfbe16e2-26c5-7498-d686-6acec1f942b8",
                          "2dbe7172-c1e3-b1e2-d5a9-578cf4cd9617",
                        ],
                      },
                      xValue: 0,
                      xUnit: "%",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-16-n-3",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 0,
                      target: {
                        selector: ".marquee_slide._11",
                        selectorGuids: [
                          "cfbe16e2-26c5-7498-d686-6acec1f942b8",
                          "2dbe7172-c1e3-b1e2-d5a9-578cf4cd9617",
                        ],
                      },
                      xValue: -142,
                      xUnit: "%",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !0,
            createdOn: 0x1953d386fca,
          },
          "a-17": {
            id: "a-17",
            title: "\uD83D\uDC46Marquee-12",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-17-n",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 1e4,
                      target: {
                        selector: ".marquee_slide._12",
                        selectorGuids: [
                          "cfbe16e2-26c5-7498-d686-6acec1f942b8",
                          "23a450f0-e583-a753-94eb-b7e2e649d42c",
                        ],
                      },
                      xValue: -237,
                      xUnit: "%",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-17-n-2",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 0,
                      target: {
                        selector: ".marquee_slide._12",
                        selectorGuids: [
                          "cfbe16e2-26c5-7498-d686-6acec1f942b8",
                          "23a450f0-e583-a753-94eb-b7e2e649d42c",
                        ],
                      },
                      xValue: 0,
                      xUnit: "%",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !1,
            createdOn: 0x1953d386fca,
          },
          "a-18": {
            id: "a-18",
            title: "\uD83D\uDC46Marquee-13",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-18-n",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 1e4,
                      target: {
                        selector: ".marquee_slide._13",
                        selectorGuids: [
                          "cfbe16e2-26c5-7498-d686-6acec1f942b8",
                          "c32e5292-890a-3b76-aeb0-d1feaa21a282",
                        ],
                      },
                      xValue: -165,
                      xUnit: "%",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-18-n-2",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 0,
                      target: {
                        selector: ".marquee_slide._13",
                        selectorGuids: [
                          "cfbe16e2-26c5-7498-d686-6acec1f942b8",
                          "c32e5292-890a-3b76-aeb0-d1feaa21a282",
                        ],
                      },
                      xValue: 0,
                      xUnit: "%",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !1,
            createdOn: 0x1953d386fca,
          },
          "a-19": {
            id: "a-19",
            title: "\uD83D\uDC46Marquee-14",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-19-n",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 1e4,
                      target: {
                        selector: ".marquee_slide._14",
                        selectorGuids: [
                          "cfbe16e2-26c5-7498-d686-6acec1f942b8",
                          "a2662713-7ed6-2ce0-0b02-1509c0dc44e7",
                        ],
                      },
                      xValue: -186,
                      xUnit: "%",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-19-n-2",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 1e4,
                      target: {
                        selector: ".marquee_slide._14",
                        selectorGuids: [
                          "cfbe16e2-26c5-7498-d686-6acec1f942b8",
                          "a2662713-7ed6-2ce0-0b02-1509c0dc44e7",
                        ],
                      },
                      xValue: 0,
                      xUnit: "%",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-19-n-3",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 0,
                      target: {
                        selector: ".marquee_slide._14",
                        selectorGuids: [
                          "cfbe16e2-26c5-7498-d686-6acec1f942b8",
                          "a2662713-7ed6-2ce0-0b02-1509c0dc44e7",
                        ],
                      },
                      xValue: -186,
                      xUnit: "%",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !0,
            createdOn: 0x1953d386fca,
          },
          "a-20": {
            id: "a-20",
            title: "\uD83D\uDC46Marquee-15",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-20-n",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 1e4,
                      target: {
                        selector: ".marquee_slide._15",
                        selectorGuids: [
                          "cfbe16e2-26c5-7498-d686-6acec1f942b8",
                          "57b876c4-9a9f-3d6c-540c-f61329eb4d4d",
                        ],
                      },
                      xValue: -184,
                      xUnit: "%",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-20-n-2",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 0,
                      target: {
                        selector: ".marquee_slide._15",
                        selectorGuids: [
                          "cfbe16e2-26c5-7498-d686-6acec1f942b8",
                          "57b876c4-9a9f-3d6c-540c-f61329eb4d4d",
                        ],
                      },
                      xValue: 0,
                      xUnit: "%",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !1,
            createdOn: 0x1953d386fca,
          },
          "a-21": {
            id: "a-21",
            title: "\uD83D\uDC46Marquee-16",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-21-n",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 1e4,
                      target: {
                        selector: ".marquee_slide._16",
                        selectorGuids: [
                          "cfbe16e2-26c5-7498-d686-6acec1f942b8",
                          "baba9adc-07be-827c-7e5a-794bf46bda6d",
                        ],
                      },
                      xValue: -138,
                      xUnit: "%",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-21-n-2",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 0,
                      target: {
                        selector: ".marquee_slide._16",
                        selectorGuids: [
                          "cfbe16e2-26c5-7498-d686-6acec1f942b8",
                          "baba9adc-07be-827c-7e5a-794bf46bda6d",
                        ],
                      },
                      xValue: 0,
                      xUnit: "%",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !1,
            createdOn: 0x1953d386fca,
          },
          "a-22": {
            id: "a-22",
            title: "\uD83D\uDC46Marquee-17",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-22-n",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 1e4,
                      target: {
                        id: "67df2cb3d3ad1c8c0bab5b1f|6c73299e-d495-9f74-aba7-df894b194acc",
                      },
                      xValue: -192,
                      xUnit: "%",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-22-n-2",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 1e4,
                      target: {
                        id: "67df2cb3d3ad1c8c0bab5b1f|6c73299e-d495-9f74-aba7-df894b194acc",
                      },
                      xValue: 0,
                      xUnit: "%",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-22-n-3",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 0,
                      target: {
                        id: "67df2cb3d3ad1c8c0bab5b1f|6c73299e-d495-9f74-aba7-df894b194acc",
                      },
                      xValue: -192,
                      xUnit: "%",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !0,
            createdOn: 0x1953d386fca,
          },
          "a-24": {
            id: "a-24",
            title: "\uD83D\uDC46Marquee-19",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-24-n",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 1e4,
                      target: {
                        selector: ".marquee_slide._19",
                        selectorGuids: [
                          "cfbe16e2-26c5-7498-d686-6acec1f942b8",
                          "4d1a49e3-282e-bad4-e344-e6f8e6b0091b",
                        ],
                      },
                      xValue: -185,
                      xUnit: "%",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-24-n-2",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 0,
                      target: {
                        selector: ".marquee_slide._19",
                        selectorGuids: [
                          "cfbe16e2-26c5-7498-d686-6acec1f942b8",
                          "4d1a49e3-282e-bad4-e344-e6f8e6b0091b",
                        ],
                      },
                      xValue: 0,
                      xUnit: "%",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !1,
            createdOn: 0x1953d386fca,
          },
          "a-25": {
            id: "a-25",
            title: "\uD83D\uDC46Marquee-20",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-25-n",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 1e4,
                      target: {
                        selector: ".marquee_slide._20",
                        selectorGuids: [
                          "cfbe16e2-26c5-7498-d686-6acec1f942b8",
                          "b4055cc4-6691-242d-273a-65fbb6104732",
                        ],
                      },
                      xValue: -170,
                      xUnit: "%",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-25-n-2",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 1e4,
                      target: {
                        selector: ".marquee_slide._20",
                        selectorGuids: [
                          "cfbe16e2-26c5-7498-d686-6acec1f942b8",
                          "b4055cc4-6691-242d-273a-65fbb6104732",
                        ],
                      },
                      xValue: 0,
                      xUnit: "%",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-25-n-3",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 0,
                      target: {
                        selector: ".marquee_slide._20",
                        selectorGuids: [
                          "cfbe16e2-26c5-7498-d686-6acec1f942b8",
                          "b4055cc4-6691-242d-273a-65fbb6104732",
                        ],
                      },
                      xValue: -170,
                      xUnit: "%",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !0,
            createdOn: 0x1953d386fca,
          },
          "a-26": {
            id: "a-26",
            title: "\uD83D\uDC46Marquee-21",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-26-n",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 1e4,
                      target: {
                        selector: ".marquee_slide._21",
                        selectorGuids: [
                          "cfbe16e2-26c5-7498-d686-6acec1f942b8",
                          "7566b8db-2be6-ca5c-2411-e80842174f0a",
                        ],
                      },
                      xValue: -193,
                      xUnit: "%",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-26-n-2",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 0,
                      target: {
                        selector: ".marquee_slide._21",
                        selectorGuids: [
                          "cfbe16e2-26c5-7498-d686-6acec1f942b8",
                          "7566b8db-2be6-ca5c-2411-e80842174f0a",
                        ],
                      },
                      xValue: 0,
                      xUnit: "%",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !1,
            createdOn: 0x1953d386fca,
          },
          "a-23": {
            id: "a-23",
            title: "\uD83D\uDC46Marquee-18",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-23-n",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 1e4,
                      target: {
                        selector: ".marquee_slide._18",
                        selectorGuids: [
                          "cfbe16e2-26c5-7498-d686-6acec1f942b8",
                          "22cc2154-7c12-dcc4-eccc-601dc6f5d0ec",
                        ],
                      },
                      xValue: -169,
                      xUnit: "%",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-23-n-2",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 0,
                      target: {
                        selector: ".marquee_slide._18",
                        selectorGuids: [
                          "cfbe16e2-26c5-7498-d686-6acec1f942b8",
                          "22cc2154-7c12-dcc4-eccc-601dc6f5d0ec",
                        ],
                      },
                      xValue: 0,
                      xUnit: "%",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !1,
            createdOn: 0x1953d386fca,
          },
          "a-27": {
            id: "a-27",
            title: "\uD83D\uDC46nav-tap-1",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-27-n",
                    actionTypeId: "STYLE_SIZE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        selector: ".nav_menu",
                        selectorGuids: ["e1351820-8d34-15f6-35f2-a0e9263a63a9"],
                      },
                      heightValue: 0,
                      widthUnit: "PX",
                      heightUnit: "px",
                      locked: !1,
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-27-n-2",
                    actionTypeId: "STYLE_SIZE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 300,
                      target: {
                        selector: ".nav_menu",
                        selectorGuids: ["e1351820-8d34-15f6-35f2-a0e9263a63a9"],
                      },
                      widthUnit: "PX",
                      heightUnit: "AUTO",
                      locked: !1,
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !0,
            createdOn: 0x1953e3951e0,
          },
          "a-28": {
            id: "a-28",
            title: "\uD83D\uDC46nav-tap-1 2",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-28-n",
                    actionTypeId: "STYLE_SIZE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 300,
                      target: {
                        selector: ".nav_menu",
                        selectorGuids: ["e1351820-8d34-15f6-35f2-a0e9263a63a9"],
                      },
                      heightValue: 0,
                      widthUnit: "PX",
                      heightUnit: "px",
                      locked: !1,
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !1,
            createdOn: 0x1953e3951e0,
          },
          "a-29": {
            id: "a-29",
            title: "⚡footer_link[hover-in]",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-29-n",
                    actionTypeId: "STYLE_SIZE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".footer_link-underlined",
                        selectorGuids: ["5f6d3c75-173e-5037-465f-fc7b831044d4"],
                      },
                      widthValue: 0,
                      widthUnit: "%",
                      heightUnit: "PX",
                      locked: !1,
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-29-n-2",
                    actionTypeId: "STYLE_SIZE",
                    config: {
                      delay: 0,
                      easing: "outQuad",
                      duration: 500,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".footer_link-underlined",
                        selectorGuids: ["5f6d3c75-173e-5037-465f-fc7b831044d4"],
                      },
                      widthValue: 100,
                      widthUnit: "%",
                      heightUnit: "PX",
                      locked: !1,
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !0,
            createdOn: 0x19541b3c713,
          },
          "a-30": {
            id: "a-30",
            title: "⚡footer_link[hover-out]",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-30-n",
                    actionTypeId: "STYLE_SIZE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".footer_link-underlined",
                        selectorGuids: ["5f6d3c75-173e-5037-465f-fc7b831044d4"],
                      },
                      widthValue: 0,
                      widthUnit: "%",
                      heightUnit: "PX",
                      locked: !1,
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !1,
            createdOn: 0x19541b3c713,
          },
          "a-31": {
            id: "a-31",
            title: "\uD83D\uDC46Marquee-22",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-31-n",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 1e4,
                      target: {
                        id: "67df2cb3d3ad1c8c0bab5b1f|e3b15a7c-8819-7f88-dbb7-3daf33f40885",
                      },
                      xValue: -166,
                      xUnit: "%",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-31-n-2",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 0,
                      target: {
                        id: "67df2cb3d3ad1c8c0bab5b1f|e3b15a7c-8819-7f88-dbb7-3daf33f40885",
                      },
                      xValue: 0,
                      xUnit: "%",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !1,
            createdOn: 0x1953d386fca,
          },
          a: {
            id: "a",
            title: "\uD83D\uDC46choose-card-wiew-more",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-n",
                    actionTypeId: "STYLE_SIZE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".choose_body",
                        selectorGuids: ["1ae1d94d-4710-dd78-3712-378d2d250db7"],
                      },
                      heightValue: 0,
                      widthUnit: "PX",
                      heightUnit: "px",
                      locked: !1,
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-n-2",
                    actionTypeId: "STYLE_SIZE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 350,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".choose_body",
                        selectorGuids: ["1ae1d94d-4710-dd78-3712-378d2d250db7"],
                      },
                      widthUnit: "PX",
                      heightUnit: "AUTO",
                      locked: !1,
                    },
                  },
                  {
                    id: "a-n-3",
                    actionTypeId: "STYLE_BACKGROUND_COLOR",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 350,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".choose_card.slide_bottom-000",
                        selectorGuids: [
                          "0c89b8cd-a06e-87ea-53b8-3514165caf57",
                          "b9bab179-66bb-dcb2-8999-8027643f827b",
                        ],
                      },
                      globalSwatchId: "--base-color-brand--black-dark",
                      rValue: 0,
                      bValue: 0,
                      gValue: 0,
                      aValue: 1,
                    },
                  },
                  {
                    id: "a-n-4",
                    actionTypeId: "STYLE_TEXT_COLOR",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 350,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".text-size-22.text-weight-bold",
                        selectorGuids: [
                          "53afa5d0-ca01-cb5a-5c0e-a3120ad8d9cb",
                          "93b82d87-0cc1-c12e-fc5c-08bed1e3f7ad",
                        ],
                      },
                      globalSwatchId: "--base-color-neutral--white",
                      rValue: 255,
                      bValue: 255,
                      gValue: 255,
                      aValue: 1,
                    },
                  },
                  {
                    id: "a-n-5",
                    actionTypeId: "STYLE_TEXT_COLOR",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 350,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".text-size-regular",
                        selectorGuids: ["07815991-952a-8d98-0e00-e4c25af27122"],
                      },
                      globalSwatchId: "--base-color-neutral--white",
                      rValue: 255,
                      bValue: 255,
                      gValue: 255,
                      aValue: 1,
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !0,
            createdOn: 0x19537d899cc,
          },
          "a-2": {
            id: "a-2",
            title: "\uD83D\uDC46choose-card-wiew-less",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-2-n-2",
                    actionTypeId: "STYLE_SIZE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 350,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".choose_body",
                        selectorGuids: ["1ae1d94d-4710-dd78-3712-378d2d250db7"],
                      },
                      heightValue: 0,
                      widthUnit: "PX",
                      heightUnit: "px",
                      locked: !1,
                    },
                  },
                  {
                    id: "a-2-n-3",
                    actionTypeId: "STYLE_BACKGROUND_COLOR",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 350,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".choose_card.slide_bottom-000",
                        selectorGuids: [
                          "0c89b8cd-a06e-87ea-53b8-3514165caf57",
                          "b9bab179-66bb-dcb2-8999-8027643f827b",
                        ],
                      },
                      globalSwatchId: "--base-color-neutral--white",
                      rValue: 255,
                      bValue: 255,
                      gValue: 255,
                      aValue: 1,
                    },
                  },
                  {
                    id: "a-2-n-4",
                    actionTypeId: "STYLE_TEXT_COLOR",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 350,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".text-size-22.text-weight-bold",
                        selectorGuids: [
                          "53afa5d0-ca01-cb5a-5c0e-a3120ad8d9cb",
                          "93b82d87-0cc1-c12e-fc5c-08bed1e3f7ad",
                        ],
                      },
                      globalSwatchId: "--base-color-neutral--black",
                      rValue: 45,
                      bValue: 45,
                      gValue: 45,
                      aValue: 1,
                    },
                  },
                  {
                    id: "a-2-n-5",
                    actionTypeId: "STYLE_TEXT_COLOR",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 350,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".text-size-regular",
                        selectorGuids: ["07815991-952a-8d98-0e00-e4c25af27122"],
                      },
                      globalSwatchId: "--base-color-neutral--black",
                      rValue: 45,
                      bValue: 45,
                      gValue: 45,
                      aValue: 1,
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !1,
            createdOn: 0x19537d899cc,
          },
          "a-32": {
            id: "a-32",
            title: "\uD83D\uDC46choose-card-wiew-more 2",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-32-n",
                    actionTypeId: "STYLE_SIZE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".choose_body",
                        selectorGuids: ["1ae1d94d-4710-dd78-3712-378d2d250db7"],
                      },
                      heightValue: 0,
                      widthUnit: "PX",
                      heightUnit: "px",
                      locked: !1,
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-32-n-2",
                    actionTypeId: "STYLE_SIZE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 350,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".choose_body",
                        selectorGuids: ["1ae1d94d-4710-dd78-3712-378d2d250db7"],
                      },
                      widthUnit: "PX",
                      heightUnit: "AUTO",
                      locked: !1,
                    },
                  },
                  {
                    id: "a-32-n-3",
                    actionTypeId: "STYLE_BACKGROUND_COLOR",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 350,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".choose_card.slide_bottom-200",
                        selectorGuids: [
                          "0c89b8cd-a06e-87ea-53b8-3514165caf57",
                          "887d40de-e1fe-f42f-0c2d-3c442cd7c3ef",
                        ],
                      },
                      globalSwatchId: "--base-color-brand--black-dark",
                      rValue: 0,
                      bValue: 0,
                      gValue: 0,
                      aValue: 1,
                    },
                  },
                  {
                    id: "a-32-n-4",
                    actionTypeId: "STYLE_TEXT_COLOR",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 350,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".text-size-22.text-weight-bold",
                        selectorGuids: [
                          "53afa5d0-ca01-cb5a-5c0e-a3120ad8d9cb",
                          "93b82d87-0cc1-c12e-fc5c-08bed1e3f7ad",
                        ],
                      },
                      globalSwatchId: "--base-color-neutral--white",
                      rValue: 255,
                      bValue: 255,
                      gValue: 255,
                      aValue: 1,
                    },
                  },
                  {
                    id: "a-32-n-5",
                    actionTypeId: "STYLE_TEXT_COLOR",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 350,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".text-size-regular",
                        selectorGuids: ["07815991-952a-8d98-0e00-e4c25af27122"],
                      },
                      globalSwatchId: "--base-color-neutral--white",
                      rValue: 255,
                      bValue: 255,
                      gValue: 255,
                      aValue: 1,
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !0,
            createdOn: 0x19537d899cc,
          },
          "a-33": {
            id: "a-33",
            title: "\uD83D\uDC46choose-card-wiew-less 2",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-33-n",
                    actionTypeId: "STYLE_SIZE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 350,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".choose_body",
                        selectorGuids: ["1ae1d94d-4710-dd78-3712-378d2d250db7"],
                      },
                      heightValue: 0,
                      widthUnit: "PX",
                      heightUnit: "px",
                      locked: !1,
                    },
                  },
                  {
                    id: "a-33-n-2",
                    actionTypeId: "STYLE_BACKGROUND_COLOR",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 350,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".choose_card.slide_bottom-200",
                        selectorGuids: [
                          "0c89b8cd-a06e-87ea-53b8-3514165caf57",
                          "887d40de-e1fe-f42f-0c2d-3c442cd7c3ef",
                        ],
                      },
                      globalSwatchId: "--base-color-neutral--white",
                      rValue: 255,
                      bValue: 255,
                      gValue: 255,
                      aValue: 1,
                    },
                  },
                  {
                    id: "a-33-n-3",
                    actionTypeId: "STYLE_TEXT_COLOR",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 350,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".text-size-22.text-weight-bold",
                        selectorGuids: [
                          "53afa5d0-ca01-cb5a-5c0e-a3120ad8d9cb",
                          "93b82d87-0cc1-c12e-fc5c-08bed1e3f7ad",
                        ],
                      },
                      globalSwatchId: "--base-color-neutral--black",
                      rValue: 45,
                      bValue: 45,
                      gValue: 45,
                      aValue: 1,
                    },
                  },
                  {
                    id: "a-33-n-4",
                    actionTypeId: "STYLE_TEXT_COLOR",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 350,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".text-size-regular",
                        selectorGuids: ["07815991-952a-8d98-0e00-e4c25af27122"],
                      },
                      globalSwatchId: "--base-color-neutral--black",
                      rValue: 45,
                      bValue: 45,
                      gValue: 45,
                      aValue: 1,
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !1,
            createdOn: 0x19537d899cc,
          },
          "a-34": {
            id: "a-34",
            title: "FAQ Drop Down",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-34-n",
                    actionTypeId: "STYLE_SIZE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {},
                      heightValue: 0,
                      widthUnit: "PX",
                      heightUnit: "PX",
                      locked: !1,
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-34-n-2",
                    actionTypeId: "STYLE_SIZE",
                    config: {
                      delay: 0,
                      easing: "outQuart",
                      duration: 500,
                      target: {},
                      widthUnit: "PX",
                      heightUnit: "AUTO",
                      locked: !1,
                    },
                  },
                  {
                    id: "a-34-n-3",
                    actionTypeId: "TRANSFORM_ROTATE",
                    config: {
                      delay: 0,
                      easing: "easeOut",
                      duration: 300,
                      target: {},
                      zValue: 45,
                      xUnit: "DEG",
                      yUnit: "DEG",
                      zUnit: "DEG",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !0,
            createdOn: 0x1682d19a9f7,
          },
          "a-35": {
            id: "a-35",
            title: "FAQ Drop Down (Close)",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-35-n",
                    actionTypeId: "STYLE_SIZE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {},
                      heightValue: 0,
                      widthUnit: "PX",
                      heightUnit: "PX",
                      locked: !1,
                    },
                  },
                  {
                    id: "a-35-n-2",
                    actionTypeId: "TRANSFORM_ROTATE",
                    config: {
                      delay: 0,
                      easing: "easeOut",
                      duration: 300,
                      target: {},
                      zValue: 0,
                      xUnit: "DEG",
                      yUnit: "DEG",
                      zUnit: "DEG",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !1,
            createdOn: 0x1682d19a9f7,
          },
          "a-36": {
            id: "a-36",
            title: "faq_open",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-36-n",
                    actionTypeId: "STYLE_SIZE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".dropdown-list",
                        selectorGuids: ["fed7928c-1870-8e21-051b-3d427dbc6337"],
                      },
                      heightValue: 0,
                      widthUnit: "PX",
                      heightUnit: "px",
                      locked: !1,
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-36-n-2",
                    actionTypeId: "STYLE_SIZE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 400,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".dropdown-list",
                        selectorGuids: ["fed7928c-1870-8e21-051b-3d427dbc6337"],
                      },
                      widthUnit: "PX",
                      heightUnit: "AUTO",
                      locked: !1,
                    },
                  },
                  {
                    id: "a-36-n-3",
                    actionTypeId: "PLUGIN_LOTTIE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 400,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".lottie",
                        selectorGuids: ["4a81bacd-e789-71c7-9374-c688ca089982"],
                      },
                      value: 100,
                    },
                  },
                  {
                    id: "a-36-n-4",
                    actionTypeId: "STYLE_BACKGROUND_COLOR",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 400,
                      target: {
                        useEventTarget: !0,
                        id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc9010",
                      },
                      globalSwatchId: "--base-color-brand--black-dark",
                      rValue: 0,
                      bValue: 0,
                      gValue: 0,
                      aValue: 1,
                    },
                  },
                  {
                    id: "a-36-n-5",
                    actionTypeId: "STYLE_TEXT_COLOR",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 400,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".dropdown-toggle-2",
                        selectorGuids: ["354cc53b-a8ba-a632-94ca-e70c92e31ed8"],
                      },
                      globalSwatchId: "--base-color-neutral--white",
                      rValue: 255,
                      bValue: 255,
                      gValue: 255,
                      aValue: 1,
                    },
                  },
                  {
                    id: "a-36-n-6",
                    actionTypeId: "STYLE_TEXT_COLOR",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 400,
                      target: {
                        useEventTarget: !0,
                        id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc9010",
                      },
                      globalSwatchId: "",
                      rValue: 255,
                      bValue: 255,
                      gValue: 255,
                      aValue: 1,
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !0,
            createdOn: 0x1955e2f8856,
          },
          "a-37": {
            id: "a-37",
            title: "d01 2",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-37-n-2",
                    actionTypeId: "STYLE_SIZE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 400,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".dropdown-list",
                        selectorGuids: ["fed7928c-1870-8e21-051b-3d427dbc6337"],
                      },
                      heightValue: 0,
                      widthUnit: "PX",
                      heightUnit: "px",
                      locked: !1,
                    },
                  },
                  {
                    id: "a-37-n-3",
                    actionTypeId: "PLUGIN_LOTTIE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 400,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".lottie",
                        selectorGuids: ["4a81bacd-e789-71c7-9374-c688ca089982"],
                      },
                      value: 0,
                    },
                  },
                  {
                    id: "a-37-n-4",
                    actionTypeId: "STYLE_BACKGROUND_COLOR",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 400,
                      target: {
                        useEventTarget: !0,
                        id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc9010",
                      },
                      globalSwatchId: "",
                      rValue: 255,
                      bValue: 255,
                      gValue: 255,
                      aValue: 1,
                    },
                  },
                  {
                    id: "a-37-n-5",
                    actionTypeId: "STYLE_TEXT_COLOR",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 400,
                      target: {
                        useEventTarget: !0,
                        id: "67df2cb3d3ad1c8c0bab5b1f|806eaec6-df40-d04e-304f-3066a3bc9010",
                      },
                      globalSwatchId: "--base-color-brand--black-dark",
                      rValue: 0,
                      bValue: 0,
                      gValue: 0,
                      aValue: 1,
                    },
                  },
                  {
                    id: "a-37-n-6",
                    actionTypeId: "STYLE_TEXT_COLOR",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 400,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".dropdown-toggle-2",
                        selectorGuids: ["354cc53b-a8ba-a632-94ca-e70c92e31ed8"],
                      },
                      globalSwatchId: "--base-color-brand--black-dark",
                      rValue: 0,
                      bValue: 0,
                      gValue: 0,
                      aValue: 1,
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !1,
            createdOn: 0x1955e2f8856,
          },
          "a-38": {
            id: "a-38",
            title: "\uD83D\uDC46pop_up-show",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-38-n-2",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        selector: ".pop_up",
                        selectorGuids: ["605b2d84-54e0-dc9b-28dc-06b63541e915"],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                  {
                    id: "a-38-n-4",
                    actionTypeId: "GENERAL_DISPLAY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 0,
                      target: {
                        selector: ".pop_up",
                        selectorGuids: ["605b2d84-54e0-dc9b-28dc-06b63541e915"],
                      },
                      value: "none",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-38-n",
                    actionTypeId: "GENERAL_DISPLAY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 0,
                      target: {
                        selector: ".pop_up",
                        selectorGuids: ["605b2d84-54e0-dc9b-28dc-06b63541e915"],
                      },
                      value: "flex",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-38-n-3",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 300,
                      target: {
                        selector: ".pop_up",
                        selectorGuids: ["605b2d84-54e0-dc9b-28dc-06b63541e915"],
                      },
                      value: 1,
                      unit: "",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !0,
            createdOn: 0x19586ec8466,
          },
          "a-39": {
            id: "a-39",
            title: "\uD83D\uDC46pop_up-hide",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-39-n-2",
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 300,
                      target: {
                        selector: ".pop_up",
                        selectorGuids: ["605b2d84-54e0-dc9b-28dc-06b63541e915"],
                      },
                      value: 0,
                      unit: "",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-39-n",
                    actionTypeId: "GENERAL_DISPLAY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 0,
                      target: {
                        selector: ".pop_up",
                        selectorGuids: ["605b2d84-54e0-dc9b-28dc-06b63541e915"],
                      },
                      value: "none",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !1,
            createdOn: 0x19586ec8466,
          },
          "a-40": {
            id: "a-40",
            title: "⚡tab-monthly",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-40-n",
                    actionTypeId: "GENERAL_DISPLAY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 0,
                      target: {
                        selector: ".summary_4-cols.monthly",
                        selectorGuids: [
                          "61ef1206-ef1c-5089-ecf9-2f5d80d0d819",
                          "1380ad32-7119-9f29-2762-b2f03335bbff",
                        ],
                      },
                      value: "grid",
                    },
                  },
                  {
                    id: "a-40-n-2",
                    actionTypeId: "GENERAL_DISPLAY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 0,
                      target: {
                        selector: ".summary_4-cols.quartely",
                        selectorGuids: [
                          "61ef1206-ef1c-5089-ecf9-2f5d80d0d819",
                          "6d17886e-8465-ce78-90a6-510624e41dcf",
                        ],
                      },
                      value: "none",
                    },
                  },
                  {
                    id: "a-40-n-3",
                    actionTypeId: "GENERAL_DISPLAY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 0,
                      target: {
                        selector: ".summary_4-cols.yearly",
                        selectorGuids: [
                          "61ef1206-ef1c-5089-ecf9-2f5d80d0d819",
                          "cd245936-fef2-d057-e761-3e492099ad2e",
                        ],
                      },
                      value: "none",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-40-n-4",
                    actionTypeId: "GENERAL_DISPLAY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 0,
                      target: {
                        selector: ".summary_4-cols.monthly",
                        selectorGuids: [
                          "61ef1206-ef1c-5089-ecf9-2f5d80d0d819",
                          "1380ad32-7119-9f29-2762-b2f03335bbff",
                        ],
                      },
                      value: "grid",
                    },
                  },
                  {
                    id: "a-40-n-6",
                    actionTypeId: "GENERAL_DISPLAY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 0,
                      target: {
                        selector: ".summary_4-cols.yearly",
                        selectorGuids: [
                          "61ef1206-ef1c-5089-ecf9-2f5d80d0d819",
                          "cd245936-fef2-d057-e761-3e492099ad2e",
                        ],
                      },
                      value: "none",
                    },
                  },
                  {
                    id: "a-40-n-5",
                    actionTypeId: "GENERAL_DISPLAY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 0,
                      target: {
                        selector: ".summary_4-cols.quartely",
                        selectorGuids: [
                          "61ef1206-ef1c-5089-ecf9-2f5d80d0d819",
                          "6d17886e-8465-ce78-90a6-510624e41dcf",
                        ],
                      },
                      value: "none",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !0,
            createdOn: 0x195b4d8488b,
          },
          "a-41": {
            id: "a-41",
            title: "⚡tab-quartely",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-41-n-4",
                    actionTypeId: "GENERAL_DISPLAY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 0,
                      target: {
                        selector: ".summary_4-cols.monthly",
                        selectorGuids: [
                          "61ef1206-ef1c-5089-ecf9-2f5d80d0d819",
                          "1380ad32-7119-9f29-2762-b2f03335bbff",
                        ],
                      },
                      value: "none",
                    },
                  },
                  {
                    id: "a-41-n-5",
                    actionTypeId: "GENERAL_DISPLAY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 0,
                      target: {
                        selector: ".summary_4-cols.yearly",
                        selectorGuids: [
                          "61ef1206-ef1c-5089-ecf9-2f5d80d0d819",
                          "cd245936-fef2-d057-e761-3e492099ad2e",
                        ],
                      },
                      value: "none",
                    },
                  },
                  {
                    id: "a-41-n-6",
                    actionTypeId: "GENERAL_DISPLAY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 0,
                      target: {
                        selector: ".summary_4-cols.quartely",
                        selectorGuids: [
                          "61ef1206-ef1c-5089-ecf9-2f5d80d0d819",
                          "6d17886e-8465-ce78-90a6-510624e41dcf",
                        ],
                      },
                      value: "grid",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !1,
            createdOn: 0x195b4d8488b,
          },
          "a-42": {
            id: "a-42",
            title: "⚡tab-yearly",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-42-n",
                    actionTypeId: "GENERAL_DISPLAY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 0,
                      target: {
                        selector: ".summary_4-cols.monthly",
                        selectorGuids: [
                          "61ef1206-ef1c-5089-ecf9-2f5d80d0d819",
                          "1380ad32-7119-9f29-2762-b2f03335bbff",
                        ],
                      },
                      value: "none",
                    },
                  },
                  {
                    id: "a-42-n-2",
                    actionTypeId: "GENERAL_DISPLAY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 0,
                      target: {
                        selector: ".summary_4-cols.yearly",
                        selectorGuids: [
                          "61ef1206-ef1c-5089-ecf9-2f5d80d0d819",
                          "cd245936-fef2-d057-e761-3e492099ad2e",
                        ],
                      },
                      value: "grid",
                    },
                  },
                  {
                    id: "a-42-n-3",
                    actionTypeId: "GENERAL_DISPLAY",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 0,
                      target: {
                        selector: ".summary_4-cols.quartely",
                        selectorGuids: [
                          "61ef1206-ef1c-5089-ecf9-2f5d80d0d819",
                          "6d17886e-8465-ce78-90a6-510624e41dcf",
                        ],
                      },
                      value: "none",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !1,
            createdOn: 0x195b4d8488b,
          },
          slideInBottom: {
            id: "slideInBottom",
            useFirstGroupAsInitialState: !0,
            actionItemGroups: [
              {
                actionItems: [
                  {
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      duration: 0,
                      target: {
                        id: "N/A",
                        appliesTo: "TRIGGER_ELEMENT",
                        useEventTarget: !0,
                      },
                      value: 0,
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      duration: 0,
                      target: {
                        id: "N/A",
                        appliesTo: "TRIGGER_ELEMENT",
                        useEventTarget: !0,
                      },
                      xValue: 0,
                      yValue: 100,
                      xUnit: "PX",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "outQuart",
                      duration: 1e3,
                      target: {
                        id: "N/A",
                        appliesTo: "TRIGGER_ELEMENT",
                        useEventTarget: !0,
                      },
                      xValue: 0,
                      yValue: 0,
                      xUnit: "PX",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                  {
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "outQuart",
                      duration: 1e3,
                      target: {
                        id: "N/A",
                        appliesTo: "TRIGGER_ELEMENT",
                        useEventTarget: !0,
                      },
                      value: 1,
                    },
                  },
                ],
              },
            ],
          },
          slideInLeft: {
            id: "slideInLeft",
            useFirstGroupAsInitialState: !0,
            actionItemGroups: [
              {
                actionItems: [
                  {
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      duration: 0,
                      target: {
                        id: "N/A",
                        appliesTo: "TRIGGER_ELEMENT",
                        useEventTarget: !0,
                      },
                      value: 0,
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      duration: 0,
                      target: {
                        id: "N/A",
                        appliesTo: "TRIGGER_ELEMENT",
                        useEventTarget: !0,
                      },
                      xValue: -100,
                      yValue: 0,
                      xUnit: "PX",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "outQuart",
                      duration: 1e3,
                      target: {
                        id: "N/A",
                        appliesTo: "TRIGGER_ELEMENT",
                        useEventTarget: !0,
                      },
                      value: 1,
                    },
                  },
                  {
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "outQuart",
                      duration: 1e3,
                      target: {
                        id: "N/A",
                        appliesTo: "TRIGGER_ELEMENT",
                        useEventTarget: !0,
                      },
                      xValue: 0,
                      yValue: 0,
                      xUnit: "PX",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
            ],
          },
          slideInRight: {
            id: "slideInRight",
            useFirstGroupAsInitialState: !0,
            actionItemGroups: [
              {
                actionItems: [
                  {
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      duration: 0,
                      target: {
                        id: "N/A",
                        appliesTo: "TRIGGER_ELEMENT",
                        useEventTarget: !0,
                      },
                      value: 0,
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      duration: 0,
                      target: {
                        id: "N/A",
                        appliesTo: "TRIGGER_ELEMENT",
                        useEventTarget: !0,
                      },
                      xValue: 100,
                      yValue: 0,
                      xUnit: "PX",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    actionTypeId: "STYLE_OPACITY",
                    config: {
                      delay: 0,
                      easing: "outQuart",
                      duration: 1e3,
                      target: {
                        id: "N/A",
                        appliesTo: "TRIGGER_ELEMENT",
                        useEventTarget: !0,
                      },
                      value: 1,
                    },
                  },
                  {
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "outQuart",
                      duration: 1e3,
                      target: {
                        id: "N/A",
                        appliesTo: "TRIGGER_ELEMENT",
                        useEventTarget: !0,
                      },
                      xValue: 0,
                      yValue: 0,
                      xUnit: "PX",
                      yUnit: "PX",
                      zUnit: "PX",
                    },
                  },
                ],
              },
            ],
          },
        },
        site: {
          mediaQueries: [
            { key: "main", min: 992, max: 1e4 },
            { key: "medium", min: 768, max: 991 },
            { key: "small", min: 480, max: 767 },
            { key: "tiny", min: 0, max: 479 },
          ],
        },
      });
    },
  },
]);
