// Copyright 2012 Google Inc. All rights reserved.

(function () {
  var data = {
    resource: {
      version: "2",

      macros: [
        {
          function: "__u",
          vtp_component: "URL",
          vtp_enableMultiQueryKeys: false,
          vtp_enableIgnoreEmptyQueryParam: false,
        },
        {
          function: "__u",
          vtp_component: "HOST",
          vtp_enableMultiQueryKeys: false,
          vtp_enableIgnoreEmptyQueryParam: false,
        },
        {
          function: "__u",
          vtp_component: "PATH",
          vtp_enableMultiQueryKeys: false,
          vtp_enableIgnoreEmptyQueryParam: false,
        },
        { function: "__f", vtp_component: "URL" },
        { function: "__e" },
      ],
      tags: [],
      predicates: [],
      rules: [],
    },
    runtime: [
      [
        50,
        "__e",
        [46, "a"],
        [
          36,
          [
            13,
            [41, "$0"],
            [3, "$0", ["require", "internal.getEventData"]],
            ["$0", "event"],
          ],
        ],
      ],
      [
        50,
        "__f",
        [46, "a"],
        [52, "b", ["require", "copyFromDataLayer"]],
        [52, "c", ["require", "getReferrerUrl"]],
        [52, "d", ["require", "makeString"]],
        [52, "e", ["require", "parseUrl"]],
        [52, "f", [15, "__module_legacyUrls"]],
        [52, "g", [30, ["b", "gtm.referrer", 1], ["c"]]],
        [22, [28, [15, "g"]], [46, [36, ["d", [15, "g"]]]]],
        [
          38,
          [17, [15, "a"], "component"],
          [46, "PROTOCOL", "HOST", "PORT", "PATH", "QUERY", "FRAGMENT", "URL"],
          [
            46,
            [5, [46, [36, [2, [15, "f"], "B", [7, [15, "g"]]]]]],
            [
              5,
              [
                46,
                [
                  36,
                  [
                    2,
                    [15, "f"],
                    "C",
                    [7, [15, "g"], [17, [15, "a"], "stripWww"]],
                  ],
                ],
              ],
            ],
            [5, [46, [36, [2, [15, "f"], "D", [7, [15, "g"]]]]]],
            [
              5,
              [
                46,
                [
                  36,
                  [
                    2,
                    [15, "f"],
                    "E",
                    [7, [15, "g"], [17, [15, "a"], "defaultPages"]],
                  ],
                ],
              ],
            ],
            [
              5,
              [
                46,
                [
                  22,
                  [17, [15, "a"], "queryKey"],
                  [
                    46,
                    [
                      53,
                      [
                        36,
                        [
                          2,
                          [15, "f"],
                          "H",
                          [7, [15, "g"], [17, [15, "a"], "queryKey"]],
                        ],
                      ],
                    ],
                  ],
                ],
                [52, "h", ["e", [15, "g"]]],
                [36, [2, [17, [15, "h"], "search"], "replace", [7, "?", ""]]],
              ],
            ],
            [5, [46, [36, [2, [15, "f"], "G", [7, [15, "g"]]]]]],
            [5, [46]],
            [9, [46, [36, [2, [15, "f"], "A", [7, ["d", [15, "g"]]]]]]],
          ],
        ],
      ],
      [
        50,
        "__u",
        [46, "a"],
        [
          50,
          "k",
          [46, "l", "m"],
          [52, "n", [17, [15, "m"], "multiQueryKeys"]],
          [52, "o", [30, [17, [15, "m"], "queryKey"], ""]],
          [52, "p", [17, [15, "m"], "ignoreEmptyQueryParam"]],
          [
            22,
            [20, [15, "o"], ""],
            [
              46,
              [
                53,
                [
                  52,
                  "r",
                  [
                    2,
                    [17, ["i", [15, "l"]], "search"],
                    "replace",
                    [7, "?", ""],
                  ],
                ],
                [36, [39, [1, [28, [15, "r"]], [15, "p"]], [44], [15, "r"]]],
              ],
            ],
          ],
          [41, "q"],
          [
            22,
            [15, "n"],
            [
              46,
              [
                53,
                [
                  22,
                  [20, ["e", [15, "o"]], "array"],
                  [46, [53, [3, "q", [15, "o"]]]],
                  [
                    46,
                    [
                      53,
                      [52, "r", ["c", "\\s+", "g"]],
                      [
                        3,
                        "q",
                        [
                          2,
                          [2, ["f", [15, "o"]], "replace", [7, [15, "r"], ""]],
                          "split",
                          [7, ","],
                        ],
                      ],
                    ],
                  ],
                ],
              ],
            ],
            [46, [53, [3, "q", [7, ["f", [15, "o"]]]]]],
          ],
          [
            65,
            "r",
            [15, "q"],
            [
              46,
              [
                53,
                [52, "s", [2, [15, "h"], "H", [7, [15, "l"], [15, "r"]]]],
                [
                  22,
                  [29, [15, "s"], [44]],
                  [
                    46,
                    [
                      53,
                      [
                        22,
                        [1, [15, "p"], [20, [15, "s"], ""]],
                        [46, [53, [6]]],
                      ],
                      [36, [15, "s"]],
                    ],
                  ],
                ],
              ],
            ],
          ],
          [36, [44]],
        ],
        [52, "b", ["require", "copyFromDataLayer"]],
        [52, "c", ["require", "internal.createRegex"]],
        [52, "d", ["require", "getUrl"]],
        [52, "e", ["require", "getType"]],
        [52, "f", ["require", "makeString"]],
        [52, "g", ["require", "parseUrl"]],
        [52, "h", [15, "__module_legacyUrls"]],
        [52, "i", ["require", "internal.legacyParseUrl"]],
        [41, "j"],
        [
          22,
          [17, [15, "a"], "customUrlSource"],
          [46, [53, [3, "j", [17, [15, "a"], "customUrlSource"]]]],
          [46, [53, [3, "j", ["b", "gtm.url", 1]]]],
        ],
        [3, "j", [30, [15, "j"], ["d"]]],
        [
          38,
          [17, [15, "a"], "component"],
          [
            46,
            "PROTOCOL",
            "HOST",
            "PORT",
            "PATH",
            "EXTENSION",
            "QUERY",
            "FRAGMENT",
            "URL",
          ],
          [
            46,
            [5, [46, [36, [2, [15, "h"], "B", [7, [15, "j"]]]]]],
            [
              5,
              [
                46,
                [
                  36,
                  [
                    2,
                    [15, "h"],
                    "C",
                    [7, [15, "j"], [17, [15, "a"], "stripWww"]],
                  ],
                ],
              ],
            ],
            [5, [46, [36, [2, [15, "h"], "D", [7, [15, "j"]]]]]],
            [
              5,
              [
                46,
                [
                  36,
                  [
                    2,
                    [15, "h"],
                    "E",
                    [7, [15, "j"], [17, [15, "a"], "defaultPages"]],
                  ],
                ],
              ],
            ],
            [5, [46, [36, [2, [15, "h"], "F", [7, [15, "j"]]]]]],
            [5, [46, [36, ["k", [15, "j"], [15, "a"]]]]],
            [5, [46, [36, [2, [15, "h"], "G", [7, [15, "j"]]]]]],
            [5, [46]],
            [9, [46, [36, [2, [15, "h"], "A", [7, ["f", [15, "j"]]]]]]],
          ],
        ],
      ],
      [
        52,
        "__module_legacyUrls",
        [
          13,
          [41, "$0"],
          [
            3,
            "$0",
            [
              51,
              "",
              [7],
              [
                50,
                "a",
                [46],
                [
                  50,
                  "h",
                  [46, "p"],
                  [52, "q", [2, [15, "p"], "indexOf", [7, "#"]]],
                  [
                    36,
                    [
                      39,
                      [23, [15, "q"], 0],
                      [15, "p"],
                      [2, [15, "p"], "substring", [7, 0, [15, "q"]]],
                    ],
                  ],
                ],
                [
                  50,
                  "i",
                  [46, "p"],
                  [52, "q", [17, ["e", [15, "p"]], "protocol"]],
                  [
                    36,
                    [
                      39,
                      [15, "q"],
                      [2, [15, "q"], "replace", [7, ":", ""]],
                      "",
                    ],
                  ],
                ],
                [
                  50,
                  "j",
                  [46, "p", "q"],
                  [41, "r"],
                  [3, "r", [17, ["e", [15, "p"]], "hostname"]],
                  [22, [28, [15, "r"]], [46, [36, ""]]],
                  [52, "s", ["b", ":[0-9]+"]],
                  [3, "r", [2, [15, "r"], "replace", [7, [15, "s"], ""]]],
                  [
                    22,
                    [15, "q"],
                    [
                      46,
                      [
                        53,
                        [52, "t", ["b", "^www\\d*\\."]],
                        [52, "u", [2, [15, "r"], "match", [7, [15, "t"]]]],
                        [
                          22,
                          [1, [15, "u"], [16, [15, "u"], 0]],
                          [
                            46,
                            [
                              3,
                              "r",
                              [
                                2,
                                [15, "r"],
                                "substring",
                                [7, [17, [16, [15, "u"], 0], "length"]],
                              ],
                            ],
                          ],
                        ],
                      ],
                    ],
                  ],
                  [36, [15, "r"]],
                ],
                [
                  50,
                  "k",
                  [46, "p"],
                  [52, "q", ["e", [15, "p"]]],
                  [41, "r"],
                  [3, "r", ["f", [17, [15, "q"], "port"]]],
                  [
                    22,
                    [28, [15, "r"]],
                    [
                      46,
                      [
                        53,
                        [
                          22,
                          [20, [17, [15, "q"], "protocol"], "http:"],
                          [46, [53, [3, "r", 80]]],
                          [
                            46,
                            [
                              22,
                              [20, [17, [15, "q"], "protocol"], "https:"],
                              [46, [53, [3, "r", 443]]],
                              [46, [53, [3, "r", ""]]],
                            ],
                          ],
                        ],
                      ],
                    ],
                  ],
                  [36, ["g", [15, "r"]]],
                ],
                [
                  50,
                  "l",
                  [46, "p", "q"],
                  [52, "r", ["e", [15, "p"]]],
                  [41, "s"],
                  [
                    3,
                    "s",
                    [
                      39,
                      [
                        20,
                        [2, [17, [15, "r"], "pathname"], "indexOf", [7, "/"]],
                        0,
                      ],
                      [17, [15, "r"], "pathname"],
                      [0, "/", [17, [15, "r"], "pathName"]],
                    ],
                  ],
                  [
                    22,
                    [20, ["d", [15, "q"]], "array"],
                    [
                      46,
                      [
                        53,
                        [52, "t", [2, [15, "s"], "split", [7, "/"]]],
                        [
                          22,
                          [
                            19,
                            [
                              2,
                              [15, "q"],
                              "indexOf",
                              [
                                7,
                                [
                                  16,
                                  [15, "t"],
                                  [37, [17, [15, "t"], "length"], 1],
                                ],
                              ],
                            ],
                            0,
                          ],
                          [
                            46,
                            [
                              53,
                              [
                                43,
                                [15, "t"],
                                [37, [17, [15, "t"], "length"], 1],
                                "",
                              ],
                              [3, "s", [2, [15, "t"], "join", [7, "/"]]],
                            ],
                          ],
                        ],
                      ],
                    ],
                  ],
                  [36, [15, "s"]],
                ],
                [
                  50,
                  "m",
                  [46, "p"],
                  [52, "q", [17, ["e", [15, "p"]], "pathname"]],
                  [52, "r", [2, [15, "q"], "split", [7, "."]]],
                  [41, "s"],
                  [
                    3,
                    "s",
                    [
                      39,
                      [18, [17, [15, "r"], "length"], 1],
                      [16, [15, "r"], [37, [17, [15, "r"], "length"], 1]],
                      "",
                    ],
                  ],
                  [36, [16, [2, [15, "s"], "split", [7, "/"]], 0]],
                ],
                [
                  50,
                  "n",
                  [46, "p"],
                  [52, "q", [17, ["e", [15, "p"]], "hash"]],
                  [36, [2, [15, "q"], "replace", [7, "#", ""]]],
                ],
                [
                  50,
                  "o",
                  [46, "p", "q"],
                  [
                    50,
                    "s",
                    [46, "t"],
                    [
                      36,
                      [
                        "c",
                        [2, [15, "t"], "replace", [7, ["b", "\\+", "g"], " "]],
                      ],
                    ],
                  ],
                  [
                    52,
                    "r",
                    [
                      2,
                      [17, ["e", [15, "p"]], "search"],
                      "replace",
                      [7, "?", ""],
                    ],
                  ],
                  [
                    65,
                    "t",
                    [2, [15, "r"], "split", [7, "&"]],
                    [
                      46,
                      [
                        53,
                        [52, "u", [2, [15, "t"], "split", [7, "="]]],
                        [
                          22,
                          [21, ["s", [16, [15, "u"], 0]], [15, "q"]],
                          [46, [6]],
                        ],
                        [
                          36,
                          [
                            "s",
                            [
                              2,
                              [2, [15, "u"], "slice", [7, 1]],
                              "join",
                              [7, "="],
                            ],
                          ],
                        ],
                      ],
                    ],
                  ],
                  [36],
                ],
                [52, "b", ["require", "internal.createRegex"]],
                [52, "c", ["require", "decodeUriComponent"]],
                [52, "d", ["require", "getType"]],
                [52, "e", ["require", "internal.legacyParseUrl"]],
                [52, "f", ["require", "makeNumber"]],
                [52, "g", ["require", "makeString"]],
                [
                  36,
                  [
                    8,
                    "F",
                    [15, "m"],
                    "H",
                    [15, "o"],
                    "G",
                    [15, "n"],
                    "C",
                    [15, "j"],
                    "E",
                    [15, "l"],
                    "D",
                    [15, "k"],
                    "B",
                    [15, "i"],
                    "A",
                    [15, "h"],
                  ],
                ],
              ],
              [36, ["a"]],
            ],
          ],
          ["$0"],
        ],
      ],
    ],
    entities: {
      __e: { 2: true, 5: true },
      __f: { 2: true, 5: true },
      __u: { 2: true, 5: true },
    },
    blob: {
      1: "2",
      10: "GTM-NQ4V4HJM",
      14: "5b50",
      15: "0",
      16: "ChAIgJTByAYQh4uIkdi/rr08Eh0AIHjqS0FShV+gQ55Mx5WzbT/yznpt/G5WV82HsBoCJSc=",
      19: "dataLayer",
      20: "",
      21: "www.googletagmanager.com",
      22: "eyIwIjoiVUEiLCIxIjoiVUEtMzAiLCIyIjpmYWxzZSwiMyI6Imdvb2dsZS5jb20udWEiLCI0IjoiIiwiNSI6dHJ1ZSwiNiI6ZmFsc2UsIjciOiJhZF9zdG9yYWdlfGFuYWx5dGljc19zdG9yYWdlfGFkX3VzZXJfZGF0YXxhZF9wZXJzb25hbGl6YXRpb24ifQ",
      23: "google.tagmanager.debugui2.queue",
      24: "tagassistant.google.com",
      27: 0.005,
      3: "www.googletagmanager.com",
      30: "UA",
      31: "UA-30",
      32: true,
      36: "https://adservice.google.com/pagead/regclk",
      37: "__TAGGY_INSTALLED",
      38: "cct.google",
      39: "googTaggyReferrer",
      40: "https://cct.google/taggy/agent.js",
      41: "google.tagmanager.ta.prodqueue",
      42: 0.01,
      43: '{"keys":[{"hpkePublicKey":{"params":{"aead":"AES_128_GCM","kdf":"HKDF_SHA256","kem":"DHKEM_P256_HKDF_SHA256"},"publicKey":"BNRn4G3Ogm749mjaB9fOxD/6bjafS6b9rzHQ8mWaphBTcUmRwamRRevQQeHPjwEX6+ni/5oZHMsSu+SYE7vqBU8=","version":0},"id":"fad776f2-88f4-44d3-a3bd-b955e5a9a90e"},{"hpkePublicKey":{"params":{"aead":"AES_128_GCM","kdf":"HKDF_SHA256","kem":"DHKEM_P256_HKDF_SHA256"},"publicKey":"BKhUvCrZrzsWs5VEcP5pTfRWW4KfY+n/WcCxZ88fxacarBkVc9DNA/KuoHrCqN0DPGYeRrQGcKi8cgxEoeBXKAU=","version":0},"id":"f4072d4b-756f-4fb1-bc7a-4047be69fa31"},{"hpkePublicKey":{"params":{"aead":"AES_128_GCM","kdf":"HKDF_SHA256","kem":"DHKEM_P256_HKDF_SHA256"},"publicKey":"BOrfDR2srmlOkUJAov5FQq86rtlej/TYuNhP+aJXELkYFJcxzD8AQrNAztMrMk+BDbu2ACtSdsuApyTAcVNTsdY=","version":0},"id":"eca0f020-7fcc-4910-90d5-aef704ebab19"},{"hpkePublicKey":{"params":{"aead":"AES_128_GCM","kdf":"HKDF_SHA256","kem":"DHKEM_P256_HKDF_SHA256"},"publicKey":"BJwvv6L3gl/9l2PuulqK7Cmi2bhGpqMSPk9D5HKTxPkUwKUNfPzMwYa/CIFkxrEGvEFmTASanLZuDOOWRn12zj8=","version":0},"id":"a6286983-86e3-48fc-bf2d-374bd10e603f"},{"hpkePublicKey":{"params":{"aead":"AES_128_GCM","kdf":"HKDF_SHA256","kem":"DHKEM_P256_HKDF_SHA256"},"publicKey":"BGIJdTKsn6t6T/l52lDd9PXfReBhUWR7F/muumdXSv3ArffJ4Y9al6zgOCMo16jy/iXyg6Sdj+Hcrd/nRsPY4xI=","version":0},"id":"1f6af0c7-cff8-4109-9d8c-7d78f5999e5c"}]}',
      44: "101509157~102015666~103116026~103200004~103233427~104684208~104684211~116217636~116217638",
      46: {
        1: "1000",
        10: "5a20",
        11: "5a20",
        14: "1000",
        16: "US-CO~US-CT~US-MT~US-NE~US-NH~US-TX~US-MN~US-NJ~US-MD~US-OR~US-DE",
        17: "US-CO~US-CT~US-MT~US-NE~US-NH~US-TX~US-MN~US-NJ~US-MD",
        2: "9",
        20: "5000",
        21: "5000",
        22: "3.2.0",
        23: "0.0.0",
        25: "1",
        26: "4000",
        27: "100",
        3: "5",
        4: "ad_storage|analytics_storage|ad_user_data|ad_personalization",
        44: "15000",
        48: "30000",
        5: "ad_storage|analytics_storage|ad_user_data",
        6: "1",
        60: "0",
        7: "10",
      },
      48: true,
      5: "GTM-NQ4V4HJM",
      55: ["GTM-NQ4V4HJM"],
      56: [
        { 1: 403, 3: 0.5, 4: 115938465, 5: 115938466, 6: 0, 7: 2 },
        { 1: 404, 3: 0.5, 4: 115938468, 5: 115938469, 6: 0, 7: 1 },
        { 1: 406, 2: true },
        { 1: 414, 3: 0.001, 4: 115985661, 5: 115985660, 6: 0, 7: 2 },
      ],
      59: ["GTM-NQ4V4HJM"],
      6: "217431586",
    },
    permissions: {
      __e: {
        read_event_data: {
          eventDataAccess: "specific",
          keyPatterns: ["event"],
        },
      },
      __f: {
        read_data_layer: { keyPatterns: ["gtm.referrer"] },
        get_referrer: { urlParts: "any" },
      },
      __u: {
        read_data_layer: { keyPatterns: ["gtm.url"] },
        get_url: { urlParts: "any" },
      },
    },

    security_groups: {
      google: ["__e", "__f", "__u"],
    },
  };

  var k,
    aa =
      typeof Object.create == "function"
        ? Object.create
        : function (a) {
            var b = function () {};
            b.prototype = a;
            return new b();
          },
    ba =
      typeof Object.defineProperties == "function"
        ? Object.defineProperty
        : function (a, b, c) {
            if (a == Array.prototype || a == Object.prototype) return a;
            a[b] = c.value;
            return a;
          },
    ca = function (a) {
      for (
        var b = [
            "object" == typeof globalThis && globalThis,
            a,
            "object" == typeof window && window,
            "object" == typeof self && self,
            "object" == typeof global && global,
          ],
          c = 0;
        c < b.length;
        ++c
      ) {
        var d = b[c];
        if (d && d.Math == Math) return d;
      }
      throw Error("Cannot find global object");
    },
    da = ca(this),
    ea = typeof Symbol === "function" && typeof Symbol("x") === "symbol",
    fa = {},
    ia = {},
    la = function (a, b, c) {
      if (!c || a != null) {
        var d = ia[b];
        if (d == null) return a[b];
        var e = a[d];
        return e !== void 0 ? e : a[b];
      }
    },
    na = function (a, b, c) {
      if (b)
        a: {
          var d = a.split("."),
            e = d.length === 1,
            f = d[0],
            g;
          !e && f in fa ? (g = fa) : (g = da);
          for (var h = 0; h < d.length - 1; h++) {
            var l = d[h];
            if (!(l in g)) break a;
            g = g[l];
          }
          var n = d[d.length - 1],
            p = ea && c === "es6" ? g[n] : null,
            q = b(p);
          if (q != null)
            if (e) ba(fa, n, { configurable: !0, writable: !0, value: q });
            else if (q !== p) {
              if (ia[n] === void 0) {
                var r = (Math.random() * 1e9) >>> 0;
                ia[n] = ea ? da.Symbol(n) : "$jscp$" + r + "$" + n;
              }
              ba(g, ia[n], { configurable: !0, writable: !0, value: q });
            }
        }
    },
    oa;
  if (ea && typeof Object.setPrototypeOf == "function")
    oa = Object.setPrototypeOf;
  else {
    var qa;
    a: {
      var ra = { a: !0 },
        sa = {};
      try {
        sa.__proto__ = ra;
        qa = sa.a;
        break a;
      } catch (a) {}
      qa = !1;
    }
    oa = qa
      ? function (a, b) {
          a.__proto__ = b;
          if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
          return a;
        }
      : null;
  }
  var ta = oa,
    ua = function (a, b) {
      a.prototype = aa(b.prototype);
      a.prototype.constructor = a;
      if (ta) ta(a, b);
      else
        for (var c in b)
          if (c != "prototype")
            if (Object.defineProperties) {
              var d = Object.getOwnPropertyDescriptor(b, c);
              d && Object.defineProperty(a, c, d);
            } else a[c] = b[c];
      a.Qr = b.prototype;
    },
    wa = function (a) {
      var b = 0;
      return function () {
        return b < a.length ? { done: !1, value: a[b++] } : { done: !0 };
      };
    },
    m = function (a) {
      var b =
        typeof Symbol != "undefined" && Symbol.iterator && a[Symbol.iterator];
      if (b) return b.call(a);
      if (typeof a.length == "number") return { next: wa(a) };
      throw Error(String(a) + " is not an iterable or ArrayLike");
    },
    xa = function (a) {
      for (var b, c = []; !(b = a.next()).done; ) c.push(b.value);
      return c;
    },
    ya = function (a) {
      return a instanceof Array ? a : xa(m(a));
    },
    Aa = function (a) {
      return za(a, a);
    },
    za = function (a, b) {
      a.raw = b;
      Object.freeze && (Object.freeze(a), Object.freeze(b));
      return a;
    },
    Ba =
      ea && typeof la(Object, "assign") == "function"
        ? la(Object, "assign")
        : function (a, b) {
            if (a == null) throw new TypeError("No nullish arg");
            a = Object(a);
            for (var c = 1; c < arguments.length; c++) {
              var d = arguments[c];
              if (d)
                for (var e in d)
                  Object.prototype.hasOwnProperty.call(d, e) && (a[e] = d[e]);
            }
            return a;
          };
  na(
    "Object.assign",
    function (a) {
      return a || Ba;
    },
    "es6"
  );
  var Ca = function () {
    for (var a = Number(this), b = [], c = a; c < arguments.length; c++)
      b[c - a] = arguments[c];
    return b;
  }; /*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
  var Da = this || self,
    Ea = function (a, b) {
      function c() {}
      c.prototype = b.prototype;
      a.Qr = b.prototype;
      a.prototype = new c();
      a.prototype.constructor = a;
      a.Ws = function (d, e, f) {
        for (
          var g = Array(arguments.length - 2), h = 2;
          h < arguments.length;
          h++
        )
          g[h - 2] = arguments[h];
        return b.prototype[e].apply(d, g);
      };
    };
  var Fa = function (a, b) {
    this.type = a;
    this.data = b;
  };
  var Ga = function () {
    this.map = {};
    this.C = {};
  };
  Ga.prototype.get = function (a) {
    return this.map["dust." + a];
  };
  Ga.prototype.set = function (a, b) {
    var c = "dust." + a;
    this.C.hasOwnProperty(c) || (this.map[c] = b);
  };
  Ga.prototype.has = function (a) {
    return this.map.hasOwnProperty("dust." + a);
  };
  Ga.prototype.remove = function (a) {
    var b = "dust." + a;
    this.C.hasOwnProperty(b) || delete this.map[b];
  };
  var Ha = function (a, b) {
    var c = [],
      d;
    for (d in a.map)
      if (a.map.hasOwnProperty(d)) {
        var e = d.substring(5);
        switch (b) {
          case 1:
            c.push(e);
            break;
          case 2:
            c.push(a.map[d]);
            break;
          case 3:
            c.push([e, a.map[d]]);
        }
      }
    return c;
  };
  Ga.prototype.za = function () {
    return Ha(this, 1);
  };
  Ga.prototype.sc = function () {
    return Ha(this, 2);
  };
  Ga.prototype.bc = function () {
    return Ha(this, 3);
  };
  var Ia = function () {};
  Ia.prototype.reset = function () {};
  var Ja = function (a, b) {
    this.T = a;
    this.parent = b;
    this.P = this.C = void 0;
    this.yb = !1;
    this.H = function (c, d, e) {
      return c.apply(d, e);
    };
    this.values = new Ga();
  };
  Ja.prototype.add = function (a, b) {
    Ka(this, a, b, !1);
  };
  Ja.prototype.Hh = function (a, b) {
    Ka(this, a, b, !0);
  };
  var Ka = function (a, b, c, d) {
    if (!a.yb)
      if (d) {
        var e = a.values;
        e.set(b, c);
        e.C["dust." + b] = !0;
      } else a.values.set(b, c);
  };
  k = Ja.prototype;
  k.set = function (a, b) {
    this.yb ||
      (!this.values.has(a) && this.parent && this.parent.has(a)
        ? this.parent.set(a, b)
        : this.values.set(a, b));
  };
  k.get = function (a) {
    return this.values.has(a)
      ? this.values.get(a)
      : this.parent
      ? this.parent.get(a)
      : void 0;
  };
  k.has = function (a) {
    return !!this.values.has(a) || !(!this.parent || !this.parent.has(a));
  };
  k.mb = function () {
    var a = new Ja(this.T, this);
    this.C && a.Pb(this.C);
    a.Yc(this.H);
    a.Sd(this.P);
    return a;
  };
  k.Kd = function () {
    return this.T;
  };
  k.Pb = function (a) {
    this.C = a;
  };
  k.fn = function () {
    return this.C;
  };
  k.Yc = function (a) {
    this.H = a;
  };
  k.qj = function () {
    return this.H;
  };
  k.Ua = function () {
    this.yb = !0;
  };
  k.Sd = function (a) {
    this.P = a;
  };
  k.ob = function () {
    return this.P;
  };
  var La = function () {
    this.value = {};
    this.prefix = "gtm.";
  };
  La.prototype.set = function (a, b) {
    this.value[this.prefix + String(a)] = b;
  };
  La.prototype.get = function (a) {
    return this.value[this.prefix + String(a)];
  };
  La.prototype.has = function (a) {
    return this.value.hasOwnProperty(this.prefix + String(a));
  };
  function Na() {
    try {
      if (Map) return new Map();
    } catch (a) {}
    return new La();
  }
  var Oa = function () {
    this.values = [];
  };
  Oa.prototype.add = function (a) {
    this.values.indexOf(a) === -1 && this.values.push(a);
  };
  Oa.prototype.has = function (a) {
    return this.values.indexOf(a) > -1;
  };
  var Pa = function (a, b) {
    this.la = a;
    this.parent = b;
    this.T = this.H = void 0;
    this.yb = !1;
    this.P = function (d, e, f) {
      return d.apply(e, f);
    };
    this.C = Na();
    var c;
    a: {
      try {
        if (Set) {
          c = new Set();
          break a;
        }
      } catch (d) {}
      c = new Oa();
    }
    this.V = c;
  };
  Pa.prototype.add = function (a, b) {
    Qa(this, a, b, !1);
  };
  Pa.prototype.Hh = function (a, b) {
    Qa(this, a, b, !0);
  };
  var Qa = function (a, b, c, d) {
    a.yb || a.V.has(b) || (d && a.V.add(b), a.C.set(b, c));
  };
  k = Pa.prototype;
  k.set = function (a, b) {
    this.yb ||
      (!this.C.has(a) && this.parent && this.parent.has(a)
        ? this.parent.set(a, b)
        : this.V.has(a) || this.C.set(a, b));
  };
  k.get = function (a) {
    return this.C.has(a)
      ? this.C.get(a)
      : this.parent
      ? this.parent.get(a)
      : void 0;
  };
  k.has = function (a) {
    return !!this.C.has(a) || !(!this.parent || !this.parent.has(a));
  };
  k.mb = function () {
    var a = new Pa(this.la, this);
    this.H && a.Pb(this.H);
    a.Yc(this.P);
    a.Sd(this.T);
    return a;
  };
  k.Kd = function () {
    return this.la;
  };
  k.Pb = function (a) {
    this.H = a;
  };
  k.fn = function () {
    return this.H;
  };
  k.Yc = function (a) {
    this.P = a;
  };
  k.qj = function () {
    return this.P;
  };
  k.Ua = function () {
    this.yb = !0;
  };
  k.Sd = function (a) {
    this.T = a;
  };
  k.ob = function () {
    return this.T;
  };
  var Ra = function (a, b, c) {
    var d;
    d = Error.call(this, a.message);
    this.message = d.message;
    "stack" in d && (this.stack = d.stack);
    this.qn = a;
    this.Vm = c === void 0 ? !1 : c;
    this.debugInfo = [];
    this.C = b;
  };
  ua(Ra, Error);
  var Sa = function (a) {
    return a instanceof Ra ? a : new Ra(a, void 0, !0);
  };
  var Ta = [];
  function Ua(a) {
    return Ta[a] === void 0 ? !1 : Ta[a];
  }
  var Va = Na();
  function Xa(a, b) {
    for (
      var c, d = m(b), e = d.next();
      !e.done && !((c = Ya(a, e.value)), c instanceof Fa);
      e = d.next()
    );
    return c;
  }
  function Ya(a, b) {
    try {
      if (Ua(19)) {
        var c = b[0],
          d = b.slice(1),
          e = String(c),
          f = Va.has(e) ? Va.get(e) : a.get(e);
        if (!f || typeof f.invoke !== "function")
          throw Sa(Error("Attempting to execute non-function " + b[0] + "."));
        return f.apply(a, d);
      }
      var g = m(b),
        h = g.next().value,
        l = xa(g),
        n = a.get(String(h));
      if (!n || typeof n.invoke !== "function")
        throw Sa(Error("Attempting to execute non-function " + b[0] + "."));
      return n.invoke.apply(n, [a].concat(ya(l)));
    } catch (q) {
      var p = a.fn();
      p && p(q, b.context ? { id: b[0], line: b.context.line } : null);
      throw q;
    }
  }
  var Za = function () {
    this.H = new Ia();
    this.C = Ua(19) ? new Pa(this.H) : new Ja(this.H);
  };
  k = Za.prototype;
  k.Kd = function () {
    return this.H;
  };
  k.Pb = function (a) {
    this.C.Pb(a);
  };
  k.Yc = function (a) {
    this.C.Yc(a);
  };
  k.execute = function (a) {
    return this.Qj([a].concat(ya(Ca.apply(1, arguments))));
  };
  k.Qj = function () {
    for (
      var a, b = m(Ca.apply(0, arguments)), c = b.next();
      !c.done;
      c = b.next()
    )
      a = Ya(this.C, c.value);
    return a;
  };
  k.tp = function (a) {
    var b = Ca.apply(1, arguments),
      c = this.C.mb();
    c.Sd(a);
    for (var d, e = m(b), f = e.next(); !f.done; f = e.next())
      d = Ya(c, f.value);
    return d;
  };
  k.Ua = function () {
    this.C.Ua();
  };
  var $a = function () {
    this.Ha = !1;
    this.da = new Ga();
  };
  k = $a.prototype;
  k.get = function (a) {
    return this.da.get(a);
  };
  k.set = function (a, b) {
    this.Ha || this.da.set(a, b);
  };
  k.has = function (a) {
    return this.da.has(a);
  };
  k.remove = function (a) {
    this.Ha || this.da.remove(a);
  };
  k.za = function () {
    return this.da.za();
  };
  k.sc = function () {
    return this.da.sc();
  };
  k.bc = function () {
    return this.da.bc();
  };
  k.Ua = function () {
    this.Ha = !0;
  };
  k.yb = function () {
    return this.Ha;
  };
  function ab() {
    for (var a = bb, b = {}, c = 0; c < a.length; ++c) b[a[c]] = c;
    return b;
  }
  function db() {
    var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    a += a.toLowerCase() + "0123456789-_";
    return a + ".";
  }
  var bb, fb;
  function gb(a) {
    bb = bb || db();
    fb = fb || ab();
    for (var b = [], c = 0; c < a.length; c += 3) {
      var d = c + 1 < a.length,
        e = c + 2 < a.length,
        f = a.charCodeAt(c),
        g = d ? a.charCodeAt(c + 1) : 0,
        h = e ? a.charCodeAt(c + 2) : 0,
        l = f >> 2,
        n = ((f & 3) << 4) | (g >> 4),
        p = ((g & 15) << 2) | (h >> 6),
        q = h & 63;
      e || ((q = 64), d || (p = 64));
      b.push(bb[l], bb[n], bb[p], bb[q]);
    }
    return b.join("");
  }
  function hb(a) {
    function b(l) {
      for (; d < a.length; ) {
        var n = a.charAt(d++),
          p = fb[n];
        if (p != null) return p;
        if (!/^[\s\xa0]*$/.test(n))
          throw Error("Unknown base64 encoding at char: " + n);
      }
      return l;
    }
    bb = bb || db();
    fb = fb || ab();
    for (var c = "", d = 0; ; ) {
      var e = b(-1),
        f = b(0),
        g = b(64),
        h = b(64);
      if (h === 64 && e === -1) return c;
      c += String.fromCharCode((e << 2) | (f >> 4));
      g !== 64 &&
        ((c += String.fromCharCode(((f << 4) & 240) | (g >> 2))),
        h !== 64 && (c += String.fromCharCode(((g << 6) & 192) | h)));
    }
  }
  var ib = {};
  function jb(a, b) {
    ib[a] = ib[a] || [];
    ib[a][b] = !0;
  }
  function kb() {
    delete ib.GA4_EVENT;
  }
  function lb() {
    var a = mb.slice();
    ib.GTAG_EVENT_FEATURE_CHANNEL = a;
  }
  function nb(a) {
    var b = ib[a];
    if (!b || b.length === 0) return "";
    for (var c = [], d = 0, e = 0; e < b.length; e++)
      e % 8 === 0 && e > 0 && (c.push(String.fromCharCode(d)), (d = 0)),
        b[e] && (d |= 1 << e % 8);
    d > 0 && c.push(String.fromCharCode(d));
    return gb(c.join("")).replace(/\.+$/, "");
  }
  function ob() {}
  function pb(a) {
    return typeof a === "function";
  }
  function rb(a) {
    return typeof a === "string";
  }
  function sb(a) {
    return typeof a === "number" && !isNaN(a);
  }
  function tb(a) {
    return Array.isArray(a) ? a : [a];
  }
  function ub(a, b) {
    if (a && Array.isArray(a))
      for (var c = 0; c < a.length; c++) if (a[c] && b(a[c])) return a[c];
  }
  function vb(a, b) {
    if (!sb(a) || !sb(b) || a > b) (a = 0), (b = 2147483647);
    return Math.floor(Math.random() * (b - a + 1) + a);
  }
  function wb(a, b) {
    for (var c = new xb(), d = 0; d < a.length; d++) c.set(a[d], !0);
    for (var e = 0; e < b.length; e++) if (c.get(b[e])) return !0;
    return !1;
  }
  function yb(a, b) {
    for (var c in a) Object.prototype.hasOwnProperty.call(a, c) && b(c, a[c]);
  }
  function zb(a) {
    return (
      !!a &&
      (Object.prototype.toString.call(a) === "[object Arguments]" ||
        Object.prototype.hasOwnProperty.call(a, "callee"))
    );
  }
  function Ab(a) {
    return Math.round(Number(a)) || 0;
  }
  function Bb(a) {
    return "false" === String(a).toLowerCase() ? !1 : !!a;
  }
  function Cb(a) {
    var b = [];
    if (Array.isArray(a))
      for (var c = 0; c < a.length; c++) b.push(String(a[c]));
    return b;
  }
  function Db(a) {
    return a ? a.replace(/^\s+|\s+$/g, "") : "";
  }
  function Eb() {
    return new Date(Date.now());
  }
  function Fb() {
    return Eb().getTime();
  }
  var xb = function () {
    this.prefix = "gtm.";
    this.values = {};
  };
  xb.prototype.set = function (a, b) {
    this.values[this.prefix + a] = b;
  };
  xb.prototype.get = function (a) {
    return this.values[this.prefix + a];
  };
  xb.prototype.contains = function (a) {
    return this.get(a) !== void 0;
  };
  function Gb(a, b, c) {
    return a && a.hasOwnProperty(b) ? a[b] : c;
  }
  function Hb(a) {
    var b = a;
    return function () {
      if (b) {
        var c = b;
        b = void 0;
        try {
          c();
        } catch (d) {}
      }
    };
  }
  function Ib(a, b) {
    for (var c in b) b.hasOwnProperty(c) && (a[c] = b[c]);
  }
  function Jb(a, b) {
    for (var c = [], d = 0; d < a.length; d++)
      c.push(a[d]), c.push.apply(c, b[a[d]] || []);
    return c;
  }
  function Kb(a, b) {
    return a.length >= b.length && a.substring(0, b.length) === b;
  }
  function Lb(a, b) {
    return (
      a.length >= b.length && a.substring(a.length - b.length, a.length) === b
    );
  }
  function Mb(a, b, c) {
    c = c || [];
    for (var d = a, e = 0; e < b.length - 1; e++) {
      if (!d.hasOwnProperty(b[e])) return;
      d = d[b[e]];
      if (c.indexOf(d) >= 0) return;
    }
    return d;
  }
  function Nb(a, b) {
    for (var c = {}, d = c, e = a.split("."), f = 0; f < e.length - 1; f++)
      d = d[e[f]] = {};
    d[e[e.length - 1]] = b;
    return c;
  }
  var Ob = /^\w{1,9}$/;
  function Pb(a, b) {
    a = a || {};
    b = b || ",";
    var c = [];
    yb(a, function (d, e) {
      Ob.test(d) && e && c.push(d);
    });
    return c.join(b);
  }
  function Qb(a) {
    for (var b = [], c = 0; c < a.length; c++) {
      var d = a.charCodeAt(c);
      d < 128
        ? b.push(d)
        : d < 2048
        ? b.push(192 | (d >> 6), 128 | (d & 63))
        : d < 55296 || d >= 57344
        ? b.push(224 | (d >> 12), 128 | ((d >> 6) & 63), 128 | (d & 63))
        : ((d = 65536 + (((d & 1023) << 10) | (a.charCodeAt(++c) & 1023))),
          b.push(
            240 | (d >> 18),
            128 | ((d >> 12) & 63),
            128 | ((d >> 6) & 63),
            128 | (d & 63)
          ));
    }
    return new Uint8Array(b);
  }
  function Rb(a, b) {
    function c() {
      e && ++d === b && (e(), (e = null), (c.done = !0));
    }
    var d = 0,
      e = a;
    c.done = !1;
    return c;
  }
  function Sb(a) {
    if (!a) return a;
    var b = a;
    try {
      b = decodeURIComponent(a);
    } catch (d) {}
    var c = b.split(",");
    return c.length === 2 && c[0] === c[1] ? c[0] : a;
  }
  function Tb(a, b, c) {
    function d(n) {
      var p = n.split("=")[0];
      if (a.indexOf(p) < 0) return n;
      if (c !== void 0) return p + "=" + c;
    }
    function e(n) {
      return n
        .split("&")
        .map(d)
        .filter(function (p) {
          return p !== void 0;
        })
        .join("&");
    }
    var f = b.href.split(/[?#]/)[0],
      g = b.search,
      h = b.hash;
    g[0] === "?" && (g = g.substring(1));
    h[0] === "#" && (h = h.substring(1));
    g = e(g);
    h = e(h);
    g !== "" && (g = "?" + g);
    h !== "" && (h = "#" + h);
    var l = "" + f + g + h;
    l[l.length - 1] === "/" && (l = l.substring(0, l.length - 1));
    return l;
  }
  function Ub(a) {
    for (var b = 0; b < 3; ++b)
      try {
        var c = decodeURIComponent(a).replace(/\+/g, " ");
        if (c === a) break;
        a = c;
      } catch (d) {
        return "";
      }
    return a;
  }
  function Vb() {
    var a = x,
      b;
    a: {
      var c = a.crypto || a.msCrypto;
      if (c && c.getRandomValues)
        try {
          var d = new Uint8Array(25);
          c.getRandomValues(d);
          b = btoa(String.fromCharCode.apply(String, ya(d)))
            .replace(/\+/g, "-")
            .replace(/\//g, "_")
            .replace(/=+$/, "");
          break a;
        } catch (e) {}
      b = void 0;
    }
    return b;
  } /*

 Copyright Google LLC
 SPDX-License-Identifier: Apache-2.0
*/
  var Wb = globalThis.trustedTypes,
    Xb;
  function Yb() {
    var a = null;
    if (!Wb) return a;
    try {
      var b = function (c) {
        return c;
      };
      a = Wb.createPolicy("goog#html", {
        createHTML: b,
        createScript: b,
        createScriptURL: b,
      });
    } catch (c) {}
    return a;
  }
  function Zb() {
    Xb === void 0 && (Xb = Yb());
    return Xb;
  }
  var $b = function (a) {
    this.C = a;
  };
  $b.prototype.toString = function () {
    return this.C + "";
  };
  function ac(a) {
    var b = a,
      c = Zb(),
      d = c ? c.createScriptURL(b) : b;
    return new $b(d);
  }
  function bc(a) {
    if (a instanceof $b) return a.C;
    throw Error("");
  }
  var cc = Aa([""]),
    dc = za(["\x00"], ["\\0"]),
    ec = za(["\n"], ["\\n"]),
    fc = za(["\x00"], ["\\u0000"]);
  function hc(a) {
    return a.toString().indexOf("`") === -1;
  }
  hc(function (a) {
    return a(cc);
  }) ||
    hc(function (a) {
      return a(dc);
    }) ||
    hc(function (a) {
      return a(ec);
    }) ||
    hc(function (a) {
      return a(fc);
    });
  var jc = function (a) {
    this.C = a;
  };
  jc.prototype.toString = function () {
    return this.C;
  };
  var kc = function (a) {
    this.ar = a;
  };
  function lc(a) {
    return new kc(function (b) {
      return b.substr(0, a.length + 1).toLowerCase() === a + ":";
    });
  }
  var mc = [
    lc("data"),
    lc("http"),
    lc("https"),
    lc("mailto"),
    lc("ftp"),
    new kc(function (a) {
      return /^[^:]*([/?#]|$)/.test(a);
    }),
  ];
  function nc(a) {
    var b;
    b = b === void 0 ? mc : b;
    if (a instanceof jc) return a;
    for (var c = 0; c < b.length; ++c) {
      var d = b[c];
      if (d instanceof kc && d.ar(a)) return new jc(a);
    }
  }
  var oc = /^\s*(?!javascript:)(?:[\w+.-]+:|[^:/?#]*(?:[/?#]|$))/i;
  function pc(a) {
    var b;
    if (a instanceof jc)
      if (a instanceof jc) b = a.C;
      else throw Error("");
    else b = oc.test(a) ? a : void 0;
    return b;
  }
  function qc(a, b) {
    var c = pc(b);
    c !== void 0 && (a.action = c);
  }
  function rc(a, b) {
    throw Error(b === void 0 ? "unexpected value " + a + "!" : b);
  }
  var sc = function (a) {
    this.C = a;
  };
  sc.prototype.toString = function () {
    return this.C + "";
  };
  var vc = function () {
    this.C = tc[0].toLowerCase();
  };
  vc.prototype.toString = function () {
    return this.C;
  };
  function wc(a, b) {
    var c = [new vc()];
    if (c.length === 0) throw Error("");
    var d = c.map(function (f) {
        var g;
        if (f instanceof vc) g = f.C;
        else throw Error("");
        return g;
      }),
      e = b.toLowerCase();
    if (
      d.every(function (f) {
        return e.indexOf(f) !== 0;
      })
    )
      throw Error(
        'Attribute "' + b + '" does not match any of the allowed prefixes.'
      );
    a.setAttribute(b, "true");
  }
  var xc = Array.prototype.indexOf
    ? function (a, b) {
        return Array.prototype.indexOf.call(a, b, void 0);
      }
    : function (a, b) {
        if (typeof a === "string")
          return typeof b !== "string" || b.length != 1 ? -1 : a.indexOf(b, 0);
        for (var c = 0; c < a.length; c++) if (c in a && a[c] === b) return c;
        return -1;
      };
  "ARTICLE SECTION NAV ASIDE H1 H2 H3 H4 H5 H6 HEADER FOOTER ADDRESS P HR PRE BLOCKQUOTE OL UL LH LI DL DT DD FIGURE FIGCAPTION MAIN DIV EM STRONG SMALL S CITE Q DFN ABBR RUBY RB RT RTC RP DATA TIME CODE VAR SAMP KBD SUB SUP I B U MARK BDI BDO SPAN BR WBR NOBR INS DEL PICTURE PARAM TRACK MAP TABLE CAPTION COLGROUP COL TBODY THEAD TFOOT TR TD TH SELECT DATALIST OPTGROUP OPTION OUTPUT PROGRESS METER FIELDSET LEGEND DETAILS SUMMARY MENU DIALOG SLOT CANVAS FONT CENTER ACRONYM BASEFONT BIG DIR HGROUP STRIKE TT"
    .split(" ")
    .concat(["BUTTON", "INPUT"]);
  function yc(a) {
    return a === null ? "null" : a === void 0 ? "undefined" : a;
  }
  var x = window,
    zc = window.history,
    A = document,
    Ac = navigator;
  function Bc() {
    var a;
    try {
      a = Ac.serviceWorker;
    } catch (b) {
      return;
    }
    return a;
  }
  var Cc = A.currentScript,
    Dc = Cc && Cc.src;
  function Ec(a, b) {
    var c = x,
      d = c[a];
    c[a] = d === void 0 ? b : d;
    return c[a];
  }
  function Fc(a) {
    return (Ac.userAgent || "").indexOf(a) !== -1;
  }
  function Gc() {
    return Fc("Firefox") || Fc("FxiOS");
  }
  function Hc() {
    return (Fc("GSA") || Fc("GoogleApp")) && (Fc("iPhone") || Fc("iPad"));
  }
  function Ic() {
    return Fc("Edg/") || Fc("EdgA/") || Fc("EdgiOS/");
  }
  var Jc = { async: 1, nonce: 1, onerror: 1, onload: 1, src: 1, type: 1 },
    Kc = { height: 1, onload: 1, src: 1, style: 1, width: 1 };
  function Lc(a, b, c) {
    b &&
      yb(b, function (d, e) {
        d = d.toLowerCase();
        c.hasOwnProperty(d) || a.setAttribute(d, e);
      });
  }
  function Mc(a, b, c, d, e) {
    var f = A.createElement("script");
    Lc(f, d, Jc);
    f.type = "text/javascript";
    f.async = d && d.async === !1 ? !1 : !0;
    var g;
    g = ac(yc(a));
    f.src = bc(g);
    var h,
      l = f.ownerDocument;
    l = l === void 0 ? document : l;
    var n,
      p,
      q =
        (p = (n = l).querySelector) == null
          ? void 0
          : p.call(n, "script[nonce]");
    (h = q == null ? "" : q.nonce || q.getAttribute("nonce") || "") &&
      f.setAttribute("nonce", h);
    b && (f.onload = b);
    c && (f.onerror = c);
    if (e) e.appendChild(f);
    else {
      var r = A.getElementsByTagName("script")[0] || A.body || A.head;
      r.parentNode.insertBefore(f, r);
    }
    return f;
  }
  function Nc() {
    if (Dc) {
      var a = Dc.toLowerCase();
      if (a.indexOf("https://") === 0) return 2;
      if (a.indexOf("http://") === 0) return 3;
    }
    return 1;
  }
  function Oc(a, b, c, d, e, f) {
    f = f === void 0 ? !0 : f;
    var g = e,
      h = !1;
    g || ((g = A.createElement("iframe")), (h = !0));
    Lc(g, c, Kc);
    d &&
      yb(d, function (n, p) {
        g.dataset[n] = p;
      });
    f &&
      ((g.height = "0"),
      (g.width = "0"),
      (g.style.display = "none"),
      (g.style.visibility = "hidden"));
    a !== void 0 && (g.src = a);
    if (h) {
      var l = (A.body && A.body.lastChild) || A.body || A.head;
      l.parentNode.insertBefore(g, l);
    }
    b && (g.onload = b);
    return g;
  }
  function Pc(a, b, c, d) {
    return Qc(a, b, c, d);
  }
  function Rc(a, b, c, d) {
    a.addEventListener && a.addEventListener(b, c, !!d);
  }
  function Sc(a, b, c) {
    a.removeEventListener && a.removeEventListener(b, c, !1);
  }
  function Tc(a) {
    x.setTimeout(a, 0);
  }
  function Uc(a, b) {
    return a && b && a.attributes && a.attributes[b]
      ? a.attributes[b].value
      : null;
  }
  function Vc(a) {
    var b = a.innerText || a.textContent || "";
    b &&
      b !== " " &&
      ((b = b.replace(/^[\s\xa0]+/g, "")), (b = b.replace(/[\s\xa0]+$/g, "")));
    b && (b = b.replace(/(\xa0+|\s{2,}|\n|\r\t)/g, " "));
    return b;
  }
  function Wc(a) {
    var b = A.createElement("div"),
      c = b,
      d,
      e = yc("A<div>" + a + "</div>"),
      f = Zb(),
      g = f ? f.createHTML(e) : e;
    d = new sc(g);
    if (c.nodeType === 1 && /^(script|style)$/i.test(c.tagName))
      throw Error("");
    var h;
    if (d instanceof sc) h = d.C;
    else throw Error("");
    c.innerHTML = h;
    b = b.lastChild;
    for (var l = []; b && b.firstChild; ) l.push(b.removeChild(b.firstChild));
    return l;
  }
  function Xc(a, b, c) {
    c = c || 100;
    for (var d = {}, e = 0; e < b.length; e++) d[b[e]] = !0;
    for (var f = a, g = 0; f && g <= c; g++) {
      if (d[String(f.tagName).toLowerCase()]) return f;
      f = f.parentElement;
    }
    return null;
  }
  function Yc(a, b, c) {
    var d;
    try {
      d = Ac.sendBeacon && Ac.sendBeacon(a);
    } catch (e) {
      jb("TAGGING", 15);
    }
    d ? b == null || b() : Qc(a, b, c);
  }
  function Zc(a, b) {
    try {
      return Ac.sendBeacon(a, b);
    } catch (c) {
      jb("TAGGING", 15);
    }
    return !1;
  }
  var $c = {
    cache: "no-store",
    credentials: "include",
    keepalive: !0,
    method: "POST",
    mode: "no-cors",
    redirect: "follow",
  };
  function ad(a, b, c, d, e) {
    if (bd()) {
      var f = la(Object, "assign").call(Object, {}, $c);
      b && (f.body = b);
      c &&
        (c.attributionReporting &&
          (f.attributionReporting = c.attributionReporting),
        c.browsingTopics && (f.browsingTopics = c.browsingTopics),
        c.credentials && (f.credentials = c.credentials),
        c.mode && (f.mode = c.mode),
        c.method && (f.method = c.method));
      try {
        var g = x.fetch(a, f);
        if (g)
          return (
            g
              .then(function (l) {
                l && (l.ok || l.status === 0)
                  ? d == null || d()
                  : e == null || e();
              })
              .catch(function () {
                e == null || e();
              }),
            !0
          );
      } catch (l) {}
    }
    if (c && c.Qe) return e == null || e(), !1;
    if (b) {
      var h = Zc(a, b);
      h ? d == null || d() : e == null || e();
      return h;
    }
    cd(a, d, e);
    return !0;
  }
  function bd() {
    return typeof x.fetch === "function";
  }
  function dd(a, b) {
    var c = a[b];
    c && typeof c.animVal === "string" && (c = c.animVal);
    return c;
  }
  function ed() {
    var a = x.performance;
    if (a && pb(a.now)) return a.now();
  }
  function fd() {
    var a,
      b = x.performance;
    if (b && b.getEntriesByType)
      try {
        var c = b.getEntriesByType("navigation");
        c && c.length > 0 && (a = c[0].type);
      } catch (d) {
        return "e";
      }
    if (!a) return "u";
    switch (a) {
      case "navigate":
        return "n";
      case "back_forward":
        return "h";
      case "reload":
        return "r";
      case "prerender":
        return "p";
      default:
        return "x";
    }
  }
  function gd() {
    return x.performance || void 0;
  }
  function hd() {
    var a = x.webPixelsManager;
    return a ? a.createShopifyExtend !== void 0 : !1;
  }
  var Qc = function (a, b, c, d) {
      var e = new Image(1, 1);
      Lc(e, d, {});
      e.onload = function () {
        e.onload = null;
        b && b();
      };
      e.onerror = function () {
        e.onerror = null;
        c && c();
      };
      e.src = a;
      return e;
    },
    cd = Yc;
  function id(a, b) {
    return this.evaluate(a) && this.evaluate(b);
  }
  function jd(a, b) {
    return this.evaluate(a) === this.evaluate(b);
  }
  function kd(a, b) {
    return this.evaluate(a) || this.evaluate(b);
  }
  function ld(a, b) {
    var c = this.evaluate(a),
      d = this.evaluate(b);
    return String(c).indexOf(String(d)) > -1;
  }
  function md(a, b) {
    var c = String(this.evaluate(a)),
      d = String(this.evaluate(b));
    return c.substring(0, d.length) === d;
  }
  function nd(a, b) {
    var c = this.evaluate(a),
      d = this.evaluate(b);
    switch (c) {
      case "pageLocation":
        var e = x.location.href;
        d instanceof $a &&
          d.get("stripProtocol") &&
          (e = e.replace(/^https?:\/\//, ""));
        return e;
    }
  } /*
 jQuery (c) 2005, 2012 jQuery Foundation, Inc. jquery.org/license.
*/
  var od = /\[object (Boolean|Number|String|Function|Array|Date|RegExp)\]/,
    pd = function (a) {
      if (a == null) return String(a);
      var b = od.exec(Object.prototype.toString.call(Object(a)));
      return b ? b[1].toLowerCase() : "object";
    },
    qd = function (a, b) {
      return Object.prototype.hasOwnProperty.call(Object(a), b);
    },
    rd = function (a) {
      if (!a || pd(a) != "object" || a.nodeType || a == a.window) return !1;
      try {
        if (
          a.constructor &&
          !qd(a, "constructor") &&
          !qd(a.constructor.prototype, "isPrototypeOf")
        )
          return !1;
      } catch (c) {
        return !1;
      }
      for (var b in a);
      return b === void 0 || qd(a, b);
    },
    sd = function (a, b) {
      var c = b || (pd(a) == "array" ? [] : {}),
        d;
      for (d in a)
        if (qd(a, d)) {
          var e = a[d];
          pd(e) == "array"
            ? (pd(c[d]) != "array" && (c[d] = []), (c[d] = sd(e, c[d])))
            : rd(e)
            ? (rd(c[d]) || (c[d] = {}), (c[d] = sd(e, c[d])))
            : (c[d] = e);
        }
      return c;
    };
  function td(a) {
    if (a == void 0 || Array.isArray(a) || rd(a)) return !0;
    switch (typeof a) {
      case "boolean":
      case "number":
      case "string":
      case "function":
        return !0;
    }
    return !1;
  }
  function ud(a) {
    return (
      (typeof a === "number" && a >= 0 && isFinite(a) && a % 1 === 0) ||
      (typeof a === "string" && a[0] !== "-" && a === "" + parseInt(a))
    );
  }
  var vd = function (a) {
    a = a === void 0 ? [] : a;
    this.da = new Ga();
    this.values = [];
    this.Ha = !1;
    for (var b in a)
      a.hasOwnProperty(b) &&
        (ud(b)
          ? (this.values[Number(b)] = a[Number(b)])
          : this.da.set(b, a[b]));
  };
  k = vd.prototype;
  k.toString = function (a) {
    if (a && a.indexOf(this) >= 0) return "";
    for (var b = [], c = 0; c < this.values.length; c++) {
      var d = this.values[c];
      d === null || d === void 0
        ? b.push("")
        : d instanceof vd
        ? ((a = a || []), a.push(this), b.push(d.toString(a)), a.pop())
        : b.push(String(d));
    }
    return b.join(",");
  };
  k.set = function (a, b) {
    if (!this.Ha)
      if (a === "length") {
        if (!ud(b))
          throw Sa(
            Error("RangeError: Length property must be a valid integer.")
          );
        this.values.length = Number(b);
      } else ud(a) ? (this.values[Number(a)] = b) : this.da.set(a, b);
  };
  k.get = function (a) {
    return a === "length"
      ? this.length()
      : ud(a)
      ? this.values[Number(a)]
      : this.da.get(a);
  };
  k.length = function () {
    return this.values.length;
  };
  k.za = function () {
    for (var a = this.da.za(), b = 0; b < this.values.length; b++)
      this.values.hasOwnProperty(b) && a.push(String(b));
    return a;
  };
  k.sc = function () {
    for (var a = this.da.sc(), b = 0; b < this.values.length; b++)
      this.values.hasOwnProperty(b) && a.push(this.values[b]);
    return a;
  };
  k.bc = function () {
    for (var a = this.da.bc(), b = 0; b < this.values.length; b++)
      this.values.hasOwnProperty(b) && a.push([String(b), this.values[b]]);
    return a;
  };
  k.remove = function (a) {
    ud(a) ? delete this.values[Number(a)] : this.Ha || this.da.remove(a);
  };
  k.pop = function () {
    return this.values.pop();
  };
  k.push = function () {
    return this.values.push.apply(this.values, ya(Ca.apply(0, arguments)));
  };
  k.shift = function () {
    return this.values.shift();
  };
  k.splice = function (a, b) {
    var c = Ca.apply(2, arguments);
    return b === void 0 && c.length === 0
      ? new vd(this.values.splice(a))
      : new vd(
          this.values.splice.apply(this.values, [a, b || 0].concat(ya(c)))
        );
  };
  k.unshift = function () {
    return this.values.unshift.apply(this.values, ya(Ca.apply(0, arguments)));
  };
  k.has = function (a) {
    return (ud(a) && this.values.hasOwnProperty(a)) || this.da.has(a);
  };
  k.Ua = function () {
    this.Ha = !0;
    Object.freeze(this.values);
  };
  k.yb = function () {
    return this.Ha;
  };
  function wd(a) {
    for (var b = [], c = 0; c < a.length(); c++) a.has(c) && (b[c] = a.get(c));
    return b;
  }
  var xd = function (a, b) {
    this.functionName = a;
    this.Jd = b;
    this.da = new Ga();
    this.Ha = !1;
  };
  k = xd.prototype;
  k.toString = function () {
    return this.functionName;
  };
  k.getName = function () {
    return this.functionName;
  };
  k.getKeys = function () {
    return new vd(this.za());
  };
  k.invoke = function (a) {
    return this.Jd.call.apply(
      this.Jd,
      [new yd(this, a)].concat(ya(Ca.apply(1, arguments)))
    );
  };
  k.apply = function (a, b) {
    return this.Jd.apply(new yd(this, a), b);
  };
  k.Nb = function (a) {
    var b = Ca.apply(1, arguments);
    try {
      return this.invoke.apply(this, [a].concat(ya(b)));
    } catch (c) {}
  };
  k.get = function (a) {
    return this.da.get(a);
  };
  k.set = function (a, b) {
    this.Ha || this.da.set(a, b);
  };
  k.has = function (a) {
    return this.da.has(a);
  };
  k.remove = function (a) {
    this.Ha || this.da.remove(a);
  };
  k.za = function () {
    return this.da.za();
  };
  k.sc = function () {
    return this.da.sc();
  };
  k.bc = function () {
    return this.da.bc();
  };
  k.Ua = function () {
    this.Ha = !0;
  };
  k.yb = function () {
    return this.Ha;
  };
  var zd = function (a, b) {
    xd.call(this, a, b);
  };
  ua(zd, xd);
  var Ad = function (a, b) {
    xd.call(this, a, b);
  };
  ua(Ad, xd);
  var yd = function (a, b) {
    this.Jd = a;
    this.J = b;
  };
  yd.prototype.evaluate = function (a) {
    var b = this.J;
    return Array.isArray(a) ? Ya(b, a) : a;
  };
  yd.prototype.getName = function () {
    return this.Jd.getName();
  };
  yd.prototype.Kd = function () {
    return this.J.Kd();
  };
  var Bd = function () {
    this.map = new Map();
  };
  Bd.prototype.set = function (a, b) {
    this.map.set(a, b);
  };
  Bd.prototype.get = function (a) {
    return this.map.get(a);
  };
  var Cd = function () {
    this.keys = [];
    this.values = [];
  };
  Cd.prototype.set = function (a, b) {
    this.keys.push(a);
    this.values.push(b);
  };
  Cd.prototype.get = function (a) {
    var b = this.keys.indexOf(a);
    if (b > -1) return this.values[b];
  };
  function Dd() {
    try {
      return Map ? new Bd() : new Cd();
    } catch (a) {
      return new Cd();
    }
  }
  var Ed = function (a) {
    if (a instanceof Ed) return a;
    if (td(a)) throw Error("Type of given value has an equivalent Pixie type.");
    this.value = a;
  };
  Ed.prototype.getValue = function () {
    return this.value;
  };
  Ed.prototype.toString = function () {
    return String(this.value);
  };
  var Gd = function (a) {
    this.promise = a;
    this.Ha = !1;
    this.da = new Ga();
    this.da.set("then", Fd(this));
    this.da.set("catch", Fd(this, !0));
    this.da.set("finally", Fd(this, !1, !0));
  };
  k = Gd.prototype;
  k.get = function (a) {
    return this.da.get(a);
  };
  k.set = function (a, b) {
    this.Ha || this.da.set(a, b);
  };
  k.has = function (a) {
    return this.da.has(a);
  };
  k.remove = function (a) {
    this.Ha || this.da.remove(a);
  };
  k.za = function () {
    return this.da.za();
  };
  k.sc = function () {
    return this.da.sc();
  };
  k.bc = function () {
    return this.da.bc();
  };
  var Fd = function (a, b, c) {
    b = b === void 0 ? !1 : b;
    c = c === void 0 ? !1 : c;
    return new zd("", function (d, e) {
      b && ((e = d), (d = void 0));
      c && (e = d);
      d instanceof zd || (d = void 0);
      e instanceof zd || (e = void 0);
      var f = this.J.mb(),
        g = function (l) {
          return function (n) {
            try {
              return c ? (l.invoke(f), a.promise) : l.invoke(f, n);
            } catch (p) {
              return Promise.reject(p instanceof Error ? new Ed(p) : String(p));
            }
          };
        },
        h = a.promise.then(d && g(d), e && g(e));
      return new Gd(h);
    });
  };
  Gd.prototype.Ua = function () {
    this.Ha = !0;
  };
  Gd.prototype.yb = function () {
    return this.Ha;
  };
  function B(a, b, c) {
    var d = Dd(),
      e = function (g, h) {
        for (var l = g.za(), n = 0; n < l.length; n++) h[l[n]] = f(g.get(l[n]));
      },
      f = function (g) {
        if (g === null || g === void 0) return g;
        var h = d.get(g);
        if (h) return h;
        if (g instanceof vd) {
          var l = [];
          d.set(g, l);
          for (var n = g.za(), p = 0; p < n.length; p++)
            l[n[p]] = f(g.get(n[p]));
          return l;
        }
        if (g instanceof Gd)
          return g.promise.then(
            function (t) {
              return B(t, b, 1);
            },
            function (t) {
              return Promise.reject(B(t, b, 1));
            }
          );
        if (g instanceof $a) {
          var q = {};
          d.set(g, q);
          e(g, q);
          return q;
        }
        if (g instanceof zd) {
          var r = function () {
            for (var t = [], v = 0; v < arguments.length; v++)
              t[v] = Hd(arguments[v], b, c);
            var w = new Ja(b ? b.Kd() : new Ia());
            b && w.Sd(b.ob());
            return f(
              Ua(19) ? g.apply(w, t) : g.invoke.apply(g, [w].concat(ya(t)))
            );
          };
          d.set(g, r);
          e(g, r);
          return r;
        }
        var u = !1;
        switch (c) {
          case 1:
            u = !0;
            break;
          case 2:
            u = !1;
            break;
          case 3:
            u = !1;
            break;
          default:
        }
        if (g instanceof Ed && u) return g.getValue();
        switch (typeof g) {
          case "boolean":
          case "number":
          case "string":
          case "undefined":
            return g;
          case "object":
            if (g === null) return null;
        }
      };
    return f(a);
  }
  function Hd(a, b, c) {
    var d = Dd(),
      e = function (g, h) {
        for (var l in g) g.hasOwnProperty(l) && h.set(l, f(g[l]));
      },
      f = function (g) {
        var h = d.get(g);
        if (h) return h;
        if (Array.isArray(g) || zb(g)) {
          var l = new vd();
          d.set(g, l);
          for (var n in g) g.hasOwnProperty(n) && l.set(n, f(g[n]));
          return l;
        }
        if (rd(g)) {
          var p = new $a();
          d.set(g, p);
          e(g, p);
          return p;
        }
        if (typeof g === "function") {
          var q = new zd("", function () {
            for (
              var t = Ca.apply(0, arguments), v = [], w = 0;
              w < t.length;
              w++
            )
              v[w] = B(this.evaluate(t[w]), b, c);
            return f(this.J.qj()(g, g, v));
          });
          d.set(g, q);
          e(g, q);
          return q;
        }
        var r = typeof g;
        if (g === null || r === "string" || r === "number" || r === "boolean")
          return g;
        var u = !1;
        switch (c) {
          case 1:
            u = !0;
            break;
          case 2:
            u = !1;
            break;
          default:
        }
        if (g !== void 0 && u) return new Ed(g);
      };
    return f(a);
  }
  var Id = {
    supportedMethods:
      "concat every filter forEach hasOwnProperty indexOf join lastIndexOf map pop push reduce reduceRight reverse shift slice some sort splice unshift toString".split(
        " "
      ),
    concat: function (a) {
      for (var b = [], c = 0; c < this.length(); c++) b.push(this.get(c));
      for (var d = 1; d < arguments.length; d++)
        if (arguments[d] instanceof vd)
          for (var e = arguments[d], f = 0; f < e.length(); f++)
            b.push(e.get(f));
        else b.push(arguments[d]);
      return new vd(b);
    },
    every: function (a, b) {
      for (var c = this.length(), d = 0; d < this.length() && d < c; d++)
        if (this.has(d) && !b.invoke(a, this.get(d), d, this)) return !1;
      return !0;
    },
    filter: function (a, b) {
      for (
        var c = this.length(), d = [], e = 0;
        e < this.length() && e < c;
        e++
      )
        this.has(e) && b.invoke(a, this.get(e), e, this) && d.push(this.get(e));
      return new vd(d);
    },
    forEach: function (a, b) {
      for (var c = this.length(), d = 0; d < this.length() && d < c; d++)
        this.has(d) && b.invoke(a, this.get(d), d, this);
    },
    hasOwnProperty: function (a, b) {
      return this.has(b);
    },
    indexOf: function (a, b, c) {
      var d = this.length(),
        e = c === void 0 ? 0 : Number(c);
      e < 0 && (e = Math.max(d + e, 0));
      for (var f = e; f < d; f++)
        if (this.has(f) && this.get(f) === b) return f;
      return -1;
    },
    join: function (a, b) {
      for (var c = [], d = 0; d < this.length(); d++) c.push(this.get(d));
      return c.join(b);
    },
    lastIndexOf: function (a, b, c) {
      var d = this.length(),
        e = d - 1;
      c !== void 0 && (e = c < 0 ? d + c : Math.min(c, e));
      for (var f = e; f >= 0; f--)
        if (this.has(f) && this.get(f) === b) return f;
      return -1;
    },
    map: function (a, b) {
      for (
        var c = this.length(), d = [], e = 0;
        e < this.length() && e < c;
        e++
      )
        this.has(e) && (d[e] = b.invoke(a, this.get(e), e, this));
      return new vd(d);
    },
    pop: function () {
      return this.pop();
    },
    push: function (a) {
      return this.push.apply(this, ya(Ca.apply(1, arguments)));
    },
    reduce: function (a, b, c) {
      var d = this.length(),
        e,
        f = 0;
      if (c !== void 0) e = c;
      else {
        if (d === 0)
          throw Sa(Error("TypeError: Reduce on List with no elements."));
        for (var g = 0; g < d; g++)
          if (this.has(g)) {
            e = this.get(g);
            f = g + 1;
            break;
          }
        if (g === d)
          throw Sa(Error("TypeError: Reduce on List with no elements."));
      }
      for (var h = f; h < d; h++)
        this.has(h) && (e = b.invoke(a, e, this.get(h), h, this));
      return e;
    },
    reduceRight: function (a, b, c) {
      var d = this.length(),
        e,
        f = d - 1;
      if (c !== void 0) e = c;
      else {
        if (d === 0)
          throw Sa(Error("TypeError: ReduceRight on List with no elements."));
        for (var g = 1; g <= d; g++)
          if (this.has(d - g)) {
            e = this.get(d - g);
            f = d - (g + 1);
            break;
          }
        if (g > d)
          throw Sa(Error("TypeError: ReduceRight on List with no elements."));
      }
      for (var h = f; h >= 0; h--)
        this.has(h) && (e = b.invoke(a, e, this.get(h), h, this));
      return e;
    },
    reverse: function () {
      for (var a = wd(this), b = a.length - 1, c = 0; b >= 0; b--, c++)
        a.hasOwnProperty(b) ? this.set(c, a[b]) : this.remove(c);
      return this;
    },
    shift: function () {
      return this.shift();
    },
    slice: function (a, b, c) {
      var d = this.length();
      b === void 0 && (b = 0);
      b = b < 0 ? Math.max(d + b, 0) : Math.min(b, d);
      c = c === void 0 ? d : c < 0 ? Math.max(d + c, 0) : Math.min(c, d);
      c = Math.max(b, c);
      for (var e = [], f = b; f < c; f++) e.push(this.get(f));
      return new vd(e);
    },
    some: function (a, b) {
      for (var c = this.length(), d = 0; d < this.length() && d < c; d++)
        if (this.has(d) && b.invoke(a, this.get(d), d, this)) return !0;
      return !1;
    },
    sort: function (a, b) {
      var c = wd(this);
      b === void 0
        ? c.sort()
        : c.sort(function (e, f) {
            return Number(b.invoke(a, e, f));
          });
      for (var d = 0; d < c.length; d++)
        c.hasOwnProperty(d) ? this.set(d, c[d]) : this.remove(d);
      return this;
    },
    splice: function (a, b, c) {
      return this.splice.apply(this, [b, c].concat(ya(Ca.apply(3, arguments))));
    },
    toString: function () {
      return this.toString();
    },
    unshift: function (a) {
      return this.unshift.apply(this, ya(Ca.apply(1, arguments)));
    },
  };
  var Jd = {
      charAt: 1,
      concat: 1,
      indexOf: 1,
      lastIndexOf: 1,
      match: 1,
      replace: 1,
      search: 1,
      slice: 1,
      split: 1,
      substring: 1,
      toLowerCase: 1,
      toLocaleLowerCase: 1,
      toString: 1,
      toUpperCase: 1,
      toLocaleUpperCase: 1,
      trim: 1,
    },
    Kd = new Fa("break"),
    Ld = new Fa("continue");
  function Md(a, b) {
    return this.evaluate(a) + this.evaluate(b);
  }
  function Nd(a, b) {
    return this.evaluate(a) && this.evaluate(b);
  }
  function Od(a, b, c) {
    var d = this.evaluate(a),
      e = this.evaluate(b),
      f = this.evaluate(c);
    if (!(f instanceof vd))
      throw Error("Error: Non-List argument given to Apply instruction.");
    if (d === null || d === void 0)
      throw Sa(Error("TypeError: Can't read property " + e + " of " + d + "."));
    var g = typeof d === "number";
    if (typeof d === "boolean" || g) {
      if (e === "toString") {
        if (g && f.length()) {
          var h = B(f.get(0));
          try {
            return d.toString(h);
          } catch (v) {}
        }
        return d.toString();
      }
      throw Sa(Error("TypeError: " + d + "." + e + " is not a function."));
    }
    if (typeof d === "string") {
      if (Jd.hasOwnProperty(e)) {
        var l = 2;
        l = 1;
        var n = B(f, void 0, l);
        return Hd(d[e].apply(d, n), this.J);
      }
      throw Sa(Error("TypeError: " + e + " is not a function"));
    }
    if (d instanceof vd) {
      if (d.has(e)) {
        var p = d.get(String(e));
        if (p instanceof zd) {
          var q = wd(f);
          return Ua(19)
            ? p.apply(this.J, q)
            : p.invoke.apply(p, [this.J].concat(ya(q)));
        }
        throw Sa(Error("TypeError: " + e + " is not a function"));
      }
      if (Id.supportedMethods.indexOf(e) >= 0) {
        var r = wd(f);
        return Id[e].call.apply(Id[e], [d, this.J].concat(ya(r)));
      }
    }
    if (d instanceof zd || d instanceof $a || d instanceof Gd) {
      if (d.has(e)) {
        var u = d.get(e);
        if (u instanceof zd) {
          var t = wd(f);
          return Ua(19)
            ? u.apply(this.J, t)
            : u.invoke.apply(u, [this.J].concat(ya(t)));
        }
        throw Sa(Error("TypeError: " + e + " is not a function"));
      }
      if (e === "toString") return d instanceof zd ? d.getName() : d.toString();
      if (e === "hasOwnProperty") return d.has(f.get(0));
    }
    if (d instanceof Ed && e === "toString") return d.toString();
    throw Sa(Error("TypeError: Object has no '" + e + "' property."));
  }
  function Pd(a, b) {
    a = this.evaluate(a);
    if (typeof a !== "string")
      throw Error("Invalid key name given for assignment.");
    var c = this.J;
    if (!c.has(a)) throw Error("Attempting to assign to undefined value " + b);
    var d = this.evaluate(b);
    c.set(a, d);
    return d;
  }
  function Qd() {
    var a = Ca.apply(0, arguments),
      b = this.J.mb(),
      c = Xa(b, a);
    if (c instanceof Fa) return c;
  }
  function Rd() {
    return Kd;
  }
  function Sd(a) {
    for (var b = this.evaluate(a), c = 0; c < b.length; c++) {
      var d = this.evaluate(b[c]);
      if (d instanceof Fa) return d;
    }
  }
  function Td() {
    for (var a = this.J, b = 0; b < arguments.length - 1; b += 2) {
      var c = arguments[b];
      if (typeof c === "string") {
        var d = this.evaluate(arguments[b + 1]);
        a.Hh(c, d);
      }
    }
  }
  function Ud() {
    return Ld;
  }
  function Vd(a, b) {
    return new Fa(a, this.evaluate(b));
  }
  function Wd(a, b) {
    var c = Ca.apply(2, arguments),
      d;
    d = new vd();
    for (var e = this.evaluate(b), f = 0; f < e.length; f++) d.push(e[f]);
    var g = [51, a, d].concat(ya(c));
    this.J.add(a, this.evaluate(g));
  }
  function Xd(a, b) {
    return this.evaluate(a) / this.evaluate(b);
  }
  function Yd(a, b) {
    var c = this.evaluate(a),
      d = this.evaluate(b),
      e = c instanceof Ed,
      f = d instanceof Ed;
    return e || f ? (e && f ? c.getValue() === d.getValue() : !1) : c == d;
  }
  function Zd() {
    for (var a, b = 0; b < arguments.length; b++)
      a = this.evaluate(arguments[b]);
    return a;
  }
  function $d(a, b, c, d) {
    for (var e = 0; e < b(); e++) {
      var f = a(c(e)),
        g = Xa(f, d);
      if (g instanceof Fa) {
        if (g.type === "break") break;
        if (g.type === "return") return g;
      }
    }
  }
  function ae(a, b, c) {
    if (typeof b === "string")
      return $d(
        a,
        function () {
          return b.length;
        },
        function (f) {
          return f;
        },
        c
      );
    if (
      b instanceof $a ||
      b instanceof Gd ||
      b instanceof vd ||
      b instanceof zd
    ) {
      var d = b.za(),
        e = d.length;
      return $d(
        a,
        function () {
          return e;
        },
        function (f) {
          return d[f];
        },
        c
      );
    }
  }
  function be(a, b, c) {
    var d = this.evaluate(a),
      e = this.evaluate(b),
      f = this.evaluate(c),
      g = this.J;
    return ae(
      function (h) {
        g.set(d, h);
        return g;
      },
      e,
      f
    );
  }
  function ce(a, b, c) {
    var d = this.evaluate(a),
      e = this.evaluate(b),
      f = this.evaluate(c),
      g = this.J;
    return ae(
      function (h) {
        var l = g.mb();
        l.Hh(d, h);
        return l;
      },
      e,
      f
    );
  }
  function de(a, b, c) {
    var d = this.evaluate(a),
      e = this.evaluate(b),
      f = this.evaluate(c),
      g = this.J;
    return ae(
      function (h) {
        var l = g.mb();
        l.add(d, h);
        return l;
      },
      e,
      f
    );
  }
  function ee(a, b, c) {
    var d = this.evaluate(a),
      e = this.evaluate(b),
      f = this.evaluate(c),
      g = this.J;
    return fe(
      function (h) {
        g.set(d, h);
        return g;
      },
      e,
      f
    );
  }
  function ge(a, b, c) {
    var d = this.evaluate(a),
      e = this.evaluate(b),
      f = this.evaluate(c),
      g = this.J;
    return fe(
      function (h) {
        var l = g.mb();
        l.Hh(d, h);
        return l;
      },
      e,
      f
    );
  }
  function he(a, b, c) {
    var d = this.evaluate(a),
      e = this.evaluate(b),
      f = this.evaluate(c),
      g = this.J;
    return fe(
      function (h) {
        var l = g.mb();
        l.add(d, h);
        return l;
      },
      e,
      f
    );
  }
  function fe(a, b, c) {
    if (typeof b === "string")
      return $d(
        a,
        function () {
          return b.length;
        },
        function (d) {
          return b[d];
        },
        c
      );
    if (b instanceof vd)
      return $d(
        a,
        function () {
          return b.length();
        },
        function (d) {
          return b.get(d);
        },
        c
      );
    throw Sa(Error("The value is not iterable."));
  }
  function ie(a, b, c, d) {
    function e(q, r) {
      for (var u = 0; u < f.length(); u++) {
        var t = f.get(u);
        r.add(t, q.get(t));
      }
    }
    var f = this.evaluate(a);
    if (!(f instanceof vd))
      throw Error("TypeError: Non-List argument given to ForLet instruction.");
    var g = this.J,
      h = this.evaluate(d),
      l = g.mb();
    for (e(g, l); Ya(l, b); ) {
      var n = Xa(l, h);
      if (n instanceof Fa) {
        if (n.type === "break") break;
        if (n.type === "return") return n;
      }
      var p = g.mb();
      e(l, p);
      Ya(p, c);
      l = p;
    }
  }
  function je(a, b) {
    var c = Ca.apply(2, arguments),
      d = this.J,
      e = this.evaluate(b);
    if (!(e instanceof vd))
      throw Error("Error: non-List value given for Fn argument names.");
    return new zd(
      a,
      (function () {
        return function () {
          var f = Ca.apply(0, arguments),
            g = d.mb();
          g.ob() === void 0 && g.Sd(this.J.ob());
          for (var h = [], l = 0; l < f.length; l++) {
            var n = this.evaluate(f[l]);
            h[l] = n;
          }
          for (var p = e.get("length"), q = 0; q < p; q++)
            q < h.length ? g.add(e.get(q), h[q]) : g.add(e.get(q), void 0);
          g.add("arguments", new vd(h));
          var r = Xa(g, c);
          if (r instanceof Fa) return r.type === "return" ? r.data : r;
        };
      })()
    );
  }
  function ke(a) {
    var b = this.evaluate(a),
      c = this.J;
    if (le && !c.has(b)) throw new ReferenceError(b + " is not defined.");
    return c.get(b);
  }
  function me(a, b) {
    var c,
      d = this.evaluate(a),
      e = this.evaluate(b);
    if (d === void 0 || d === null)
      throw Sa(
        Error(
          "TypeError: Cannot read properties of " + d + " (reading '" + e + "')"
        )
      );
    if (
      d instanceof $a ||
      d instanceof Gd ||
      d instanceof vd ||
      d instanceof zd
    )
      c = d.get(e);
    else if (typeof d === "string")
      e === "length" ? (c = d.length) : ud(e) && (c = d[e]);
    else if (d instanceof Ed) return;
    return c;
  }
  function ne(a, b) {
    return this.evaluate(a) > this.evaluate(b);
  }
  function oe(a, b) {
    return this.evaluate(a) >= this.evaluate(b);
  }
  function pe(a, b) {
    var c = this.evaluate(a),
      d = this.evaluate(b);
    c instanceof Ed && (c = c.getValue());
    d instanceof Ed && (d = d.getValue());
    return c === d;
  }
  function qe(a, b) {
    return !pe.call(this, a, b);
  }
  function re(a, b, c) {
    var d = [];
    this.evaluate(a) ? (d = this.evaluate(b)) : c && (d = this.evaluate(c));
    var e = Xa(this.J, d);
    if (e instanceof Fa) return e;
  }
  var le = !1;
  function se(a, b) {
    return this.evaluate(a) < this.evaluate(b);
  }
  function te(a, b) {
    return this.evaluate(a) <= this.evaluate(b);
  }
  function ue() {
    for (var a = new vd(), b = 0; b < arguments.length; b++) {
      var c = this.evaluate(arguments[b]);
      a.push(c);
    }
    return a;
  }
  function ve() {
    for (var a = new $a(), b = 0; b < arguments.length - 1; b += 2) {
      var c = String(this.evaluate(arguments[b])),
        d = this.evaluate(arguments[b + 1]);
      a.set(c, d);
    }
    return a;
  }
  function we(a, b) {
    return this.evaluate(a) % this.evaluate(b);
  }
  function xe(a, b) {
    return this.evaluate(a) * this.evaluate(b);
  }
  function ye(a) {
    return -this.evaluate(a);
  }
  function ze(a) {
    return !this.evaluate(a);
  }
  function Ae(a, b) {
    return !Yd.call(this, a, b);
  }
  function Be() {
    return null;
  }
  function Ce(a, b) {
    return this.evaluate(a) || this.evaluate(b);
  }
  function De(a, b) {
    var c = this.evaluate(a);
    this.evaluate(b);
    return c;
  }
  function Ee(a) {
    return this.evaluate(a);
  }
  function Fe() {
    return Ca.apply(0, arguments);
  }
  function Ge(a) {
    return new Fa("return", this.evaluate(a));
  }
  function He(a, b, c) {
    var d = this.evaluate(a),
      e = this.evaluate(b),
      f = this.evaluate(c);
    if (d === null || d === void 0)
      throw Sa(Error("TypeError: Can't set property " + e + " of " + d + "."));
    (d instanceof zd || d instanceof vd || d instanceof $a) &&
      d.set(String(e), f);
    return f;
  }
  function Ie(a, b) {
    return this.evaluate(a) - this.evaluate(b);
  }
  function Je(a, b, c) {
    var d = this.evaluate(a),
      e = this.evaluate(b),
      f = this.evaluate(c);
    if (!Array.isArray(e) || !Array.isArray(f))
      throw Error("Error: Malformed switch instruction.");
    for (var g, h = !1, l = 0; l < e.length; l++)
      if (h || d === this.evaluate(e[l]))
        if (((g = this.evaluate(f[l])), g instanceof Fa)) {
          var n = g.type;
          if (n === "break") return;
          if (n === "return" || n === "continue") return g;
        } else h = !0;
    if (
      f.length === e.length + 1 &&
      ((g = this.evaluate(f[f.length - 1])),
      g instanceof Fa && (g.type === "return" || g.type === "continue"))
    )
      return g;
  }
  function Ke(a, b, c) {
    return this.evaluate(a) ? this.evaluate(b) : this.evaluate(c);
  }
  function Le(a) {
    var b = this.evaluate(a);
    return b instanceof zd ? "function" : typeof b;
  }
  function Me() {
    for (var a = this.J, b = 0; b < arguments.length; b++) {
      var c = arguments[b];
      typeof c !== "string" || a.add(c, void 0);
    }
  }
  function Ne(a, b, c, d) {
    var e = this.evaluate(d);
    if (this.evaluate(c)) {
      var f = Xa(this.J, e);
      if (f instanceof Fa) {
        if (f.type === "break") return;
        if (f.type === "return") return f;
      }
    }
    for (; this.evaluate(a); ) {
      var g = Xa(this.J, e);
      if (g instanceof Fa) {
        if (g.type === "break") break;
        if (g.type === "return") return g;
      }
      this.evaluate(b);
    }
  }
  function Oe(a) {
    return ~Number(this.evaluate(a));
  }
  function Pe(a, b) {
    return Number(this.evaluate(a)) << Number(this.evaluate(b));
  }
  function Qe(a, b) {
    return Number(this.evaluate(a)) >> Number(this.evaluate(b));
  }
  function Re(a, b) {
    return Number(this.evaluate(a)) >>> Number(this.evaluate(b));
  }
  function Se(a, b) {
    return Number(this.evaluate(a)) & Number(this.evaluate(b));
  }
  function Te(a, b) {
    return Number(this.evaluate(a)) ^ Number(this.evaluate(b));
  }
  function Ue(a, b) {
    return Number(this.evaluate(a)) | Number(this.evaluate(b));
  }
  function Ve() {}
  function We(a, b, c) {
    try {
      var d = this.evaluate(b);
      if (d instanceof Fa) return d;
    } catch (h) {
      if (!(h instanceof Ra && h.Vm)) throw h;
      var e = this.J.mb();
      a !== "" && (h instanceof Ra && (h = h.qn), e.add(a, new Ed(h)));
      var f = this.evaluate(c),
        g = Xa(e, f);
      if (g instanceof Fa) return g;
    }
  }
  function Xe(a, b) {
    var c, d;
    try {
      d = this.evaluate(a);
    } catch (f) {
      if (!(f instanceof Ra && f.Vm)) throw f;
      c = f;
    }
    var e = this.evaluate(b);
    if (e instanceof Fa) return e;
    if (c) throw c;
    if (d instanceof Fa) return d;
  }
  var Ze = function () {
    this.C = new Za();
    Ye(this);
  };
  Ze.prototype.execute = function (a) {
    return this.C.Qj(a);
  };
  var Ye = function (a) {
    var b = function (c, d) {
      var e = new Ad(String(c), d);
      e.Ua();
      var f = String(c);
      a.C.C.set(f, e);
      Va.set(f, e);
    };
    b("map", ve);
    b("and", id);
    b("contains", ld);
    b("equals", jd);
    b("or", kd);
    b("startsWith", md);
    b("variable", nd);
  };
  Ze.prototype.Pb = function (a) {
    this.C.Pb(a);
  };
  var af = function () {
    this.H = !1;
    this.C = new Za();
    $e(this);
    this.H = !0;
  };
  af.prototype.execute = function (a) {
    return bf(this.C.Qj(a));
  };
  var cf = function (a, b, c) {
    return bf(a.C.tp(b, c));
  };
  af.prototype.Ua = function () {
    this.C.Ua();
  };
  var $e = function (a) {
    var b = function (c, d) {
      var e = String(c),
        f = new Ad(e, d);
      f.Ua();
      a.C.C.set(e, f);
      Va.set(e, f);
    };
    b(0, Md);
    b(1, Nd);
    b(2, Od);
    b(3, Pd);
    b(56, Se);
    b(57, Pe);
    b(58, Oe);
    b(59, Ue);
    b(60, Qe);
    b(61, Re);
    b(62, Te);
    b(53, Qd);
    b(4, Rd);
    b(5, Sd);
    b(68, We);
    b(52, Td);
    b(6, Ud);
    b(49, Vd);
    b(7, ue);
    b(8, ve);
    b(9, Sd);
    b(50, Wd);
    b(10, Xd);
    b(12, Yd);
    b(13, Zd);
    b(67, Xe);
    b(51, je);
    b(47, be);
    b(54, ce);
    b(55, de);
    b(63, ie);
    b(64, ee);
    b(65, ge);
    b(66, he);
    b(15, ke);
    b(16, me);
    b(17, me);
    b(18, ne);
    b(19, oe);
    b(20, pe);
    b(21, qe);
    b(22, re);
    b(23, se);
    b(24, te);
    b(25, we);
    b(26, xe);
    b(27, ye);
    b(28, ze);
    b(29, Ae);
    b(45, Be);
    b(30, Ce);
    b(32, De);
    b(33, De);
    b(34, Ee);
    b(35, Ee);
    b(46, Fe);
    b(36, Ge);
    b(43, He);
    b(37, Ie);
    b(38, Je);
    b(39, Ke);
    b(40, Le);
    b(44, Ve);
    b(41, Me);
    b(42, Ne);
  };
  af.prototype.Kd = function () {
    return this.C.Kd();
  };
  af.prototype.Pb = function (a) {
    this.C.Pb(a);
  };
  af.prototype.Yc = function (a) {
    this.C.Yc(a);
  };
  function bf(a) {
    if (
      a instanceof Fa ||
      a instanceof zd ||
      a instanceof vd ||
      a instanceof $a ||
      a instanceof Gd ||
      a instanceof Ed ||
      a === null ||
      a === void 0 ||
      typeof a === "string" ||
      typeof a === "number" ||
      typeof a === "boolean"
    )
      return a;
  }
  var df = function (a) {
    this.message = a;
  };
  function ef(a) {
    a.ct = !0;
    return a;
  }
  var ff = ef(function (a) {
    return typeof a === "string";
  });
  function gf(a) {
    var b = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[
      a
    ];
    return b === void 0
      ? new df(
          "Value " + a + " can not be encoded in web-safe base64 dictionary."
        )
      : b;
  }
  function hf(a) {
    switch (a) {
      case 1:
        return "1";
      case 2:
      case 4:
        return "0";
      default:
        return "-";
    }
  }
  var jf = /^[1-9a-zA-Z_-][1-9a-c][1-9a-v]\d$/;
  function kf(a, b) {
    for (var c = "", d = !0; a > 7; ) {
      var e = a & 31;
      a >>= 5;
      d ? (d = !1) : (e |= 32);
      c = "" + gf(e) + c;
    }
    a <<= 2;
    d || (a |= 32);
    return (c = "" + gf(a | b) + c);
  }
  function lf(a, b) {
    var c;
    var d = a.Wh,
      e = a.Ej;
    d === void 0
      ? (c = "")
      : (e || (e = 0), (c = "" + kf(1, 1) + gf((d << 2) | e)));
    var f = a.Xp,
      g = "4" + c + (f ? "" + kf(2, 1) + gf(f) : ""),
      h,
      l = a.Bn;
    h = l && jf.test(l) ? "" + kf(3, 2) + l : "";
    var n,
      p = a.xn;
    n = p ? "" + kf(4, 1) + gf(p) : "";
    var q;
    var r = a.ctid;
    if (r && b) {
      var u = kf(5, 3),
        t = r.split("-"),
        v = t[0].toUpperCase();
      if (v !== "GTM" && v !== "OPT") q = "";
      else {
        var w = t[1];
        q = "" + u + gf(1 + w.length) + (a.er || 0) + w;
      }
    } else q = "";
    var y = a.Or,
      z = a.canonicalId,
      D = a.Qa,
      E = a.it,
      L =
        g +
        h +
        n +
        q +
        (y ? "" + kf(6, 1) + gf(y) : "") +
        (z ? "" + kf(7, 3) + gf(z.length) + z : "") +
        (D ? "" + kf(8, 3) + gf(D.length) + D : "") +
        (E ? "" + kf(9, 3) + gf(E.length) + E : ""),
      I;
    var R = a.fq;
    R = R === void 0 ? {} : R;
    for (
      var X = [], Z = m(Object.keys(R)), Q = Z.next();
      !Q.done;
      Q = Z.next()
    ) {
      var W = Q.value;
      X[Number(W)] = R[W];
    }
    if (X.length) {
      var ma = kf(10, 3),
        ka;
      if (X.length === 0) ka = gf(0);
      else {
        for (var T = [], U = 0, ha = !1, va = 0; va < X.length; va++) {
          ha = !0;
          var pa = va % 6;
          X[va] && (U |= 1 << pa);
          pa === 5 && (T.push(gf(U)), (U = 0), (ha = !1));
        }
        ha && T.push(gf(U));
        ka = T.join("");
      }
      var Ma = ka;
      I = "" + ma + gf(Ma.length) + Ma;
    } else I = "";
    var Wa = a.mr,
      qb = a.Er,
      cb = a.Pr;
    return (
      L +
      I +
      (Wa ? "" + kf(11, 3) + gf(Wa.length) + Wa : "") +
      (qb ? "" + kf(13, 3) + gf(qb.length) + qb : "") +
      (cb ? "" + kf(14, 1) + gf(cb) : "")
    );
  }
  var mf = function (a) {
    for (var b = [], c = 0, d = 0; d < a.length; d++) {
      var e = a.charCodeAt(d);
      e < 128
        ? (b[c++] = e)
        : (e < 2048
            ? (b[c++] = (e >> 6) | 192)
            : ((e & 64512) == 55296 &&
              d + 1 < a.length &&
              (a.charCodeAt(d + 1) & 64512) == 56320
                ? ((e =
                    65536 + ((e & 1023) << 10) + (a.charCodeAt(++d) & 1023)),
                  (b[c++] = (e >> 18) | 240),
                  (b[c++] = ((e >> 12) & 63) | 128))
                : (b[c++] = (e >> 12) | 224),
              (b[c++] = ((e >> 6) & 63) | 128)),
          (b[c++] = (e & 63) | 128));
    }
    return b;
  };
  function nf(a, b) {
    for (var c = hb(b), d = new Uint8Array(c.length), e = 0; e < c.length; e++)
      d[e] = c.charCodeAt(e);
    if (d.length !== 32) throw Error("Key is not 32 bytes.");
    return of(a, d);
  }
  function of(a, b) {
    if (a === "") return "";
    var c = Qb(a),
      d = b.slice(-2),
      e = [].concat(ya(d), ya(c)).map(function (g, h) {
        return g ^ b[h % b.length];
      }),
      f = new Uint8Array([].concat(ya(e), ya(d)));
    return gb(String.fromCharCode.apply(String, ya(f))).replace(/\.+$/, "");
  }
  var pf = (function () {
    function a(b) {
      return {
        toString: function () {
          return b;
        },
      };
    }
    return {
      Un: a("consent"),
      pk: a("convert_case_to"),
      qk: a("convert_false_to"),
      rk: a("convert_null_to"),
      sk: a("convert_true_to"),
      tk: a("convert_undefined_to"),
      es: a("debug_mode_metadata"),
      Sa: a("function"),
      uh: a("instance_name"),
      xp: a("live_only"),
      yp: a("malware_disabled"),
      METADATA: a("metadata"),
      Bp: a("original_activity_id"),
      Is: a("original_vendor_template_id"),
      Hs: a("once_on_load"),
      Ap: a("once_per_event"),
      vm: a("once_per_load"),
      Ks: a("priority_override"),
      Ns: a("respected_consent_types"),
      Cm: a("setup_tags"),
      Gh: a("tag_id"),
      Mm: a("teardown_tags"),
    };
  })();
  var Mf;
  var Nf = [],
    Of = [],
    Pf = [],
    Qf = [],
    Rf = [],
    Sf,
    Tf,
    Uf;
  function Vf(a) {
    Uf = Uf || a;
  }
  function Wf() {
    for (
      var a = data.resource || {}, b = a.macros || [], c = 0;
      c < b.length;
      c++
    )
      Nf.push(b[c]);
    for (var d = a.tags || [], e = 0; e < d.length; e++) Qf.push(d[e]);
    for (var f = a.predicates || [], g = 0; g < f.length; g++) Pf.push(f[g]);
    for (var h = a.rules || [], l = 0; l < h.length; l++) {
      for (var n = h[l], p = {}, q = 0; q < n.length; q++) {
        var r = n[q][0];
        p[r] = Array.prototype.slice.call(n[q], 1);
        (r !== "if" && r !== "unless") || Xf(p[r]);
      }
      Of.push(p);
    }
  }
  function Xf(a) {}
  var Yf,
    Zf = [],
    $f = [];
  function ag(a, b) {
    var c = {};
    c[pf.Sa] = "__" + a;
    for (var d in b) b.hasOwnProperty(d) && (c["vtp_" + d] = b[d]);
    return c;
  }
  function bg(a, b, c) {
    try {
      return Tf(cg(a, b, c));
    } catch (d) {
      JSON.stringify(a);
    }
    return 2;
  }
  var cg = function (a, b, c) {
      c = c || [];
      var d = {},
        e;
      for (e in a) a.hasOwnProperty(e) && (d[e] = dg(a[e], b, c));
      return d;
    },
    dg = function (a, b, c) {
      if (Array.isArray(a)) {
        var d;
        switch (a[0]) {
          case "function_id":
            return a[1];
          case "list":
            d = [];
            for (var e = 1; e < a.length; e++) d.push(dg(a[e], b, c));
            return d;
          case "macro":
            var f = a[1];
            if (c[f]) return;
            var g = Nf[f];
            if (!g || b.isBlocked(g)) return;
            c[f] = !0;
            var h = String(g[pf.uh]);
            try {
              var l = cg(g, b, c);
              l.vtp_gtmEventId = b.id;
              b.priorityId && (l.vtp_gtmPriorityId = b.priorityId);
              d = eg(l, { event: b, index: f, type: 2, name: h });
              Yf && (d = Yf.gq(d, l));
            } catch (z) {
              b.logMacroError && b.logMacroError(z, Number(f), h), (d = !1);
            }
            c[f] = !1;
            return d;
          case "map":
            d = {};
            for (var n = 1; n < a.length; n += 2)
              d[dg(a[n], b, c)] = dg(a[n + 1], b, c);
            return d;
          case "template":
            d = [];
            for (var p = !1, q = 1; q < a.length; q++) {
              var r = dg(a[q], b, c);
              Uf && (p = p || Uf.Xq(r));
              d.push(r);
            }
            return Uf && p ? Uf.lq(d) : d.join("");
          case "escape":
            d = dg(a[1], b, c);
            if (Uf && Array.isArray(a[1]) && a[1][0] === "macro" && Uf.Yq(a))
              return Uf.wr(d);
            d = String(d);
            for (var u = 2; u < a.length; u++) wf[a[u]] && (d = wf[a[u]](d));
            return d;
          case "tag":
            var t = a[1];
            if (!Qf[t])
              throw Error("Unable to resolve tag reference " + t + ".");
            return { Zm: a[2], index: t };
          case "zb":
            var v = { arg0: a[2], arg1: a[3], ignore_case: a[5] };
            v[pf.Sa] = a[1];
            var w = bg(v, b, c),
              y = !!a[4];
            return y || w !== 2 ? y !== (w === 1) : null;
          default:
            throw Error(
              "Attempting to expand unknown Value type: " + a[0] + "."
            );
        }
      }
      return a;
    },
    eg = function (a, b) {
      var c = a[pf.Sa],
        d = b && b.event;
      if (!c) throw Error("Error: No function name given for function call.");
      var e = Sf[c],
        f =
          b &&
          b.type === 2 &&
          (d == null ? void 0 : d.reportMacroDiscrepancy) &&
          e &&
          Zf.indexOf(c) !== -1,
        g = {},
        h = {},
        l;
      for (l in a)
        a.hasOwnProperty(l) &&
          Kb(l, "vtp_") &&
          (e && (g[l] = a[l]), !e || f) &&
          (h[l.substring(4)] = a[l]);
      e &&
        d &&
        d.cachedModelValues &&
        (g.vtp_gtmCachedValues = d.cachedModelValues);
      if (b) {
        if (b.name == null) {
          var n;
          a: {
            var p = b.type,
              q = b.index;
            if (q == null) n = "";
            else {
              var r;
              switch (p) {
                case 2:
                  r = Nf[q];
                  break;
                case 1:
                  r = Qf[q];
                  break;
                default:
                  n = "";
                  break a;
              }
              var u = r && r[pf.uh];
              n = u ? String(u) : "";
            }
          }
          b.name = n;
        }
        e && ((g.vtp_gtmEntityIndex = b.index), (g.vtp_gtmEntityName = b.name));
      }
      var t, v, w;
      if (f && $f.indexOf(c) === -1) {
        $f.push(c);
        var y = Fb();
        t = e(g);
        var z = Fb() - y,
          D = Fb();
        v = Mf(c, h, b);
        w = z - (Fb() - D);
      } else if ((e && (t = e(g)), !e || f)) v = Mf(c, h, b);
      if (f && d) {
        d.reportMacroDiscrepancy(d.id, c, void 0, !0);
        if (td(t)) {
          var E = !1;
          if (Array.isArray(t)) E = !Array.isArray(v);
          else if (rd(t))
            if (rd(v)) {
              if (c === "__gas")
                a: {
                  for (
                    var L = t, I = v, R = m(Object.keys(L)), X = R.next();
                    !X.done;
                    X = R.next()
                  ) {
                    var Z = X.value;
                    if (
                      Z === "vtp_fieldsToSet" ||
                      Z === "vtp_contentGroup" ||
                      Z === "vtp_dimension" ||
                      Z === "vtp_metric"
                    ) {
                      var Q = L[Z],
                        W = I[Z.substring(4)];
                      if (fg(Z, Q, I[Z]) && fg(Z, Q, W)) continue;
                      else {
                        E = !0;
                        break a;
                      }
                    }
                    if (
                      Z !== "vtp_gtmCachedValues" &&
                      Z !== "vtp_gtmEntityIndex" &&
                      Z !== "vtp_gtmEntityName" &&
                      Z !== "function" &&
                      Z !== "instance_name"
                    ) {
                      var ma = L[Z];
                      if (I[Z] !== ma || I[Z.substring(4)] !== ma) {
                        E = !0;
                        break a;
                      }
                    }
                  }
                  E = !1;
                }
            } else E = !0;
          else E = typeof t === "function" ? typeof v !== "function" : t !== v;
          E && d.reportMacroDiscrepancy(d.id, c);
        } else t !== v && d.reportMacroDiscrepancy(d.id, c);
        w !== void 0 && d.reportMacroDiscrepancy(d.id, c, w);
      }
      return e ? t : v;
    };
  function fg(a, b, c) {
    if (b.length !== c.length) return !1;
    var d, e;
    a === "vtp_fieldsToSet"
      ? ((d = "fieldName"), (e = "value"))
      : ((d = "index"),
        (e =
          a === "vtp_contentGroup"
            ? "group"
            : a === "vtp_dimension"
            ? "dimension"
            : "metric"));
    for (var f = 0; f < b.length; f++)
      if (b[f][d] !== c[f][d] || b[f][e] !== c[f][e]) return !1;
    return !0;
  }
  function gg(a) {
    var b;
    b = b === void 0 ? !1 : b;
    var c, d;
    return (
      (c = data) == null ? 0 : (d = c.blob) == null ? 0 : d.hasOwnProperty(a)
    )
      ? !!data.blob[a]
      : b;
  }
  function hg(a) {
    var b;
    b = b === void 0 ? "" : b;
    var c, d;
    return (
      (c = data) == null ? 0 : (d = c.blob) == null ? 0 : d.hasOwnProperty(a)
    )
      ? String(data.blob[a])
      : b;
  }
  function ig(a) {
    var b, c;
    return (
      (b = data) == null ? 0 : (c = b.blob) == null ? 0 : c.hasOwnProperty(a)
    )
      ? Number(data.blob[a])
      : 0;
  }
  function jg(a) {
    var b;
    b = b === void 0 ? [] : b;
    var c,
      d,
      e = (c = data) == null ? void 0 : (d = c.blob) == null ? void 0 : d[a];
    return Array.isArray(e) ? e : b;
  }
  function kg(a) {
    var b;
    b = b === void 0 ? "" : b;
    var c = lg(46);
    return c && (c == null ? 0 : c.hasOwnProperty(a)) ? String(c[a]) : b;
  }
  function mg(a, b) {
    var c = lg(46);
    return c && (c == null ? 0 : c.hasOwnProperty(a)) ? Number(c[a]) : b;
  }
  function lg(a) {
    var b, c;
    return (b = data) == null ? void 0 : (c = b.blob) == null ? void 0 : c[a];
  }
  var ng = function (a, b, c) {
    var d;
    d = Error.call(this, c);
    this.message = d.message;
    "stack" in d && (this.stack = d.stack);
    this.permissionId = a;
    this.parameters = b;
    this.name = "PermissionError";
  };
  ua(ng, Error);
  ng.prototype.getMessage = function () {
    return this.message;
  };
  function og(a, b) {
    if (Array.isArray(a)) {
      Object.defineProperty(a, "context", { value: { line: b[0] } });
      for (var c = 1; c < a.length; c++) og(a[c], b[c]);
    }
  }
  function pg() {
    return function (a, b) {
      var c;
      var d = qg;
      a instanceof Ra ? ((a.C = d), (c = a)) : (c = new Ra(a, d));
      var e = c;
      b && e.debugInfo.push(b);
      throw e;
    };
  }
  function qg(a) {
    if (!a.length) return a;
    a.push({ id: "main", line: 0 });
    for (var b = a.length - 1; b > 0; b--) sb(a[b].id) && a.splice(b++, 1);
    for (var c = a.length - 1; c > 0; c--) a[c].line = a[c - 1].line;
    a.splice(0, 1);
    return a;
  }
  function rg(a) {
    function b(r) {
      for (var u = 0; u < r.length; u++) d[r[u]] = !0;
    }
    for (var c = [], d = [], e = sg(a), f = 0; f < Of.length; f++) {
      var g = Of[f],
        h = tg(g, e);
      if (h) {
        for (var l = g.add || [], n = 0; n < l.length; n++) c[l[n]] = !0;
        b(g.block || []);
      } else h === null && b(g.block || []);
    }
    for (var p = [], q = 0; q < Qf.length; q++) c[q] && !d[q] && (p[q] = !0);
    return p;
  }
  function tg(a, b) {
    for (var c = a["if"] || [], d = 0; d < c.length; d++) {
      var e = b(c[d]);
      if (e === 0) return !1;
      if (e === 2) return null;
    }
    for (var f = a.unless || [], g = 0; g < f.length; g++) {
      var h = b(f[g]);
      if (h === 2) return null;
      if (h === 1) return !1;
    }
    return !0;
  }
  function sg(a) {
    var b = [];
    return function (c) {
      b[c] === void 0 && (b[c] = bg(Pf[c], a));
      return b[c];
    };
  }
  function ug(a, b) {
    b[pf.pk] &&
      typeof a === "string" &&
      (a = b[pf.pk] === 1 ? a.toLowerCase() : a.toUpperCase());
    b.hasOwnProperty(pf.rk) && a === null && (a = b[pf.rk]);
    b.hasOwnProperty(pf.tk) && a === void 0 && (a = b[pf.tk]);
    b.hasOwnProperty(pf.sk) && a === !0 && (a = b[pf.sk]);
    b.hasOwnProperty(pf.qk) && a === !1 && (a = b[pf.qk]);
    return a;
  }
  var vg = function () {
      this.C = {};
    },
    xg = function (a, b) {
      var c = wg.C,
        d;
      (d = c.C)[a] != null || (d[a] = []);
      c.C[a].push(function () {
        return b.apply(null, ya(Ca.apply(0, arguments)));
      });
    };
  function yg(a, b, c, d) {
    if (a)
      for (var e = 0; e < a.length; e++) {
        var f = void 0,
          g = "A policy function denied the permission request";
        try {
          (f = a[e](b, c, d)), (g += ".");
        } catch (h) {
          g =
            typeof h === "string"
              ? g + (": " + h)
              : h instanceof Error
              ? g + (": " + h.message)
              : g + ".";
        }
        if (!f) throw new ng(c, d, g);
      }
  }
  function zg(a, b, c) {
    return function (d) {
      if (d) {
        var e = a.C[d],
          f = a.C.all;
        if (e || f) {
          var g = c.apply(void 0, [d].concat(ya(Ca.apply(1, arguments))));
          yg(e, b, d, g);
          yg(f, b, d, g);
        }
      }
    };
  }
  var Cg = function (a, b) {
      var c = this;
      this.H = {};
      this.C = new vg();
      var d = {},
        e = {},
        f = zg(this.C, a, function (g) {
          return g && d[g]
            ? d[g].apply(void 0, [g].concat(ya(Ca.apply(1, arguments))))
            : {};
        });
      yb(b, function (g, h) {
        function l(p) {
          var q = Ca.apply(1, arguments);
          if (!n[p])
            throw Ag(
              p,
              {},
              "The requested additional permission " + p + " is not configured."
            );
          f.apply(null, [p].concat(ya(q)));
        }
        var n = {};
        yb(h, function (p, q) {
          var r = Bg(p, q);
          n[p] = r.assert;
          d[p] || (d[p] = r.U);
          r.Tm && !e[p] && (e[p] = r.Tm);
        });
        c.H[g] = function (p, q) {
          var r = n[p];
          if (!r)
            throw Ag(
              p,
              {},
              "The requested permission " + p + " is not configured."
            );
          var u = Array.prototype.slice.call(arguments, 0);
          r.apply(void 0, u);
          f.apply(void 0, u);
          var t = e[p];
          t && t.apply(null, [l].concat(ya(u.slice(1))));
        };
      });
    },
    Dg = function (a) {
      return wg.H[a] || function () {};
    };
  function Bg(a, b) {
    var c = ag(a, b);
    c.vtp_permissionName = a;
    c.vtp_createPermissionError = Ag;
    try {
      return eg(c);
    } catch (d) {
      return {
        assert: function (e) {
          throw new ng(e, {}, "Permission " + e + " is unknown.");
        },
        U: function () {
          throw new ng(a, {}, "Permission " + a + " is unknown.");
        },
      };
    }
  }
  function Ag(a, b, c) {
    return new ng(a, b, c);
  }
  var Eg = hg(5),
    Fg = hg(20),
    Gg = hg(1),
    Ig = !1;
  var Jg = {};
  Jg.Jn = gg(29);
  Jg.sq = gg(28);
  var Og = [];
  function Pg(a) {
    switch (a) {
      case 1:
        return 0;
      case 235:
        return 20;
      case 38:
        return 15;
      case 287:
        return 13;
      case 288:
        return 14;
      case 285:
        return 11;
      case 286:
        return 12;
      case 219:
        return 9;
      case 220:
        return 10;
      case 53:
        return 1;
      case 54:
        return 2;
      case 52:
        return 6;
      case 203:
        return 19;
      case 75:
        return 3;
      case 103:
        return 16;
      case 197:
        return 17;
      case 109:
        return 21;
      case 116:
        return 4;
      case 135:
        return 8;
      case 136:
        return 5;
    }
  }
  function Qg(a, b) {
    Og[a] = b;
    var c = Pg(a);
    c !== void 0 && (Ta[c] = b);
  }
  function C(a) {
    Qg(a, !0);
  }
  C(39);
  C(145);
  C(153);
  C(144);
  C(120);
  C(5);
  C(111);
  C(139);
  C(87);
  C(92);

  C(159);
  C(132);
  C(20);
  C(72);
  C(113);
  C(154);
  C(116);
  Qg(23, !1), C(24);
  mg(6, 6e4);
  mg(7, 1);
  mg(35, 50);
  C(29);
  Qg(25, !1), C(26);
  C(37);
  C(9);
  C(91);
  C(123);
  C(158);
  C(71);
  C(136);
  C(127);
  C(27);
  C(69);
  C(135);
  C(95);
  C(38);
  C(103);
  C(112);
  C(101);
  C(122);
  C(121);
  C(21);
  C(134);
  C(22);
  C(141);
  C(104);
  C(59);
  C(175);
  C(177);
  C(185);
  C(197);
  C(200);
  C(280);
  C(206);
  C(218);
  C(231);
  C(232);
  C(250);
  C(251), C(250);

  C(275);
  C(278);
  function F(a) {
    return !!Og[a];
  }
  function Rg(a, b) {
    for (var c = !1, d = !1, e = 0; c === d; )
      if (
        ((c = (((Math.random() * 4294967296) | 0) & 1) === 0),
        (d = (((Math.random() * 4294967296) | 0) & 1) === 0),
        e++,
        e > 30)
      )
        return;
    c ? C(b) : C(a);
  }
  var Tg = {
    O: {
      co: 1,
      ho: 2,
      Nm: 3,
      xm: 4,
      zk: 5,
      Ak: 6,
      op: 7,
      io: 8,
      np: 9,
      bo: 10,
      ao: 11,
      Gm: 12,
      Dm: 13,
      ik: 14,
      On: 15,
      Qn: 16,
      sm: 17,
      Bk: 18,
      om: 19,
      eo: 20,
      zp: 21,
      Tn: 22,
      Pn: 23,
      Rn: 24,
      yk: 25,
      gk: 26,
      Hp: 27,
      Sl: 28,
      am: 29,
      Zl: 30,
      Yl: 31,
      Vl: 32,
      Tl: 33,
      Ul: 34,
      Rl: 35,
      Ql: 36,
    },
  };
  Tg.O[Tg.O.co] = "CREATE_EVENT_SOURCE";
  Tg.O[Tg.O.ho] = "EDIT_EVENT";
  Tg.O[Tg.O.Nm] = "TRAFFIC_TYPE";
  Tg.O[Tg.O.xm] = "REFERRAL_EXCLUSION";
  Tg.O[Tg.O.zk] = "ECOMMERCE_FROM_GTM_TAG";
  Tg.O[Tg.O.Ak] = "ECOMMERCE_FROM_GTM_UA_SCHEMA";
  Tg.O[Tg.O.op] = "GA_SEND";
  Tg.O[Tg.O.io] = "EM_FORM";
  Tg.O[Tg.O.np] = "GA_GAM_LINK";
  Tg.O[Tg.O.bo] = "CREATE_EVENT_AUTO_PAGE_PATH";
  Tg.O[Tg.O.ao] = "CREATED_EVENT";
  Tg.O[Tg.O.Gm] = "SIDELOADED";
  Tg.O[Tg.O.Dm] = "SGTM_LEGACY_CONFIGURATION";
  Tg.O[Tg.O.ik] = "CCD_EM_EVENT";
  Tg.O[Tg.O.On] = "AUTO_REDACT_EMAIL";
  Tg.O[Tg.O.Qn] = "AUTO_REDACT_QUERY_PARAM";
  Tg.O[Tg.O.sm] = "MULTIPLE_PAGEVIEW_FROM_CONFIG";
  Tg.O[Tg.O.Bk] = "EM_EVENT_SENT_BEFORE_CONFIG";
  Tg.O[Tg.O.om] = "LOADED_VIA_CST_OR_SIDELOADING";
  Tg.O[Tg.O.eo] = "DECODED_PARAM_MATCH";
  Tg.O[Tg.O.zp] = "NON_DECODED_PARAM_MATCH";
  Tg.O[Tg.O.Tn] = "CCD_EVENT_SGTM";
  Tg.O[Tg.O.Pn] = "AUTO_REDACT_EMAIL_SGTM";
  Tg.O[Tg.O.Rn] = "AUTO_REDACT_QUERY_PARAM_SGTM";
  Tg.O[Tg.O.yk] = "DAILY_LIMIT_REACHED";
  Tg.O[Tg.O.gk] = "BURST_LIMIT_REACHED";
  Tg.O[Tg.O.Hp] = "SHARED_USER_ID_SET_AFTER_REQUEST";
  Tg.O[Tg.O.Sl] = "GA4_MULTIPLE_SESSION_COOKIES";
  Tg.O[Tg.O.am] = "INVALID_GA4_SESSION_COUNT";
  Tg.O[Tg.O.Zl] = "INVALID_GA4_LAST_EVENT_TIMESTAMP";
  Tg.O[Tg.O.Yl] = "INVALID_GA4_JOIN_TIMER";
  Tg.O[Tg.O.Vl] = "GA4_STALE_SESSION_COOKIE_SELECTED";
  Tg.O[Tg.O.Tl] = "GA4_SESSION_COOKIE_GS1_READ";
  Tg.O[Tg.O.Ul] = "GA4_SESSION_COOKIE_GS2_READ";
  Tg.O[Tg.O.Rl] = "GA4_DL_PARAM_RECOVERY_AVAILABLE";
  Tg.O[Tg.O.Ql] = "GA4_DL_PARAM_RECOVERY_APPLIED";
  var Ug = {},
    Vg =
      ((Ug.uaa = !0),
      (Ug.uab = !0),
      (Ug.uafvl = !0),
      (Ug.uamb = !0),
      (Ug.uam = !0),
      (Ug.uap = !0),
      (Ug.uapv = !0),
      (Ug.uaw = !0),
      Ug);
  var ch = function (a, b) {
      for (var c = 0; c < b.length; c++) {
        var d = a,
          e = b[c];
        if (!ah.exec(e)) throw Error("Invalid key wildcard");
        var f = e.indexOf(".*"),
          g = f !== -1 && f === e.length - 2,
          h = g ? e.slice(0, e.length - 2) : e,
          l;
        a: if (d.length === 0) l = !1;
        else {
          for (var n = d.split("."), p = 0; p < n.length; p++)
            if (!bh.exec(n[p])) {
              l = !1;
              break a;
            }
          l = !0;
        }
        if (
          !l || h.length > d.length || (!g && d.length !== e.length)
            ? 0
            : g
            ? Kb(d, h) && (d === h || d.charAt(h.length) === ".")
            : d === h
        )
          return !0;
      }
      return !1;
    },
    bh = /^[a-z$_][\w-$]*$/i,
    ah = /^(?:[a-z_$][a-z-_$0-9]*\.)*[a-z_$][a-z-_$0-9]*(?:\.\*)?$/i;
  var dh = [
    "matches",
    "webkitMatchesSelector",
    "mozMatchesSelector",
    "msMatchesSelector",
    "oMatchesSelector",
  ];
  function eh(a, b) {
    var c = String(a),
      d = String(b),
      e = c.length - d.length;
    return e >= 0 && c.indexOf(d, e) === e;
  }
  function fh(a, b) {
    return String(a).split(",").indexOf(String(b)) >= 0;
  }
  var gh = new xb();
  function hh(a, b, c) {
    var d = c ? "i" : void 0;
    try {
      var e = String(b) + String(d),
        f = gh.get(e);
      f || ((f = new RegExp(b, d)), gh.set(e, f));
      return f.test(a);
    } catch (g) {
      return !1;
    }
  }
  function ih(a, b) {
    return String(a).indexOf(String(b)) >= 0;
  }
  function jh(a, b) {
    return String(a) === String(b);
  }
  function kh(a, b) {
    return Number(a) >= Number(b);
  }
  function lh(a, b) {
    return Number(a) <= Number(b);
  }
  function mh(a, b) {
    return Number(a) > Number(b);
  }
  function nh(a, b) {
    return Number(a) < Number(b);
  }
  function oh(a, b) {
    return Kb(String(a), String(b));
  }
  var vh =
      /^([a-z][a-z0-9]*):(!|\?)(\*|string|boolean|number|Fn|PixieMap|List|OpaqueValue)$/i,
    wh = { Fn: "function", PixieMap: "Object", List: "Array" };
  function xh(a, b) {
    for (var c = ["input:!*"], d = 0; d < c.length; d++) {
      var e = vh.exec(c[d]);
      if (!e) throw Error("Internal Error in " + a);
      var f = e[1],
        g = e[2] === "!",
        h = e[3],
        l = b[d];
      if (l == null) {
        if (g)
          throw Error(
            "Error in " + a + ". Required argument " + f + " not supplied."
          );
      } else if (h !== "*") {
        var n = typeof l;
        l instanceof zd
          ? (n = "Fn")
          : l instanceof vd
          ? (n = "List")
          : l instanceof $a
          ? (n = "PixieMap")
          : l instanceof Gd
          ? (n = "PixiePromise")
          : l instanceof Ed && (n = "OpaqueValue");
        if (n !== h)
          throw Error(
            "Error in " +
              a +
              ". Argument " +
              f +
              " has type " +
              ((wh[n] || n) + ", which does not match required type ") +
              ((wh[h] || h) + ".")
          );
      }
    }
  }
  function G(a, b, c) {
    for (var d = [], e = m(c), f = e.next(); !f.done; f = e.next()) {
      var g = f.value;
      g instanceof zd
        ? d.push("function")
        : g instanceof vd
        ? d.push("Array")
        : g instanceof $a
        ? d.push("Object")
        : g instanceof Gd
        ? d.push("Promise")
        : g instanceof Ed
        ? d.push("OpaqueValue")
        : d.push(typeof g);
    }
    return Error(
      "Argument error in " +
        a +
        ". Expected argument types [" +
        (b.join(",") + "], but received [") +
        (d.join(",") + "].")
    );
  }
  function yh(a) {
    return a instanceof $a;
  }
  function zh(a) {
    return yh(a) || a === null || Ah(a);
  }
  function Bh(a) {
    return a instanceof zd;
  }
  function Ch(a) {
    return Bh(a) || a === null || Ah(a);
  }
  function Dh(a) {
    return a instanceof vd;
  }
  function Eh(a) {
    return a instanceof Ed;
  }
  function Fh(a) {
    return typeof a === "string";
  }
  function Gh(a) {
    return Fh(a) || a === null || Ah(a);
  }
  function Hh(a) {
    return typeof a === "boolean";
  }
  function Ih(a) {
    return Hh(a) || Ah(a);
  }
  function Jh(a) {
    return Hh(a) || a === null || Ah(a);
  }
  function Kh(a) {
    return typeof a === "number";
  }
  function Ah(a) {
    return a === void 0;
  }
  function Lh(a) {
    return "" + a;
  }
  function Mh(a, b) {
    var c = [];
    return c;
  }
  function Nh(a, b) {
    var c = new zd(a, function () {
      for (
        var d = Array.prototype.slice.call(arguments, 0), e = 0;
        e < d.length;
        e++
      )
        d[e] = this.evaluate(d[e]);
      try {
        return b.apply(this, d);
      } catch (g) {
        throw Sa(g);
      }
    });
    c.Ua();
    return c;
  }
  function Oh(a, b) {
    var c = new $a(),
      d;
    for (d in b)
      if (b.hasOwnProperty(d)) {
        var e = b[d];
        pb(e)
          ? c.set(d, Nh(a + "_" + d, e))
          : rd(e)
          ? c.set(d, Oh(a + "_" + d, e))
          : (sb(e) || rb(e) || typeof e === "boolean") && c.set(d, e);
      }
    c.Ua();
    return c;
  }
  function Ph(a, b) {
    if (!Fh(a)) throw G(this.getName(), ["string"], arguments);
    if (!Gh(b)) throw G(this.getName(), ["string", "undefined"], arguments);
    var c = {},
      d = new $a();
    return (d = Oh("AssertApiSubject", c));
  }
  function Qh(a, b) {
    if (!Gh(b)) throw G(this.getName(), ["string", "undefined"], arguments);
    if (a instanceof Gd)
      throw Error(
        "Argument actual cannot have type Promise. Assertions on asynchronous code aren't supported."
      );
    var c = {},
      d = new $a();
    return (d = Oh("AssertThatSubject", c));
  }
  function Rh(a) {
    return function () {
      for (
        var b = Ca.apply(0, arguments), c = [], d = this.J, e = 0;
        e < b.length;
        ++e
      )
        c.push(B(b[e], d));
      return Hd(a.apply(null, c));
    };
  }
  function Sh() {
    for (var a = Math, b = Th, c = {}, d = 0; d < b.length; d++) {
      var e = b[d];
      a.hasOwnProperty(e) && (c[e] = Rh(a[e].bind(a)));
    }
    return c;
  }
  function Uh(a) {
    return a != null && Kb(a, "__cvt_");
  }
  function Vh(a) {
    var b;
    return b;
  }
  function Wh(a) {
    var b;
    if (!Fh(a)) throw G(this.getName(), ["string"], arguments);
    try {
      b = decodeURIComponent(a);
    } catch (c) {}
    return b;
  }
  function Xh(a) {
    try {
      return encodeURI(a);
    } catch (b) {}
  }
  function Yh(a) {
    try {
      return encodeURIComponent(String(a));
    } catch (b) {}
  }
  function ci(a) {
    if (!Gh(a)) throw G(this.getName(), ["string|undefined"], arguments);
  }
  function di(a) {
    var b = 1,
      c,
      d,
      e;
    if (a)
      for (b = 0, d = a.length - 1; d >= 0; d--)
        (e = a.charCodeAt(d)),
          (b = ((b << 6) & 268435455) + e + (e << 14)),
          (c = b & 266338304),
          (b = c !== 0 ? b ^ (c >> 21) : b);
    return b;
  }
  function ei(a) {
    var b = B(a);
    return di(b ? "" + b : "");
  }
  function fi(a, b) {
    if (!Kh(a) || !Kh(b))
      throw G(this.getName(), ["number", "number"], arguments);
    return vb(a, b);
  }
  function gi() {
    return new Date().getTime();
  }
  function hi(a) {
    if (a === null) return "null";
    if (a instanceof vd) return "array";
    if (a instanceof zd) return "function";
    if (a instanceof Ed) {
      var b = a.getValue();
      if (
        (b == null ? void 0 : b.constructor) === void 0 ||
        b.constructor.name === void 0
      ) {
        var c = String(b);
        return c.substring(8, c.length - 1);
      }
      return String(b.constructor.name);
    }
    return typeof a;
  }
  function ii(a) {
    function b(c) {
      return function (d) {
        try {
          return c(d);
        } catch (e) {
          (Ig || Jg.Jn) && a.call(this, e.message);
        }
      };
    }
    return {
      parse: b(function (c) {
        return Hd(JSON.parse(c));
      }),
      stringify: b(function (c) {
        return JSON.stringify(B(c));
      }),
      publicName: "JSON",
    };
  }
  function ji(a) {
    return Ab(B(a, this.J));
  }
  function ki(a) {
    return Number(B(a, this.J));
  }
  function li(a) {
    return a === null ? "null" : a === void 0 ? "undefined" : a.toString();
  }
  function mi(a, b, c) {
    var d = null,
      e = !1;
    return e ? d : null;
  }
  var Th = "floor ceil round max min abs pow sqrt".split(" ");
  function ni() {
    var a = {};
    return {
      Cq: function (b) {
        return a.hasOwnProperty(b) ? a[b] : void 0;
      },
      En: function (b, c) {
        a[b] = c;
      },
      reset: function () {
        a = {};
      },
    };
  }
  function oi(a, b) {
    return function () {
      return zd.prototype.invoke.apply(
        a,
        [b].concat(ya(Ca.apply(0, arguments)))
      );
    };
  }
  function pi(a, b) {
    if (!Fh(a)) throw G(this.getName(), ["string", "any"], arguments);
  }
  function qi(a, b) {
    if (!Fh(a) || !yh(b))
      throw G(this.getName(), ["string", "PixieMap"], arguments);
  }
  var ri = {};
  ri.keys = function (a) {
    return new vd();
  };
  ri.values = function (a) {
    return new vd();
  };
  ri.entries = function (a) {
    return new vd();
  };
  ri.freeze = function (a) {
    return a;
  };
  ri.delete = function (a, b) {
    return !1;
  };
  function H(a, b) {
    var c = Ca.apply(2, arguments),
      d = a.J.ob();
    if (!d) throw Error("Missing program state.");
    if (d.Cr) {
      try {
        d.Um.apply(null, [b].concat(ya(c)));
      } catch (e) {
        throw (jb("TAGGING", 21), e);
      }
      return;
    }
    d.Um.apply(null, [b].concat(ya(c)));
  }
  var yi = function () {
    this.H = {};
    this.C = {};
    this.P = !0;
  };
  yi.prototype.get = function (a, b) {
    var c = this.contains(a) ? this.H[a] : void 0;
    return c;
  };
  yi.prototype.contains = function (a) {
    return this.H.hasOwnProperty(a);
  };
  yi.prototype.add = function (a, b, c) {
    if (this.contains(a))
      throw Error(
        "Attempting to add a function which already exists: " + a + "."
      );
    if (this.C.hasOwnProperty(a))
      throw Error(
        "Attempting to add an API with an existing private API name: " + a + "."
      );
    this.H[a] = c ? void 0 : pb(b) ? Nh(a, b) : Oh(a, b);
  };
  function zi(a, b) {
    var c = void 0;
    return c;
  }
  function Ai() {
    var a = {};
    return a;
  }
  var J = {
    m: {
      La: "ad_personalization",
      W: "ad_storage",
      X: "ad_user_data",
      ja: "analytics_storage",
      kc: "region",
      fa: "consent_updated",
      Jg: "wait_for_update",
      jo: "app_remove",
      ko: "app_store_refund",
      lo: "app_store_subscription_cancel",
      mo: "app_store_subscription_convert",
      no: "app_store_subscription_renew",
      oo: "consent_update",
      po: "conversion",
      Dk: "add_payment_info",
      Ek: "add_shipping_info",
      ce: "add_to_cart",
      de: "remove_from_cart",
      Fk: "view_cart",
      ed: "begin_checkout",
      ee: "select_item",
      mc: "view_item_list",
      xc: "select_promotion",
      nc: "view_promotion",
      zb: "purchase",
      fe: "refund",
      oc: "view_item",
      Gk: "add_to_wishlist",
      qo: "exception",
      ro: "first_open",
      so: "first_visit",
      na: "gtag.config",
      Ab: "gtag.get",
      uo: "in_app_purchase",
      fd: "page_view",
      vo: "screen_view",
      wo: "session_start",
      xo: "source_update",
      yo: "timing_complete",
      zo: "track_social",
      he: "user_engagement",
      Ao: "user_id_update",
      af: "gclid_link_decoration_source",
      bf: "gclid_storage_source",
      qc: "gclgb",
      rb: "gclid",
      Hk: "gclid_len",
      ie: "gclgs",
      je: "gcllp",
      ke: "gclst",
      Ia: "ads_data_redaction",
      cf: "gad_source",
      df: "gad_source_src",
      gd: "gclid_url",
      Ik: "gclsrc",
      ef: "gbraid",
      me: "wbraid",
      Rb: "allow_ad_personalization_signals",
      ff: "allow_custom_scripts",
      hf: "allow_direct_google_requests",
      Pg: "allow_display_features",
      gi: "allow_enhanced_conversions",
      Sb: "allow_google_signals",
      hi: "allow_interest_groups",
      Bo: "app_id",
      Co: "app_installer_id",
      Do: "app_name",
      Eo: "app_version",
      hd: "auid",
      ns: "auto_detection_enabled",
      Jk: "aw_remarketing",
      ii: "aw_remarketing_only",
      jf: "discount",
      kf: "aw_feed_country",
      lf: "aw_feed_language",
      Ca: "items",
      nf: "aw_merchant_id",
      ji: "aw_basket_type",
      pf: "campaign_content",
      qf: "campaign_id",
      rf: "campaign_medium",
      tf: "campaign_name",
      uf: "campaign",
      vf: "campaign_source",
      wf: "campaign_term",
      Tb: "client_id",
      Kk: "rnd",
      ki: "consent_update_type",
      Fo: "content_group",
      Go: "content_type",
      Bb: "conversion_cookie_prefix",
      li: "conversion_id",
      sb: "conversion_linker",
      Qg: "conversion_linker_disabled",
      jd: "conversion_api",
      Rg: "cookie_deprecation",
      tb: "cookie_domain",
      ub: "cookie_expires",
      Cb: "cookie_flags",
      kd: "cookie_name",
      Ub: "cookie_path",
      Wa: "cookie_prefix",
      yc: "cookie_update",
      zc: "country",
      kb: "currency",
      Sg: "customer_buyer_stage",
      oe: "customer_lifetime_value",
      Tg: "customer_loyalty",
      Ug: "customer_ltv_bucket",
      pe: "custom_map",
      Vg: "gcldc",
      ld: "dclid",
      Lk: "debug_mode",
      Ga: "developer_id",
      Ho: "disable_merchant_reported_purchases",
      Ac: "dc_custom_params",
      Mk: "dc_natural_search",
      Nk: "dynamic_event_settings",
      Ok: "affiliation",
      Wg: "checkout_option",
      mi: "checkout_step",
      Pk: "coupon",
      xf: "item_list_name",
      ni: "list_name",
      Io: "promotions",
      md: "shipping",
      Qk: "tax",
      Xg: "engagement_time_msec",
      Yg: "enhanced_client_id",
      Jo: "enhanced_conversions",
      qs: "enhanced_conversions_automatic_settings",
      qe: "estimated_delivery_date",
      yf: "event_callback",
      Ko: "event_category",
      Bc: "event_developer_id_string",
      Lo: "event_label",
      Cc: "event",
      Zg: "event_settings",
      ah: "event_timeout",
      Mo: "description",
      No: "fatal",
      Oo: "experiments",
      oi: "firebase_id",
      zf: "first_party_collection",
      bh: "_x_20",
      rc: "_x_19",
      Po: "flight_error_code",
      Qo: "flight_error_message",
      Rk: "fl_activity_category",
      Sk: "fl_activity_group",
      ri: "fl_advertiser_id",
      Tk: "fl_ar_dedupe",
      Af: "match_id",
      Uk: "fl_random_number",
      Vk: "tran",
      Wk: "u",
      eh: "gac_gclid",
      te: "gac_wbraid",
      Xk: "gac_wbraid_multiple_conversions",
      Yk: "ga_restrict_domain",
      Zk: "ga_temp_client_id",
      Ro: "ga_temp_ecid",
      ue: "gdpr_applies",
      al: "geo_granularity",
      Bf: "value_callback",
      Cf: "value_key",
      Ec: "google_analysis_params",
      ve: "_google_ng",
      we: "google_signals",
      bl: "google_tld",
      fh: "gpp_sid",
      gh: "gpp_string",
      hh: "groups",
      fl: "gsa_experiment_id",
      Df: "gtag_event_feature_usage",
      il: "gtm_up",
      nd: "iframe_state",
      Ef: "ignore_referrer",
      si: "internal_traffic_results",
      jl: "_is_fpm",
      Fc: "is_legacy_converted",
      Gc: "is_legacy_loaded",
      ui: "is_passthrough",
      od: "_lps",
      lb: "language",
      ih: "legacy_developer_id_string",
      Xa: "linker",
      Ff: "accept_incoming",
      Hc: "decorate_forms",
      oa: "domains",
      pd: "url_position",
      Ic: "merchant_feed_label",
      Jc: "merchant_feed_language",
      Kc: "merchant_id",
      kl: "method",
      So: "name",
      ml: "navigation_type",
      xe: "new_customer",
      jh: "non_interaction",
      To: "optimize_id",
      nl: "page_hostname",
      Gf: "page_path",
      Ya: "page_referrer",
      Db: "page_title",
      Uo: "passengers",
      ol: "phone_conversion_callback",
      Vo: "phone_conversion_country_code",
      pl: "phone_conversion_css_class",
      Wo: "phone_conversion_ids",
      ql: "phone_conversion_number",
      rl: "phone_conversion_options",
      Xo: "_platinum_request_status",
      Yo: "_protected_audience_enabled",
      ye: "quantity",
      kh: "redact_device_info",
      wi: "referral_exclusion_definition",
      rs: "_request_start_time",
      Vb: "restricted_data_processing",
      Zo: "retoken",
      ap: "sample_rate",
      xi: "screen_name",
      Lc: "screen_resolution",
      sl: "_script_source",
      bp: "search_term",
      rd: "send_page_view",
      sd: "send_to",
      ud: "server_container_url",
      cp: "session_attributes_encoded",
      Hf: "session_duration",
      mh: "session_engaged",
      yi: "session_engaged_time",
      Wb: "session_id",
      nh: "session_number",
      If: "_shared_user_id",
      vd: "delivery_postal_code",
      us: "_tag_firing_delay",
      vs: "_tag_firing_time",
      ws: "temporary_client_id",
      zi: "_timezone",
      Ai: "topmost_url",
      oh: "tracking_id",
      Bi: "traffic_type",
      Ma: "transaction_id",
      Mc: "transport_url",
      ep: "trip_type",
      wd: "update",
      Eb: "url_passthrough",
      tl: "uptgs",
      Jf: "_user_agent_architecture",
      Kf: "_user_agent_bitness",
      Lf: "_user_agent_full_version_list",
      Mf: "_user_agent_mobile",
      Nf: "_user_agent_model",
      Of: "_user_agent_platform",
      Pf: "_user_agent_platform_version",
      Qf: "_user_agent_wow64",
      Fb: "user_data",
      vl: "user_data_auto_latency",
      wl: "user_data_auto_meta",
      xl: "user_data_auto_multi",
      yl: "user_data_auto_selectors",
      zl: "user_data_auto_status",
      Gb: "user_data_mode",
      Al: "user_data_settings",
      Na: "user_id",
      xd: "user_properties",
      Bl: "_user_region",
      Rf: "us_privacy_string",
      Ja: "value",
      Cl: "wbraid_multiple_conversions",
      Nc: "_fpm_parameters",
      Hi: "_host_name",
      bm: "_in_page_command",
      Ji: "_ip_override",
      im: "_is_passthrough_cid",
      Bh: "_measurement_type",
      Gd: "non_personalized_ads",
      Vi: "_sst_parameters",
      Gp: "sgtm_geo_user_country",
      ne: "conversion_label",
      ya: "page_location",
      se: "_extracted_data",
      Dc: "global_developer_id_string",
      ze: "tc_privacy_string",
    },
  };
  var Bi = {},
    Ci =
      ((Bi[J.m.fa] = "gcu"),
      (Bi[J.m.qc] = "gclgb"),
      (Bi[J.m.rb] = "gclaw"),
      (Bi[J.m.Hk] = "gclid_len"),
      (Bi[J.m.ie] = "gclgs"),
      (Bi[J.m.je] = "gcllp"),
      (Bi[J.m.ke] = "gclst"),
      (Bi[J.m.hd] = "auid"),
      (Bi[J.m.jf] = "dscnt"),
      (Bi[J.m.kf] = "fcntr"),
      (Bi[J.m.lf] = "flng"),
      (Bi[J.m.nf] = "mid"),
      (Bi[J.m.ji] = "bttype"),
      (Bi[J.m.Tb] = "gacid"),
      (Bi[J.m.ne] = "label"),
      (Bi[J.m.jd] = "capi"),
      (Bi[J.m.Rg] = "pscdl"),
      (Bi[J.m.kb] = "currency_code"),
      (Bi[J.m.Sg] = "clobs"),
      (Bi[J.m.oe] = "vdltv"),
      (Bi[J.m.Tg] = "clolo"),
      (Bi[J.m.Ug] = "clolb"),
      (Bi[J.m.Lk] = "_dbg"),
      (Bi[J.m.qe] = "oedeld"),
      (Bi[J.m.Bc] = "edid"),
      (Bi[J.m.eh] = "gac"),
      (Bi[J.m.te] = "gacgb"),
      (Bi[J.m.Xk] = "gacmcov"),
      (Bi[J.m.ue] = "gdpr"),
      (Bi[J.m.Dc] = "gdid"),
      (Bi[J.m.ve] = "_ng"),
      (Bi[J.m.fh] = "gpp_sid"),
      (Bi[J.m.gh] = "gpp"),
      (Bi[J.m.fl] = "gsaexp"),
      (Bi[J.m.Df] = "_tu"),
      (Bi[J.m.nd] = "frm"),
      (Bi[J.m.ui] = "gtm_up"),
      (Bi[J.m.od] = "lps"),
      (Bi[J.m.ih] = "did"),
      (Bi[J.m.Ic] = "fcntr"),
      (Bi[J.m.Jc] = "flng"),
      (Bi[J.m.Kc] = "mid"),
      (Bi[J.m.xe] = void 0),
      (Bi[J.m.Db] = "tiba"),
      (Bi[J.m.Vb] = "rdp"),
      (Bi[J.m.Wb] = "ecsid"),
      (Bi[J.m.If] = "ga_uid"),
      (Bi[J.m.vd] = "delopc"),
      (Bi[J.m.ze] = "gdpr_consent"),
      (Bi[J.m.Ma] = "oid"),
      (Bi[J.m.tl] = "uptgs"),
      (Bi[J.m.Jf] = "uaa"),
      (Bi[J.m.Kf] = "uab"),
      (Bi[J.m.Lf] = "uafvl"),
      (Bi[J.m.Mf] = "uamb"),
      (Bi[J.m.Nf] = "uam"),
      (Bi[J.m.Of] = "uap"),
      (Bi[J.m.Pf] = "uapv"),
      (Bi[J.m.Qf] = "uaw"),
      (Bi[J.m.vl] = "ec_lat"),
      (Bi[J.m.wl] = "ec_meta"),
      (Bi[J.m.xl] = "ec_m"),
      (Bi[J.m.yl] = "ec_sel"),
      (Bi[J.m.zl] = "ec_s"),
      (Bi[J.m.Gb] = "ec_mode"),
      (Bi[J.m.Na] = "userId"),
      (Bi[J.m.Rf] = "us_privacy"),
      (Bi[J.m.Ja] = "value"),
      (Bi[J.m.Cl] = "mcov"),
      (Bi[J.m.Hi] = "hn"),
      (Bi[J.m.bm] = "gtm_ee"),
      (Bi[J.m.Ji] = "uip"),
      (Bi[J.m.Bh] = "mt"),
      (Bi[J.m.Gd] = "npa"),
      (Bi[J.m.Gp] = "sg_uc"),
      (Bi[J.m.li] = null),
      (Bi[J.m.Lc] = null),
      (Bi[J.m.lb] = null),
      (Bi[J.m.Ca] = null),
      (Bi[J.m.ya] = null),
      (Bi[J.m.Ya] = null),
      (Bi[J.m.Ai] = null),
      (Bi[J.m.Nc] = null),
      (Bi[J.m.af] = null),
      (Bi[J.m.bf] = null),
      (Bi[J.m.Ec] = null),
      (Bi[J.m.se] = null),
      Bi);
  function Di(a, b) {
    if (a) {
      var c = a.split("x");
      c.length === 2 && (Ei(b, "u_w", c[0]), Ei(b, "u_h", c[1]));
    }
  }
  function Fi(a) {
    var b = Gi;
    b = b === void 0 ? Hi : b;
    var c;
    var d = b;
    if (a && a.length) {
      for (var e = [], f = 0; f < a.length; ++f) {
        var g = a[f];
        g &&
          e.push({
            item_id: d(g),
            quantity: g.quantity,
            value: g.price,
            start_date: g.start_date,
            end_date: g.end_date,
          });
      }
      c = e;
    } else c = [];
    var h;
    var l = c;
    if (l) {
      for (var n = [], p = 0; p < l.length; p++) {
        var q = l[p],
          r = [];
        q &&
          (r.push(Ii(q.value)),
          r.push(Ii(q.quantity)),
          r.push(Ii(q.item_id)),
          r.push(Ii(q.start_date)),
          r.push(Ii(q.end_date)),
          n.push("(" + r.join("*") + ")"));
      }
      h = n.length > 0 ? n.join("") : "";
    } else h = "";
    return h;
  }
  function Hi(a) {
    return Ji(a.item_id, a.id, a.item_name);
  }
  function Ji() {
    for (
      var a = m(Ca.apply(0, arguments)), b = a.next();
      !b.done;
      b = a.next()
    ) {
      var c = b.value;
      if (c !== null && c !== void 0) return c;
    }
  }
  function Ki(a) {
    if (a && a.length) {
      for (var b = [], c = 0; c < a.length; ++c) {
        var d = a[c];
        d && d.estimated_delivery_date
          ? b.push("" + d.estimated_delivery_date)
          : b.push("");
      }
      return b.join(",");
    }
  }
  function Ei(a, b, c) {
    c === void 0 || c === null || (c === "" && !Vg[b]) || (a[b] = c);
  }
  function Ii(a) {
    return typeof a !== "number" && typeof a !== "string" ? "" : a.toString();
  }
  var Li = {},
    Mi = function () {
      for (var a = !1, b = !1, c = 0; a === b; )
        if (((a = vb(0, 1) === 0), (b = vb(0, 1) === 0), c++, c > 30)) return;
      return a;
    },
    Oi = { Hr: Ni };
  function Ni(a, b) {
    var c = Li[b];
    if (!(vb(0, 9999) < c.probability * (c.controlId2 ? 4 : 2) * 1e4)) return a;
    a: {
      var d = c.studyId,
        e = c.experimentId,
        f = c.controlId,
        g = c.controlId2;
      if (!((a.exp || {})[e] || (a.exp || {})[f] || (g && (a.exp || {})[g]))) {
        var h = Mi();
        if (h !== void 0) {
          var l = h ? 0 : 1;
          if (g) {
            var n = Mi();
            if (n === void 0) break a;
            l |= (n ? 0 : 1) << 1;
          }
          l === 0
            ? Pi(a, e, d)
            : l === 1
            ? Pi(a, f, d)
            : l === 2 && Pi(a, g, d);
        }
      }
    }
    return a;
  }
  function Qi(a, b) {
    return Li[b]
      ? !!Li[b].active ||
          Li[b].probability > 0.5 ||
          !!(a.exp || {})[Li[b].experimentId]
      : !1;
  }
  function Ri(a, b) {
    for (
      var c = a.exp || {}, d = m(Object.keys(c).map(Number)), e = d.next();
      !e.done;
      e = d.next()
    ) {
      var f = e.value;
      if (c[f] === b) return f;
    }
  }
  function Pi(a, b, c) {
    var d = a.exp || {};
    d[b] = c;
    a.exp = d;
  }
  var Si = {
    M: {
      hk: "call_conversion",
      Yd: "ccm_conversion",
      Ba: "conversion",
      fp: "floodlight",
      Tf: "ga_conversion",
      zd: "gcp_remarketing",
      lm: "landing_page",
      Da: "page_view",
      Fe: "fpm_test_hit",
      Ib: "remarketing",
      Xb: "user_data_lead",
      xb: "user_data_web",
    },
  };
  var Ti = function () {
      this.C = new Set();
      this.H = new Set();
    },
    Vi = function (a) {
      var b = Ui.C;
      a = a === void 0 ? [] : a;
      var c = []
        .concat(ya(b.C))
        .concat([].concat(ya(b.H)))
        .concat(a);
      c.sort(function (d, e) {
        return d - e;
      });
      return c;
    },
    Wi = function () {
      var a = [].concat(ya(Ui.C.C));
      a.sort(function (b, c) {
        return b - c;
      });
      return a;
    },
    Xi = function () {
      var a = Ui.C,
        b = hg(44);
      a.C = new Set();
      if (b !== "")
        for (var c = m(b.split("~")), d = c.next(); !d.done; d = c.next()) {
          var e = Number(d.value);
          isNaN(e) || a.C.add(e);
        }
    };
  var Yi = {},
    Zi = {
      __cl: 1,
      __ecl: 1,
      __ehl: 1,
      __evl: 1,
      __fal: 1,
      __fil: 1,
      __fsl: 1,
      __hl: 1,
      __jel: 1,
      __lcl: 1,
      __sdl: 1,
      __tl: 1,
      __ytl: 1,
    },
    $i = { __paused: 1, __tg: 1 },
    aj;
  for (aj in Zi) Zi.hasOwnProperty(aj) && ($i[aj] = 1);
  var bj = !1,
    cj = gg(45),
    dj,
    ej = !1;
  dj = ej;
  var fj = null,
    gj = null,
    hj = {},
    ij = {},
    jj = "";
  Yi.Wi = jj;
  var Ui = new (function () {
    this.C = new Ti();
    this.H = !1;
  })();
  function kj() {
    var a = hg(18),
      b = a.length;
    return a[b - 1] === "/" ? a.substring(0, b - 1) : a;
  }
  function lj() {
    if (!gg(47)) return !1;
    var a = ig(54);
    return F(84) ? a === 0 : a !== 1;
  }
  function mj(a) {
    for (var b = {}, c = m(a.split("|")), d = c.next(); !d.done; d = c.next())
      b[d.value] = !0;
    return b;
  }
  var nj = /:[0-9]+$/,
    oj = /^\d+\.fls\.doubleclick\.net$/;
  function pj(a, b, c, d) {
    var e = qj(a, !!d, b),
      f,
      g;
    return c
      ? (g = e[b]) != null
        ? g
        : []
      : (f = e[b]) == null
      ? void 0
      : f[0];
  }
  function qj(a, b, c) {
    for (var d = {}, e = m(a.split("&")), f = e.next(); !f.done; f = e.next()) {
      var g = m(f.value.split("=")),
        h = g.next().value,
        l = xa(g),
        n = decodeURIComponent(h.replace(/\+/g, " "));
      if (c === void 0 || n === c) {
        var p = l.join("=");
        d[n] || (d[n] = []);
        d[n].push(b ? p : decodeURIComponent(p.replace(/\+/g, " ")));
      }
    }
    return d;
  }
  function rj(a) {
    try {
      return decodeURIComponent(a);
    } catch (b) {}
  }
  function sj(a, b, c, d, e) {
    b && (b = String(b).toLowerCase());
    if (b === "protocol" || b === "port")
      a.protocol = tj(a.protocol) || tj(x.location.protocol);
    b === "port"
      ? (a.port = String(
          Number(a.hostname ? a.port : x.location.port) ||
            (a.protocol === "http" ? 80 : a.protocol === "https" ? 443 : "")
        ))
      : b === "host" &&
        (a.hostname = (a.hostname || x.location.hostname)
          .replace(nj, "")
          .toLowerCase());
    return uj(a, b, c, d, e);
  }
  function uj(a, b, c, d, e) {
    var f,
      g = tj(a.protocol);
    b && (b = String(b).toLowerCase());
    switch (b) {
      case "url_no_fragment":
        f = vj(a);
        break;
      case "protocol":
        f = g;
        break;
      case "host":
        f = a.hostname.replace(nj, "").toLowerCase();
        if (c) {
          var h = /^www\d*\./.exec(f);
          h && h[0] && (f = f.substring(h[0].length));
        }
        break;
      case "port":
        f = String(
          Number(a.port) || (g === "http" ? 80 : g === "https" ? 443 : "")
        );
        break;
      case "path":
        a.pathname || a.hostname || jb("TAGGING", 1);
        f = a.pathname.substring(0, 1) === "/" ? a.pathname : "/" + a.pathname;
        var l = f.split("/");
        (d || []).indexOf(l[l.length - 1]) >= 0 && (l[l.length - 1] = "");
        f = l.join("/");
        break;
      case "query":
        f = a.search.replace("?", "");
        e && (f = pj(f, e, !1));
        break;
      case "extension":
        var n = a.pathname.split(".");
        f = n.length > 1 ? n[n.length - 1] : "";
        f = f.split("/")[0];
        break;
      case "fragment":
        f = a.hash.replace("#", "");
        break;
      default:
        f = a && a.href;
    }
    return f;
  }
  function tj(a) {
    return a ? a.replace(":", "").toLowerCase() : "";
  }
  function vj(a) {
    var b = "";
    if (a && a.href) {
      var c = a.href.indexOf("#");
      b = c < 0 ? a.href : a.href.substring(0, c);
    }
    return b;
  }
  var wj = {},
    xj = 0;
  function yj(a) {
    var b = wj[a];
    if (!b) {
      var c = A.createElement("a");
      a && (c.href = a);
      var d = c.pathname;
      d[0] !== "/" && (a || jb("TAGGING", 1), (d = "/" + d));
      var e = c.hostname.replace(nj, "");
      b = {
        href: c.href,
        protocol: c.protocol,
        host: c.host,
        hostname: e,
        pathname: d,
        search: c.search,
        hash: c.hash,
        port: c.port,
      };
      xj < 5 && ((wj[a] = b), xj++);
    }
    return b;
  }
  function zj(a, b, c) {
    var d = yj(a);
    return Tb(b, d, c);
  }
  function Aj(a) {
    var b = yj(x.location.href),
      c = sj(b, "host", !1);
    if (c && c.match(oj)) {
      var d = sj(b, "path");
      if (d) {
        var e = d.split(a + "=");
        if (e.length > 1) return e[1].split(";")[0].split("?")[0];
      }
    }
  }
  var Bj = /gtag[.\/]js/,
    Cj = /gtm[.\/]js/,
    Dj = !1;
  function Ej(a) {
    if ((a.scriptContainerId || "").indexOf("GTM-") >= 0) {
      var b;
      a: {
        var c,
          d = (c = a.scriptElement) == null ? void 0 : c.src;
        if (d) {
          for (
            var e = gg(47),
              f = yj(d),
              g = e ? f.pathname : "" + f.hostname + f.pathname,
              h = A.scripts,
              l = "",
              n = 0;
            n < h.length;
            ++n
          ) {
            var p = h[n];
            if (
              !(
                p.innerHTML.length === 0 ||
                (!e &&
                  p.innerHTML.indexOf(
                    a.scriptContainerId || "SHOULD_NOT_BE_SET"
                  ) < 0) ||
                p.innerHTML.indexOf(g) < 0
              )
            ) {
              if (p.innerHTML.indexOf("(function(w,d,s,l,i)") >= 0) {
                b = String(n);
                break a;
              }
              l = String(n);
            }
          }
          if (l) {
            b = l;
            break a;
          }
        }
        b = void 0;
      }
      var q = b;
      if (q) return (Dj = !0), q;
    }
    var r = [].slice.call(A.scripts);
    return a.scriptElement ? String(r.indexOf(a.scriptElement)) : "-1";
  }
  function Fj(a) {
    if (Dj) return "1";
    var b,
      c = (b = a.scriptElement) == null ? void 0 : b.src;
    if (c) {
      if (Bj.test(c)) return "3";
      if (Cj.test(c)) return "2";
    }
    return "0";
  }
  function K(a) {
    jb("GTM", a);
  }
  function Gj(a) {
    var b = Hj().destinationArray[a],
      c = Hj().destination[a];
    return b && b.length > 0 ? b[0] : c;
  }
  function Ij(a, b) {
    var c = Hj();
    c.pending || (c.pending = []);
    ub(c.pending, function (d) {
      return (
        d.target.ctid === a.ctid && d.target.isDestination === a.isDestination
      );
    }) || c.pending.push({ target: a, onLoad: b });
  }
  function Jj() {
    var a = x.google_tags_first_party;
    Array.isArray(a) || (a = []);
    for (var b = {}, c = m(a), d = c.next(); !d.done; d = c.next())
      b[d.value] = !0;
    return Object.freeze(b);
  }
  var Kj = function () {
    this.container = {};
    this.destination = {};
    this.destinationArray = {};
    this.canonical = {};
    this.pending = [];
    this.injectedFirstPartyContainers = {};
    this.injectedFirstPartyContainers = Jj();
  };
  function Hj() {
    var a = Ec("google_tag_data", {}),
      b = a.tidr;
    (b && typeof b === "object") || ((b = new Kj()), (a.tidr = b));
    var c = b;
    c.container || (c.container = {});
    c.destination || (c.destination = {});
    c.destinationArray || (c.destinationArray = {});
    c.canonical || (c.canonical = {});
    c.pending || (c.pending = []);
    c.injectedFirstPartyContainers || (c.injectedFirstPartyContainers = Jj());
    return c;
  }
  function Lj() {
    return (
      gg(7) &&
      Mj().some(function (a) {
        return a === hg(5);
      })
    );
  }
  function Nj() {
    var a;
    return (a = jg(55)) != null ? a : [];
  }
  function Oj() {
    return hg(6) || "_" + hg(5);
  }
  function Pj() {
    var a = hg(10);
    return a ? a.split("|") : [hg(5)];
  }
  function Mj() {
    var a = jg(59);
    return Array.isArray(a)
      ? a
          .filter(function (b) {
            return typeof b === "string";
          })
          .filter(function (b) {
            return b.indexOf("GTM-") !== 0;
          })
      : [];
  }
  function Qj() {
    var a = Rj(Sj()),
      b = a && a.parent;
    if (b) return Rj(b);
  }
  function Tj() {
    var a = Rj(Sj());
    if (a) {
      for (; a.parent; ) {
        var b = Rj(a.parent);
        if (!b) break;
        a = b;
      }
      return a;
    }
  }
  function Rj(a) {
    var b = Hj();
    return a.isDestination ? Gj(a.ctid) : b.container[a.ctid];
  }
  function Uj() {
    var a = Hj();
    if (a.pending) {
      for (
        var b, c = [], d = !1, e = Pj(), f = Mj(), g = {}, h = 0;
        h < a.pending.length;
        g = { Bg: void 0 }, h++
      )
        (g.Bg = a.pending[h]),
          ub(
            g.Bg.target.isDestination ? f : e,
            (function (l) {
              return function (n) {
                return n === l.Bg.target.ctid;
              };
            })(g)
          )
            ? d || ((b = g.Bg.onLoad), (d = !0))
            : c.push(g.Bg);
      a.pending = c;
      if (b)
        try {
          b(Oj());
        } catch (l) {}
    }
  }
  function Vj() {
    for (
      var a = hg(5),
        b = Pj(),
        c = Mj(),
        d = Nj(),
        e = function (q, r) {
          var u = {
            canonicalContainerId: hg(6),
            scriptContainerId: a,
            state: 2,
            containers: b.slice(),
            destinations: c.slice(),
          };
          Cc && (u.scriptElement = Cc);
          Dc && (u.scriptSource = Dc);
          Qj() === void 0 &&
            ((u.htmlLoadOrder = Ej(u)), (u.loadScriptType = Fj(u)));
          var t, v;
          switch (r) {
            case 0:
              t = function (z) {
                f.container[q] = z;
              };
              v = f.container[q];
              break;
            case 1:
              t = function (z) {
                f.destinationArray[q] = f.destinationArray[q] || [];
                f.destinationArray[q].unshift(z);
              };
              var w,
                y =
                  ((w = f.destinationArray[q]) == null ? void 0 : w[0]) ||
                  f.destination[q];
              !y || (y.state !== 0 && y.state !== 1) || (v = y);
              break;
            case 2:
              (t = function (z) {
                f.destinationArray[q] = f.destinationArray[q] || [];
                f.destinationArray[q].push(z);
              }),
                (v = void 0);
          }
          t &&
            (v
              ? (v.state === 0 && K(93),
                la(Object, "assign").call(Object, v, u))
              : t(u));
        },
        f = Hj(),
        g = m(b),
        h = g.next();
      !h.done;
      h = g.next()
    )
      e(h.value, 0);
    for (var l = m(c), n = l.next(); !n.done; n = l.next()) {
      var p = n.value;
      d.includes(p) ? e(p, 1) : e(p, 2);
    }
    f.canonical[Oj()] = {};
    Uj();
  }
  function Wj() {
    var a = Oj();
    return !!Hj().canonical[a];
  }
  function Xj(a) {
    return !!Hj().container[a];
  }
  function Yj(a) {
    var b = Gj(a);
    return b ? b.state !== 0 : !1;
  }
  function Sj() {
    return { ctid: hg(5), isDestination: gg(7) };
  }
  function Zj(a, b, c) {
    var d = Sj(),
      e = Hj().container[a];
    (e && e.state !== 3) ||
      ((Hj().container[a] = { state: 1, context: b, parent: d }),
      Ij({ ctid: a, isDestination: !1 }, c));
  }
  function ak() {
    var a = Hj().container,
      b;
    for (b in a) if (a.hasOwnProperty(b) && a[b].state === 1) return !0;
    return !1;
  }
  function bk() {
    var a = {};
    yb(Hj().destination, function (b, c) {
      (c == null ? void 0 : c.state) === 0 && (a[b] = c);
    });
    yb(Hj().destinationArray, function (b, c) {
      var d = c[0];
      (d == null ? void 0 : d.state) === 0 && (a[b] = d);
    });
    return a;
  }
  function ck(a) {
    return !!(
      a &&
      a.parent &&
      a.context &&
      a.context.source === 1 &&
      a.parent.ctid.indexOf("GTM-") !== 0
    );
  }
  function dk() {
    for (var a = Hj(), b = m(Pj()), c = b.next(); !c.done; c = b.next())
      if (a.injectedFirstPartyContainers[c.value]) return !0;
    return !1;
  }
  var ek = {},
    fk =
      ((ek.tdp = 1),
      (ek.exp = 1),
      (ek.pid = 1),
      (ek.dl = 1),
      (ek.seq = 1),
      (ek.t = 1),
      (ek.v = 1),
      ek),
    gk = {};
  function hk() {
    return Object.keys(gk).filter(function (a) {
      return gk[a];
    });
  }
  var ik = {};
  function jk(a, b, c) {
    ik[a] = b;
    (c === void 0 || c) && kk(a);
  }
  function kk(a, b) {
    (gk[a] !== void 0 && (b === void 0 || !b)) ||
      (Kb(hg(5), "GTM-") && a === "mcc") ||
      (gk[a] = !0);
  }
  function lk(a) {
    a.forEach(function (b) {
      fk[b] || (gk[b] = !1);
    });
  }
  function mk(a) {
    a = a === void 0 ? [] : a;
    return Vi(a).join("~");
  }
  function nk() {
    if (!F(118)) return "";
    var a, b;
    return (
      ((a = Rj(Sj())) == null
        ? void 0
        : (b = a.context) == null
        ? void 0
        : b.loadExperiments) || []
    ).join("~");
  }
  var ok = {
      "https://www.google.com": "/g",
      "https://www.googleadservices.com": "/as",
      "https://pagead2.googlesyndication.com": "/gs",
    },
    pk = [
      "/as/d/ccm/conversion",
      "/g/d/ccm/conversion",
      "/gs/ccm/conversion",
      "/d/ccm/form-data",
    ];
  function qk(a, b) {
    if (a) {
      var c = "" + a;
      c.indexOf("http://") !== 0 &&
        c.indexOf("https://") !== 0 &&
        (c = "https://" + c);
      c[c.length - 1] === "/" && (c = c.substring(0, c.length - 1));
      return yj("" + c + b).href;
    }
  }
  function rk(a, b) {
    if (lj() || gg(50)) return qk(a, b);
  }
  function sk() {
    return !!Yi.Wi && Yi.Wi.split("@@").join("") !== "SGTM_TOKEN";
  }
  function tk(a) {
    for (var b = m([J.m.ud, J.m.Mc]), c = b.next(); !c.done; c = b.next()) {
      var d = M(a, c.value);
      if (d) return d;
    }
  }
  function uk(a, b, c) {
    c = c === void 0 ? "" : c;
    if (!lj()) return a;
    var d = b ? ok[a] || "" : "";
    d === "/gs" && (c = "");
    return "" + kj() + d + c;
  }
  function vk(a) {
    if (!lj()) return a;
    for (var b = m(pk), c = b.next(); !c.done; c = b.next()) {
      var d = c.value;
      if (Kb(a, "" + kj() + d)) return a + "&_uip=" + encodeURIComponent("::");
    }
    return a;
  }
  function wk() {
    return { total: 0, jb: 0, Re: {} };
  }
  function xk(a, b, c, d) {
    var e = Object.keys(a.Se)
      .sort(function (f, g) {
        return Number(f) - Number(g);
      })
      .map(function (f) {
        return [f, b(a.Se[f])];
      })
      .filter(function (f) {
        return f[1] !== void 0;
      })
      .map(function (f) {
        return f.join(c);
      })
      .join(d);
    return e ? e : void 0;
  }
  function yk(a, b) {
    var c, d, e;
    c = c === void 0 ? "_" : c;
    d = d === void 0 ? ";" : d;
    e = e === void 0 ? "~" : e;
    for (
      var f = [], g = m(Object.keys(a.Re).sort()), h = g.next();
      !h.done;
      h = g.next()
    ) {
      var l = h.value,
        n = xk(a.Re[l], b, c, d);
      if (n) {
        var p = void 0;
        f.push("" + ((p = l) != null ? p : "") + d + n);
      }
    }
    return f.length ? f.join(e) : void 0;
  }
  function zk(a) {
    a.jb = 0;
    for (var b = m(Object.keys(a.Re)), c = b.next(); !c.done; c = b.next()) {
      var d = a.Re[c.value];
      d.jb = 0;
      for (var e = m(Object.keys(d.Se)), f = e.next(); !f.done; f = e.next())
        d.Se[f.value].jb = 0;
    }
  }
  function Ak(a, b, c) {
    var d;
    d = d === void 0 ? 1 : d;
    a.total += d;
    a.jb += d;
    var e,
      f = b === void 0 ? "" : b;
    e = a.Re[f] || (a.Re[f] = { total: 0, jb: 0, Se: {} });
    e.total += d;
    e.jb += d;
    var g,
      h = String(c);
    g = e.Se[h] || (e.Se[h] = { total: 0, jb: 0 });
    g.total += d;
    g.jb += d;
  }
  var Bk = wk();
  var Ck = {},
    Dk = ((Ck[1] = {}), (Ck[2] = {}), (Ck[3] = {}), (Ck[4] = {}), Ck);
  function Ek(a, b, c) {
    var d = Fk(b, c);
    if (d) {
      var e = Dk[b][d];
      e || (e = Dk[b][d] = []);
      e.push(la(Object, "assign").call(Object, {}, a));
      Ak(Bk, a.destinationId, a.endpoint);
      a.endpoint !== 56 && a.endpoint !== 61 && kk("mde", !0);
    }
  }
  function Gk(a, b) {
    var c = Fk(a, b);
    if (c) {
      var d = Dk[a][c];
      d &&
        (Dk[a][c] = d.filter(function (e) {
          return !e.yn;
        }));
    }
  }
  function Hk(a) {
    switch (a) {
      case "script-src":
      case "script-src-elem":
        return 1;
      case "frame-src":
        return 4;
      case "connect-src":
        return 2;
      case "img-src":
        return 3;
    }
  }
  function Fk(a, b) {
    var c = b;
    if (b[0] === "/") {
      var d;
      c = ((d = x.location) == null ? void 0 : d.origin) + b;
    }
    try {
      var e = new URL(c);
      return a === 4 ? e.origin : e.origin + e.pathname;
    } catch (f) {}
  }
  function Ik(a) {
    var b = String(a[pf.Sa] || "").replace(/_/g, "");
    return Kb(b, "cvt") ? "cvt" : b;
  }
  var Jk =
    x.location.search.indexOf("?gtm_latency=") >= 0 ||
    x.location.search.indexOf("&gtm_latency=") >= 0;
  var Kk = Math.random(),
    Lk,
    Mk = ig(27);
  Lk = Jk || Kk < Mk;
  var Nk,
    Ok = ig(42);
  Nk = Jk || Kk >= 1 - Ok;
  function Pk(a, b, c) {
    var d,
      e = a.GooglebQhCsO;
    e || ((e = {}), (a.GooglebQhCsO = e));
    d = e;
    if (d[b]) return !1;
    d[b] = [];
    d[b][0] = c;
    return !0;
  }
  var Qk, Rk;
  a: {
    for (var Sk = ["CLOSURE_FLAGS"], Tk = Da, Zk = 0; Zk < Sk.length; Zk++)
      if (((Tk = Tk[Sk[Zk]]), Tk == null)) {
        Rk = null;
        break a;
      }
    Rk = Tk;
  }
  var $k = Rk && Rk[610401301];
  Qk = $k != null ? $k : !1;
  function al() {
    var a = Da.navigator;
    if (a) {
      var b = a.userAgent;
      if (b) return b;
    }
    return "";
  }
  var bl,
    cl = Da.navigator;
  bl = cl ? cl.userAgentData || null : null;
  function dl(a) {
    if (!Qk || !bl) return !1;
    for (var b = 0; b < bl.brands.length; b++) {
      var c = bl.brands[b].brand;
      if (c && c.indexOf(a) != -1) return !0;
    }
    return !1;
  }
  function el(a) {
    return al().indexOf(a) != -1;
  }
  function fl() {
    return Qk ? !!bl && bl.brands.length > 0 : !1;
  }
  function gl() {
    return fl() ? !1 : el("Opera");
  }
  function hl() {
    return el("Firefox") || el("FxiOS");
  }
  function il() {
    return fl()
      ? dl("Chromium")
      : ((el("Chrome") || el("CriOS")) && !(fl() ? 0 : el("Edge"))) ||
          el("Silk");
  }
  function jl() {
    return Qk ? !!bl && !!bl.platform : !1;
  }
  function kl() {
    return el("iPhone") && !el("iPod") && !el("iPad");
  }
  function ll() {
    kl() || el("iPad") || el("iPod");
  }
  var ml = function (a) {
    ml[" "](a);
    return a;
  };
  ml[" "] = function () {};
  gl();
  fl() || el("Trident") || el("MSIE");
  el("Edge");
  !el("Gecko") ||
    (al().toLowerCase().indexOf("webkit") != -1 && !el("Edge")) ||
    el("Trident") ||
    el("MSIE") ||
    el("Edge");
  al().toLowerCase().indexOf("webkit") != -1 && !el("Edge") && el("Mobile");
  jl() || el("Macintosh");
  jl() || el("Windows");
  (jl() ? bl.platform === "Linux" : el("Linux")) || jl() || el("CrOS");
  jl() || el("Android");
  kl();
  el("iPad");
  el("iPod");
  ll();
  al().toLowerCase().indexOf("kaios");
  hl();
  kl() || el("iPod");
  el("iPad");
  !el("Android") || il() || hl() || gl() || el("Silk");
  il();
  !el("Safari") ||
    il() ||
    (fl() ? 0 : el("Coast")) ||
    gl() ||
    (fl() ? 0 : el("Edge")) ||
    (fl() ? dl("Microsoft Edge") : el("Edg/")) ||
    (fl() ? dl("Opera") : el("OPR")) ||
    hl() ||
    el("Silk") ||
    el("Android") ||
    ll();
  var nl = {},
    ol = null,
    pl = function (a) {
      for (var b = [], c = 0, d = 0; d < a.length; d++) {
        var e = a.charCodeAt(d);
        e > 255 && ((b[c++] = e & 255), (e >>= 8));
        b[c++] = e;
      }
      var f = 4;
      f === void 0 && (f = 0);
      if (!ol) {
        ol = {};
        for (
          var g =
              "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(
                ""
              ),
            h = ["+/=", "+/", "-_=", "-_.", "-_"],
            l = 0;
          l < 5;
          l++
        ) {
          var n = g.concat(h[l].split(""));
          nl[l] = n;
          for (var p = 0; p < n.length; p++) {
            var q = n[p];
            ol[q] === void 0 && (ol[q] = p);
          }
        }
      }
      for (
        var r = nl[f],
          u = Array(Math.floor(b.length / 3)),
          t = r[64] || "",
          v = 0,
          w = 0;
        v < b.length - 2;
        v += 3
      ) {
        var y = b[v],
          z = b[v + 1],
          D = b[v + 2],
          E = r[y >> 2],
          L = r[((y & 3) << 4) | (z >> 4)],
          I = r[((z & 15) << 2) | (D >> 6)],
          R = r[D & 63];
        u[w++] = "" + E + L + I + R;
      }
      var X = 0,
        Z = t;
      switch (b.length - v) {
        case 2:
          (X = b[v + 1]), (Z = r[(X & 15) << 2] || t);
        case 1:
          var Q = b[v];
          u[w] = "" + r[Q >> 2] + r[((Q & 3) << 4) | (X >> 4)] + Z + t;
      }
      return u.join("");
    };
  var ql = function (a) {
    return decodeURIComponent(a.replace(/\+/g, " "));
  };
  var rl = function (a, b, c, d) {
      for (var e = b, f = c.length; (e = a.indexOf(c, e)) >= 0 && e < d; ) {
        var g = a.charCodeAt(e - 1);
        if (g == 38 || g == 63) {
          var h = a.charCodeAt(e + f);
          if (!h || h == 61 || h == 38 || h == 35) return e;
        }
        e += f + 1;
      }
      return -1;
    },
    sl = /#|$/,
    tl = function (a, b) {
      var c = a.search(sl),
        d = rl(a, 0, b, c);
      if (d < 0) return null;
      var e = a.indexOf("&", d);
      if (e < 0 || e > c) e = c;
      d += b.length + 1;
      return ql(a.slice(d, e !== -1 ? e : 0));
    },
    ul = /[?&]($|#)/,
    vl = function (a, b, c) {
      for (
        var d, e = a.search(sl), f = 0, g, h = [];
        (g = rl(a, f, b, e)) >= 0;

      )
        h.push(a.substring(f, g)),
          (f = Math.min(a.indexOf("&", g) + 1 || e, e));
      h.push(a.slice(f));
      d = h.join("").replace(ul, "$1");
      var l,
        n = c != null ? "=" + encodeURIComponent(String(c)) : "";
      var p = b + n;
      if (p) {
        var q,
          r = d.indexOf("#");
        r < 0 && (r = d.length);
        var u = d.indexOf("?"),
          t;
        u < 0 || u > r ? ((u = r), (t = "")) : (t = d.substring(u + 1, r));
        q = [d.slice(0, u), t, d.slice(r)];
        var v = q[1];
        q[1] = p ? (v ? v + "&" + p : p) : v;
        l = q[0] + (q[1] ? "?" + q[1] : "") + q[2];
      } else l = d;
      return l;
    };
  function wl(a, b, c, d, e, f, g) {
    var h = tl(c, "fmt");
    if (d) {
      var l = tl(c, "random"),
        n = tl(c, "label") || "";
      if (!l) return !1;
      var p = pl(ql(n) + ":" + ql(l));
      if (!Pk(a, p, d)) return !1;
    }
    h && Number(h) !== 4 && (c = vl(c, "rfmt", h));
    var q = vl(c, "fmt", 4),
      r = b.getElementsByTagName("script")[0].parentElement;
    g == null || xl(g);
    Mc(
      q,
      function () {
        g == null || yl(g);
        a.google_noFurtherRedirects &&
          d &&
          ((a.google_noFurtherRedirects = null), d());
      },
      function () {
        g == null || yl(g);
        e == null || e();
      },
      f,
      r || void 0
    );
    return !0;
  }
  function zl(a) {
    var b = Ca.apply(1, arguments);
    Nk && (Ek(a, 2, b[0]), Ek(a, 3, b[0]));
    Yc.apply(null, ya(b));
  }
  function Al(a) {
    var b = Ca.apply(1, arguments);
    Nk && Ek(a, 2, b[0]);
    return Zc.apply(null, ya(b));
  }
  function Bl(a) {
    var b = Ca.apply(1, arguments);
    Nk && Ek(a, 3, b[0]);
    Pc.apply(null, ya(b));
  }
  function Cl(a) {
    var b = Ca.apply(1, arguments),
      c = b[0];
    Nk && (Ek(a, 2, c), Ek(a, 3, c));
    return ad.apply(null, ya(b));
  }
  function Dl(a) {
    var b = Ca.apply(1, arguments);
    Nk && Ek(a, 1, b[0]);
    Mc.apply(null, ya(b));
  }
  function El(a) {
    var b = Ca.apply(1, arguments);
    b[0] && Nk && Ek(a, 4, b[0]);
    Oc.apply(null, ya(b));
  }
  function Fl(a) {
    var b = Ca.apply(1, arguments);
    Nk && Ek(a, 1, b[2]);
    return wl.apply(null, ya(b));
  }
  var Gl = { Ka: { Be: 0, Ee: 1, Pi: 2 } };
  Gl.Ka[Gl.Ka.Be] = "FULL_TRANSMISSION";
  Gl.Ka[Gl.Ka.Ee] = "LIMITED_TRANSMISSION";
  Gl.Ka[Gl.Ka.Pi] = "NO_TRANSMISSION";
  var Hl = { aa: { Qc: 0, Ra: 1, bd: 2, Oc: 3 } };
  Hl.aa[Hl.aa.Qc] = "NO_QUEUE";
  Hl.aa[Hl.aa.Ra] = "ADS";
  Hl.aa[Hl.aa.bd] = "ANALYTICS";
  Hl.aa[Hl.aa.Oc] = "MONITORING";
  function Il() {
    var a = Ec("google_tag_data", {});
    return (a.ics = a.ics || new Jl());
  }
  var Jl = function () {
    this.entries = {};
    this.waitPeriodTimedOut =
      this.wasSetLate =
      this.accessedAny =
      this.accessedDefault =
      this.usedImplicit =
      this.usedUpdate =
      this.usedDefault =
      this.usedDeclare =
      this.active =
        !1;
    this.C = [];
  };
  Jl.prototype.default = function (a, b, c, d, e, f, g) {
    this.usedDefault ||
      this.usedDeclare ||
      (!this.accessedDefault && !this.accessedAny) ||
      (this.wasSetLate = !0);
    this.usedDefault = this.active = !0;
    jb("TAGGING", 19);
    b == null ? jb("TAGGING", 18) : Kl(this, a, b === "granted", c, d, e, f, g);
  };
  Jl.prototype.waitForUpdate = function (a, b, c) {
    for (var d = 0; d < a.length; d++)
      Kl(this, a[d], void 0, void 0, "", "", b, c);
  };
  var Kl = function (a, b, c, d, e, f, g, h) {
    var l = a.entries,
      n = l[b] || {},
      p = n.region,
      q = d && rb(d) ? d.toUpperCase() : void 0;
    e = e.toUpperCase();
    f = f.toUpperCase();
    if (e === "" || q === f || (q === e ? p !== f : !q && !p)) {
      var r = !!(g && g > 0 && n.update === void 0),
        u = {
          region: q,
          declare_region: n.declare_region,
          implicit: n.implicit,
          default: c !== void 0 ? c : n.default,
          declare: n.declare,
          update: n.update,
          quiet: r,
        };
      if (e !== "" || n.default !== !1) l[b] = u;
      r &&
        x.setTimeout(function () {
          l[b] === u &&
            u.quiet &&
            (jb("TAGGING", 2),
            (a.waitPeriodTimedOut = !0),
            a.clearTimeout(b, void 0, h),
            a.notifyListeners());
        }, g);
    }
  };
  k = Jl.prototype;
  k.clearTimeout = function (a, b, c) {
    var d = [a],
      e = c.delegatedConsentTypes,
      f;
    for (f in e) e.hasOwnProperty(f) && e[f] === a && d.push(f);
    var g = this.entries[a] || {},
      h = this.getConsentState(a, c);
    if (g.quiet) {
      g.quiet = !1;
      for (var l = m(d), n = l.next(); !n.done; n = l.next()) Ll(this, n.value);
    } else if (b !== void 0 && h !== b)
      for (var p = m(d), q = p.next(); !q.done; q = p.next()) Ll(this, q.value);
  };
  k.update = function (a, b, c) {
    this.usedDefault ||
      this.usedDeclare ||
      this.usedUpdate ||
      !this.accessedAny ||
      (this.wasSetLate = !0);
    this.usedUpdate = this.active = !0;
    if (b != null) {
      var d = this.getConsentState(a, c),
        e = this.entries;
      (e[a] = e[a] || {}).update = b === "granted";
      this.clearTimeout(a, d, c);
    }
  };
  k.declare = function (a, b, c, d, e) {
    this.usedDeclare = this.active = !0;
    var f = this.entries,
      g = f[a] || {},
      h = g.declare_region,
      l = c && rb(c) ? c.toUpperCase() : void 0;
    d = d.toUpperCase();
    e = e.toUpperCase();
    if (d === "" || l === e || (l === d ? h !== e : !l && !h)) {
      var n = {
        region: g.region,
        declare_region: l,
        declare: b === "granted",
        implicit: g.implicit,
        default: g.default,
        update: g.update,
        quiet: g.quiet,
      };
      if (d !== "" || g.declare !== !1) f[a] = n;
    }
  };
  k.implicit = function (a, b) {
    this.usedImplicit = !0;
    var c = this.entries,
      d = (c[a] = c[a] || {});
    d.implicit !== !1 && (d.implicit = b === "granted");
  };
  k.getConsentState = function (a, b) {
    var c = this.entries,
      d = c[a] || {},
      e = d.update;
    if (e !== void 0) return e ? 1 : 2;
    if (b.usedContainerScopedDefaults) {
      var f = b.containerScopedDefaults[a];
      if (f === 3) return 1;
      if (f === 2) return 2;
    } else if (((e = d.default), e !== void 0)) return e ? 1 : 2;
    if (b == null ? 0 : b.delegatedConsentTypes.hasOwnProperty(a)) {
      var g = b.delegatedConsentTypes[a],
        h = c[g] || {};
      e = h.update;
      if (e !== void 0) return e ? 1 : 2;
      if (b.usedContainerScopedDefaults) {
        var l = b.containerScopedDefaults[g];
        if (l === 3) return 1;
        if (l === 2) return 2;
      } else if (((e = h.default), e !== void 0)) return e ? 1 : 2;
    }
    e = d.declare;
    if (e !== void 0) return e ? 1 : 2;
    e = d.implicit;
    return e !== void 0 ? (e ? 3 : 4) : 0;
  };
  k.addListener = function (a, b) {
    this.C.push({ consentTypes: a, Jd: b });
  };
  var Ll = function (a, b) {
    for (var c = 0; c < a.C.length; ++c) {
      var d = a.C[c];
      Array.isArray(d.consentTypes) &&
        d.consentTypes.indexOf(b) !== -1 &&
        (d.tn = !0);
    }
  };
  Jl.prototype.notifyListeners = function (a, b) {
    for (var c = 0; c < this.C.length; ++c) {
      var d = this.C[c];
      if (d.tn) {
        d.tn = !1;
        try {
          d.Jd({ consentEventId: a, consentPriorityId: b });
        } catch (e) {}
      }
    }
  };
  var Ml = !1,
    Nl = !1,
    Ol = {},
    Pl = {
      delegatedConsentTypes: {},
      corePlatformServices: {},
      usedCorePlatformServices: !1,
      selectedAllCorePlatformServices: !1,
      containerScopedDefaults:
        ((Ol.ad_storage = 1),
        (Ol.analytics_storage = 1),
        (Ol.ad_user_data = 1),
        (Ol.ad_personalization = 1),
        Ol),
      usedContainerScopedDefaults: !1,
    };
  function Ql(a) {
    var b = Il();
    b.accessedAny = !0;
    return (rb(a) ? [a] : a).every(function (c) {
      switch (b.getConsentState(c, Pl)) {
        case 1:
        case 3:
          return !0;
        case 2:
        case 4:
          return !1;
        default:
          return !0;
      }
    });
  }
  function Rl(a) {
    var b = Il();
    b.accessedAny = !0;
    return b.getConsentState(a, Pl);
  }
  function Sl(a) {
    var b = Il();
    b.accessedAny = !0;
    return !(b.entries[a] || {}).quiet;
  }
  function Tl() {
    if (!Ua(7)) return !1;
    var a = Il();
    a.accessedAny = !0;
    if (a.active) return !0;
    if (!Pl.usedContainerScopedDefaults) return !1;
    for (
      var b = m(Object.keys(Pl.containerScopedDefaults)), c = b.next();
      !c.done;
      c = b.next()
    )
      if (Pl.containerScopedDefaults[c.value] !== 1) return !0;
    return !1;
  }
  function Ul(a, b) {
    Il().addListener(a, b);
  }
  function Vl(a, b) {
    Il().notifyListeners(a, b);
  }
  function Wl(a, b) {
    function c() {
      for (var e = 0; e < b.length; e++) if (!Sl(b[e])) return !0;
      return !1;
    }
    if (c()) {
      var d = !1;
      Ul(b, function (e) {
        d || c() || ((d = !0), a(e));
      });
    } else a({});
  }
  function Xl(a, b) {
    function c() {
      for (var h = [], l = 0; l < e.length; l++) {
        var n = e[l];
        Ql(n) && !f[n] && h.push(n);
      }
      return h;
    }
    function d(h) {
      for (var l = 0; l < h.length; l++) f[h[l]] = !0;
    }
    var e = rb(b) ? [b] : b,
      f = {},
      g = c();
    g.length !== e.length &&
      (d(g),
      Ul(e, function (h) {
        function l(q) {
          q.length !== 0 && (d(q), (h.consentTypes = q), a(h));
        }
        var n = c();
        if (n.length !== 0) {
          var p = Object.keys(f).length;
          n.length + p >= e.length
            ? l(n)
            : x.setTimeout(function () {
                l(c());
              }, 500);
        }
      }));
  }
  var Yl = {},
    Zl =
      ((Yl[Hl.aa.Qc] = Gl.Ka.Be),
      (Yl[Hl.aa.Ra] = Gl.Ka.Be),
      (Yl[Hl.aa.bd] = Gl.Ka.Be),
      (Yl[Hl.aa.Oc] = Gl.Ka.Be),
      Yl),
    $l = function (a, b) {
      this.C = a;
      this.consentTypes = b;
    };
  $l.prototype.isConsentGranted = function () {
    switch (this.C) {
      case 0:
        return this.consentTypes.every(function (a) {
          return Ql(a);
        });
      case 1:
        return this.consentTypes.some(function (a) {
          return Ql(a);
        });
      default:
        rc(this.C, "consentsRequired had an unknown type");
    }
  };
  var am = {},
    bm =
      ((am[Hl.aa.Qc] = new $l(0, [])),
      (am[Hl.aa.Ra] = new $l(0, ["ad_storage"])),
      (am[Hl.aa.bd] = new $l(0, ["analytics_storage"])),
      (am[Hl.aa.Oc] = new $l(1, ["ad_storage", "analytics_storage"])),
      am);
  var dm = function (a) {
    var b = this;
    this.type = a;
    this.C = [];
    Ul(bm[a].consentTypes, function () {
      cm(b) || b.flush();
    });
  };
  dm.prototype.flush = function () {
    for (var a = m(this.C), b = a.next(); !b.done; b = a.next()) {
      var c = b.value;
      c();
    }
    this.C = [];
  };
  var cm = function (a) {
      return Zl[a.type] === Gl.Ka.Pi && !bm[a.type].isConsentGranted();
    },
    em = function (a, b) {
      cm(a) ? a.C.push(b) : b();
    },
    fm = new Map();
  function gm(a) {
    fm.has(a) || fm.set(a, new dm(a));
    return fm.get(a);
  }
  var hm = {
    Z: {
      Nn: "aw_user_data_cache",
      bi: "cookie_deprecation_label",
      Og: "diagnostics_page_id",
      ls: "em_registry",
      Ci: "eab",
      hp: "fl_user_data_cache",
      mp: "ga4_user_data_cache",
      Ce: "ip_geo_data_cache",
      Ii: "ip_geo_fetch_in_progress",
      tm: "nb_data",
      Qi: "page_experiment_ids",
      Ge: "pt_data",
      wm: "pt_listener_set",
      Bm: "service_worker_endpoint",
      Em: "shared_user_id",
      Fm: "shared_user_id_requested",
      Fh: "shared_user_id_source",
    },
  };
  var im = (function (a) {
    return ef(function (b) {
      for (var c in a) if (b === a[c] && !/^[0-9]+$/.test(c)) return !0;
      return !1;
    });
  })(hm.Z);
  function jm(a, b) {
    b = b === void 0 ? !1 : b;
    if (im(a)) {
      var c,
        d,
        e =
          (d = (c = Ec("google_tag_data", {})).xcd) != null ? d : (c.xcd = {});
      if (e[a]) return e[a];
      if (b) {
        var f = void 0,
          g = 1,
          h = {},
          l = {
            set: function (n) {
              f = n;
              l.notify();
            },
            get: function () {
              return f;
            },
            subscribe: function (n) {
              h[String(g)] = n;
              return g++;
            },
            unsubscribe: function (n) {
              var p = String(n);
              return h.hasOwnProperty(p) ? (delete h[p], !0) : !1;
            },
            notify: function () {
              for (
                var n = m(Object.keys(h)), p = n.next();
                !p.done;
                p = n.next()
              ) {
                var q = p.value;
                try {
                  h[q](a, f);
                } catch (r) {}
              }
            },
          };
        return (e[a] = l);
      }
    }
  }
  function km(a, b) {
    var c = jm(a, !0);
    c && c.set(b);
  }
  function lm(a) {
    var b;
    return (b = jm(a)) == null ? void 0 : b.get();
  }
  function mm(a, b) {
    var c = jm(a);
    if (!c) {
      c = jm(a, !0);
      if (!c) return;
      c.set(b);
    }
    return c.get();
  }
  function nm(a, b) {
    if (typeof b === "function") {
      var c;
      return (c = jm(a, !0)) == null ? void 0 : c.subscribe(b);
    }
  }
  function om(a, b) {
    var c = jm(a);
    return c ? c.unsubscribe(b) : !1;
  }
  var pm = ["fin", "mcc"],
    qm = !1;
  function rm(a) {
    a = a === void 0 ? !1 : a;
    var b = hk().filter(function (c) {
      return ik[c] !== void 0 && (a || !pm.includes(c));
    });
    lk(b);
    return (
      b
        .map(function (c) {
          var d = ik[c];
          typeof d === "function" && (d = d());
          return d ? "&" + c + "=" + d : "";
        })
        .join("") + "&z=0"
    );
  }
  function sm(a) {
    var b = "https://" + hg(21),
      c = "/td?id=" + hg(5);
    return "" + uk(b) + c + a;
  }
  function tm(a) {
    a = a === void 0 ? !1 : a;
    if (Ui.H && Nk && hg(5)) {
      var b = gm(Hl.aa.Oc);
      if (cm(b)) qm || ((qm = !0), em(b, tm));
      else {
        a && jk("fin", "1");
        var c = rm(a),
          d = sm(c),
          e = { destinationId: hg(5), endpoint: 61 };
        a
          ? Cl(e, d, void 0, { Qe: !0 }, void 0, function () {
              Bl(e, d + "&img=1");
            })
          : Bl(e, d);
        qm = !1;
        um(c);
      }
    }
  }
  function um(a) {
    if (F(171) && !(a.indexOf("&csp=") < 0 && a.indexOf("&mde=") < 0)) {
      var b;
      a: {
        try {
          if (Dc) {
            b = new URL(Dc);
            break a;
          }
        } catch (c) {}
        b = void 0;
      }
      b && Mc("" + Dc + (Dc.indexOf("?") >= 0 ? "&" : "?") + "is_td=1" + a);
    }
  }
  function vm() {
    hk().some(function (a) {
      return !fk[a];
    }) && tm(!0);
  }
  var wm;
  function xm() {
    if (lm(hm.Z.Og) === void 0) {
      var a = function () {
        km(hm.Z.Og, vb());
        wm = 0;
      };
      a();
      x.setInterval(a, 864e5);
    } else
      nm(hm.Z.Og, function () {
        wm = 0;
      });
    wm = 0;
  }
  function ym() {
    xm();
    jk("v", "3");
    jk("t", "t");
    jk("pid", function () {
      return String(lm(hm.Z.Og));
    });
    jk("seq", function () {
      return String(++wm);
    });
    jk("exp", mk());
    Rc(x, "pagehide", vm);
  }
  var zm = [
      "ad_storage",
      "analytics_storage",
      "ad_user_data",
      "ad_personalization",
    ],
    Am = [
      J.m.ud,
      J.m.Mc,
      J.m.zf,
      J.m.Tb,
      J.m.Wb,
      J.m.Na,
      J.m.Xa,
      J.m.Wa,
      J.m.tb,
      J.m.Ub,
    ],
    Bm = !1,
    Cm = !1,
    Dm = {},
    Em = {};
  function Fm() {
    !Cm &&
      Bm &&
      (zm.some(function (a) {
        return Pl.containerScopedDefaults[a] !== 1;
      }) ||
        Gm("mbc"));
    Cm = !0;
  }
  function Gm(a) {
    Nk && (jk(a, "1"), tm());
  }
  function Hm(a, b) {
    if (!Dm[b] && ((Dm[b] = !0), Em[b]))
      for (var c = m(Am), d = c.next(); !d.done; d = c.next())
        if (M(a, d.value)) {
          Gm("erc");
          break;
        }
  }
  function Im(a) {
    jb("HEALTH", a);
  }
  var Jm = {},
    Km = !1;
  function Lm() {
    function a() {
      c !== void 0 && om(hm.Z.Ce, c);
      try {
        var e = lm(hm.Z.Ce);
        Jm = JSON.parse(e);
      } catch (f) {
        K(123), Im(2), (Jm = {});
      }
      Km = !0;
      b();
    }
    var b = Mm,
      c = void 0,
      d = lm(hm.Z.Ce);
    d ? a(d) : ((c = nm(hm.Z.Ce, a)), Nm());
  }
  function Nm() {
    function a(b) {
      km(hm.Z.Ce, b || "{}");
      km(hm.Z.Ii, !1);
    }
    if (!lm(hm.Z.Ii)) {
      km(hm.Z.Ii, !0);
      try {
        x.fetch("https://www.google.com/ccm/geo", {
          method: "GET",
          cache: "no-store",
          mode: "cors",
          credentials: "omit",
        }).then(
          function (b) {
            b.ok
              ? b.text().then(
                  function (c) {
                    a(c);
                  },
                  function () {
                    a();
                  }
                )
              : a();
          },
          function () {
            a();
          }
        );
      } catch (b) {
        a();
      }
    }
  }
  function Om() {
    var a = hg(22);
    try {
      return JSON.parse(hb(a));
    } catch (b) {
      return K(123), Im(2), {};
    }
  }
  function Pm() {
    return Jm["0"] || "";
  }
  function Qm() {
    return Jm["1"] || "";
  }
  function Rm() {
    var a = !1;
    return a;
  }
  function Sm() {
    return Jm["6"] !== !1;
  }
  function Tm() {
    var a = "";
    return a;
  }
  function Um() {
    var a = "";
    return a;
  }
  var Vm = {},
    Wm = Object.freeze(
      ((Vm[J.m.Rb] = 1),
      (Vm[J.m.Pg] = 1),
      (Vm[J.m.gi] = 1),
      (Vm[J.m.Sb] = 1),
      (Vm[J.m.Ca] = 1),
      (Vm[J.m.tb] = 1),
      (Vm[J.m.ub] = 1),
      (Vm[J.m.Cb] = 1),
      (Vm[J.m.kd] = 1),
      (Vm[J.m.Ub] = 1),
      (Vm[J.m.Wa] = 1),
      (Vm[J.m.yc] = 1),
      (Vm[J.m.pe] = 1),
      (Vm[J.m.Ga] = 1),
      (Vm[J.m.Nk] = 1),
      (Vm[J.m.yf] = 1),
      (Vm[J.m.Zg] = 1),
      (Vm[J.m.ah] = 1),
      (Vm[J.m.se] = 1),
      (Vm[J.m.zf] = 1),
      (Vm[J.m.Yk] = 1),
      (Vm[J.m.Ec] = 1),
      (Vm[J.m.we] = 1),
      (Vm[J.m.bl] = 1),
      (Vm[J.m.hh] = 1),
      (Vm[J.m.si] = 1),
      (Vm[J.m.Fc] = 1),
      (Vm[J.m.Gc] = 1),
      (Vm[J.m.Xa] = 1),
      (Vm[J.m.wi] = 1),
      (Vm[J.m.Vb] = 1),
      (Vm[J.m.rd] = 1),
      (Vm[J.m.sd] = 1),
      (Vm[J.m.ud] = 1),
      (Vm[J.m.Hf] = 1),
      (Vm[J.m.yi] = 1),
      (Vm[J.m.vd] = 1),
      (Vm[J.m.Mc] = 1),
      (Vm[J.m.wd] = 1),
      (Vm[J.m.Al] = 1),
      (Vm[J.m.xd] = 1),
      (Vm[J.m.Nc] = 1),
      (Vm[J.m.Vi] = 1),
      Vm)
    );
  Object.freeze([
    J.m.ya,
    J.m.Ya,
    J.m.Db,
    J.m.lb,
    J.m.xi,
    J.m.Na,
    J.m.oi,
    J.m.Fo,
  ]);
  var Xm = {},
    Ym = Object.freeze(
      ((Xm[J.m.jo] = 1),
      (Xm[J.m.ko] = 1),
      (Xm[J.m.lo] = 1),
      (Xm[J.m.mo] = 1),
      (Xm[J.m.no] = 1),
      (Xm[J.m.ro] = 1),
      (Xm[J.m.so] = 1),
      (Xm[J.m.uo] = 1),
      (Xm[J.m.wo] = 1),
      (Xm[J.m.he] = 1),
      Xm)
    ),
    Zm = {},
    $m = Object.freeze(
      ((Zm[J.m.Dk] = 1),
      (Zm[J.m.Ek] = 1),
      (Zm[J.m.ce] = 1),
      (Zm[J.m.de] = 1),
      (Zm[J.m.Fk] = 1),
      (Zm[J.m.ed] = 1),
      (Zm[J.m.ee] = 1),
      (Zm[J.m.mc] = 1),
      (Zm[J.m.xc] = 1),
      (Zm[J.m.nc] = 1),
      (Zm[J.m.zb] = 1),
      (Zm[J.m.fe] = 1),
      (Zm[J.m.oc] = 1),
      (Zm[J.m.Gk] = 1),
      Zm)
    ),
    an = Object.freeze([
      J.m.Rb,
      J.m.hf,
      J.m.Sb,
      J.m.yc,
      J.m.zf,
      J.m.Ef,
      J.m.rd,
      J.m.wd,
    ]),
    bn = Object.freeze([].concat(ya(an))),
    cn = Object.freeze([J.m.ub, J.m.ah, J.m.Hf, J.m.yi, J.m.Xg]),
    dn = Object.freeze([].concat(ya(cn))),
    en = {},
    fn =
      ((en[J.m.W] = "1"),
      (en[J.m.ja] = "2"),
      (en[J.m.X] = "3"),
      (en[J.m.La] = "4"),
      en),
    gn = {},
    hn = Object.freeze(
      ((gn.search = "s"),
      (gn.youtube = "y"),
      (gn.playstore = "p"),
      (gn.shopping = "h"),
      (gn.ads = "a"),
      (gn.maps = "m"),
      gn)
    );
  function jn(a) {
    return typeof a !== "object" || a === null ? {} : a;
  }
  function kn(a) {
    return a === void 0 || a === null
      ? ""
      : typeof a === "object"
      ? a.toString()
      : String(a);
  }
  function ln(a) {
    if (a !== void 0 && a !== null) return kn(a);
  }
  function mn(a) {
    return typeof a === "number" ? a : ln(a);
  }
  function nn(a) {
    return a && a.indexOf("pending:") === 0 ? on(a.substr(8)) : !1;
  }
  function on(a) {
    if (a == null || a.length === 0) return !1;
    var b = Number(a),
      c = Fb();
    return b < c + 3e5 && b > c - 9e5;
  }
  var pn = !1,
    qn = !1,
    rn = !1,
    sn = 0,
    tn = !1,
    un = [];
  function vn(a) {
    if (sn === 0) tn && un && (un.length >= 100 && un.shift(), un.push(a));
    else if (wn()) {
      var b = hg(41),
        c = Ec(b, []);
      c.length >= 50 && c.shift();
      c.push(a);
    }
  }
  function xn() {
    yn();
    Sc(A, "TAProdDebugSignal", xn);
  }
  function yn() {
    if (!qn) {
      qn = !0;
      zn();
      var a = un;
      un = void 0;
      a == null ||
        a.forEach(function (b) {
          vn(b);
        });
    }
  }
  function zn() {
    var a = A.documentElement.getAttribute("data-tag-assistant-prod-present");
    on(a)
      ? (sn = 1)
      : !nn(a) || pn || rn
      ? (sn = 2)
      : ((rn = !0),
        Rc(A, "TAProdDebugSignal", xn, !1),
        x.setTimeout(function () {
          yn();
          pn = !0;
        }, 200));
  }
  function wn() {
    if (!tn) return !1;
    switch (sn) {
      case 1:
      case 0:
        return !0;
      case 2:
        return !1;
      default:
        return !1;
    }
  }
  var An = !1;
  function Bn(a, b) {
    var c = Pj(),
      d = Mj();
    hg(26);
    if (wn()) {
      var e = Cn("INIT");
      e.containerLoadSource = a != null ? a : 0;
      b && (e.parentTargetReference = b);
      e.aliases = c;
      e.destinations = d;
      vn(e);
    }
  }
  function Dn(a) {
    var b, c, d, e;
    b = a.targetId;
    c = a.request;
    d = a.hb;
    e = a.isBatched;
    var f;
    if ((f = wn())) {
      var g;
      a: switch (c.endpoint) {
        case 19:
        case 47:
          g = !0;
          break a;
        default:
          g = !1;
      }
      f = !g;
    }
    if (f) {
      var h = Cn("GTAG_HIT", { eventId: d.eventId, priorityId: d.priorityId });
      h.target = b;
      h.url = c.url;
      c.postBody && (h.postBody = c.postBody);
      h.parameterEncoding = c.parameterEncoding;
      h.endpoint = c.endpoint;
      e !== void 0 && (h.isBatched = e);
      vn(h);
    }
  }
  function En(a) {
    wn() && Dn(a());
  }
  function Cn(a, b) {
    b = b === void 0 ? {} : b;
    b.groupId = Fn;
    var c,
      d = b,
      e = Gn,
      f = { publicId: Hn };
    d.eventId != null && (f.eventId = d.eventId);
    d.priorityId != null && (f.priorityId = d.priorityId);
    d.eventName && (f.eventName = d.eventName);
    d.groupId && (f.groupId = d.groupId);
    d.tagName && (f.tagName = d.tagName);
    c = { containerProduct: "GTM", key: f, version: e, messageType: a };
    c.containerProduct = An ? "OGT" : "GTM";
    c.key.targetRef = In;
    return c;
  }
  var Hn = "",
    Gn = "",
    In = { ctid: "", isDestination: !1 },
    Fn;
  function Jn(a) {
    var b = hg(5),
      c = Lj(),
      d = hg(6),
      e = hg(1);
    hg(23);
    sn = 0;
    tn = !0;
    zn();
    Fn = a;
    Hn = b;
    Gn = e;
    An = cj;
    In = { ctid: b, isDestination: c, canonicalId: d };
  }
  var Kn = [J.m.W, J.m.ja, J.m.X, J.m.La],
    Ln,
    Mn;
  function Nn(a) {
    var b = a[J.m.kc];
    b || (b = [""]);
    for (var c = { pg: 0 }; c.pg < b.length; c = { pg: c.pg }, ++c.pg)
      yb(
        a,
        (function (d) {
          return function (e, f) {
            if (e !== J.m.kc) {
              var g = kn(f),
                h = b[d.pg],
                l = Pm(),
                n = Qm();
              Nl = !0;
              Ml && jb("TAGGING", 20);
              Il().declare(e, g, h, l, n);
            }
          };
        })(c)
      );
  }
  function On(a) {
    Fm();
    !Mn && Ln && Gm("crc");
    Mn = !0;
    var b = a[J.m.Jg];
    b && K(41);
    var c = a[J.m.kc];
    c ? K(40) : (c = [""]);
    for (var d = { qg: 0 }; d.qg < c.length; d = { qg: d.qg }, ++d.qg)
      yb(
        a,
        (function (e) {
          return function (f, g) {
            if (f !== J.m.kc && f !== J.m.Jg) {
              var h = ln(g),
                l = c[e.qg],
                n = Number(b),
                p = Pm(),
                q = Qm();
              n = n === void 0 ? 0 : n;
              Ml = !0;
              Nl && jb("TAGGING", 20);
              Il().default(f, h, l, p, q, n, Pl);
            }
          };
        })(d)
      );
  }
  function Pn(a) {
    Pl.usedContainerScopedDefaults = !0;
    var b = a[J.m.kc];
    if (b) {
      var c = Array.isArray(b) ? b : [b];
      if (!c.includes(Qm()) && !c.includes(Pm())) return;
    }
    yb(a, function (d, e) {
      switch (d) {
        case "ad_storage":
        case "analytics_storage":
        case "ad_user_data":
        case "ad_personalization":
          break;
        default:
          return;
      }
      Pl.usedContainerScopedDefaults = !0;
      Pl.containerScopedDefaults[d] = e === "granted" ? 3 : 2;
    });
  }
  function Qn(a, b) {
    Fm();
    Ln = !0;
    yb(a, function (c, d) {
      var e = kn(d);
      Ml = !0;
      Nl && jb("TAGGING", 20);
      Il().update(c, e, Pl);
    });
    Vl(b.eventId, b.priorityId);
  }
  function Rn(a) {
    a.hasOwnProperty("all") &&
      ((Pl.selectedAllCorePlatformServices = !0),
      yb(hn, function (b) {
        Pl.corePlatformServices[b] = a.all === "granted";
        Pl.usedCorePlatformServices = !0;
      }));
    yb(a, function (b, c) {
      b !== "all" &&
        ((Pl.corePlatformServices[b] = c === "granted"),
        (Pl.usedCorePlatformServices = !0));
    });
  }
  function Sn(a) {
    Array.isArray(a) || (a = [a]);
    return a.every(function (b) {
      return Ql(b);
    });
  }
  function Tn(a, b) {
    Ul(a, b);
  }
  function Un(a, b) {
    Xl(a, b);
  }
  function Vn(a, b) {
    Wl(a, b);
  }
  function Wn() {
    var a = [J.m.W, J.m.La, J.m.X];
    Il().waitForUpdate(a, 500, Pl);
  }
  function Xn(a) {
    for (var b = m(a), c = b.next(); !c.done; c = b.next()) {
      var d = c.value;
      Il().clearTimeout(d, void 0, Pl);
    }
    Vl();
  }
  function Yn() {
    if (!dj)
      for (var a = Sm() ? mj(kg(5)) : mj(kg(4)), b = 0; b < Kn.length; b++) {
        var c = Kn[b],
          d = c,
          e = a[c] ? "granted" : "denied";
        Il().implicit(d, e);
      }
  }
  var Zn = (x.google_tag_manager = x.google_tag_manager || {});
  function $n(a, b) {
    return (Zn[a] = Zn[a] || b());
  }
  function ao() {
    var a = hg(5),
      b = bo;
    Zn[a] = Zn[a] || b;
  }
  function co() {
    var a = hg(19);
    return (Zn[a] = Zn[a] || {});
  }
  function eo() {
    var a = hg(19);
    return Zn[a];
  }
  function fo() {
    var a = Zn.sequence || 1;
    Zn.sequence = a + 1;
    return a;
  }
  x.google_tag_data = x.google_tag_data || {};
  var go = !1,
    ho = [];
  function io() {
    if (!go) {
      go = !0;
      for (var a = ho.length - 1; a >= 0; a--) ho[a]();
      ho = [];
    }
  }
  var jo = /^(?:AW|DC|G|GF|GT|HA|MC|UA)$/,
    ko = /\s/;
  function lo(a, b) {
    if (rb(a)) {
      a = Db(a);
      var c = a.indexOf("-");
      if (!(c < 0)) {
        var d = a.substring(0, c);
        if (jo.test(d)) {
          var e = a.substring(c + 1),
            f;
          if (b) {
            var g = function (n) {
              var p = n.indexOf("/");
              return p < 0 ? [n] : [n.substring(0, p), n.substring(p + 1)];
            };
            f = g(e);
            if (d === "DC" && f.length === 2) {
              var h = g(f[1]);
              h.length === 2 && ((f[1] = h[0]), f.push(h[1]));
            }
          } else {
            f = e.split("/");
            for (var l = 0; l < f.length; l++)
              if (!f[l] || (ko.test(f[l]) && (d !== "AW" || l !== 1))) return;
          }
          return { id: a, prefix: d, destinationId: d + "-" + f[0], ids: f };
        }
      }
    }
  }
  function mo(a, b) {
    for (var c = {}, d = 0; d < a.length; ++d) {
      var e = lo(a[d], b);
      e && (c[e.id] = e);
    }
    var f = [],
      g;
    for (g in c)
      if (c.hasOwnProperty(g)) {
        var h = c[g];
        h.prefix === "AW" && h.ids[no[1]] && f.push(h.destinationId);
      }
    for (var l = 0; l < f.length; ++l) delete c[f[l]];
    for (var n = [], p = m(Object.keys(c)), q = p.next(); !q.done; q = p.next())
      n.push(c[q.value]);
    return n;
  }
  var oo = {},
    no =
      ((oo[0] = 0),
      (oo[1] = 1),
      (oo[2] = 2),
      (oo[3] = 0),
      (oo[4] = 1),
      (oo[5] = 0),
      (oo[6] = 0),
      (oo[7] = 0),
      oo);
  var po = mg(34, 500),
    qo = {},
    ro = {},
    so = { initialized: 11, complete: 12, interactive: 13 },
    to = {},
    uo = Object.freeze(((to[J.m.rd] = !0), to)),
    vo = void 0;
  function wo(a, b) {
    if (b.length && Nk) {
      var c;
      (c = qo)[a] != null || (c[a] = []);
      ro[a] != null || (ro[a] = []);
      var d = b.filter(function (e) {
        return !ro[a].includes(e);
      });
      qo[a].push.apply(qo[a], ya(d));
      ro[a].push.apply(ro[a], ya(d));
      !vo &&
        d.length > 0 &&
        (kk("tdc", !0),
        (vo = x.setTimeout(function () {
          tm();
          qo = {};
          vo = void 0;
        }, po)));
    }
  }
  function xo(a, b) {
    var c = {},
      d;
    for (d in b) b.hasOwnProperty(d) && (c[d] = !0);
    for (var e in a) a.hasOwnProperty(e) && (c[e] = !0);
    return c;
  }
  function yo(a, b, c, d) {
    c = c === void 0 ? {} : c;
    d = d === void 0 ? "" : d;
    if (a === b) return [];
    var e = function (r, u) {
        var t;
        pd(u) === "object" ? (t = u[r]) : pd(u) === "array" && (t = u[r]);
        return t === void 0 ? uo[r] : t;
      },
      f = xo(a, b),
      g;
    for (g in f)
      if (f.hasOwnProperty(g)) {
        var h = (d ? d + "." : "") + g,
          l = e(g, a),
          n = e(g, b),
          p = pd(l) === "object" || pd(l) === "array",
          q = pd(n) === "object" || pd(n) === "array";
        if (p && q) yo(l, n, c, h);
        else if (p || q || l !== n) c[h] = !0;
      }
    return Object.keys(c);
  }
  function zo() {
    jk(
      "tdc",
      function () {
        vo && (x.clearTimeout(vo), (vo = void 0));
        var a = [],
          b;
        for (b in qo) qo.hasOwnProperty(b) && a.push(b + "*" + qo[b].join("."));
        return a.length ? a.join("!") : void 0;
      },
      !1
    );
  }
  var Ao = {
    R: {
      ek: 1,
      Ui: 2,
      Yj: 3,
      wk: 4,
      Zj: 5,
      dd: 6,
      vk: 7,
      wp: 8,
      Am: 9,
      bk: 10,
      dk: 11,
      sh: 12,
      Ol: 13,
      Ll: 14,
      Nl: 15,
      Kl: 16,
      Ml: 17,
      Jl: 18,
      Mn: 19,
      jp: 20,
      kp: 21,
      Oi: 22,
    },
  };
  Ao.R[Ao.R.ek] = "ALLOW_INTEREST_GROUPS";
  Ao.R[Ao.R.Ui] = "SERVER_CONTAINER_URL";
  Ao.R[Ao.R.Yj] = "ADS_DATA_REDACTION";
  Ao.R[Ao.R.wk] = "CUSTOMER_LIFETIME_VALUE";
  Ao.R[Ao.R.Zj] = "ALLOW_CUSTOM_SCRIPTS";
  Ao.R[Ao.R.dd] = "ANY_COOKIE_PARAMS";
  Ao.R[Ao.R.vk] = "COOKIE_EXPIRES";
  Ao.R[Ao.R.wp] = "LEGACY_ENHANCED_CONVERSION_JS_VARIABLE";
  Ao.R[Ao.R.Am] = "RESTRICTED_DATA_PROCESSING";
  Ao.R[Ao.R.bk] = "ALLOW_DISPLAY_FEATURES";
  Ao.R[Ao.R.dk] = "ALLOW_GOOGLE_SIGNALS";
  Ao.R[Ao.R.sh] = "GENERATED_TRANSACTION_ID";
  Ao.R[Ao.R.Ol] = "FLOODLIGHT_COUNTING_METHOD_UNKNOWN";
  Ao.R[Ao.R.Ll] = "FLOODLIGHT_COUNTING_METHOD_STANDARD";
  Ao.R[Ao.R.Nl] = "FLOODLIGHT_COUNTING_METHOD_UNIQUE";
  Ao.R[Ao.R.Kl] = "FLOODLIGHT_COUNTING_METHOD_PER_SESSION";
  Ao.R[Ao.R.Ml] = "FLOODLIGHT_COUNTING_METHOD_TRANSACTIONS";
  Ao.R[Ao.R.Jl] = "FLOODLIGHT_COUNTING_METHOD_ITEMS_SOLD";
  Ao.R[Ao.R.Mn] = "ADS_OGT_V1_USAGE";
  Ao.R[Ao.R.jp] = "FORM_INTERACTION_PERMISSION_DENIED";
  Ao.R[Ao.R.kp] = "FORM_SUBMIT_PERMISSION_DENIED";
  Ao.R[Ao.R.Oi] = "MICROTASK_NOT_SUPPORTED";
  var Bo = {},
    Co =
      ((Bo[J.m.hi] = Ao.R.ek),
      (Bo[J.m.ud] = Ao.R.Ui),
      (Bo[J.m.Mc] = Ao.R.Ui),
      (Bo[J.m.Ia] = Ao.R.Yj),
      (Bo[J.m.oe] = Ao.R.wk),
      (Bo[J.m.ff] = Ao.R.Zj),
      (Bo[J.m.yc] = Ao.R.dd),
      (Bo[J.m.Wa] = Ao.R.dd),
      (Bo[J.m.tb] = Ao.R.dd),
      (Bo[J.m.kd] = Ao.R.dd),
      (Bo[J.m.Ub] = Ao.R.dd),
      (Bo[J.m.Cb] = Ao.R.dd),
      (Bo[J.m.ub] = Ao.R.vk),
      (Bo[J.m.Vb] = Ao.R.Am),
      (Bo[J.m.Pg] = Ao.R.bk),
      (Bo[J.m.Sb] = Ao.R.dk),
      Bo),
    Do = {},
    Eo =
      ((Do.unknown = Ao.R.Ol),
      (Do.standard = Ao.R.Ll),
      (Do.unique = Ao.R.Nl),
      (Do.per_session = Ao.R.Kl),
      (Do.transactions = Ao.R.Ml),
      (Do.items_sold = Ao.R.Jl),
      Do);
  var mb = [];
  function Fo(a, b) {
    b = b === void 0 ? !1 : b;
    jb("GTAG_EVENT_FEATURE_CHANNEL", a);
    b && (mb[a] = !0);
  }
  function Go(a, b) {
    b = b === void 0 ? !1 : b;
    for (
      var c = Object.keys(a), d = m(Object.keys(Co)), e = d.next();
      !e.done;
      e = d.next()
    ) {
      var f = e.value;
      c.includes(f) && Fo(Co[f], b);
    }
  }
  var Ho = function (a, b, c, d, e, f, g, h, l, n, p) {
      this.eventId = a;
      this.priorityId = b;
      this.C = c;
      this.V = d;
      this.H = e;
      this.T = f;
      this.P = g;
      this.eventMetadata = h;
      this.onSuccess = l;
      this.onFailure = n;
      this.isGtmEvent = p;
    },
    Io = function (a, b) {
      var c = [];
      switch (b) {
        case 3:
          c.push(a.C);
          c.push(a.V);
          c.push(a.H);
          c.push(a.T);
          c.push(a.P);
          break;
        case 2:
          c.push(a.C);
          break;
        case 1:
          c.push(a.V);
          c.push(a.H);
          c.push(a.T);
          c.push(a.P);
          break;
        case 4:
          c.push(a.C), c.push(a.V), c.push(a.H), c.push(a.T);
      }
      return c;
    },
    M = function (a, b, c, d) {
      for (
        var e = m(Io(a, d === void 0 ? 3 : d)), f = e.next();
        !f.done;
        f = e.next()
      ) {
        var g = f.value;
        if (g[b] !== void 0) return g[b];
      }
      return c;
    },
    Jo = function (a) {
      for (
        var b = {}, c = Io(a, 4), d = m(c), e = d.next();
        !e.done;
        e = d.next()
      )
        for (
          var f = Object.keys(e.value), g = m(f), h = g.next();
          !h.done;
          h = g.next()
        )
          b[h.value] = 1;
      return Object.keys(b);
    };
  Ho.prototype.getMergedValues = function (a, b, c) {
    function d(n) {
      rd(n) &&
        yb(n, function (p, q) {
          f = !0;
          e[p] = q;
        });
    }
    b = b === void 0 ? 3 : b;
    var e = {},
      f = !1;
    c && d(c);
    var g = Io(this, b);
    g.reverse();
    for (var h = m(g), l = h.next(); !l.done; l = h.next()) d(l.value[a]);
    return f ? e : void 0;
  };
  var Ko = function (a) {
      for (
        var b = [J.m.uf, J.m.pf, J.m.qf, J.m.rf, J.m.tf, J.m.vf, J.m.wf],
          c = Io(a, 3),
          d = m(c),
          e = d.next();
        !e.done;
        e = d.next()
      ) {
        for (
          var f = e.value, g = {}, h = !1, l = m(b), n = l.next();
          !n.done;
          n = l.next()
        ) {
          var p = n.value;
          f[p] !== void 0 && ((g[p] = f[p]), (h = !0));
        }
        var q = h ? g : void 0;
        if (q) return q;
      }
      return {};
    },
    Lo = function (a, b) {
      this.eventId = a;
      this.priorityId = b;
      this.H = {};
      this.V = {};
      this.C = {};
      this.P = {};
      this.la = {};
      this.T = {};
      this.eventMetadata = {};
      this.isGtmEvent = !1;
      this.onSuccess = function () {};
      this.onFailure = function () {};
    },
    Mo = function (a, b) {
      a.H = b;
      return a;
    },
    No = function (a, b) {
      a.V = b;
      return a;
    },
    Oo = function (a, b) {
      a.C = b;
      return a;
    },
    Po = function (a, b) {
      a.P = b;
      return a;
    },
    Qo = function (a, b) {
      a.la = b;
      return a;
    },
    cp = function (a, b) {
      a.T = b;
      return a;
    },
    dp = function (a, b) {
      a.eventMetadata = b || {};
      return a;
    },
    ep = function (a, b) {
      a.onSuccess = b;
      return a;
    },
    fp = function (a, b) {
      a.onFailure = b;
      return a;
    },
    gp = function (a, b) {
      a.isGtmEvent = b;
      return a;
    },
    hp = function (a) {
      return new Ho(
        a.eventId,
        a.priorityId,
        a.H,
        a.V,
        a.C,
        a.P,
        a.T,
        a.eventMetadata,
        a.onSuccess,
        a.onFailure,
        a.isGtmEvent
      );
    };
  var N = {
    A: {
      Hg: "accept_by_default",
      Ig: "add_tag_timing",
      Xd: "ads_event_page_view",
      Zc: "allow_ad_personalization",
      fk: "batch_on_navigation",
      jk: "client_id_source",
      Xe: "consent_event_id",
      Ye: "consent_priority_id",
      ds: "consent_state",
      fa: "consent_updated",
      Zd: "conversion_linker_enabled",
      Fa: "cookie_options",
      Lg: "create_dc_join",
      Mg: "create_fpm_geo_join",
      Ng: "create_fpm_signals_join",
      ae: "create_google_join",
      ei: "dc_random",
      be: "em_event",
      ks: "endpoint_for_debug",
      Ck: "enhanced_client_id_source",
      fi: "enhanced_match_result",
      Dl: "euid_logged_in_state",
      Ae: "euid_mode_enabled",
      eb: "event_start_timestamp_ms",
      Hl: "event_usage",
      Ei: "extra_tag_experiment_ids",
      zs: "add_parameter",
      Fi: "attribution_reporting_experiment",
      Gi: "counting_method",
      qh: "send_as_iframe",
      As: "parameter_order",
      rh: "parsed_target",
      lp: "ga4_collection_subdomain",
      Wl: "gbraid_cookie_marked",
      th: "handle_internally",
      ba: "hit_type",
      Bd: "hit_type_override",
      Uf: "ignore_hit_success_failure",
      Ds: "is_config_command",
      wh: "is_consent_update",
      Vf: "is_conversion",
      dm: "is_ecommerce",
      fm: "is_ec_cm_split",
      Cd: "is_external_event",
      Ki: "is_fallback_aw_conversion_ping_allowed",
      Wf: "is_first_visit",
      gm: "is_first_visit_conversion",
      xh: "is_fl_fallback_conversion_flow_allowed",
      Dd: "is_fpm_encryption",
      Li: "is_fpm_split",
      Hb: "is_gcp_conversion",
      hm: "is_google_signals_allowed",
      Ed: "is_merchant_center",
      yh: "is_new_to_site",
      zh: "is_personalization",
      Ah: "is_server_side_destination",
      De: "is_session_start",
      jm: "is_session_start_conversion",
      Es: "is_sgtm_ga_ads_conversion_study_control_group",
      Fs: "is_sgtm_prehit",
      km: "is_sgtm_service_worker",
      Mi: "is_split_conversion",
      rp: "is_syn",
      Xf: "join_id",
      Ni: "join_elapsed",
      Yf: "join_timer_sec",
      qm: "local_storage_aw_conversion_counters",
      He: "tunnel_updated",
      Js: "prehit_for_retry",
      Ls: "promises",
      Ms: "record_aw_latency",
      Rc: "redact_ads_data",
      Ie: "redact_click_ids",
      zm: "remarketing_only",
      Si: "send_ccm_parallel_ping",
      Os: "send_ccm_parallel_test_ping",
      eg: "send_to_destinations",
      Ti: "send_to_targets",
      Ep: "send_user_data_hit",
      Oa: "source_canonical_id",
      xa: "speculative",
      Hm: "speculative_in_message",
      Im: "suppress_script_load",
      Jm: "syn_or_mod",
      Om: "transient_ecsid",
      fg: "transmission_type",
      Ta: "user_data",
      Rs: "user_data_from_automatic",
      Ss: "user_data_from_automatic_getter",
      Qm: "user_data_from_code",
      Kp: "user_data_from_manual",
      Rm: "user_data_mode",
      gg: "user_id_updated",
    },
  };
  var ip = new xb(),
    jp = {},
    kp = {},
    np = {
      name: hg(19),
      set: function (a, b) {
        sd(Nb(a, b), jp);
        lp();
      },
      get: function (a) {
        return mp(a, 2);
      },
      reset: function () {
        ip = new xb();
        jp = {};
        lp();
      },
    };
  function mp(a, b) {
    return b != 2 ? ip.get(a) : op(a);
  }
  function op(a, b) {
    var c = a.split(".");
    b = b || [];
    for (var d = jp, e = 0; e < c.length; e++) {
      if (d === null) return !1;
      if (d === void 0) break;
      d = d[c[e]];
      if (b.indexOf(d) !== -1) return;
    }
    return d;
  }
  function pp(a, b) {
    kp.hasOwnProperty(a) || (ip.set(a, b), sd(Nb(a, b), jp), lp());
  }
  function qp() {
    for (
      var a = [
          "gtm.allowlist",
          "gtm.blocklist",
          "gtm.whitelist",
          "gtm.blacklist",
          "tagTypeBlacklist",
        ],
        b = 0;
      b < a.length;
      b++
    ) {
      var c = a[b],
        d = mp(c, 1);
      if (Array.isArray(d) || rd(d)) d = sd(d, null);
      kp[c] = d;
    }
  }
  function lp(a) {
    yb(kp, function (b, c) {
      ip.set(b, c);
      sd(Nb(b), jp);
      sd(Nb(b, c), jp);
      a && delete kp[b];
    });
  }
  function rp(a, b) {
    var c,
      d = (b === void 0 ? 2 : b) !== 1 ? op(a) : ip.get(a);
    pd(d) === "array" || pd(d) === "object" ? (c = sd(d, null)) : (c = d);
    return c;
  }
  var sp = { UA: 1, AW: 2, DC: 3, G: 4, GF: 5, GT: 12, GTM: 14, HA: 6, MC: 7 };
  function tp(a) {
    a = a === void 0 ? {} : a;
    var b = hg(5).split("-")[0].toUpperCase(),
      c,
      d = {
        ctid: hg(5),
        xn: ig(15),
        Bn: hg(14),
        er: gg(7) ? 2 : 1,
        Or: a.Dn,
        canonicalId: hg(6),
        Er: (c = Tj()) == null ? void 0 : c.canonicalContainerId,
        Pr: a.Ud === void 0 ? void 0 : a.Ud ? 10 : 12,
      };
    d.canonicalId !== a.Qa && (d.Qa = a.Qa);
    var e = Qj();
    d.mr = e ? e.canonicalContainerId : void 0;
    cj ? ((d.Wh = sp[b]), d.Wh || (d.Wh = 0)) : (d.Wh = dj ? 13 : 10);
    gg(47) ? ((d.Ej = 0), (d.Xp = 2)) : gg(50) ? (d.Ej = 1) : (d.Ej = 3);
    var f = { 6: !1 };
    ig(54) === 2 ? (f[7] = !0) : ig(54) === 1 && (f[2] = !0);
    if (Dc) {
      var g = sj(yj(Dc), "host");
      g && (f[8] = g.match(/^(www\.)?googletagmanager\.com$/) === null);
    }
    d.fq = f;
    return lf(d, a.Ih);
  }
  var up = { Ln: mg(3, 0) },
    vp = [],
    wp = !1;
  function xp(a) {
    vp.push(a);
  }
  var yp = void 0,
    zp = {},
    Ap = void 0,
    Bp = new (function () {
      var a = 5;
      up.Ln > 0 && (a = up.Ln);
      this.H = a;
      this.C = 0;
      this.P = [];
    })(),
    Cp = 1e3;
  function Dp(a, b) {
    var c = yp;
    if (c === void 0)
      if (b) c = fo();
      else return "";
    for (
      var d = [uk("https://" + hg(21)), "/a", "?id=" + hg(5)],
        e = m(vp),
        f = e.next();
      !f.done;
      f = e.next()
    )
      for (
        var g = f.value, h = g({ eventId: c, Wd: !!a }), l = m(h), n = l.next();
        !n.done;
        n = l.next()
      ) {
        var p = m(n.value),
          q = p.next().value,
          r = p.next().value;
        d.push("&" + q + "=" + r);
      }
    d.push("&z=0");
    return d.join("");
  }
  function Ep() {
    if (
      Ui.H &&
      (Ap && (x.clearTimeout(Ap), (Ap = void 0)), yp !== void 0 && Fp)
    ) {
      var a = gm(Hl.aa.Oc);
      if (cm(a)) wp || ((wp = !0), em(a, Ep));
      else {
        var b;
        if (!(b = zp[yp])) {
          var c = Bp;
          b = c.C < c.H ? !1 : Fb() - c.P[c.C % c.H] < 1e3;
        }
        if (b || Cp-- <= 0) K(1), (zp[yp] = !0);
        else {
          var d = Bp,
            e = d.C++ % d.H;
          d.P[e] = Fb();
          var f = Dp(!0);
          Bl({ destinationId: hg(5), endpoint: 56, eventId: yp }, f);
          wp = Fp = !1;
        }
      }
    }
  }
  function Gp() {
    if (Lk && Ui.H) {
      var a = Dp(!0, !0);
      Bl({ destinationId: hg(5), endpoint: 56, eventId: yp }, a);
    }
  }
  var Fp = !1;
  function Hp(a) {
    zp[a] ||
      (a !== yp && (Ep(), (yp = a)),
      (Fp = !0),
      Ap || (Ap = x.setTimeout(Ep, 500)),
      Dp().length >= 2022 && Ep());
  }
  var Ip = vb();
  function Jp() {
    Ip = vb();
  }
  function Kp() {
    var a = [
        ["v", "3"],
        ["t", "t"],
        ["pid", String(Ip)],
      ],
      b = tp();
    b && a.push(["gtm", b]);
    return a;
  }
  var Lp = {};
  function Mp(a, b, c) {
    Lk && a !== void 0 && ((Lp[a] = Lp[a] || []), Lp[a].push(c + b), Hp(a));
  }
  function Np(a) {
    var b = a.eventId,
      c = a.Wd,
      d = [],
      e = Lp[b] || [];
    e.length && d.push(["epr", e.join(".")]);
    c && delete Lp[b];
    return d;
  }
  function Op(a, b, c, d) {
    var e = lo(c, d.isGtmEvent);
    e && (bj && (d.deferrable = !0), Pp.push("event", [b, a], e, d));
  }
  function Qp(a, b, c, d) {
    var e = lo(c, d.isGtmEvent);
    e && Pp.push("get", [a, b], e, d);
  }
  function Rp(a) {
    var b = lo(a, !0),
      c;
    b ? (c = Sp(Pp, b).T) : (c = {});
    return c;
  }
  var Tp = function () {
      this.C = {};
      this.T = {};
      this.V = {};
      this.la = null;
      this.P = {};
      this.H = !1;
      this.status = 1;
    },
    Up = function (a, b, c, d) {
      this.H = Fb();
      this.C = b;
      this.args = c;
      this.messageContext = d;
      this.type = a;
    },
    Vp = function () {
      this.destinations = {};
      this.C = {};
      this.commands = [];
    },
    Sp = function (a, b) {
      return (a.destinations[b.destinationId] =
        a.destinations[b.destinationId] || new Tp());
    },
    Wp = function (a, b, c, d) {
      if (d.C) {
        var e = Sp(a, d.C),
          f = e.la;
        if (f) {
          var g = sd(c, null),
            h = sd(F(240) ? e.C[d.C.destinationId] : e.C[d.C.id], null),
            l = sd(e.P, null),
            n = sd(e.T, null),
            p = sd(a.C, null),
            q = {};
          if (Lk)
            try {
              q = sd(jp, null);
            } catch (w) {
              K(72);
            }
          var r = d.C.prefix,
            u = function (w) {
              Mp(d.messageContext.eventId, r, w);
            },
            t = hp(
              gp(
                fp(
                  ep(
                    dp(
                      Qo(
                        Po(
                          cp(
                            Oo(
                              No(
                                Mo(
                                  new Lo(
                                    d.messageContext.eventId,
                                    d.messageContext.priorityId
                                  ),
                                  g
                                ),
                                h
                              ),
                              l
                            ),
                            n
                          ),
                          p
                        ),
                        q
                      ),
                      d.messageContext.eventMetadata
                    ),
                    function () {
                      if (u) {
                        var w = u;
                        u = void 0;
                        w("2");
                        if (d.messageContext.onSuccess)
                          d.messageContext.onSuccess();
                      }
                    }
                  ),
                  function () {
                    if (u) {
                      var w = u;
                      u = void 0;
                      w("3");
                      if (d.messageContext.onFailure)
                        d.messageContext.onFailure();
                    }
                  }
                ),
                !!d.messageContext.isGtmEvent
              )
            ),
            v = function () {
              try {
                Mp(d.messageContext.eventId, r, "1");
                var w = d.type,
                  y = d.C.id;
                if (Nk && w === "config") {
                  var z,
                    D = (z = lo(y)) == null ? void 0 : z.ids;
                  if (!(D && D.length > 1)) {
                    var E,
                      L = Ec("google_tag_data", {});
                    L.td || (L.td = {});
                    E = L.td;
                    var I = sd(t.T);
                    sd(t.C, I);
                    var R = [],
                      X;
                    for (X in E)
                      E.hasOwnProperty(X) && yo(E[X], I).length && R.push(X);
                    R.length &&
                      (wo(y, R), jb("TAGGING", so[A.readyState] || 14));
                    E[y] = I;
                  }
                }
                f(d.C.id, b, d.H, t);
              } catch (Z) {
                Mp(d.messageContext.eventId, r, "4");
              }
            };
          b === "gtag.get" ? v() : em(e.wa, v);
        }
      }
    };
  Vp.prototype.register = function (a, b, c, d) {
    var e = Sp(this, a);
    e.status !== 3 &&
      ((e.la = b),
      (e.status = 3),
      (e.wa = gm(c)),
      Xp(this, a, d || {}),
      this.flush());
  };
  Vp.prototype.push = function (a, b, c, d) {
    c !== void 0 &&
      (Sp(this, c).status === 1 &&
        ((Sp(this, c).status = 2), this.push("require", [{}], c, {})),
      Sp(this, c).H && (d.deferrable = !1),
      d.eventMetadata || (d.eventMetadata = {}),
      d.eventMetadata[N.A.eg] || (d.eventMetadata[N.A.eg] = [c.destinationId]),
      d.eventMetadata[N.A.Ti] || (d.eventMetadata[N.A.Ti] = [c.id]));
    this.commands.push(new Up(a, c, b, d));
    d.deferrable || this.flush();
  };
  Vp.prototype.flush = function (a) {
    for (
      var b = this, c = [], d = !1, e = {};
      this.commands.length;
      e = { Tc: void 0, Kh: void 0, fj: void 0, gj: void 0 }
    ) {
      var f = this.commands[0],
        g = f.C;
      if (f.messageContext.deferrable)
        !g || Sp(this, g).H
          ? ((f.messageContext.deferrable = !1), this.commands.push(f))
          : c.push(f),
          this.commands.shift();
      else {
        switch (f.type) {
          case "require":
            if (Sp(this, g).status !== 3 && !a) {
              this.commands.push.apply(this.commands, c);
              return;
            }
            break;
          case "set":
            var h = f.args[0];
            yb(h, function (v, w) {
              sd(Nb(v, w), b.C);
            });
            Go(h, !0);
            break;
          case "config":
            var l = Sp(this, g);
            e.Tc = {};
            yb(
              f.args[0],
              (function (v) {
                return function (w, y) {
                  sd(Nb(w, y), v.Tc);
                };
              })(e)
            );
            var n = !!e.Tc[J.m.wd];
            delete e.Tc[J.m.wd];
            var p = g.destinationId === g.id;
            Go(e.Tc, !0);
            n || (p ? (l.P = {}) : (l.C[g.id] = {}));
            (l.H && n) || Wp(this, J.m.na, e.Tc, f);
            l.H = !0;
            p ? sd(e.Tc, l.P) : (sd(e.Tc, l.C[g.id]), K(70));
            d = !0;
            break;
          case "event":
            e.Kh = {};
            yb(
              f.args[0],
              (function (v) {
                return function (w, y) {
                  sd(Nb(w, y), v.Kh);
                };
              })(e)
            );
            Go(e.Kh);
            Wp(this, f.args[1], e.Kh, f);
            break;
          case "get":
            var q = {},
              r = ((q[J.m.Cf] = f.args[0]), (q[J.m.Bf] = f.args[1]), q);
            Wp(this, J.m.Ab, r, f);
            break;
          case "container_config":
            var u = Sp(this, g);
            e.fj = {};
            yb(
              f.args[0],
              (function (v) {
                return function (w, y) {
                  sd(Nb(w, y), v.fj);
                };
              })(e)
            );
            u.P = e.fj;
            d = u.H = !0;
            break;
          case "destination_config":
            var t = Sp(this, g);
            e.gj = {};
            yb(
              f.args[0],
              (function (v) {
                return function (w, y) {
                  sd(Nb(w, y), v.gj);
                };
              })(e)
            );
            t.C[g.id] || (t.C[g.id] = {});
            t.C[g.id] = e.gj;
            d = t.H = !0;
        }
        this.commands.shift();
        Yp(this, f);
      }
    }
    this.commands.push.apply(this.commands, c);
    d && this.flush();
  };
  var Yp = function (a, b) {
      if (b.type !== "require")
        if (b.C)
          for (var c = Sp(a, b.C).V[b.type] || [], d = 0; d < c.length; d++)
            c[d]();
        else
          for (var e in a.destinations)
            if (a.destinations.hasOwnProperty(e)) {
              var f = a.destinations[e];
              if (f && f.V)
                for (var g = f.V[b.type] || [], h = 0; h < g.length; h++)
                  g[h]();
            }
    },
    Xp = function (a, b, c) {
      var d = sd(c, null);
      sd(Sp(a, b).T, d);
      Sp(a, b).T = d;
    },
    Pp = new Vp();
  function Zp(a) {
    var b = a.location.href;
    if (a === a.top) return { url: b, Zq: !0 };
    var c = !1,
      d = a.document;
    d && d.referrer && ((b = d.referrer), a.parent === a.top && (c = !0));
    var e = a.location.ancestorOrigins;
    if (e) {
      var f = e[e.length - 1],
        g;
      f &&
        ((g = b) == null ? void 0 : g.indexOf(f)) === -1 &&
        ((c = !1), (b = f));
    }
    return { url: b, Zq: c };
  }
  function $p(a) {
    try {
      var b;
      if ((b = !!a && a.location.href != null))
        a: {
          try {
            ml(a.foo);
            b = !0;
            break a;
          } catch (c) {}
          b = !1;
        }
      return b;
    } catch (c) {
      return !1;
    }
  }
  function aq() {
    for (var a = x, b = a; a && a != a.parent; )
      (a = a.parent), $p(a) && (b = a);
    return b;
  }
  var bq = function (a, b) {
      var c = function () {};
      c.prototype = a.prototype;
      var d = new c();
      a.apply(d, Array.prototype.slice.call(arguments, 1));
      return d;
    },
    cq = function (a) {
      var b = a;
      return function () {
        if (b) {
          var c = b;
          b = null;
          c();
        }
      };
    };
  function dq(a, b) {
    if (a)
      for (var c in a)
        Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a);
  }
  var eq = function (a, b) {
      for (var c = a, d = 0; d < 50; ++d) {
        var e;
        try {
          e = !(!c.frames || !c.frames[b]);
        } catch (h) {
          e = !1;
        }
        if (e) return c;
        var f;
        a: {
          try {
            var g = c.parent;
            if (g && g != c) {
              f = g;
              break a;
            }
          } catch (h) {}
          f = null;
        }
        if (!(c = f)) break;
      }
      return null;
    },
    fq = function (a) {
      var b = x;
      if (b.top == b) return 0;
      if (a === void 0 ? 0 : a) {
        var c = b.location.ancestorOrigins;
        if (c) return c[c.length - 1] == b.location.origin ? 1 : 2;
      }
      return $p(b.top) ? 1 : 2;
    },
    gq = function (a) {
      a = a === void 0 ? document : a;
      return a.createElement("img");
    };
  function hq(a, b, c) {
    return typeof a.addEventListener === "function"
      ? (a.addEventListener(b, c, !1), !0)
      : !1;
  }
  function iq(a, b, c) {
    typeof a.removeEventListener === "function" &&
      a.removeEventListener(b, c, !1);
  }
  function jq(a, b, c, d) {
    d = d === void 0 ? !1 : d;
    a.google_image_requests || (a.google_image_requests = []);
    var e = gq(a.document);
    if (c) {
      var f = function () {
        if (c) {
          var g = a.google_image_requests,
            h = xc(g, e);
          h >= 0 && Array.prototype.splice.call(g, h, 1);
        }
        iq(e, "load", f);
        iq(e, "error", f);
      };
      hq(e, "load", f);
      hq(e, "error", f);
    }
    d && (e.attributionSrc = "");
    e.src = b;
    a.google_image_requests.push(e);
  }
  function kq(a) {
    var b;
    b = b === void 0 ? !1 : b;
    var c = "https://pagead2.googlesyndication.com/pagead/gen_204?id=tcfe";
    dq(a, function (d, e) {
      if (d || d === 0) c += "&" + e + "=" + encodeURIComponent(String(d));
    });
    lq(c, b);
  }
  function lq(a, b) {
    var c = window,
      d;
    b = b === void 0 ? !1 : b;
    d = d === void 0 ? !1 : d;
    if (c.fetch) {
      var e = {
        keepalive: !0,
        credentials: "include",
        redirect: "follow",
        method: "get",
        mode: "no-cors",
      };
      d &&
        ((e.mode = "cors"),
        "setAttributionReporting" in XMLHttpRequest.prototype
          ? (e.attributionReporting = {
              eventSourceEligible: "true",
              triggerEligible: "false",
            })
          : (e.headers = { "Attribution-Reporting-Eligible": "event-source" }));
      c.fetch(a, e);
    } else jq(c, a, b === void 0 ? !1 : b, d === void 0 ? !1 : d);
  }
  var mq = function () {
    this.la = this.la;
    this.T = this.T;
  };
  mq.prototype.la = !1;
  mq.prototype.dispose = function () {
    this.la || ((this.la = !0), this.P());
  };
  mq.prototype[Symbol.dispose] = function () {
    this.dispose();
  };
  mq.prototype.addOnDisposeCallback = function (a, b) {
    this.la
      ? b !== void 0
        ? a.call(b)
        : a()
      : (this.T || (this.T = []), b && (a = a.bind(b)), this.T.push(a));
  };
  mq.prototype.P = function () {
    if (this.T) for (; this.T.length; ) this.T.shift()();
  };
  function nq(a) {
    a.addtlConsent !== void 0 &&
      typeof a.addtlConsent !== "string" &&
      (a.addtlConsent = void 0);
    a.gdprApplies !== void 0 &&
      typeof a.gdprApplies !== "boolean" &&
      (a.gdprApplies = void 0);
    return (a.tcString !== void 0 && typeof a.tcString !== "string") ||
      (a.listenerId !== void 0 && typeof a.listenerId !== "number")
      ? 2
      : a.cmpStatus && a.cmpStatus !== "error"
      ? 0
      : 3;
  }
  var oq = function (a, b) {
    b = b === void 0 ? {} : b;
    mq.call(this);
    this.C = null;
    this.wa = {};
    this.Pc = 0;
    this.V = null;
    this.H = a;
    var c;
    this.wb = (c = b.timeoutMs) != null ? c : 500;
    var d;
    this.Za = (d = b.Xs) != null ? d : !1;
  };
  ua(oq, mq);
  oq.prototype.P = function () {
    this.wa = {};
    this.V && (iq(this.H, "message", this.V), delete this.V);
    delete this.wa;
    delete this.H;
    delete this.C;
    mq.prototype.P.call(this);
  };
  var qq = function (a) {
    return typeof a.H.__tcfapi === "function" || pq(a) != null;
  };
  oq.prototype.addEventListener = function (a) {
    var b = this,
      c = { internalBlockOnErrors: this.Za },
      d = cq(function () {
        return a(c);
      }),
      e = 0;
    this.wb !== -1 &&
      (e = setTimeout(function () {
        c.tcString = "tcunavailable";
        c.internalErrorState = 1;
        d();
      }, this.wb));
    var f = function (g, h) {
      clearTimeout(e);
      g
        ? ((c = g),
          (c.internalErrorState = nq(c)),
          (c.internalBlockOnErrors = b.Za),
          (h && c.internalErrorState === 0) ||
            ((c.tcString = "tcunavailable"), h || (c.internalErrorState = 3)))
        : ((c.tcString = "tcunavailable"), (c.internalErrorState = 3));
      a(c);
    };
    try {
      rq(this, "addEventListener", f);
    } catch (g) {
      (c.tcString = "tcunavailable"),
        (c.internalErrorState = 3),
        e && (clearTimeout(e), (e = 0)),
        d();
    }
  };
  oq.prototype.removeEventListener = function (a) {
    a && a.listenerId && rq(this, "removeEventListener", null, a.listenerId);
  };
  var tq = function (a, b, c) {
      var d;
      d = d === void 0 ? "755" : d;
      var e;
      a: {
        if (a.publisher && a.publisher.restrictions) {
          var f = a.publisher.restrictions[b];
          if (f !== void 0) {
            e = f[d === void 0 ? "755" : d];
            break a;
          }
        }
        e = void 0;
      }
      var g = e;
      if (g === 0) return !1;
      var h = c;
      c === 2
        ? ((h = 0), g === 2 && (h = 1))
        : c === 3 && ((h = 1), g === 1 && (h = 0));
      var l;
      if (h === 0)
        if (a.purpose && a.vendor) {
          var n = sq(a.vendor.consents, d === void 0 ? "755" : d);
          l =
            n && b === "1" && a.purposeOneTreatment && a.publisherCC === "CH"
              ? !0
              : n && sq(a.purpose.consents, b);
        } else l = !0;
      else
        l =
          h === 1
            ? a.purpose && a.vendor
              ? sq(a.purpose.legitimateInterests, b) &&
                sq(a.vendor.legitimateInterests, d === void 0 ? "755" : d)
              : !0
            : !0;
      return l;
    },
    sq = function (a, b) {
      return !(!a || !a[b]);
    },
    rq = function (a, b, c, d) {
      c || (c = function () {});
      var e = a.H;
      if (typeof e.__tcfapi === "function") {
        var f = e.__tcfapi;
        f(b, 2, c, d);
      } else if (pq(a)) {
        uq(a);
        var g = ++a.Pc;
        a.wa[g] = c;
        if (a.C) {
          var h = {};
          a.C.postMessage(
            ((h.__tcfapiCall = {
              command: b,
              version: 2,
              callId: g,
              parameter: d,
            }),
            h),
            "*"
          );
        }
      } else c({}, !1);
    },
    pq = function (a) {
      if (a.C) return a.C;
      a.C = eq(a.H, "__tcfapiLocator");
      return a.C;
    },
    uq = function (a) {
      if (!a.V) {
        var b = function (c) {
          try {
            var d;
            d = (typeof c.data === "string" ? JSON.parse(c.data) : c.data)
              .__tcfapiReturn;
            a.wa[d.callId](d.returnValue, d.success);
          } catch (e) {}
        };
        a.V = b;
        hq(a.H, "message", b);
      }
    },
    vq = function (a) {
      if (a.gdprApplies === !1) return !0;
      a.internalErrorState === void 0 && (a.internalErrorState = nq(a));
      return a.cmpStatus === "error" || a.internalErrorState !== 0
        ? a.internalBlockOnErrors
          ? (kq({ e: String(a.internalErrorState) }), !1)
          : !0
        : a.cmpStatus !== "loaded" ||
          (a.eventStatus !== "tcloaded" &&
            a.eventStatus !== "useractioncomplete")
        ? !1
        : !0;
    };
  var wq = { 1: 0, 3: 0, 4: 0, 7: 3, 9: 3, 10: 3 };
  mg(32, 500);
  function xq() {
    return $n("tcf", function () {
      return {};
    });
  }
  var yq = function () {
    return new oq(x, { timeoutMs: -1 });
  };
  function zq() {
    var a = xq(),
      b = yq();
    qq(b) && !Aq() && !Bq() && K(124);
    if (!a.active && qq(b)) {
      Aq() &&
        ((a.active = !0),
        (a.purposes = {}),
        (a.cmpId = 0),
        (a.tcfPolicyVersion = 0),
        (Il().active = !0),
        (a.tcString = "tcunavailable"));
      Wn();
      try {
        b.addEventListener(function (c) {
          if (c.internalErrorState !== 0)
            Cq(a), Xn([J.m.W, J.m.La, J.m.X]), (Il().active = !0);
          else if (
            ((a.gdprApplies = c.gdprApplies),
            (a.cmpId = c.cmpId),
            (a.enableAdvertiserConsentMode = c.enableAdvertiserConsentMode),
            Bq() && (a.active = !0),
            !Dq(c) || Aq() || Bq())
          ) {
            a.tcfPolicyVersion = c.tcfPolicyVersion;
            var d;
            if (c.gdprApplies === !1) {
              var e = {},
                f;
              for (f in wq) wq.hasOwnProperty(f) && (e[f] = !0);
              d = e;
              b.removeEventListener(c);
            } else if (Dq(c)) {
              var g = {},
                h;
              for (h in wq)
                if (wq.hasOwnProperty(h))
                  if (h === "1") {
                    var l,
                      n = c,
                      p = { Bq: !0 };
                    p = p === void 0 ? {} : p;
                    l = vq(n)
                      ? n.gdprApplies === !1
                        ? !0
                        : n.tcString === "tcunavailable"
                        ? !p.idpcApplies
                        : (p.idpcApplies || n.gdprApplies !== void 0 || p.Bq) &&
                          (p.idpcApplies ||
                            (typeof n.tcString === "string" &&
                              n.tcString.length))
                        ? tq(n, "1", 0)
                        : !0
                      : !1;
                    g["1"] = l;
                  } else g[h] = tq(c, h, wq[h]);
              d = g;
            }
            if (d) {
              a.tcString = c.tcString || "tcempty";
              a.purposes = d;
              var q = {},
                r = ((q[J.m.W] = a.purposes["1"] ? "granted" : "denied"), q);
              a.gdprApplies !== !0
                ? (Xn([J.m.W, J.m.La, J.m.X]), (Il().active = !0))
                : ((r[J.m.La] =
                    a.purposes["3"] && a.purposes["4"] ? "granted" : "denied"),
                  typeof a.tcfPolicyVersion === "number" &&
                  a.tcfPolicyVersion >= 4
                    ? (r[J.m.X] =
                        a.purposes["1"] && a.purposes["7"]
                          ? "granted"
                          : "denied")
                    : Xn([J.m.X]),
                  Qn(
                    r,
                    { eventId: 0 },
                    {
                      gdprApplies: a ? a.gdprApplies : void 0,
                      tcString: Eq() || "",
                    }
                  ));
            }
          } else Xn([J.m.W, J.m.La, J.m.X]);
        });
      } catch (c) {
        Cq(a), Xn([J.m.W, J.m.La, J.m.X]), (Il().active = !0);
      }
    }
  }
  function Cq(a) {
    a.type = "e";
    a.tcString = "tcunavailable";
  }
  function Dq(a) {
    return (
      a.eventStatus === "tcloaded" ||
      a.eventStatus === "useractioncomplete" ||
      a.eventStatus === "cmpuishown"
    );
  }
  function Aq() {
    return x.gtag_enable_tcf_support === !0;
  }
  function Bq() {
    return xq().enableAdvertiserConsentMode === !0;
  }
  function Eq() {
    var a = xq();
    if (a.active) return a.tcString;
  }
  function Fq() {
    var a = xq();
    if (a.active && a.gdprApplies !== void 0) return a.gdprApplies ? "1" : "0";
  }
  function Gq(a) {
    if (!wq.hasOwnProperty(String(a))) return !0;
    var b = xq();
    return b.active && b.purposes ? !!b.purposes[String(a)] : !0;
  }
  var Hq = [J.m.W, J.m.ja, J.m.X, J.m.La],
    Iq = {},
    Jq = ((Iq[J.m.W] = 1), (Iq[J.m.ja] = 2), Iq);
  function Kq(a) {
    if (a === void 0) return 0;
    switch (M(a, J.m.Rb)) {
      case void 0:
        return 1;
      case !1:
        return 3;
      default:
        return 2;
    }
  }
  function Lq() {
    return (
      (F(183) ? kg(16).split("~") : kg(17).split("~")).indexOf(Qm()) !== -1 &&
      Ac.globalPrivacyControl === !0
    );
  }
  function Mq(a) {
    if (Lq()) return !1;
    var b = Kq(a);
    if (b === 3) return !1;
    switch (Rl(J.m.La)) {
      case 1:
      case 3:
        return !0;
      case 2:
        return !1;
      case 4:
        return b === 2;
      case 0:
        return !0;
      default:
        return !1;
    }
  }
  function Nq() {
    return Tl() || !Ql(J.m.W) || !Ql(J.m.ja);
  }
  function Oq() {
    var a = {},
      b;
    for (b in Jq) Jq.hasOwnProperty(b) && (a[Jq[b]] = Rl(b));
    return "G1" + hf(a[1] || 0) + hf(a[2] || 0);
  }
  var Pq = {},
    Qq =
      ((Pq[J.m.W] = 0),
      (Pq[J.m.ja] = 1),
      (Pq[J.m.X] = 2),
      (Pq[J.m.La] = 3),
      Pq);
  function Rq(a) {
    switch (a) {
      case void 0:
        return 1;
      case !0:
        return 3;
      case !1:
        return 2;
      default:
        return 0;
    }
  }
  function Sq(a) {
    for (var b = "1", c = 0; c < Hq.length; c++) {
      var d = b,
        e,
        f = Hq[c],
        g = Pl.delegatedConsentTypes[f];
      e = g === void 0 ? 0 : Qq.hasOwnProperty(g) ? 12 | Qq[g] : 8;
      var h = Il();
      h.accessedAny = !0;
      var l = h.entries[f] || {};
      e = (e << 2) | Rq(l.implicit);
      b =
        d +
        ("" +
          "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[
            e
          ] +
          "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[
            (Rq(l.declare) << 4) | (Rq(l.default) << 2) | Rq(l.update)
          ]);
    }
    var n = b,
      p = (Lq() ? 1 : 0) << 3,
      q = (Tl() ? 1 : 0) << 2,
      r = Kq(a);
    b =
      n +
      "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[
        p | q | r
      ];
    return (b +=
      "" +
      "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[
        (Pl.containerScopedDefaults.ad_storage << 4) |
          (Pl.containerScopedDefaults.analytics_storage << 2) |
          Pl.containerScopedDefaults.ad_user_data
      ] +
      "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[
        ((Pl.usedContainerScopedDefaults ? 1 : 0) << 2) |
          Pl.containerScopedDefaults.ad_personalization
      ]);
  }
  function Tq() {
    if (!Ql(J.m.X)) return "-";
    if (F(170)) return "a";
    for (
      var a = Object.keys(hn), b = {}, c = m(a), d = c.next();
      !d.done;
      d = c.next()
    ) {
      var e = d.value;
      b[e] = Pl.corePlatformServices[e] !== !1;
    }
    for (var f = "", g = m(a), h = g.next(); !h.done; h = g.next()) {
      var l = h.value;
      b[l] && (f += hn[l]);
    }
    (Pl.usedCorePlatformServices ? Pl.selectedAllCorePlatformServices : 1) &&
      (f += "o");
    return f || "-";
  }
  function Uq() {
    return Sm() || ((Aq() || Bq()) && Fq() === "1") ? "1" : "0";
  }
  function Vq() {
    return (Sm() ? !0 : !(!Aq() && !Bq()) && Fq() === "1") || !Ql(J.m.X);
  }
  function Wq() {
    var a = "0",
      b = "0",
      c;
    var d = xq();
    c = d.active ? d.cmpId : void 0;
    typeof c === "number" &&
      c >= 0 &&
      c <= 4095 &&
      ((a = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[
        (c >> 6) & 63
      ]),
      (b = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[
        c & 63
      ]));
    var e = "0",
      f;
    var g = xq();
    f = g.active ? g.tcfPolicyVersion : void 0;
    typeof f === "number" &&
      f >= 0 &&
      f <= 63 &&
      (e = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[
        f
      ]);
    var h = 0;
    Sm() && (h |= 1);
    Fq() === "1" && (h |= 2);
    Aq() && (h |= 4);
    var l;
    var n = xq();
    l =
      n.enableAdvertiserConsentMode !== void 0
        ? n.enableAdvertiserConsentMode
          ? "1"
          : "0"
        : void 0;
    l === "1" && (h |= 8);
    Il().waitPeriodTimedOut && (h |= 16);
    return (
      "1" +
      a +
      b +
      e +
      "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[h]
    );
  }
  function Xq() {
    return Qm() === "US-CO";
  }
  function Yq(a, b, c, d) {
    var e,
      f = Number(a.Wc != null ? a.Wc : void 0);
    f !== 0 && (e = new Date((b || Fb()) + 1e3 * (f || 7776e3)));
    return {
      path: a.path,
      domain: a.domain,
      flags: a.flags,
      encode: !!c,
      expires: e,
      wc: d,
    };
  }
  var Zq = ["ad_storage", "ad_user_data"];
  function $q(a, b) {
    if (!a) return jb("TAGGING", 32), 10;
    if (b === null || b === void 0 || b === "") return jb("TAGGING", 33), 11;
    var c = ar(!1);
    if (c.error !== 0) return jb("TAGGING", 34), c.error;
    if (!c.value) return jb("TAGGING", 35), 2;
    c.value[a] = b;
    var d = br(c);
    d !== 0 && jb("TAGGING", 36);
    return d;
  }
  function cr(a) {
    if (!a) return jb("TAGGING", 27), { error: 10 };
    var b = ar();
    if (b.error !== 0) return jb("TAGGING", 29), b;
    if (!b.value) return jb("TAGGING", 30), { error: 2 };
    if (!(a in b.value)) return jb("TAGGING", 31), { value: void 0, error: 15 };
    var c = b.value[a];
    return c === null || c === void 0 || c === ""
      ? (jb("TAGGING", 28), { value: void 0, error: 11 })
      : { value: c, error: 0 };
  }
  function ar(a) {
    a = a === void 0 ? !0 : a;
    if (!Ql(Zq)) return jb("TAGGING", 43), { error: 3 };
    try {
      if (!x.localStorage) return jb("TAGGING", 44), { error: 1 };
    } catch (f) {
      return jb("TAGGING", 45), { error: 14 };
    }
    var b = { schema: "gcl", version: 1 },
      c = void 0;
    try {
      c = x.localStorage.getItem("_gcl_ls");
    } catch (f) {
      return jb("TAGGING", 46), { error: 13 };
    }
    try {
      if (c) {
        var d = JSON.parse(c);
        if (d && typeof d === "object") b = d;
        else return jb("TAGGING", 47), { error: 12 };
      }
    } catch (f) {
      return jb("TAGGING", 48), { error: 8 };
    }
    if (b.schema !== "gcl") return jb("TAGGING", 49), { error: 4 };
    if (b.version !== 1) return jb("TAGGING", 50), { error: 5 };
    try {
      var e = dr(b);
      a && e && br({ value: b, error: 0 });
    } catch (f) {
      return jb("TAGGING", 48), { error: 8 };
    }
    return { value: b, error: 0 };
  }
  function dr(a) {
    if (!a || typeof a !== "object") return !1;
    if ("expires" in a && "value" in a) {
      var b;
      typeof a.expires === "number"
        ? (b = a.expires)
        : (b = typeof a.expires === "string" ? Number(a.expires) : NaN);
      if (isNaN(b) || !(Date.now() <= b))
        return (a.value = null), (a.error = 9), jb("TAGGING", 54), !0;
    } else {
      for (
        var c = !1, d = m(Object.keys(a)), e = d.next();
        !e.done;
        e = d.next()
      )
        c = dr(a[e.value]) || c;
      return c;
    }
    return !1;
  }
  function br(a) {
    if (a.error) return a.error;
    if (!a.value) return jb("TAGGING", 42), 2;
    var b = a.value,
      c;
    try {
      c = JSON.stringify(b);
    } catch (d) {
      return jb("TAGGING", 52), 6;
    }
    try {
      x.localStorage.setItem("_gcl_ls", c);
    } catch (d) {
      return jb("TAGGING", 53), 7;
    }
    return 0;
  }
  var er = { yg: "value", fb: "conversionCount", zg: 1 },
    fr = { Qh: 9, Vh: 10, yg: "timeouts", fb: "timeouts", zg: 0 },
    gr = { Qh: 11, Vh: 12, yg: "errors", fb: "errors", zg: 0 },
    hr = [
      er,
      fr,
      gr,
      { Qh: 13, Vh: 14, yg: "eopCount", fb: "endOfPageCount", zg: 0 },
    ];
  function ir(a) {
    var b;
    b = b === void 0 ? 1 : b;
    if (!jr(a)) return {};
    var c = kr(hr),
      d = c[a.fb];
    if (d === void 0 || d === -1) return c;
    var e = {},
      f = la(Object, "assign").call(Object, {}, c, ((e[a.fb] = d + b), e));
    return lr(f) ? f : c;
  }
  function kr(a) {
    var b;
    a: {
      var c = cr("gcl_ctr");
      if (c.error === 0 && c.value && typeof c.value === "object") {
        var d = c.value;
        try {
          b = "value" in d && typeof d.value === "object" ? d.value : void 0;
          break a;
        } catch (p) {}
      }
      b = void 0;
    }
    for (var e = b, f = {}, g = m(a), h = g.next(); !h.done; h = g.next()) {
      var l = h.value;
      if (e && jr(l)) {
        var n = e[l.yg];
        n === void 0 || Number.isNaN(n)
          ? (f[l.fb] = -1)
          : (f[l.fb] = Number(n));
      } else f[l.fb] = -1;
    }
    return f;
  }
  function lr(a, b) {
    b = b || {};
    for (
      var c = Fb(), d = Yq(b, c, !0), e = {}, f = m(hr), g = f.next();
      !g.done;
      g = f.next()
    ) {
      var h = g.value,
        l = a[h.fb];
      l !== void 0 && l !== -1 && (e[h.yg] = l);
    }
    e.creationTimeMs = c;
    return $q("gcl_ctr", { value: e, expires: Number(d.expires) }) === 0
      ? !0
      : !1;
  }
  function jr(a) {
    return Ql(["ad_storage", "ad_user_data"]) ? !a.Vh || Ua(a.Vh) : !1;
  }
  function mr(a) {
    return Ql(["ad_storage", "ad_user_data"]) ? !a.Qh || Ua(a.Qh) : !1;
  }
  var nr = {
    N: {
      Dp: 0,
      Xj: 1,
      Kg: 2,
      mk: 3,
      Zh: 4,
      kk: 5,
      lk: 6,
      nk: 7,
      ai: 8,
      Fl: 9,
      El: 10,
      Di: 11,
      Gl: 12,
      ph: 13,
      Pl: 14,
      cg: 15,
      Cp: 16,
      Je: 17,
      Yi: 18,
      Zi: 19,
      aj: 20,
      Lm: 21,
      bj: 22,
      di: 23,
      xk: 24,
    },
  };
  nr.N[nr.N.Dp] = "RESERVED_ZERO";
  nr.N[nr.N.Xj] = "ADS_CONVERSION_HIT";
  nr.N[nr.N.Kg] = "CONTAINER_EXECUTE_START";
  nr.N[nr.N.mk] = "CONTAINER_SETUP_END";
  nr.N[nr.N.Zh] = "CONTAINER_SETUP_START";
  nr.N[nr.N.kk] = "CONTAINER_BLOCKING_END";
  nr.N[nr.N.lk] = "CONTAINER_EXECUTE_END";
  nr.N[nr.N.nk] = "CONTAINER_YIELD_END";
  nr.N[nr.N.ai] = "CONTAINER_YIELD_START";
  nr.N[nr.N.Fl] = "EVENT_EXECUTE_END";
  nr.N[nr.N.El] = "EVENT_EVALUATION_END";
  nr.N[nr.N.Di] = "EVENT_EVALUATION_START";
  nr.N[nr.N.Gl] = "EVENT_SETUP_END";
  nr.N[nr.N.ph] = "EVENT_SETUP_START";
  nr.N[nr.N.Pl] = "GA4_CONVERSION_HIT";
  nr.N[nr.N.cg] = "PAGE_LOAD";
  nr.N[nr.N.Cp] = "PAGEVIEW";
  nr.N[nr.N.Je] = "SNIPPET_LOAD";
  nr.N[nr.N.Yi] = "TAG_CALLBACK_ERROR";
  nr.N[nr.N.Zi] = "TAG_CALLBACK_FAILURE";
  nr.N[nr.N.aj] = "TAG_CALLBACK_SUCCESS";
  nr.N[nr.N.Lm] = "TAG_EXECUTE_END";
  nr.N[nr.N.bj] = "TAG_EXECUTE_START";
  nr.N[nr.N.di] = "CUSTOM_PERFORMANCE_START";
  nr.N[nr.N.xk] = "CUSTOM_PERFORMANCE_END";
  var or = [],
    pr = {},
    qr = {};
  function rr(a) {
    if (Ua(21) && or.includes(a)) {
      var b;
      (b = gd()) == null || b.mark(a + "-" + nr.N.di + "-" + (qr[a] || 0));
    }
  }
  function sr(a) {
    if (Ua(21) && or.includes(a)) {
      var b = a + "-" + nr.N.xk + "-" + (qr[a] || 0),
        c = { start: a + "-" + nr.N.di + "-" + (qr[a] || 0), end: b },
        d;
      (d = gd()) == null || d.mark(b);
      var e,
        f,
        g =
          (f = (e = gd()) == null ? void 0 : e.measure(b, c)) == null
            ? void 0
            : f.duration;
      g !== void 0 && ((qr[a] = (qr[a] || 0) + 1), (pr[a] = g + (pr[a] || 0)));
    }
  }
  var tr = ["3", "4"];
  function ur(a) {
    return a.origin !== "null";
  }
  function vr(a, b, c, d) {
    try {
      rr("3");
      var e;
      return (e = wr(
        function (f) {
          return f === a;
        },
        b,
        c,
        d
      )[a]) != null
        ? e
        : [];
    } finally {
      sr("3");
    }
  }
  function wr(a, b, c, d) {
    var e;
    if (xr(d)) {
      for (
        var f = {}, g = String(b || yr()).split(";"), h = 0;
        h < g.length;
        h++
      ) {
        var l = g[h].split("="),
          n = l[0].trim();
        if (n && a(n)) {
          var p = l.slice(1).join("=").trim();
          p && c && (p = decodeURIComponent(p));
          var q = void 0,
            r = void 0;
          ((q = f)[(r = n)] || (q[r] = [])).push(p);
        }
      }
      e = f;
    } else e = {};
    return e;
  }
  function zr(a, b, c, d, e) {
    if (xr(e)) {
      var f = Ar(a, d, e);
      if (f.length === 1) return f[0];
      if (f.length !== 0) {
        f = Br(
          f,
          function (g) {
            return g.qq;
          },
          b
        );
        if (f.length === 1) return f[0];
        f = Br(
          f,
          function (g) {
            return g.qr;
          },
          c
        );
        return f[0];
      }
    }
  }
  function Cr(a, b, c, d) {
    var e = yr(),
      f = window;
    ur(f) && (f.document.cookie = a);
    var g = yr();
    return e !== g || (c !== void 0 && vr(b, g, !1, d).indexOf(c) >= 0);
  }
  function Dr(a, b, c, d) {
    function e(w, y, z) {
      if (z == null) return delete h[y], w;
      h[y] = z;
      return w + "; " + y + "=" + z;
    }
    function f(w, y) {
      if (y == null) return w;
      h[y] = !0;
      return w + "; " + y;
    }
    if (!xr(c.wc)) return 2;
    var g;
    b == null
      ? (g = a + "=deleted; expires=" + new Date(0).toUTCString())
      : (c.encode && (b = encodeURIComponent(b)),
        (b = Er(b)),
        (g = a + "=" + b));
    var h = {};
    g = e(g, "path", c.path);
    var l;
    c.expires instanceof Date
      ? (l = c.expires.toUTCString())
      : c.expires != null && (l = "" + c.expires);
    g = e(g, "expires", l);
    g = e(g, "max-age", c.ir);
    g = e(g, "samesite", c.Gr);
    c.secure && (g = f(g, "secure"));
    var n = c.domain;
    if (n && n.toLowerCase() === "auto") {
      for (var p = Fr(), q = void 0, r = !1, u = 0; u < p.length; ++u) {
        var t = p[u] !== "none" ? p[u] : void 0,
          v = e(g, "domain", t);
        v = f(v, c.flags);
        try {
          d && d(a, h);
        } catch (w) {
          q = w;
          continue;
        }
        r = !0;
        if (!Gr(t, c.path) && Cr(v, a, b, c.wc)) return 0;
      }
      if (q && !r) throw q;
      return 1;
    }
    n && n.toLowerCase() !== "none" && (g = e(g, "domain", n));
    g = f(g, c.flags);
    d && d(a, h);
    return Gr(n, c.path) ? 1 : Cr(g, a, b, c.wc) ? 0 : 1;
  }
  function Hr(a, b, c) {
    c.path == null && (c.path = "/");
    c.domain || (c.domain = "auto");
    rr("2");
    var d = Dr(a, b, c);
    sr("2");
    return d;
  }
  function Br(a, b, c) {
    for (var d = [], e = [], f, g = 0; g < a.length; g++) {
      var h = a[g],
        l = b(h);
      l === c
        ? d.push(h)
        : f === void 0 || l < f
        ? ((e = [h]), (f = l))
        : l === f && e.push(h);
    }
    return d.length > 0 ? d : e;
  }
  function Ar(a, b, c) {
    for (var d = [], e = vr(a, void 0, void 0, c), f = 0; f < e.length; f++) {
      var g = e[f].split("."),
        h = g.shift();
      if (!b || !h || b.indexOf(h) !== -1) {
        var l = g.shift();
        if (l) {
          var n = l.split("-");
          d.push({
            hq: e[f],
            iq: g.join("."),
            qq: Number(n[0]) || 1,
            qr: Number(n[1]) || 1,
          });
        }
      }
    }
    return d;
  }
  function Er(a) {
    a && a.length > 1200 && (a = a.substring(0, 1200));
    return a;
  }
  var Ir = /^(www\.)?google(\.com?)?(\.[a-z]{2})?$/,
    Jr = /(^|\.)doubleclick\.net$/i;
  function Gr(a, b) {
    return (
      a !== void 0 &&
      (Jr.test(window.document.location.hostname) || (b === "/" && Ir.test(a)))
    );
  }
  function Kr(a) {
    if (!a) return 1;
    var b = a;
    Ua(6) && a === "none" && (b = window.document.location.hostname);
    b = b.indexOf(".") === 0 ? b.substring(1) : b;
    return b.split(".").length;
  }
  function Lr(a) {
    if (!a || a === "/") return 1;
    a[0] !== "/" && (a = "/" + a);
    a[a.length - 1] !== "/" && (a += "/");
    return a.split("/").length - 1;
  }
  function Mr(a, b) {
    var c = "" + Kr(a),
      d = Lr(b);
    d > 1 && (c += "-" + d);
    return c;
  }
  var yr = function () {
      return ur(window) ? window.document.cookie : "";
    },
    xr = function (a) {
      return a && Ua(7)
        ? (Array.isArray(a) ? a : [a]).every(function (b) {
            return Sl(b) && Ql(b);
          })
        : !0;
    },
    Fr = function () {
      var a = [],
        b = window.document.location.hostname.split(".");
      if (b.length === 4) {
        var c = b[b.length - 1];
        if (Number(c).toString() === c) return ["none"];
      }
      for (var d = b.length - 2; d >= 0; d--) a.push(b.slice(d).join("."));
      var e = window.document.location.hostname;
      Jr.test(e) || Ir.test(e) || a.push("none");
      return a;
    };
  function Nr(a) {
    var b = Math.round(Math.random() * 2147483647);
    return a ? String(b ^ (di(a) & 2147483647)) : String(b);
  }
  function Or(a) {
    return [Nr(a), Math.round(Fb() / 1e3)].join(".");
  }
  function Pr(a, b, c, d, e) {
    var f = Kr(b),
      g;
    return (g = zr(a, f, Lr(c), d, e)) == null ? void 0 : g.iq;
  }
  var Qr;
  function Rr() {
    function a(g) {
      c(g.target || g.srcElement || {});
    }
    function b(g) {
      d(g.target || g.srcElement || {});
    }
    var c = Sr,
      d = Tr,
      e = Ur();
    if (!e.init) {
      Rc(A, "mousedown", a);
      Rc(A, "keyup", a);
      Rc(A, "submit", b);
      var f = HTMLFormElement.prototype.submit;
      HTMLFormElement.prototype.submit = function () {
        d(this);
        f.call(this);
      };
      e.init = !0;
    }
  }
  function Vr(a, b, c, d, e) {
    var f = {
      callback: a,
      domains: b,
      fragment: c === 2,
      placement: c,
      forms: d,
      sameHost: e,
    };
    Ur().decorators.push(f);
  }
  function Wr(a, b, c) {
    for (var d = Ur().decorators, e = {}, f = 0; f < d.length; ++f) {
      var g = d[f],
        h;
      if ((h = !c || g.forms))
        a: {
          var l = g.domains,
            n = a,
            p = !!g.sameHost;
          if (l && (p || n !== A.location.hostname))
            for (var q = 0; q < l.length; q++)
              if (l[q] instanceof RegExp) {
                if (l[q].test(n)) {
                  h = !0;
                  break a;
                }
              } else if (n.indexOf(l[q]) >= 0 || (p && l[q].indexOf(n) >= 0)) {
                h = !0;
                break a;
              }
          h = !1;
        }
      if (h) {
        var r = g.placement;
        r === void 0 && (r = g.fragment ? 2 : 1);
        r === b && Ib(e, g.callback());
      }
    }
    return e;
  }
  function Ur() {
    var a = Ec("google_tag_data", {}),
      b = a.gl;
    (b && b.decorators) || ((b = { decorators: [] }), (a.gl = b));
    return b;
  }
  var Xr = /(.*?)\*(.*?)\*(.*)/,
    Yr = /^https?:\/\/([^\/]*?)\.?cdn\.ampproject\.org\/?(.*)/,
    Zr = /^(?:www\.|m\.|amp\.)+/,
    $r = /([^?#]+)(\?[^#]*)?(#.*)?/;
  function as(a) {
    var b = $r.exec(a);
    if (b) return { Lj: b[1], query: b[2], fragment: b[3] };
  }
  function bs(a) {
    return new RegExp("(.*?)(^|&)" + a + "=([^&]*)&?(.*)");
  }
  function cs(a, b) {
    var c = [
        Ac.userAgent,
        new Date().getTimezoneOffset(),
        Ac.userLanguage || Ac.language,
        Math.floor(Fb() / 60 / 1e3) - (b === void 0 ? 0 : b),
        a,
      ].join("*"),
      d;
    if (!(d = Qr)) {
      for (var e = Array(256), f = 0; f < 256; f++) {
        for (var g = f, h = 0; h < 8; h++)
          g = g & 1 ? (g >>> 1) ^ 3988292384 : g >>> 1;
        e[f] = g;
      }
      d = e;
    }
    Qr = d;
    for (var l = 4294967295, n = 0; n < c.length; n++)
      l = (l >>> 8) ^ Qr[(l ^ c.charCodeAt(n)) & 255];
    return ((l ^ -1) >>> 0).toString(36);
  }
  function ds(a) {
    return function (b) {
      var c = yj(x.location.href),
        d = c.search.replace("?", ""),
        e = pj(d, "_gl", !1, !0) || "";
      b.query = es(e) || {};
      var f = sj(c, "fragment"),
        g;
      var h = -1;
      if (Kb(f, "_gl=")) h = 4;
      else {
        var l = f.indexOf("&_gl=");
        l > 0 && (h = l + 3 + 2);
      }
      if (h < 0) g = void 0;
      else {
        var n = f.indexOf("&", h);
        g = n < 0 ? f.substring(h) : f.substring(h, n);
      }
      b.fragment = es(g || "") || {};
      a && fs(c, d, f);
    };
  }
  function gs(a, b) {
    var c = bs(a).exec(b),
      d = b;
    if (c) {
      var e = c[2],
        f = c[4];
      d = c[1];
      f && (d = d + e + f);
    }
    return d;
  }
  function fs(a, b, c) {
    function d(g, h) {
      var l = gs("_gl", g);
      l.length && (l = h + l);
      return l;
    }
    if (zc && zc.replaceState) {
      var e = bs("_gl");
      if (e.test(b) || e.test(c)) {
        var f = sj(a, "path");
        b = d(b, "?");
        c = d(c, "#");
        zc.replaceState({}, "", "" + f + b + c);
      }
    }
  }
  function hs(a, b) {
    var c = ds(!!b),
      d = Ur();
    d.data || ((d.data = { query: {}, fragment: {} }), c(d.data));
    var e = {},
      f = d.data;
    f && (Ib(e, f.query), a && Ib(e, f.fragment));
    return e;
  }
  var es = function (a) {
    try {
      var b = is(a, 3);
      if (b !== void 0) {
        for (
          var c = {}, d = b ? b.split("*") : [], e = 0;
          e + 1 < d.length;
          e += 2
        ) {
          var f = d[e],
            g = hb(d[e + 1]);
          c[f] = g;
        }
        jb("TAGGING", 6);
        return c;
      }
    } catch (h) {
      jb("TAGGING", 8);
    }
  };
  function is(a, b) {
    if (a) {
      var c;
      a: {
        for (var d = a, e = 0; e < 3; ++e) {
          var f = Xr.exec(d);
          if (f) {
            c = f;
            break a;
          }
          d = rj(d) || "";
        }
        c = void 0;
      }
      var g = c;
      if (g && g[1] === "1") {
        var h = g[3],
          l;
        a: {
          for (var n = g[2], p = 0; p < b; ++p)
            if (n === cs(h, p)) {
              l = !0;
              break a;
            }
          l = !1;
        }
        if (l) return h;
        jb("TAGGING", 7);
      }
    }
  }
  function js(a, b, c, d, e) {
    function f(p) {
      p = gs(a, p);
      var q = p.charAt(p.length - 1);
      p && q !== "&" && (p += "&");
      return p + n;
    }
    d = d === void 0 ? !1 : d;
    e = e === void 0 ? !1 : e;
    var g = as(c);
    if (!g) return "";
    var h = g.query || "",
      l = g.fragment || "",
      n = a + "=" + b;
    d
      ? (l.substring(1).length !== 0 && e) || (l = "#" + f(l.substring(1)))
      : (h = "?" + f(h.substring(1)));
    return "" + g.Lj + h + l;
  }
  function ks(a, b) {
    function c(n, p, q) {
      var r;
      a: {
        for (var u in n)
          if (n.hasOwnProperty(u)) {
            r = !0;
            break a;
          }
        r = !1;
      }
      if (r) {
        var t,
          v = [],
          w;
        for (w in n)
          if (n.hasOwnProperty(w)) {
            var y = n[w];
            y !== void 0 &&
              y === y &&
              y !== null &&
              y.toString() !== "[object Object]" &&
              (v.push(w), v.push(gb(String(y))));
          }
        var z = v.join("*");
        t = ["1", cs(z), z].join("*");
        d
          ? (Ua(3) || Ua(1) || !p) && ls("_gl", t, a, p, q)
          : ms("_gl", t, a, p, q);
      }
    }
    var d = (a.tagName || "").toUpperCase() === "FORM",
      e = Wr(b, 1, d),
      f = Wr(b, 2, d),
      g = Wr(b, 4, d),
      h = Wr(b, 3, d);
    c(e, !1, !1);
    c(f, !0, !1);
    Ua(1) && c(g, !0, !0);
    for (var l in h) h.hasOwnProperty(l) && ns(l, h[l], a);
  }
  function ns(a, b, c) {
    c.tagName.toLowerCase() === "a"
      ? ms(a, b, c)
      : c.tagName.toLowerCase() === "form" && ls(a, b, c);
  }
  function ms(a, b, c, d, e) {
    d = d === void 0 ? !1 : d;
    e = e === void 0 ? !1 : e;
    var f;
    if ((f = c.href)) {
      var g;
      if (!(g = !Ua(4) || d)) {
        var h = x.location.href,
          l = as(c.href),
          n = as(h);
        g = !(l && n && l.Lj === n.Lj && l.query === n.query && l.fragment);
      }
      f = g;
    }
    if (f) {
      var p = js(a, b, c.href, d, e);
      oc.test(p) && (c.href = p);
    }
  }
  function ls(a, b, c, d, e) {
    d = d === void 0 ? !1 : d;
    e = e === void 0 ? !1 : e;
    if (c) {
      var f = c.getAttribute("action") || "";
      if (f) {
        var g = (c.method || "").toLowerCase();
        if (g !== "get" || d) {
          if (g === "get" || g === "post") {
            var h = js(a, b, f, d, e);
            oc.test(h) && (c.action = h);
          }
        } else {
          for (var l = c.childNodes || [], n = !1, p = 0; p < l.length; p++) {
            var q = l[p];
            if (q.name === a) {
              q.setAttribute("value", b);
              n = !0;
              break;
            }
          }
          if (!n) {
            var r = A.createElement("input");
            r.setAttribute("type", "hidden");
            r.setAttribute("name", a);
            r.setAttribute("value", b);
            c.appendChild(r);
          }
        }
      }
    }
  }
  function Sr(a) {
    try {
      var b;
      a: {
        for (var c = a, d = 100; c && d > 0; ) {
          if (c.href && c.nodeName.match(/^a(?:rea)?$/i)) {
            b = c;
            break a;
          }
          c = c.parentNode;
          d--;
        }
        b = null;
      }
      var e = b;
      if (e) {
        var f = e.protocol;
        (f !== "http:" && f !== "https:") || ks(e, e.hostname);
      }
    } catch (g) {}
  }
  function Tr(a) {
    try {
      var b = a.getAttribute("action");
      if (b) {
        var c = sj(yj(b), "host");
        ks(a, c);
      }
    } catch (d) {}
  }
  function os(a, b, c, d) {
    Rr();
    var e = c === "fragment" ? 2 : 1;
    d = !!d;
    Vr(a, b, e, d, !1);
    e === 2 && jb("TAGGING", 23);
    d && jb("TAGGING", 24);
  }
  function ps(a, b) {
    Rr();
    Vr(a, [uj(x.location, "host", !0)], b, !0, !0);
  }
  function qs() {
    var a = A.location.hostname,
      b = Yr.exec(A.referrer);
    if (!b) return !1;
    var c = b[2],
      d = b[1],
      e = "";
    if (c) {
      var f = c.split("/"),
        g = f[1];
      e = g === "s" ? rj(f[2]) || "" : rj(g) || "";
    } else if (d) {
      if (d.indexOf("xn--") === 0) return !1;
      e = d.replace(/-/g, ".").replace(/\.\./g, "-");
    }
    var h = a.replace(Zr, ""),
      l = e.replace(Zr, "");
    return h === l || Lb(h, "." + l);
  }
  function rs(a, b) {
    return a === !1 ? !1 : a || b || qs();
  }
  var ss = ["1"],
    ts = {},
    us = {};
  function vs(a, b) {
    b = b === void 0 ? !0 : b;
    var c = ws(a.prefix);
    if (ts[c]) xs(a);
    else if (ys(c, a.path, a.domain)) {
      var d = us[ws(a.prefix)] || { id: void 0, Sh: void 0 };
      b && zs(a, d.id, d.Sh);
      xs(a);
    } else {
      var e = Aj("auiddc");
      if (e) jb("TAGGING", 17), (ts[c] = e);
      else if (b) {
        var f = ws(a.prefix),
          g = Or();
        As(f, g, a);
        ys(c, a.path, a.domain);
        xs(a, !0);
      }
    }
  }
  function xs(a, b) {
    if ((b === void 0 ? 0 : b) && jr(er)) {
      var c = ar(!1);
      c.error !== 0
        ? jb("TAGGING", 38)
        : c.value
        ? "gcl_ctr" in c.value
          ? (delete c.value.gcl_ctr, br(c) !== 0 && jb("TAGGING", 41))
          : jb("TAGGING", 40)
        : jb("TAGGING", 39);
    }
    if (mr(er) && kr([er])[er.fb] === -1) {
      for (
        var d = {}, e = ((d[er.fb] = 0), d), f = m(hr), g = f.next();
        !g.done;
        g = f.next()
      ) {
        var h = g.value;
        h !== er && mr(h) && (e[h.fb] = 0);
      }
      lr(e, a);
    }
  }
  function zs(a, b, c) {
    var d = ws(a.prefix),
      e = ts[d];
    if (e) {
      var f = e.split(".");
      if (f.length === 2) {
        var g = Number(f[1]) || 0;
        if (g) {
          var h = e;
          b && (h = e + "." + b + "." + (c ? c : Math.floor(Fb() / 1e3)));
          As(d, h, a, g * 1e3);
        }
      }
    }
  }
  function As(a, b, c, d) {
    var e;
    e = ["1", Mr(c.domain, c.path), b].join(".");
    var f = Yq(c, d);
    f.wc = Bs();
    Hr(a, e, f);
  }
  function ys(a, b, c) {
    var d = Pr(a, b, c, ss, Bs());
    if (!d) return !1;
    Cs(a, d);
    return !0;
  }
  function Cs(a, b) {
    var c = b.split(".");
    c.length === 5
      ? ((ts[a] = c.slice(0, 2).join(".")),
        (us[a] = { id: c.slice(2, 4).join("."), Sh: Number(c[4]) || 0 }))
      : c.length === 3
      ? (us[a] = { id: c.slice(0, 2).join("."), Sh: Number(c[2]) || 0 })
      : (ts[a] = b);
  }
  function ws(a) {
    return (a || "_gcl") + "_au";
  }
  function Ds(a) {
    function b() {
      Ql(c) && a();
    }
    var c = Bs();
    Wl(function () {
      b();
      Ql(c) || Xl(b, c);
    }, c);
  }
  function Es(a) {
    var b = hs(!0),
      c = ws(a.prefix);
    Ds(function () {
      var d = b[c];
      if (d) {
        Cs(c, d);
        var e = Number(ts[c].split(".")[1]) * 1e3;
        if (e) {
          jb("TAGGING", 16);
          var f = Yq(a, e);
          f.wc = Bs();
          var g = ["1", Mr(a.domain, a.path), d].join(".");
          Hr(c, g, f);
        }
      }
    });
  }
  function Fs(a, b, c, d, e) {
    e = e || {};
    var f = function () {
      var g = {},
        h = Pr(a, e.path, e.domain, ss, Bs());
      h && (g[a] = h);
      return g;
    };
    Ds(function () {
      os(f, b, c, d);
    });
  }
  function Bs() {
    return ["ad_storage", "ad_user_data"];
  }
  function Gs(a) {
    for (
      var b = [],
        c = A.cookie.split(";"),
        d = new RegExp(
          "^\\s*" + (a || "_gac") + "_(UA-\\d+-\\d+)=\\s*(.+?)\\s*$"
        ),
        e = 0;
      e < c.length;
      e++
    ) {
      var f = c[e].match(d);
      f &&
        b.push({
          Vd: f[1],
          value: f[2],
          timestamp: Number(f[2].split(".")[1]) || 0,
        });
    }
    b.sort(function (g, h) {
      return h.timestamp - g.timestamp;
    });
    return b;
  }
  function Hs(a, b) {
    var c = Gs(a),
      d = {};
    if (!c || !c.length) return d;
    for (var e = 0; e < c.length; e++) {
      var f = c[e].value.split(".");
      if (
        !(f[0] !== "1" || (b && f.length < 3) || (!b && f.length !== 3)) &&
        Number(f[1])
      ) {
        d[c[e].Vd] || (d[c[e].Vd] = []);
        var g = { version: f[0], timestamp: Number(f[1]) * 1e3, gclid: f[2] };
        b && f.length > 3 && (g.labels = f.slice(3));
        d[c[e].Vd].push(g);
      }
    }
    return d;
  }
  var Is = {},
    Js =
      ((Is.k = { ia: /^[\w-]+$/ }),
      (Is.b = { ia: /^[\w-]+$/, Oj: !0 }),
      (Is.i = { ia: /^[1-9]\d*$/ }),
      (Is.h = { ia: /^\d+$/ }),
      (Is.t = { ia: /^[1-9]\d*$/ }),
      (Is.d = { ia: /^[A-Za-z0-9_-]+$/ }),
      (Is.j = { ia: /^\d+$/ }),
      (Is.u = { ia: /^[1-9]\d*$/ }),
      (Is.l = { ia: /^[01]$/ }),
      (Is.o = { ia: /^[1-9]\d*$/ }),
      (Is.g = { ia: /^[01]$/ }),
      (Is.s = { ia: /^.+$/ }),
      Is);
  var Ks = {},
    Os =
      ((Ks[5] = { Xh: { 2: Ls }, Dj: "2", Jh: ["k", "i", "b", "u"] }),
      (Ks[4] = { Xh: { 2: Ls, GCL: Ms }, Dj: "2", Jh: ["k", "i", "b"] }),
      (Ks[2] = {
        Xh: { GS2: Ls, GS1: Ns },
        Dj: "GS2",
        Jh: "sogtjlhd".split(""),
      }),
      Ks);
  function Ps(a, b, c) {
    var d = Os[b];
    if (d) {
      var e = a.split(".")[0];
      c == null || c(e);
      if (e) {
        var f = d.Xh[e];
        if (f) return f(a, b);
      }
    }
  }
  function Ls(a, b) {
    var c = a.split(".");
    if (c.length === 3) {
      var d = c[2];
      if (d.indexOf("$") === -1 && d.indexOf("%24") !== -1)
        try {
          d = decodeURIComponent(d);
        } catch (u) {}
      var e = {},
        f = Os[b];
      if (f) {
        for (
          var g = f.Jh, h = m(d.split("$")), l = h.next();
          !l.done;
          l = h.next()
        ) {
          var n = l.value,
            p = n[0];
          if (g.indexOf(p) !== -1)
            try {
              var q = decodeURIComponent(n.substring(1)),
                r = Js[p];
              r && (r.Oj ? ((e[p] = e[p] || []), e[p].push(q)) : (e[p] = q));
            } catch (u) {}
        }
        return e;
      }
    }
  }
  function Qs(a, b, c) {
    var d = Os[b];
    if (d) return [d.Dj, c || "1", Rs(a, b)].join(".");
  }
  function Rs(a, b) {
    var c = Os[b];
    if (c) {
      for (var d = [], e = m(c.Jh), f = e.next(); !f.done; f = e.next()) {
        var g = f.value,
          h = Js[g];
        if (h) {
          var l = a[g];
          if (l !== void 0)
            if (h.Oj && Array.isArray(l))
              for (var n = m(l), p = n.next(); !p.done; p = n.next())
                d.push(encodeURIComponent("" + g + p.value));
            else d.push(encodeURIComponent("" + g + l));
        }
      }
      return d.join("$");
    }
  }
  function Ms(a) {
    var b = a.split(".");
    b.shift();
    var c = b.shift(),
      d = b.shift(),
      e = {};
    return (e.k = d), (e.i = c), (e.b = b), e;
  }
  function Ns(a) {
    var b = a.split(".").slice(2);
    if (!(b.length < 5 || b.length > 7)) {
      var c = {};
      return (
        (c.s = b[0]),
        (c.o = b[1]),
        (c.g = b[2]),
        (c.t = b[3]),
        (c.j = b[4]),
        (c.l = b[5]),
        (c.h = b[6]),
        c
      );
    }
  }
  var Ss = new Map([
    [5, "ad_storage"],
    [4, ["ad_storage", "ad_user_data"]],
    [2, "analytics_storage"],
  ]);
  function Ts(a, b, c) {
    if (Os[b]) {
      for (
        var d = [],
          e = vr(a, void 0, void 0, Ss.get(b)),
          f = m(e),
          g = f.next();
        !g.done;
        g = f.next()
      ) {
        var h = Ps(g.value, b, c);
        h && d.push(Us(h));
      }
      return d;
    }
  }
  function Vs(a) {
    var b = Ws;
    if (Os[2]) {
      for (
        var c = {},
          d = wr(a, void 0, void 0, Ss.get(2)),
          e = Object.keys(d).sort(),
          f = m(e),
          g = f.next();
        !g.done;
        g = f.next()
      )
        for (
          var h = g.value, l = m(d[h]), n = l.next();
          !n.done;
          n = l.next()
        ) {
          var p = Ps(n.value, 2, b);
          p && (c[h] || (c[h] = []), c[h].push(Us(p)));
        }
      return c;
    }
  }
  function Xs(a, b, c, d, e) {
    d = d || {};
    var f = Mr(d.domain, d.path),
      g = Qs(b, c, f);
    if (!g) return 1;
    var h = Yq(d, e, void 0, Ss.get(c));
    return Hr(a, g, h);
  }
  function Ys(a, b) {
    var c = b.ia;
    return typeof c === "function" ? c(a) : c.test(a);
  }
  function Us(a) {
    for (
      var b = m(Object.keys(a)), c = b.next(), d = {};
      !c.done;
      d = { jg: void 0 }, c = b.next()
    ) {
      var e = c.value,
        f = a[e];
      d.jg = Js[e];
      d.jg
        ? d.jg.Oj
          ? (a[e] = Array.isArray(f)
              ? f.filter(
                  (function (g) {
                    return function (h) {
                      return Ys(h, g.jg);
                    };
                  })(d)
                )
              : void 0)
          : (typeof f === "string" && Ys(f, d.jg)) || (a[e] = void 0)
        : (a[e] = void 0);
    }
    return a;
  }
  var Zs = function () {
    this.value = 0;
  };
  Zs.prototype.set = function (a) {
    return (this.value |= 1 << a);
  };
  var $s = function (a, b) {
    b <= 0 || (a.value |= 1 << (b - 1));
  };
  Zs.prototype.get = function () {
    return this.value;
  };
  Zs.prototype.clear = function (a) {
    this.value &= ~(1 << a);
  };
  Zs.prototype.clearAll = function () {
    this.value = 0;
  };
  Zs.prototype.equals = function (a) {
    return this.value === a.value;
  };
  function at(a) {
    if (a)
      try {
        return new Uint8Array(
          atob(a.replace(/-/g, "+").replace(/_/g, "/"))
            .split("")
            .map(function (b) {
              return b.charCodeAt(0);
            })
        );
      } catch (b) {}
  }
  function bt(a, b) {
    var c = 0,
      d = 0,
      e,
      f = b;
    do {
      if (f >= a.length) return;
      e = a[f++];
      c |= (e & 127) << d;
      d += 7;
    } while (e & 128);
    return [c, f];
  }
  function ct() {
    var a = String,
      b = x.location.hostname,
      c = x.location.pathname,
      d = (b = Ub(b));
    d.split(".").length > 2 &&
      (d = d.replace(/^(www[0-9]*|web|ftp|wap|home|m|w|amp|mobile)\./, ""));
    b = d;
    c = Ub(c);
    var e = c.split(";")[0];
    e = e.replace(/\/(ar|slp|web|index)?\/?$/, "");
    return a(di(("" + b + e).toLowerCase()));
  }
  var dt = {},
    et =
      ((dt.gclid = !0),
      (dt.dclid = !0),
      (dt.gbraid = !0),
      (dt.wbraid = !0),
      dt),
    ft = /^\w+$/,
    gt = /^[\w-]+$/,
    ht = {},
    it =
      ((ht.aw = "_aw"),
      (ht.dc = "_dc"),
      (ht.gf = "_gf"),
      (ht.gp = "_gp"),
      (ht.gs = "_gs"),
      (ht.ha = "_ha"),
      (ht.ag = "_ag"),
      (ht.gb = "_gb"),
      ht),
    jt = /^(?:www\.)?google(?:\.com?)?(?:\.[a-z]{2}t?)?$/,
    kt = /^www\.googleadservices\.com$/;
  function lt() {
    return ["ad_storage", "ad_user_data"];
  }
  function mt(a) {
    return !Ua(7) || Ql(a);
  }
  function nt(a, b) {
    function c() {
      var d = mt(b);
      d && a();
      return d;
    }
    Wl(function () {
      c() || Xl(c, b);
    }, b);
  }
  function ot(a) {
    return pt(a).map(function (b) {
      return b.gclid;
    });
  }
  function qt(a) {
    return rt(a)
      .filter(function (b) {
        return b.gclid;
      })
      .map(function (b) {
        return b.gclid;
      });
  }
  function rt(a) {
    var b = st(a.prefix),
      c = tt("gb", b),
      d = tt("ag", b);
    if (!d || !c) return [];
    var e = function (h) {
        return function (l) {
          l.type = h;
          return l;
        };
      },
      f = pt(c).map(e("gb")),
      g = ut(d).map(e("ag"));
    return f.concat(g).sort(function (h, l) {
      return l.timestamp - h.timestamp;
    });
  }
  function vt(a, b, c, d, e) {
    var f = ub(a, function (g) {
      return g.gclid === b;
    });
    f
      ? (f.timestamp < c && ((f.timestamp = c), (f.Vc = e)),
        (f.labels = wt(f.labels || [], d || [])))
      : a.push({ version: "2", gclid: b, timestamp: c, labels: d, Vc: e });
  }
  function ut(a) {
    for (
      var b = Ts(a, 5) || [], c = [], d = m(b), e = d.next();
      !e.done;
      e = d.next()
    ) {
      var f = e.value,
        g = f,
        h = xt(f);
      h && vt(c, g.k, h, g.b || [], f.u);
    }
    return c.sort(function (l, n) {
      return n.timestamp - l.timestamp;
    });
  }
  function pt(a) {
    for (
      var b = [], c = vr(a, A.cookie, void 0, lt()), d = m(c), e = d.next();
      !e.done;
      e = d.next()
    ) {
      var f = zt(e.value);
      f != null && ((f.Vc = void 0), (f.Aa = new Zs()), (f.ab = [1]), At(b, f));
    }
    b.sort(function (g, h) {
      return h.timestamp - g.timestamp;
    });
    return Bt(b);
  }
  function Ct(a, b) {
    for (var c = [], d = m(a), e = d.next(); !e.done; e = d.next()) {
      var f = e.value;
      c.includes(f) || c.push(f);
    }
    for (var g = m(b), h = g.next(); !h.done; h = g.next()) {
      var l = h.value;
      c.includes(l) || c.push(l);
    }
    return c;
  }
  function At(a, b, c) {
    c = c === void 0 ? !1 : c;
    for (var d, e, f = m(a), g = f.next(); !g.done; g = f.next()) {
      var h = g.value;
      if (h.gclid === b.gclid) {
        d = h;
        break;
      }
      h.Aa && b.Aa && h.Aa.equals(b.Aa) && (e = h);
    }
    if (d) {
      var l,
        n,
        p = (l = d.Aa) != null ? l : new Zs(),
        q = (n = b.Aa) != null ? n : new Zs();
      p.value |= q.value;
      d.Aa = p;
      d.timestamp < b.timestamp && ((d.timestamp = b.timestamp), (d.Vc = b.Vc));
      d.labels = Ct(d.labels || [], b.labels || []);
      d.ab = Ct(d.ab || [], b.ab || []);
    } else c && e ? la(Object, "assign").call(Object, e, b) : a.push(b);
  }
  function Dt(a) {
    if (!a) return new Zs();
    var b = new Zs();
    if (a === 1) return $s(b, 2), $s(b, 3), b;
    $s(b, a);
    return b;
  }
  function Et() {
    var a = cr("gclid");
    if (!a || a.error || !a.value || typeof a.value !== "object") return null;
    var b = a.value;
    try {
      if (!("value" in b && b.value) || typeof b.value !== "object")
        return null;
      var c = b.value,
        d = c.value;
      if (!d || !d.match(gt)) return null;
      var e = c.linkDecorationSource,
        f = c.linkDecorationSources,
        g = new Zs();
      typeof e === "number"
        ? (g = Dt(e))
        : typeof f === "number" && (g.value = f);
      return {
        version: "",
        gclid: d,
        timestamp: Number(c.creationTimeMs) || 0,
        labels: [],
        Aa: g,
        ab: [2],
      };
    } catch (h) {
      return null;
    }
  }
  function Ft() {
    var a = cr("gcl_aw");
    if (a.error !== 0) return null;
    try {
      return a.value.reduce(function (b, c) {
        if (!c.value || typeof c.value !== "object") return b;
        var d = c.value,
          e = d.value;
        if (!e || !e.match(gt)) return b;
        var f = new Zs(),
          g = d.linkDecorationSources;
        typeof g === "number" && (f.value = g);
        b.push({
          version: "",
          gclid: e,
          timestamp: Number(d.creationTimeMs) || 0,
          expires: Number(c.expires) || 0,
          labels: [],
          Aa: f,
          ab: [2],
        });
        return b;
      }, []);
    } catch (b) {
      return null;
    }
  }
  function Gt(a) {
    for (
      var b = [], c = vr(a, A.cookie, void 0, lt()), d = m(c), e = d.next();
      !e.done;
      e = d.next()
    ) {
      var f = zt(e.value);
      f != null && ((f.Vc = void 0), (f.Aa = new Zs()), (f.ab = [1]), At(b, f));
    }
    var g = Et();
    g && ((g.Vc = void 0), (g.ab = g.ab || [2]), At(b, g));
    if (Ua(16)) {
      var h = Ft();
      if (h)
        for (var l = m(h), n = l.next(); !n.done; n = l.next()) {
          var p = n.value;
          p.Vc = void 0;
          p.ab = p.ab || [2];
          At(b, p);
        }
    }
    b.sort(function (q, r) {
      return r.timestamp - q.timestamp;
    });
    return Bt(b);
  }
  function wt(a, b) {
    if (!a.length) return b;
    if (!b.length) return a;
    var c = {};
    return a.concat(b).filter(function (d) {
      return c.hasOwnProperty(d) ? !1 : (c[d] = !0);
    });
  }
  function st(a) {
    return a && typeof a === "string" && a.match(ft) ? a : "_gcl";
  }
  function Ht(a, b) {
    if (a) {
      var c = { value: a, Aa: new Zs() };
      $s(c.Aa, b);
      return c;
    }
  }
  function It(a, b, c) {
    var d = yj(a),
      e = sj(d, "query", !1, void 0, "gclsrc"),
      f = Ht(sj(d, "query", !1, void 0, "gclid"), c ? 4 : 2);
    if (b && (!f || !e)) {
      var g = d.hash.replace("#", "");
      f || (f = Ht(pj(g, "gclid", !1), 3));
      e || (e = pj(g, "gclsrc", !1));
    }
    return f &&
      (e === void 0 || e === "aw" || e === "aw.ds" || (Ua(20) && e === "aw.dv"))
      ? [f]
      : [];
  }
  function Jt(a, b) {
    var c = yj(a),
      d = sj(c, "query", !1, void 0, "gclid"),
      e = sj(c, "query", !1, void 0, "gclsrc"),
      f = sj(c, "query", !1, void 0, "wbraid");
    f = Sb(f);
    var g = sj(c, "query", !1, void 0, "gbraid"),
      h = sj(c, "query", !1, void 0, "gad_source"),
      l = sj(c, "query", !1, void 0, "dclid");
    if (b && !(d && e && f && g)) {
      var n = c.hash.replace("#", "");
      d = d || pj(n, "gclid", !1);
      e = e || pj(n, "gclsrc", !1);
      f = f || pj(n, "wbraid", !1);
      g = g || pj(n, "gbraid", !1);
      h = h || pj(n, "gad_source", !1);
    }
    return Kt(d, e, l, f, g, h);
  }
  function Lt() {
    return Jt(x.location.href, !0);
  }
  function Kt(a, b, c, d, e, f) {
    var g = {},
      h = function (l, n) {
        g[n] || (g[n] = []);
        g[n].push(l);
      };
    g.gclid = a;
    g.gclsrc = b;
    g.dclid = c;
    if (a !== void 0 && a.match(gt))
      switch (b) {
        case void 0:
          h(a, "aw");
          break;
        case "aw.ds":
          h(a, "aw");
          h(a, "dc");
          break;
        case "aw.dv":
          Ua(20) && (h(a, "aw"), h(a, "dc"));
          break;
        case "ds":
          h(a, "dc");
          break;
        case "3p.ds":
          h(a, "dc");
          break;
        case "gf":
          h(a, "gf");
          break;
        case "ha":
          h(a, "ha");
      }
    c && h(c, "dc");
    d !== void 0 && gt.test(d) && ((g.wbraid = d), h(d, "gb"));
    e !== void 0 && gt.test(e) && ((g.gbraid = e), h(e, "ag"));
    f !== void 0 && gt.test(f) && ((g.gad_source = f), h(f, "gs"));
    return g;
  }
  function Mt(a) {
    for (
      var b = Lt(), c = !0, d = m(Object.keys(b)), e = d.next();
      !e.done;
      e = d.next()
    )
      if (b[e.value] !== void 0) {
        c = !1;
        break;
      }
    c && ((b = Jt(x.document.referrer, !1)), (b.gad_source = void 0));
    Nt(b, !1, a);
  }
  function Ot(a) {
    Mt(a);
    var b = It(x.location.href, !0, !1);
    b.length || (b = It(x.document.referrer, !1, !0));
    a = a || {};
    Pt(a);
    if (b.length) {
      var c = b[0],
        d = Fb(),
        e = Yq(a, d, !0),
        f = lt(),
        g = function () {
          mt(f) &&
            e.expires !== void 0 &&
            $q("gclid", {
              value: {
                value: c.value,
                creationTimeMs: d,
                linkDecorationSources: c.Aa.get(),
              },
              expires: Number(e.expires),
            });
        };
      Wl(function () {
        g();
        mt(f) || Xl(g, f);
      }, f);
    }
  }
  function Pt(a) {
    var b;
    if ((b = Ua(17))) {
      var c = Qt();
      b = jt.test(c) || kt.test(c) || Rt();
    }
    if (b) {
      var d;
      a: {
        for (
          var e = yj(x.location.href),
            f = qj(sj(e, "query")),
            g = m(Object.keys(f)),
            h = g.next();
          !h.done;
          h = g.next()
        ) {
          var l = h.value;
          if (!et[l]) {
            var n = f[l][0] || "",
              p;
            if (!n || n.length < 50 || n.length > 200) p = !1;
            else {
              var q = at(n),
                r;
              if (q)
                c: {
                  var u = q;
                  if (u && u.length !== 0) {
                    var t = 0;
                    try {
                      for (var v = 10; t < u.length && !(v-- <= 0); ) {
                        var w = bt(u, t);
                        if (w === void 0) break;
                        var y = m(w),
                          z = y.next().value,
                          D = y.next().value,
                          E = z,
                          L = D,
                          I = E & 7;
                        if (E >> 3 === 16382) {
                          if (I !== 0) break;
                          var R = bt(u, L);
                          if (R === void 0) break;
                          r = m(R).next().value === 1;
                          break c;
                        }
                        var X;
                        d: {
                          var Z = void 0,
                            Q = u,
                            W = L;
                          switch (I) {
                            case 0:
                              X = (Z = bt(Q, W)) == null ? void 0 : Z[1];
                              break d;
                            case 1:
                              X = W + 8;
                              break d;
                            case 2:
                              var ma = bt(Q, W);
                              if (ma === void 0) break;
                              var ka = m(ma),
                                T = ka.next().value;
                              X = ka.next().value + T;
                              break d;
                            case 5:
                              X = W + 4;
                              break d;
                          }
                          X = void 0;
                        }
                        if (X === void 0 || X > u.length || X <= t) break;
                        t = X;
                      }
                    } catch (ha) {}
                  }
                  r = !1;
                }
              else r = !1;
              p = r;
            }
            if (p) {
              d = n;
              break a;
            }
          }
        }
        d = void 0;
      }
      var U = d;
      U && St(U, 7, a);
    }
  }
  function St(a, b, c) {
    c = c || {};
    var d = Fb(),
      e = Yq(c, d, !0),
      f = lt(),
      g = function () {
        if (mt(f) && e.expires !== void 0) {
          var h = Ft() || [];
          At(
            h,
            {
              version: "",
              gclid: a,
              timestamp: d,
              expires: Number(e.expires),
              Aa: Dt(b),
            },
            !0
          );
          $q(
            "gcl_aw",
            h.map(function (l) {
              return {
                value: {
                  value: l.gclid,
                  creationTimeMs: l.timestamp,
                  linkDecorationSources: l.Aa ? l.Aa.get() : 0,
                },
                expires: Number(l.expires),
              };
            })
          );
        }
      };
    Wl(function () {
      mt(f) ? g() : Xl(g, f);
    }, f);
  }
  function Nt(a, b, c, d, e) {
    c = c || {};
    e = e || [];
    var f = st(c.prefix),
      g = d || Fb(),
      h = Math.round(g / 1e3),
      l = lt(),
      n = !1,
      p = !1,
      q = function () {
        if (mt(l)) {
          var r = Yq(c, g, !0);
          r.wc = l;
          for (
            var u = function (X, Z) {
                var Q = tt(X, f);
                Q && (Hr(Q, Z, r), X !== "gb" && (n = !0));
              },
              t = function (X) {
                var Z = ["GCL", h, X];
                e.length > 0 && Z.push(e.join("."));
                return Z.join(".");
              },
              v = m(["aw", "dc", "gf", "ha", "gp"]),
              w = v.next();
            !w.done;
            w = v.next()
          ) {
            var y = w.value;
            a[y] && u(y, t(a[y][0]));
          }
          if (!n && a.gb) {
            var z = a.gb[0],
              D = tt("gb", f);
            (!b &&
              pt(D).some(function (X) {
                return X.gclid === z && X.labels && X.labels.length > 0;
              })) ||
              u("gb", t(z));
          }
        }
        if (!p && a.gbraid && mt("ad_storage") && ((p = !0), !n)) {
          var E = a.gbraid,
            L = tt("ag", f);
          if (
            b ||
            !ut(L).some(function (X) {
              return X.gclid === E && X.labels && X.labels.length > 0;
            })
          ) {
            var I = {},
              R = ((I.k = E), (I.i = "" + h), (I.b = e), I);
            Xs(L, R, 5, c, g);
          }
        }
        Tt(a, f, g, c);
      };
    Wl(function () {
      q();
      mt(l) || Xl(q, l);
    }, l);
  }
  function Tt(a, b, c, d) {
    if (a.gad_source !== void 0 && mt("ad_storage")) {
      var e = fd();
      if (e !== "r" && e !== "h") {
        var f = a.gad_source,
          g = tt("gs", b);
        if (g) {
          var h = Math.floor((Fb() - (ed() || 0)) / 1e3),
            l,
            n = ct(),
            p = {};
          l = ((p.k = f), (p.i = "" + h), (p.u = n), p);
          Xs(g, l, 5, d, c);
        }
      }
    }
  }
  function Ut(a, b) {
    var c = hs(!0);
    nt(function () {
      for (var d = st(b.prefix), e = 0; e < a.length; ++e) {
        var f = a[e];
        if (it[f] !== void 0) {
          var g = tt(f, d),
            h = c[g];
          if (h) {
            var l = Math.min(Vt(h), Fb()),
              n;
            b: {
              for (
                var p = l, q = vr(g, A.cookie, void 0, lt()), r = 0;
                r < q.length;
                ++r
              )
                if (Vt(q[r]) > p) {
                  n = !0;
                  break b;
                }
              n = !1;
            }
            if (!n) {
              var u = Yq(b, l, !0);
              u.wc = lt();
              Hr(g, h, u);
            }
          }
        }
      }
      Nt(Kt(c.gclid, c.gclsrc), !1, b);
    }, lt());
  }
  function Wt(a) {
    var b = ["ag"],
      c = hs(!0),
      d = st(a.prefix);
    nt(
      function () {
        for (var e = 0; e < b.length; ++e) {
          var f = tt(b[e], d);
          if (f) {
            var g = c[f];
            if (g) {
              var h = Ps(g, 5);
              if (h) {
                var l = xt(h);
                l || (l = Fb());
                var n;
                a: {
                  for (var p = l, q = Ts(f, 5), r = 0; r < q.length; ++r)
                    if (xt(q[r]) > p) {
                      n = !0;
                      break a;
                    }
                  n = !1;
                }
                if (n) break;
                h.i = "" + Math.round(l / 1e3);
                Xs(f, h, 5, a, l);
              }
            }
          }
        }
      },
      ["ad_storage"]
    );
  }
  function tt(a, b) {
    var c = it[a];
    if (c !== void 0) return b + c;
  }
  function Vt(a) {
    return Xt(a.split(".")).length !== 0
      ? (Number(a.split(".")[1]) || 0) * 1e3
      : 0;
  }
  function xt(a) {
    return a ? (Number(a.i) || 0) * 1e3 : 0;
  }
  function zt(a) {
    var b = Xt(a.split("."));
    return b.length === 0
      ? null
      : {
          version: b[0],
          gclid: b[2],
          timestamp: (Number(b[1]) || 0) * 1e3,
          labels: b.slice(3),
        };
  }
  function Xt(a) {
    return a.length < 3 ||
      (a[0] !== "GCL" && a[0] !== "1") ||
      !/^\d+$/.test(a[1]) ||
      !gt.test(a[2])
      ? []
      : a;
  }
  function Yt(a, b, c, d, e) {
    if (Array.isArray(b) && ur(x)) {
      var f = st(e),
        g = function () {
          for (var h = {}, l = 0; l < a.length; ++l) {
            var n = tt(a[l], f);
            if (n) {
              var p = vr(n, A.cookie, void 0, lt());
              p.length && (h[n] = p.sort()[p.length - 1]);
            }
          }
          return h;
        };
      nt(function () {
        os(g, b, c, d);
      }, lt());
    }
  }
  function Zt(a, b, c, d) {
    if (Array.isArray(a) && ur(x)) {
      var e = ["ag"],
        f = st(d),
        g = function () {
          for (var h = {}, l = 0; l < e.length; ++l) {
            var n = tt(e[l], f);
            if (!n) return {};
            var p = Ts(n, 5);
            if (p.length) {
              var q = p.sort(function (r, u) {
                return xt(u) - xt(r);
              })[0];
              h[n] = Qs(q, 5);
            }
          }
          return h;
        };
      nt(
        function () {
          os(g, a, b, c);
        },
        ["ad_storage"]
      );
    }
  }
  function Bt(a) {
    return a.filter(function (b) {
      return gt.test(b.gclid);
    });
  }
  function $t(a, b) {
    if (ur(x)) {
      for (var c = st(b.prefix), d = {}, e = 0; e < a.length; e++)
        it[a[e]] && (d[a[e]] = it[a[e]]);
      nt(function () {
        yb(d, function (f, g) {
          var h = vr(c + g, A.cookie, void 0, lt());
          h.sort(function (u, t) {
            return Vt(t) - Vt(u);
          });
          if (h.length) {
            var l = h[0],
              n = Vt(l),
              p = Xt(l.split(".")).length !== 0 ? l.split(".").slice(3) : [],
              q = {},
              r;
            r = Xt(l.split(".")).length !== 0 ? l.split(".")[2] : void 0;
            q[f] = [r];
            Nt(q, !0, b, n, p);
          }
        });
      }, lt());
    }
  }
  function au(a) {
    var b = ["ag"],
      c = ["gbraid"];
    nt(
      function () {
        for (var d = st(a.prefix), e = 0; e < b.length; ++e) {
          var f = tt(b[e], d);
          if (!f) break;
          var g = Ts(f, 5);
          if (g.length) {
            var h = g.sort(function (q, r) {
                return xt(r) - xt(q);
              })[0],
              l = xt(h),
              n = h.b,
              p = {};
            p[c[e]] = h.k;
            Nt(p, !0, a, l, n);
          }
        }
      },
      ["ad_storage"]
    );
  }
  function bu(a, b) {
    for (var c = 0; c < b.length; ++c) if (a[b[c]]) return !0;
    return !1;
  }
  function cu(a) {
    function b(h, l, n) {
      n && (h[l] = n);
    }
    if (Tl()) {
      var c = Lt(),
        d;
      a.includes("gad_source") &&
        (d = c.gad_source !== void 0 ? c.gad_source : hs(!1)._gs);
      if (bu(c, a) || d) {
        var e = {};
        b(e, "gclid", c.gclid);
        b(e, "dclid", c.dclid);
        b(e, "gclsrc", c.gclsrc);
        b(e, "wbraid", c.wbraid);
        b(e, "gbraid", c.gbraid);
        ps(function () {
          return e;
        }, 3);
        var f = {},
          g = ((f._up = "1"), f);
        b(g, "_gs", d);
        ps(function () {
          return g;
        }, 1);
      }
    }
  }
  function Rt() {
    var a = yj(x.location.href);
    return sj(a, "query", !1, void 0, "gad_source");
  }
  function du(a) {
    if (!Ua(1)) return null;
    var b = hs(!0).gad_source;
    if (b != null) return (x.location.hash = ""), b;
    if (Ua(2)) {
      b = Rt();
      if (b != null) return b;
      var c = Lt();
      if (bu(c, a)) return "0";
    }
    return null;
  }
  function eu(a) {
    var b = du(a);
    b != null &&
      ps(function () {
        var c = {};
        return (c.gad_source = b), c;
      }, 4);
  }
  function fu(a, b, c) {
    var d = [];
    if (b.length === 0) return d;
    for (var e = {}, f = 0; f < b.length; f++) {
      var g = b[f],
        h = g.type ? g.type : "gcl";
      (g.labels || []).indexOf(c) === -1
        ? (a.push(0), e[h] || d.push(g))
        : a.push(1);
      e[h] = !0;
    }
    return d;
  }
  function gu(a, b, c, d) {
    var e = [];
    c = c || {};
    if (!mt(lt())) return e;
    var f = pt(a),
      g = fu(e, f, b);
    if (g.length && !d)
      for (var h = m(g), l = h.next(); !l.done; l = h.next()) {
        var n = l.value,
          p = n.timestamp,
          q = [n.version, Math.round(p / 1e3), n.gclid]
            .concat(n.labels || [], [b])
            .join("."),
          r = Yq(c, p, !0);
        r.wc = lt();
        Hr(a, q, r);
      }
    return e;
  }
  function hu(a, b) {
    var c = [];
    b = b || {};
    var d = rt(b),
      e = fu(c, d, a);
    if (e.length)
      for (var f = m(e), g = f.next(); !g.done; g = f.next()) {
        var h = g.value,
          l = st(b.prefix),
          n = tt(h.type, l);
        if (!n) break;
        var p = h,
          q = p.version,
          r = p.gclid,
          u = p.labels,
          t = p.timestamp,
          v = Math.round(t / 1e3);
        if (h.type === "ag") {
          var w = {},
            y = ((w.k = r), (w.i = "" + v), (w.b = (u || []).concat([a])), w);
          Xs(n, y, 5, b, t);
        } else if (h.type === "gb") {
          var z = [q, v, r].concat(u || [], [a]).join("."),
            D = Yq(b, t, !0);
          D.wc = lt();
          Hr(n, z, D);
        }
      }
    return c;
  }
  function iu(a, b) {
    var c = st(b),
      d = tt(a, c);
    if (!d) return 0;
    var e;
    e = a === "ag" ? ut(d) : pt(d);
    for (var f = 0, g = 0; g < e.length; g++) f = Math.max(f, e[g].timestamp);
    return f;
  }
  function ju(a) {
    for (var b = 0, c = m(Object.keys(a)), d = c.next(); !d.done; d = c.next())
      for (var e = a[d.value], f = 0; f < e.length; f++)
        b = Math.max(b, Number(e[f].timestamp));
    return b;
  }
  function ku(a) {
    var b = Math.max(iu("aw", a), ju(mt(lt()) ? Hs() : {})),
      c = Math.max(iu("gb", a), ju(mt(lt()) ? Hs("_gac_gb", !0) : {}));
    c = Math.max(c, iu("ag", a));
    return c > b;
  }
  function Qt() {
    return A.referrer ? sj(yj(A.referrer), "host") : "";
  }
  function wu(a) {
    var b = window,
      c = b.webkit;
    delete b.webkit;
    a(b.webkit);
    b.webkit = c;
  }
  function xu(a) {
    var b = { action: "gcl_setup" };
    if ("CWVWebViewMessage" in a.messageHandlers)
      return (
        a.messageHandlers.CWVWebViewMessage.postMessage({
          command: "awb",
          payload: b,
        }),
        !0
      );
    var c = a.messageHandlers.awb;
    return c ? (c.postMessage(b), !0) : !1;
  }
  function yu() {
    return ["ad_storage", "ad_user_data"];
  }
  function zu(a) {
    if (
      F(38) &&
      !lm(hm.Z.tm) &&
      "webkit" in window &&
      window.webkit.messageHandlers
    ) {
      var b = function () {
        try {
          wu(function (c) {
            c &&
              ("CWVWebViewMessage" in c.messageHandlers ||
                "awb" in c.messageHandlers) &&
              (km(hm.Z.tm, function (d) {
                d.gclid && St(d.gclid, 5, a);
              }),
              xu(c) || K(178));
          });
        } catch (c) {
          K(177);
        }
      };
      Wl(function () {
        mt(yu()) ? b() : Xl(b, yu());
      }, yu());
    }
  }
  var Au = [
    "https://www.google.com",
    "https://www.youtube.com",
    "https://m.youtube.com",
  ];
  function Bu(a) {
    return a.data.action !== "gcl_transfer"
      ? (K(173), !0)
      : a.data.gadSource
      ? a.data.gclid
        ? !1
        : (K(181), !0)
      : (K(180), !0);
  }
  function Cu(a, b) {
    if (F(a)) {
      if (lm(hm.Z.Ge)) return K(176), hm.Z.Ge;
      if (lm(hm.Z.wm)) return K(170), hm.Z.Ge;
      var c = aq();
      if (!c) K(171);
      else if (c.opener) {
        var d = function (g) {
          if (!Au.includes(g.origin)) K(172);
          else if (!Bu(g)) {
            var h = { gadSource: g.data.gadSource };
            F(229) && (h.gclid = g.data.gclid);
            km(hm.Z.Ge, h);
            a === 200 && g.data.gclid && St(String(g.data.gclid), 6, b);
            var l;
            (l = g.stopImmediatePropagation) == null || l.call(g);
            iq(c, "message", d);
          }
        };
        if (hq(c, "message", d)) {
          km(hm.Z.wm, !0);
          for (var e = m(Au), f = e.next(); !f.done; f = e.next())
            c.opener.postMessage({ action: "gcl_setup" }, f.value);
          K(174);
          return hm.Z.Ge;
        }
        K(175);
      }
    }
  }
  var Mu = RegExp(
      "^UA-\\d+-\\d+%3A[\\w-]+(?:%2C[\\w-]+)*(?:%3BUA-\\d+-\\d+%3A[\\w-]+(?:%2C[\\w-]+)*)*$"
    ),
    Nu = /^~?[\w-]+(?:\.~?[\w-]+)*$/,
    Ou = /^\d+\.fls\.doubleclick\.net$/,
    Pu = /;gac=([^;?]+)/,
    Qu = /;gacgb=([^;?]+)/;
  function Ru(a, b) {
    if (Ou.test(A.location.host)) {
      var c = A.location.href.match(b);
      return c && c.length === 2 && c[1].match(Mu) ? rj(c[1]) || "" : "";
    }
    for (
      var d = [], e = m(Object.keys(a)), f = e.next();
      !f.done;
      f = e.next()
    ) {
      for (var g = f.value, h = [], l = a[g], n = 0; n < l.length; n++)
        h.push(l[n].gclid);
      d.push(g + ":" + h.join(","));
    }
    return d.length > 0 ? d.join(";") : "";
  }
  function Su(a, b, c) {
    for (
      var d = mt(lt()) ? Hs("_gac_gb", !0) : {},
        e = [],
        f = !1,
        g = m(Object.keys(d)),
        h = g.next();
      !h.done;
      h = g.next()
    ) {
      var l = h.value,
        n = gu("_gac_gb_" + l, a, b, c);
      f =
        f ||
        (n.length !== 0 &&
          n.some(function (p) {
            return p === 1;
          }));
      e.push(l + ":" + n.join(","));
    }
    return { zq: f ? e.join(";") : "", yq: Ru(d, Qu) };
  }
  function Tu(a) {
    var b = A.location.href.match(new RegExp(";" + a + "=([^;?]+)"));
    return b && b.length === 2 && b[1].match(Nu) ? b[1] : void 0;
  }
  function Uu(a) {
    var b = {},
      c,
      d,
      e;
    Ou.test(A.location.host) &&
      ((c = Tu("gclgs")), (d = Tu("gclst")), (e = Tu("gcllp")));
    if (c && d && e) (b.ng = c), (b.Nh = d), (b.Mh = e);
    else {
      var f = Fb(),
        g = ut((a || "_gcl") + "_gs"),
        h = g.map(function (p) {
          return p.gclid;
        }),
        l = g.map(function (p) {
          return f - p.timestamp;
        }),
        n = g.map(function (p) {
          return p.Vc;
        });
      h.length > 0 &&
        l.length > 0 &&
        n.length > 0 &&
        ((b.ng = h.join(".")), (b.Nh = l.join(".")), (b.Mh = n.join(".")));
    }
    return b;
  }
  function Vu(a, b, c, d) {
    d = d === void 0 ? !1 : d;
    if (Ou.test(A.location.host)) {
      var e = Tu(c);
      if (e) {
        if (d) {
          var f = new Zs();
          $s(f, 2);
          $s(f, 3);
          return e.split(".").map(function (h) {
            return { gclid: h, Aa: f, ab: [1] };
          });
        }
        return e.split(".").map(function (h) {
          return { gclid: h, Aa: new Zs(), ab: [1] };
        });
      }
    } else {
      if (b === "gclid") {
        var g = (a || "_gcl") + "_aw";
        return d ? Gt(g) : pt(g);
      }
      if (b === "wbraid") return pt((a || "_gcl") + "_gb");
      if (b === "braids") return rt({ prefix: a });
    }
    return [];
  }
  function Wu(a) {
    return Ou.test(A.location.host) ? !(Tu("gclaw") || Tu("gac")) : ku(a);
  }
  function Xu(a, b, c) {
    var d;
    d = c ? hu(a, b) : gu(((b && b.prefix) || "_gcl") + "_gb", a, b);
    return d.length === 0 ||
      d.every(function (e) {
        return e === 0;
      })
      ? ""
      : d.join(".");
  }
  var cv = function (a) {
      this.C = 1;
      this.C > 0 || (this.C = 1);
      this.onSuccess = a.D.onSuccess;
    },
    dv = function (a, b) {
      return Rb(
        function () {
          a.C--;
          if (pb(a.onSuccess) && a.C === 0) a.onSuccess();
        },
        b > 0 ? b : 1
      );
    };
  function gv(a, b) {
    var c = !!lj();
    switch (a) {
      case 45:
        return "https://www.google.com/ccm/collect";
      case 46:
        return c
          ? kj() + "/gs/ccm/collect"
          : "https://pagead2.googlesyndication.com/ccm/collect";
      case 51:
        return "https://www.google.com/travel/flights/click/conversion";
      case 9:
        return "https://googleads.g.doubleclick.net/pagead/viewthroughconversion";
      case 17:
        return c ? (Tm() ? ev() : "" + kj() + "/ag/g/c") : ev();
      case 16:
        return c ? (Tm() ? fv() : "" + kj() + "/ga/g/c") : fv();
      case 67:
        return Tm() ? "" : "https://www.google.com/g/collect";
      case 1:
        return "https://ad.doubleclick.net/activity;";
      case 2:
        return c
          ? kj() + "/ddm/activity/"
          : "https://ade.googlesyndication.com/ddm/activity/";
      case 33:
        return "https://ad.doubleclick.net/activity;register_conversion=1;";
      case 11:
        return c
          ? kj() + "/d/pagead/form-data"
          : F(141)
          ? "https://www.google.com/pagead/form-data"
          : "https://google.com/pagead/form-data";
      case 3:
        return "https://" + b.Up + ".fls.doubleclick.net/activityi;";
      case 5:
        return "https://www.googleadservices.com/pagead/conversion";
      case 6:
        return c
          ? kj() + "/gs/pagead/conversion"
          : "https://pagead2.googlesyndication.com/pagead/conversion";
      case 66:
        return "https://www.google.com/pagead/uconversion";
      case 8:
        return "https://www.google.com/pagead/1p-conversion";
      case 63:
        return "https://www.googleadservices.com/pagead/conversion";
      case 64:
        return c
          ? kj() + "/gs/pagead/conversion"
          : "https://pagead2.googlesyndication.com/pagead/conversion";
      case 65:
        return "https://www.google.com/pagead/1p-conversion";
      case 22:
        return c
          ? kj() + "/as/d/ccm/conversion"
          : "https://www.googleadservices.com/ccm/conversion";
      case 60:
        return c
          ? kj() + "/gs/ccm/conversion"
          : "https://pagead2.googlesyndication.com/ccm/conversion";
      case 23:
        return c
          ? kj() + "/g/d/ccm/conversion"
          : "https://www.google.com/ccm/conversion";
      case 55:
        var d = F(280) ? "measurement/conversion" : "measurement/conversion/";
        return c
          ? kj() + "/gs/" + d
          : "https://pagead2.googlesyndication.com/" + d;
      case 54:
        var e = F(280) ? "measurement/conversion" : "measurement/conversion/";
        return F(205)
          ? "https://www.google.com/" + e
          : c
          ? kj() + "/g/" + e
          : "https://www.google.com/" + e;
      case 21:
        return c
          ? kj() + "/d/ccm/form-data"
          : F(141)
          ? "https://www.google.com/ccm/form-data"
          : "https://google.com/ccm/form-data";
      case 7:
      case 52:
      case 53:
      case 39:
      case 38:
      case 40:
      case 37:
      case 49:
      case 48:
      case 14:
      case 24:
      case 19:
      case 27:
      case 30:
      case 36:
      case 62:
      case 26:
      case 29:
      case 32:
      case 35:
      case 57:
      case 58:
      case 50:
      case 12:
      case 13:
      case 20:
      case 18:
      case 59:
      case 47:
      case 15:
      case 0:
      case 61:
      case 56:
      case 25:
      case 28:
      case 31:
      case 34:
        throw Error("Unsupported endpoint");
      default:
        rc(a, "Unknown endpoint");
    }
  }
  function iv(a) {
    switch (a) {
      case 0:
        break;
      case 9:
        return "e4";
      case 6:
        return "e5";
      case 14:
        return "e6";
      default:
        return "e7";
    }
  }
  var jv =
      "email email_address sha256_email_address phone_number sha256_phone_number first_name last_name".split(
        " "
      ),
    kv =
      "first_name sha256_first_name last_name sha256_last_name street sha256_street city region country postal_code".split(
        " "
      );
  function lv(a, b) {
    if (!b._tag_metadata) {
      for (var c = {}, d = 0, e = 0; e < a.length; e++)
        d += mv(a[e], b, c) ? 1 : 0;
      d > 0 && (b._tag_metadata = c);
    }
  }
  function mv(a, b, c) {
    var d = b[a];
    if (d === void 0 || d === null) return !1;
    c[a] = Array.isArray(d)
      ? d.map(function () {
          return { mode: "c" };
        })
      : { mode: "c" };
    return !0;
  }
  function nv(a) {
    if (F(178) && a) {
      lv(jv, a);
      for (var b = tb(a.address), c = 0; c < b.length; c++) {
        var d = b[c];
        d && lv(kv, d);
      }
      var e = a.home_address;
      e && lv(kv, e);
    }
  }
  function ov(a, b, c) {
    function d(f, g) {
      g = String(g).substring(0, 100);
      e.push("" + f + encodeURIComponent(g));
    }
    if (!c) return "";
    var e = [];
    d("i", String(a));
    d("f", b);
    c.mode && d("m", c.mode);
    c.isPreHashed && d("p", "1");
    c.rawLength && d("r", String(c.rawLength));
    c.normalizedLength && d("n", String(c.normalizedLength));
    c.location && d("l", c.location);
    c.selector && d("s", c.selector);
    return e.join(".");
  }
  function pv() {
    this.blockSize = -1;
  }
  function qv(a, b) {
    this.blockSize = -1;
    this.blockSize = 64;
    this.P = Da.Uint8Array
      ? new Uint8Array(this.blockSize)
      : Array(this.blockSize);
    this.T = this.H = 0;
    this.C = [];
    this.la = a;
    this.V = b;
    this.wa = Da.Int32Array ? new Int32Array(64) : Array(64);
    rv === void 0 && (Da.Int32Array ? (rv = new Int32Array(sv)) : (rv = sv));
    this.reset();
  }
  Ea(qv, pv);
  for (var tv = [], uv = 0; uv < 63; uv++) tv[uv] = 0;
  var vv = [].concat(128, tv);
  qv.prototype.reset = function () {
    this.T = this.H = 0;
    var a;
    if (Da.Int32Array) a = new Int32Array(this.V);
    else {
      var b = this.V,
        c = b.length;
      if (c > 0) {
        for (var d = Array(c), e = 0; e < c; e++) d[e] = b[e];
        a = d;
      } else a = [];
    }
    this.C = a;
  };
  var wv = function (a) {
    for (var b = a.P, c = a.wa, d = 0, e = 0; e < b.length; )
      (c[d++] = (b[e] << 24) | (b[e + 1] << 16) | (b[e + 2] << 8) | b[e + 3]),
        (e = d * 4);
    for (var f = 16; f < 64; f++) {
      var g = c[f - 15] | 0,
        h = c[f - 2] | 0;
      c[f] =
        ((((c[f - 16] | 0) +
          (((g >>> 7) | (g << 25)) ^ ((g >>> 18) | (g << 14)) ^ (g >>> 3))) |
          0) +
          (((c[f - 7] | 0) +
            (((h >>> 17) | (h << 15)) ^
              ((h >>> 19) | (h << 13)) ^
              (h >>> 10))) |
            0)) |
        0;
    }
    for (
      var l = a.C[0] | 0,
        n = a.C[1] | 0,
        p = a.C[2] | 0,
        q = a.C[3] | 0,
        r = a.C[4] | 0,
        u = a.C[5] | 0,
        t = a.C[6] | 0,
        v = a.C[7] | 0,
        w = 0;
      w < 64;
      w++
    ) {
      var y =
          ((((l >>> 2) | (l << 30)) ^
            ((l >>> 13) | (l << 19)) ^
            ((l >>> 22) | (l << 10))) +
            ((l & n) ^ (l & p) ^ (n & p))) |
          0,
        z =
          (((v +
            (((r >>> 6) | (r << 26)) ^
              ((r >>> 11) | (r << 21)) ^
              ((r >>> 25) | (r << 7)))) |
            0) +
            ((((((r & u) ^ (~r & t)) + (rv[w] | 0)) | 0) + (c[w] | 0)) | 0)) |
          0;
      v = t;
      t = u;
      u = r;
      r = (q + z) | 0;
      q = p;
      p = n;
      n = l;
      l = (z + y) | 0;
    }
    a.C[0] = (a.C[0] + l) | 0;
    a.C[1] = (a.C[1] + n) | 0;
    a.C[2] = (a.C[2] + p) | 0;
    a.C[3] = (a.C[3] + q) | 0;
    a.C[4] = (a.C[4] + r) | 0;
    a.C[5] = (a.C[5] + u) | 0;
    a.C[6] = (a.C[6] + t) | 0;
    a.C[7] = (a.C[7] + v) | 0;
  };
  qv.prototype.update = function (a, b) {
    b === void 0 && (b = a.length);
    var c = 0,
      d = this.H;
    if (typeof a === "string")
      for (; c < b; )
        (this.P[d++] = a.charCodeAt(c++)),
          d == this.blockSize && (wv(this), (d = 0));
    else {
      var e,
        f = typeof a;
      e = f != "object" ? f : a ? (Array.isArray(a) ? "array" : f) : "null";
      if (e == "array" || (e == "object" && typeof a.length == "number"))
        for (; c < b; ) {
          var g = a[c++];
          if (!("number" == typeof g && 0 <= g && 255 >= g && g == (g | 0)))
            throw Error("message must be a byte array");
          this.P[d++] = g;
          d == this.blockSize && (wv(this), (d = 0));
        }
      else throw Error("message must be string or array");
    }
    this.H = d;
    this.T += b;
  };
  qv.prototype.digest = function () {
    var a = [],
      b = this.T * 8;
    this.H < 56
      ? this.update(vv, 56 - this.H)
      : this.update(vv, this.blockSize - (this.H - 56));
    for (var c = 63; c >= 56; c--) (this.P[c] = b & 255), (b /= 256);
    wv(this);
    for (var d = 0, e = 0; e < this.la; e++)
      for (var f = 24; f >= 0; f -= 8) a[d++] = (this.C[e] >> f) & 255;
    return a;
  };
  var sv = [
      1116352408, 1899447441, 3049323471, 3921009573, 961987163, 1508970993,
      2453635748, 2870763221, 3624381080, 310598401, 607225278, 1426881987,
      1925078388, 2162078206, 2614888103, 3248222580, 3835390401, 4022224774,
      264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986,
      2554220882, 2821834349, 2952996808, 3210313671, 3336571891, 3584528711,
      113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291,
      1695183700, 1986661051, 2177026350, 2456956037, 2730485921, 2820302411,
      3259730800, 3345764771, 3516065817, 3600352804, 4094571909, 275423344,
      430227734, 506948616, 659060556, 883997877, 958139571, 1322822218,
      1537002063, 1747873779, 1955562222, 2024104815, 2227730452, 2361852424,
      2428436474, 2756734187, 3204031479, 3329325298,
    ],
    rv;
  function xv() {
    qv.call(this, 8, yv);
  }
  Ea(xv, qv);
  var yv = [
    1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924,
    528734635, 1541459225,
  ];
  var zv = /^[0-9A-Fa-f]{64}$/;
  function Av(a) {
    try {
      return new TextEncoder().encode(a);
    } catch (b) {
      return Qb(a);
    }
  }
  function Bv(a) {
    var b = x;
    if (a === "" || a === "e0") return Promise.resolve(a);
    var c;
    if ((c = b.crypto) == null ? 0 : c.subtle) {
      if (zv.test(a)) return Promise.resolve(a);
      try {
        var d = Av(a);
        return b.crypto.subtle
          .digest("SHA-256", d)
          .then(function (e) {
            return Cv(e, b);
          })
          .catch(function () {
            return "e2";
          });
      } catch (e) {
        return Promise.resolve("e2");
      }
    } else return Promise.resolve("e1");
  }
  function Cv(a, b) {
    var c = Array.from(new Uint8Array(a))
      .map(function (d) {
        return String.fromCharCode(d);
      })
      .join("");
    return b.btoa(c).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  }
  function kw() {
    var a = [],
      b = Number("") || 0,
      c = Number("") || 0;
    c || (c = b / 100);
    var d = (function () {
      var ja = !1;
      ja = !0;
      return ja;
    })();
    a.push({
      ma: 21,
      studyId: 21,
      experimentId: 105102050,
      controlId: 105102051,
      controlId2: 105102052,
      probability: c,
      active: d,
      ka: 0,
    });
    var e = Number("") || 0,
      f = Number("") || 0;
    f || (f = e / 100);
    var g = (function () {
      var ja = !1;
      ja = !0;
      return ja;
    })();
    a.push({
      ma: 265,
      studyId: 265,
      experimentId: 115691063,
      controlId: 115691064,
      controlId2: 115691065,
      probability: f,
      active: g,
      ka: 0,
    });
    var h = Number("") || 0,
      l = Number("") || 0;
    l || (l = h / 100);
    var n = (function () {
      var ja = !1;
      return ja;
    })();
    a.push({
      ma: 228,
      studyId: 228,
      experimentId: 105177154,
      controlId: 105177155,
      controlId2: 105255245,
      probability: l,
      active: n,
      ka: 0,
    });
    var p = Number("") || 0,
      q = Number("") || 0;
    q || (q = p / 100);
    var r = (function () {
      var ja = !1;
      return ja;
    })();
    a.push({
      ma: 287,
      studyId: 287,
      experimentId: 116133312,
      controlId: 116133313,
      controlId2: 116133314,
      probability: q,
      active: r,
      ka: 0,
    });
    var u = Number("") || 0,
      t = Number("") || 0;
    t || (t = u / 100);
    var v = (function () {
      var ja = !1;
      return ja;
    })();
    a.push({
      ma: 288,
      studyId: 288,
      experimentId: 116133315,
      controlId: 116133316,
      controlId2: 116133317,
      probability: t,
      active: v,
      ka: 0,
    });
    var w = Number("") || 0,
      y = Number("0") || 0;
    y || (y = w / 100);
    var z = (function () {
      var ja = !1;
      return ja;
    })();
    a.push({
      ma: 285,
      studyId: 285,
      experimentId: 115495938,
      controlId: 115495939,
      controlId2: 115495940,
      probability: y,
      active: z,
      ka: 0,
    });
    var D = Number("") || 0,
      E = Number("0") || 0;
    E || (E = D / 100);
    var L = (function () {
      var ja = !1;
      return ja;
    })();
    a.push({
      ma: 286,
      studyId: 286,
      experimentId: 115495941,
      controlId: 115495942,
      controlId2: 115495943,
      probability: E,
      active: L,
      ka: 0,
    });
    var I = Number("") || 0,
      R = Number("") || 0;
    R || (R = I / 100);
    var X = (function () {
      var ja = !1;
      ja = !0;
      return ja;
    })();
    a.push({
      ma: 219,
      studyId: 219,
      experimentId: 104948811,
      controlId: 104948812,
      controlId2: 0,
      probability: R,
      active: X,
      ka: 0,
    });
    var Z = Number("") || 0,
      Q = Number("1") || 0;
    Q || (Q = Z / 100);
    var W = (function () {
      var ja = !1;
      return ja;
    })();
    a.push({
      ma: 220,
      studyId: 220,
      experimentId: 104948813,
      controlId: 104948814,
      controlId2: 0,
      probability: Q,
      active: W,
      ka: 0,
    });
    var ma = Number("") || 0,
      ka = Number("0.1") || 0;
    ka || (ka = ma / 100);
    var T = (function () {
      var ja = !1;
      return ja;
    })();
    a.push({
      ma: 255,
      studyId: 255,
      experimentId: 105391252,
      controlId: 105391253,
      controlId2: 105446120,
      probability: ka,
      active: T,
      ka: 0,
    });
    var U = Number("") || 0,
      ha = Number("") || 0;
    ha || (ha = U / 100);
    var va = (function () {
      var ja = !1;
      return ja;
    })();
    a.push({
      ma: 235,
      studyId: 235,
      experimentId: 105357150,
      controlId: 105357151,
      controlId2: 0,
      probability: ha,
      active: va,
      ka: 1,
    });
    var pa = Number("") || 0,
      Ma = Number("0") || 0;
    Ma || (Ma = pa / 100);
    var Wa = (function () {
      var ja = !1;
      return ja;
    })();
    a.push({
      ma: 170,
      studyId: 170,
      experimentId: 116024733,
      controlId: 116024734,
      controlId2: 116024735,
      probability: Ma,
      active: Wa,
      ka: 0,
    });
    var qb = Number("") || 0,
      cb = Number("0.5") || 0;
    cb || (cb = qb / 100);
    var eb = (function () {
      var ja = !1;
      return ja;
    })();
    a.push({
      ma: 203,
      studyId: 203,
      experimentId: 115480710,
      controlId: 115480709,
      controlId2: 115489982,
      probability: cb,
      active: eb,
      ka: 0,
    });
    var ic = Number("") || 0,
      uc = Number("") || 0;
    uc || (uc = ic / 100);
    var Ef = (function () {
      var ja = !1;
      return ja;
    })();
    a.push({
      ma: 178,
      studyId: 178,
      experimentId: 115958700,
      controlId: 115958701,
      controlId2: 115958702,
      probability: uc,
      active: Ef,
      ka: 0,
    });
    var Uk = Number("") || 0,
      Hg = Number("") || 0;
    Hg || (Hg = Uk / 100);
    var si = (function () {
      var ja = !1;
      ja = !0;
      return ja;
    })();
    a.push({
      ma: 197,
      studyId: 197,
      experimentId: 105113532,
      controlId: 105113531,
      controlId2: 0,
      probability: Hg,
      active: si,
      ka: 0,
    });
    var Vk = Number("") || 0,
      ti = Number("0.2") || 0;
    ti || (ti = Vk / 100);
    var Wk = (function () {
      var ja = !1;
      return ja;
    })();
    a.push({
      ma: 243,
      studyId: 243,
      experimentId: 115616985,
      controlId: 115616986,
      controlId2: 0,
      probability: ti,
      active: Wk,
      ka: 0,
    });
    var Ro = Number("") || 0,
      ui = Number("") || 0;
    ui || (ui = Ro / 100);
    var Xk = (function () {
      var ja = !1;
      ja = !0;
      return ja;
    })();
    a.push({
      ma: 277,
      studyId: 277,
      experimentId: 116130039,
      controlId: 116130040,
      controlId2: 0,
      probability: ui,
      active: Xk,
      ka: 0,
    });
    var So = Number("") || 0,
      vi = Number("") || 0;
    vi || (vi = So / 100);
    var To = (function () {
      var ja = !1;
      return ja;
    })();
    a.push({
      ma: 171,
      studyId: 171,
      experimentId: 104967143,
      controlId: 104967140,
      controlId2: 0,
      probability: vi,
      active: To,
      ka: 0,
    });
    var Yk = Number("") || 0,
      wi = Number("1") || 0;
    wi || (wi = Yk / 100);
    var Uo = (function () {
      var ja = !1;
      return ja;
    })();
    a.push({
      ma: 254,
      studyId: 254,
      experimentId: 115583767,
      controlId: 115583768,
      controlId2: 115583769,
      probability: wi,
      active: Uo,
      ka: 0,
    });
    var AJ = Number("") || 0,
      Vo = Number("") || 0;
    Vo || (Vo = AJ / 100);
    var BJ = (function () {
      var ja = !1;
      return ja;
    })();
    a.push({
      ma: 253,
      studyId: 253,
      experimentId: 115583770,
      controlId: 115583771,
      controlId2: 115583772,
      probability: Vo,
      active: BJ,
      ka: 0,
    });
    var CJ = Number("") || 0,
      Wo = Number("") || 0;
    Wo || (Wo = CJ / 100);
    var DJ = (function () {
      var ja = !1;
      return ja;
    })();
    a.push({
      ma: 266,
      studyId: 266,
      experimentId: 115718529,
      controlId: 115718530,
      controlId2: 115718531,
      probability: Wo,
      active: DJ,
      ka: 0,
    });
    var EJ = Number("") || 0,
      Xo = Number("") || 0;
    Xo || (Xo = EJ / 100);
    var FJ = (function () {
      var ja = !1;
      return ja;
    })();
    a.push({
      ma: 267,
      studyId: 267,
      experimentId: 115718526,
      controlId: 115718527,
      controlId2: 115718528,
      probability: Xo,
      active: FJ,
      ka: 0,
    });
    var GJ = Number("") || 0,
      Yo = Number("0.1") || 0;
    Yo || (Yo = GJ / 100);
    var HJ = (function () {
      var ja = !1;
      return ja;
    })();
    a.push({
      ma: 259,
      studyId: 259,
      experimentId: 105322302,
      controlId: 105322303,
      controlId2: 105322304,
      probability: Yo,
      active: HJ,
      ka: 0,
    });
    var IJ = Number("") || 0,
      Zo = Number("") || 0;
    Zo || (Zo = IJ / 100);
    var JJ = (function () {
      var ja = !1;
      return ja;
    })();
    a.push({
      ma: 249,
      studyId: 249,
      experimentId: 105440521,
      controlId: 105440522,
      controlId2: 0,
      focused: !0,
      probability: Zo,
      active: JJ,
      ka: 0,
    });
    var KJ = Number("") || 0,
      $o = Number("0.5") || 0;
    $o || ($o = KJ / 100);
    var LJ = (function () {
      var ja = !1;
      return ja;
    })();
    a.push({
      ma: 195,
      studyId: 195,
      experimentId: 104527906,
      controlId: 104527907,
      controlId2: 104898015,
      probability: $o,
      active: LJ,
      ka: 1,
    });
    var MJ = Number("") || 0,
      ap = Number("0.5") || 0;
    ap || (ap = MJ / 100);
    var NJ = (function () {
      var ja = !1;
      return ja;
    })();
    a.push({
      ma: 196,
      studyId: 196,
      experimentId: 104528500,
      controlId: 104528501,
      controlId2: 104898016,
      probability: ap,
      active: NJ,
      ka: 0,
    });
    var OJ = Number("") || 0,
      bp = Number("") || 0;
    bp || (bp = OJ / 100);
    var PJ = (function () {
      var ja = !1;
      ja = !0;
      return ja;
    })();
    a.push({
      ma: 229,
      studyId: 229,
      experimentId: 105359938,
      controlId: 105359937,
      controlId2: 105359936,
      probability: bp,
      active: PJ,
      ka: 0,
    });
    return a;
  }
  var lw = {};
  function mw(a) {
    var b = a,
      c = (a = nw[b.studyId]
        ? la(Object, "assign").call(Object, {}, b, { active: !0 })
        : b);
    (c.controlId2 && c.probability <= 0.25) ||
      (c = la(Object, "assign").call(Object, {}, c, { controlId2: 0 }));
    Li[c.studyId] = c;
    a.focused && (lw[a.studyId] = !0);
    if (a.ka === 1) {
      var d = a.studyId;
      ow(mm(hm.Z.Qi, {}), d);
      pw(d) && C(d);
    } else if (a.ka === 0) {
      var e = a.studyId;
      ow(qw, e);
      pw(e) && C(e);
    }
  }
  function ow(a, b) {
    if (Li[b]) {
      var c = Li[b],
        d = c.experimentId,
        e = c.probability;
      if (!(a.studies || {})[b]) {
        var f = a.studies || {};
        f[b] = !0;
        a.studies = f;
        Li[b].active ||
          (Li[b].probability > 0.5
            ? Pi(a, d, b)
            : e <= 0 || e > 1 || Oi.Hr(a, b));
      }
    }
    if (!lw[b]) {
      var g = Ri(a, b);
      g && Ui.C.H.add(g);
    }
  }
  var qw = {};
  function pw(a) {
    return Qi(mm(hm.Z.Qi, {}), a) || Qi(qw, a);
  }
  function rw(a) {
    var b = O(a, N.A.Ei) || [];
    return mk(b);
  }
  var nw = {};
  function sw() {
    nw = {};
    var a,
      b,
      c =
        ((a = x) == null
          ? void 0
          : (b = a.location) == null
          ? void 0
          : b.hash) || "";
    if (Kb(c, "#_te=")) {
      var d = c.substring(5);
      if (d)
        for (var e = m(d.split("~")), f = e.next(); !f.done; f = e.next()) {
          var g = Number(f.value);
          g && ((nw[g] = !0), C(g));
        }
    }
    for (var h = m(kw()), l = h.next(); !l.done; l = h.next()) mw(l.value);
    for (var n = [], p = m(lg(56) || []), q = p.next(); !q.done; q = p.next()) {
      var r = q.value,
        u = {
          studyId: r[1],
          active: !!r[2],
          probability: r[3] || 0,
          experimentId: r[4] || 0,
          controlId: r[5] || 0,
          controlId2: r[6] || 0,
        },
        t = 0;
      switch (r[7]) {
        case 2:
          t = 1;
          break;
        case 1:
        case 0:
          t = 0;
      }
      var v;
      a: switch (u.studyId) {
        case 249:
          v = !0;
          break a;
        default:
          v = !1;
      }
      var w = la(Object, "assign").call(Object, {}, u, { ka: t, focused: v });
      (w.active || (w.experimentId && w.controlId)) && n.push(w);
    }
    for (var y = m(n), z = y.next(); !z.done; z = y.next()) mw(z.value);
  }
  function tw(a, b) {
    b &&
      yb(b, function (c, d) {
        typeof d !== "object" && d !== void 0 && (a["1p." + c] = String(d));
      });
  }
  function uw(a, b) {
    var c = Gu(a, J.m.Ec);
    if (c && typeof c === "object")
      for (var d = m(Object.keys(c)), e = d.next(); !e.done; e = d.next()) {
        var f = e.value,
          g = c[f];
        g !== void 0 && (g === null && (g = ""), (b["gap." + f] = String(g)));
      }
  }
  function vw(a, b, c, d) {
    if (wn()) {
      var e = b.D;
      Dn({
        targetId: d || [b.target.destinationId],
        request: { url: a, parameterEncoding: 2, endpoint: c },
        hb: { eventId: e.eventId, priorityId: e.priorityId },
        ij: { eventId: O(b, N.A.Xe), priorityId: O(b, N.A.Ye) },
      });
    }
  }
  var Iw = {};
  Iw.N = nr.N;
  var Jw = {
      Gs: "L",
      Fp: "S",
      Ts: "Y",
      bs: "B",
      ys: "E",
      Cs: "I",
      Qs: "TC",
      Bs: "HTC",
    },
    Kw = { Fp: "S", xs: "V", hs: "E", Ps: "tag" },
    Lw = {},
    Mw = ((Lw[Iw.N.Zi] = "6"), (Lw[Iw.N.aj] = "5"), (Lw[Iw.N.Yi] = "7"), Lw);
  function Nw() {
    function a(c, d) {
      var e = nb(d);
      e && b.push([c, e]);
    }
    var b = [];
    a("u", "GTM");
    a("ut", "TAGGING");
    a("h", "HEALTH");
    return b;
  }
  var Ow = !1;
  function gx(a) {}
  function hx(a) {}
  function ix() {}
  function jx(a) {}
  function kx(a) {}
  function lx(a) {}
  function mx() {}
  function nx(a, b) {}
  function ox(a, b, c) {}
  function px() {}
  var qx = Object.freeze({
    cache: "no-store",
    credentials: "include",
    method: "GET",
    keepalive: !0,
    redirect: "follow",
  });
  function rx(a, b, c, d, e, f, g, h) {
    var l = la(Object, "assign").call(Object, {}, qx);
    c && ((l.body = c), (l.method = "POST"));
    la(Object, "assign").call(Object, l, e);
    h == null || xl(h);
    x.fetch(b, l)
      .then(function (n) {
        h == null || yl(h);
        if (!n.ok) g == null || g();
        else if (n.body) {
          var p = n.body.getReader(),
            q = new TextDecoder();
          return new Promise(function (r) {
            function u() {
              p.read()
                .then(function (t) {
                  var v;
                  v = t.done;
                  var w = q.decode(t.value, { stream: !v });
                  sx(d, w);
                  v ? (f == null || f(), r()) : u();
                })
                .catch(function () {
                  r();
                });
            }
            u();
          });
        }
      })
      .catch(function () {
        h == null || yl(h);
        g
          ? g()
          : F(128) && ((b += "&_z=retryFetch"), c ? Al(a, b, c) : zl(a, b));
      });
  }
  var tx = function (a) {
      this.P = a;
      this.C = "";
    },
    ux = function (a, b) {
      a.H = b;
      return a;
    },
    sx = function (a, b) {
      b = a.C + b;
      for (var c = b.indexOf("\n\n"); c !== -1; ) {
        var d = a,
          e;
        a: {
          var f = m(b.substring(0, c).split("\n")),
            g = f.next().value,
            h = f.next().value;
          if (g.indexOf("event: message") === 0 && h.indexOf("data: ") === 0)
            try {
              e = JSON.parse(h.substring(h.indexOf(":") + 1));
              break a;
            } catch (l) {}
          e = void 0;
        }
        vx(d, e);
        b = b.substring(c + 2);
        c = b.indexOf("\n\n");
      }
      a.C = b;
    },
    wx = function (a, b) {
      return function () {
        if (b.fallback_url && b.fallback_url_method) {
          var c = {};
          vx(
            a,
            ((c[b.fallback_url_method] = [b.fallback_url]), (c.options = {}), c)
          );
        }
      };
    },
    vx = function (a, b) {
      b &&
        (xx(b.send_pixel, b.options, a.P),
        xx(b.create_iframe, b.options, a.T),
        xx(b.fetch, b.options, a.H));
    };
  function yx(a) {
    var b = a.search;
    return (
      a.protocol +
      "//" +
      a.hostname +
      a.pathname +
      (b ? b + "&richsstsse" : "?richsstsse")
    );
  }
  function xx(a, b, c) {
    if (a && c) {
      var d = a || [];
      if (Array.isArray(d))
        for (
          var e = rd(b) ? b : {}, f = m(d), g = f.next();
          !g.done;
          g = f.next()
        )
          c(g.value, e);
    }
  }
  var wg;
  function zx() {
    var a = data.permissions || {};
    wg = new Cg(hg(5), a);
  }
  function Ax(a, b) {
    xg(a, b);
  }
  var Bx = mg(57, 5),
    Cx = mg(58, 50),
    Dx = vb();
  var Fx = function (a, b) {
      a &&
        (Ex("sid", a.targetId, b),
        Ex("cc", a.clientCount, b),
        Ex("tl", a.totalLifeMs, b),
        Ex("hc", a.heartbeatCount, b),
        Ex("cl", a.clientLifeMs, b));
    },
    Ex = function (a, b, c) {
      b != null && c.push(a + "=" + b);
    },
    Gx = function () {
      var a = A.referrer;
      if (a) {
        var b;
        return sj(yj(a), "host") ===
          ((b = x.location) == null ? void 0 : b.host)
          ? 1
          : 2;
      }
      return 0;
    },
    Hx = "https://" + hg(21) + "/a?",
    Jx = function () {
      this.V = Ix;
      this.P = 0;
    };
  Jx.prototype.H = function (a, b, c, d) {
    var e = Gx(),
      f,
      g = [];
    f =
      x === x.top && e !== 0 && b
        ? (b == null ? void 0 : b.clientCount) > 1
          ? e === 2
            ? 1
            : 2
          : e === 2
          ? 0
          : 3
        : 4;
    a && Ex("si", a.vg, g);
    Ex("m", 0, g);
    Ex("iss", f, g);
    Ex("if", c, g);
    Fx(b, g);
    d && Ex("fm", encodeURIComponent(d.substring(0, Cx)), g);
    this.T(g);
  };
  Jx.prototype.C = function (a, b, c, d, e) {
    var f = [];
    Ex("m", 1, f);
    Ex("s", a, f);
    Ex("po", Gx(), f);
    b && (Ex("st", b.state, f), Ex("si", b.vg, f), Ex("sm", b.Dg, f));
    Fx(c, f);
    Ex("c", d, f);
    e && Ex("fm", encodeURIComponent(e.substring(0, Cx)), f);
    this.T(f);
  };
  Jx.prototype.T = function (a) {
    a = a === void 0 ? [] : a;
    !Lk ||
      this.P >= Bx ||
      (Ex("pid", Dx, a),
      Ex("bc", ++this.P, a),
      a.unshift("ctid=" + hg(5) + "&t=s"),
      this.V("" + Hx + a.join("&")));
  };
  function Kx(a) {
    return (a.performance && a.performance.now()) || Date.now();
  }
  var Mx = function (a, b) {
    var c = x,
      d = Lx,
      e;
    var f = function (g, h, l) {
      l =
        l === void 0
          ? {
              nn: function () {},
              on: function () {},
              mn: function () {},
              onFailure: function () {},
            }
          : l;
      this.Np = g;
      this.C = h;
      this.P = l;
      this.la = this.wa = this.heartbeatCount = this.Mp = 0;
      this.Dh = !1;
      this.H = {};
      this.id = String(Math.floor(Number.MAX_SAFE_INTEGER * Math.random()));
      this.state = 0;
      this.vg = Kx(this.C);
      this.Dg = Kx(this.C);
      this.V = 10;
    };
    f.prototype.init = function () {
      this.T(1);
      this.Za();
    };
    f.prototype.getState = function () {
      return {
        state: this.state,
        vg: Math.round(Kx(this.C) - this.vg),
        Dg: Math.round(Kx(this.C) - this.Dg),
      };
    };
    f.prototype.T = function (g) {
      this.state !== g && ((this.state = g), (this.Dg = Kx(this.C)));
    };
    f.prototype.Km = function () {
      return String(this.Mp++);
    };
    f.prototype.Za = function () {
      var g = this;
      this.heartbeatCount++;
      this.wb(
        {
          type: 0,
          clientId: this.id,
          requestId: this.Km(),
          maxDelay: this.Eh(),
        },
        function (h) {
          if (h.type === 0) {
            var l;
            if (((l = h.failure) == null ? void 0 : l.failureType) != null)
              if (
                (h.stats && (g.stats = h.stats),
                g.la++,
                h.isDead || g.la > d.rm)
              ) {
                var n = h.isDead && h.failure.failureType;
                g.V = n || 10;
                g.T(4);
                g.Lp();
                var p, q;
                (q = (p = g.P).mn) == null ||
                  q.call(p, { failureType: n || 10, data: h.failure.data });
              } else g.T(3), g.Pm();
            else {
              if (g.heartbeatCount > h.stats.heartbeatCount + d.rm) {
                g.heartbeatCount = h.stats.heartbeatCount;
                var r, u;
                (u = (r = g.P).onFailure) == null ||
                  u.call(r, { failureType: 13 });
              }
              g.stats = h.stats;
              var t = g.state;
              g.T(2);
              if (t !== 2)
                if (g.Dh) {
                  var v, w;
                  (w = (v = g.P).on) == null || w.call(v);
                } else {
                  g.Dh = !0;
                  var y, z;
                  (z = (y = g.P).nn) == null || z.call(y);
                }
              g.la = 0;
              g.Op();
              g.Pm();
            }
          }
        }
      );
    };
    f.prototype.Eh = function () {
      return this.state === 2 ? d.qp : d.Jp;
    };
    f.prototype.Pm = function () {
      var g = this;
      this.C.setTimeout(function () {
        g.Za();
      }, Math.max(0, this.Eh() - (Kx(this.C) - this.wa)));
    };
    f.prototype.Sp = function (g, h, l) {
      var n = this;
      this.wb(
        { type: 1, clientId: this.id, requestId: this.Km(), command: g },
        function (p) {
          if (p.type === 1)
            if (p.result) h(p.result);
            else {
              var q,
                r,
                u,
                t = {
                  failureType:
                    (u = (q = p.failure) == null ? void 0 : q.failureType) !=
                    null
                      ? u
                      : 12,
                  data: (r = p.failure) == null ? void 0 : r.data,
                },
                v,
                w;
              (w = (v = n.P).onFailure) == null || w.call(v, t);
              l(t);
            }
        }
      );
    };
    f.prototype.wb = function (g, h) {
      var l = this;
      if (this.state === 4) (g.failure = { failureType: this.V }), h(g);
      else {
        var n = this.state !== 2 && g.type !== 0,
          p = g.requestId,
          q,
          r = this.C.setTimeout(
            function () {
              var t = l.H[p];
              t && l.Zf(t, 7);
            },
            (q = g.maxDelay) != null ? q : d.fo
          ),
          u = { request: g, An: h, un: n, hr: r };
        this.H[p] = u;
        n || this.sendRequest(u);
      }
    };
    f.prototype.sendRequest = function (g) {
      this.wa = Kx(this.C);
      g.un = !1;
      this.Np(g.request);
    };
    f.prototype.Op = function () {
      for (
        var g = m(Object.keys(this.H)), h = g.next();
        !h.done;
        h = g.next()
      ) {
        var l = this.H[h.value];
        l.un && this.sendRequest(l);
      }
    };
    f.prototype.Lp = function () {
      for (var g = m(Object.keys(this.H)), h = g.next(); !h.done; h = g.next())
        this.Zf(this.H[h.value], this.V);
    };
    f.prototype.Zf = function (g, h) {
      this.Pc(g);
      var l = g.request;
      l.failure = { failureType: h };
      g.An(l);
    };
    f.prototype.Pc = function (g) {
      delete this.H[g.request.requestId];
      this.C.clearTimeout(g.hr);
    };
    f.prototype.Kq = function (g) {
      this.wa = Kx(this.C);
      var h = this.H[g.requestId];
      if (h) this.Pc(h), h.An(g);
      else {
        var l, n;
        (n = (l = this.P).onFailure) == null || n.call(l, { failureType: 14 });
      }
    };
    e = new f(a, c, b);
    return e;
  };
  var Nx;
  var Ox = function () {
      Nx || (Nx = new Jx());
      return Nx;
    },
    Ix = function (a) {
      em(gm(Hl.aa.Oc), function () {
        Qc(a);
      });
    },
    Px = function (a) {
      var b = a.substring(0, a.indexOf("/_/service_worker"));
      return "&1p=1" + (b ? "&path=" + encodeURIComponent(b) : "");
    },
    Qx = function (a) {
      var b = a,
        c,
        d = kg(11);
      d = kg(10);
      c = d;
      b
        ? (b.charAt(b.length - 1) !== "/" && (b += "/"), (a = b + c))
        : (a =
            "https://www.googletagmanager.com/static/service_worker/" +
            c +
            "/");
      var e;
      try {
        e = new URL(a);
      } catch (f) {
        return null;
      }
      return e.protocol !== "https:" ? null : e;
    },
    Rx = function (a) {
      var b = x.location.origin;
      if (!b) return null;
      lj() && !a && (a = "" + b + kj() + "/_/service_worker");
      return Qx(a);
    },
    Sx = function (a) {
      var b = lm(hm.Z.Bm);
      return b && b[a];
    },
    Lx = { Jp: mg(53, 500), qp: mg(54, 5e3), rm: mg(8, 20), fo: mg(55, 5e3) },
    Tx = function (a, b, c) {
      var d = this;
      this.H = b;
      this.V = this.T = !1;
      this.la = null;
      this.initTime = Math.round(Fb());
      this.C = 15;
      this.P = this.kq(a);
      x.setTimeout(function () {
        d.initialize();
      }, 1e3);
      Tc(function () {
        d.Uq(a, c);
      });
    };
  k = Tx.prototype;
  k.delegate = function (a, b, c) {
    this.getState() !== 2
      ? (this.H.C(
          this.C,
          {
            state: this.getState(),
            vg: this.initTime,
            Dg: Math.round(Fb()) - this.initTime,
          },
          void 0,
          a.commandType
        ),
        c({ failureType: this.C }))
      : this.P.Sp(a, b, c);
  };
  k.getState = function () {
    return this.P.getState().state;
  };
  k.Uq = function (a, b) {
    var c = x.location.origin,
      d = this,
      e = Oc();
    try {
      var f = e.contentDocument.createElement("iframe"),
        g = a.pathname,
        h = g[g.length - 1] === "/" ? a.toString() : a.toString() + "/",
        l = a.origin !== "https://www.googletagmanager.com" ? Px(g) : "",
        n;
      F(133) && (n = { sandbox: "allow-same-origin allow-scripts" });
      Oc(
        h +
          "sw_iframe.html?origin=" +
          encodeURIComponent(c) +
          l +
          (b ? "&e=1" : ""),
        void 0,
        n,
        void 0,
        f
      );
      var p = function () {
        e.contentDocument.body.appendChild(f);
        f.addEventListener("load", function () {
          d.la = f.contentWindow;
          e.contentWindow.addEventListener("message", function (q) {
            q.origin === a.origin && d.P.Kq(q.data);
          });
          d.initialize();
        });
      };
      e.contentDocument.readyState === "complete"
        ? p()
        : e.contentWindow.addEventListener("load", function () {
            p();
          });
    } catch (q) {
      e.parentElement.removeChild(e),
        (this.C = 11),
        this.H.H(void 0, void 0, this.C, q.toString());
    }
  };
  k.kq = function (a) {
    var b = this,
      c = Mx(
        function (d) {
          var e;
          (e = b.la) == null || e.postMessage(d, a.origin);
        },
        {
          nn: function () {
            b.T = !0;
            b.H.H(c.getState(), c.stats);
          },
          on: function () {},
          mn: function (d) {
            b.T
              ? ((b.C = (d == null ? void 0 : d.failureType) || 10),
                b.H.C(
                  b.C,
                  c.getState(),
                  c.stats,
                  void 0,
                  d == null ? void 0 : d.data
                ))
              : ((b.C = (d == null ? void 0 : d.failureType) || 4),
                b.H.H(c.getState(), c.stats, b.C, d == null ? void 0 : d.data));
          },
          onFailure: function (d) {
            b.C = d.failureType;
            b.H.C(b.C, c.getState(), c.stats, d.command, d.data);
          },
        }
      );
    return c;
  };
  k.initialize = function () {
    this.V || this.P.init();
    this.V = !0;
  };
  function Ux() {
    var a = zg(wg.C, "", function () {
      return {};
    });
    try {
      return a("internal_sw_allowed"), !0;
    } catch (b) {
      return !1;
    }
  }
  function Vx(a) {
    var b,
      c,
      d = a === void 0 ? {} : a;
    b = d.Fr;
    c = d.Hn === void 0 ? !1 : d.Hn;
    var e = Rx(b);
    if (e === null || !Ux() || F(168) || Sx(e.origin)) return;
    if (!Bc()) {
      Ox().H(void 0, void 0, 6);
      return;
    }
    var f = new Tx(e, Ox(), c);
    mm(hm.Z.Bm, {})[e.origin] = f;
  }
  var Wx = function (a, b, c, d) {
    var e;
    if ((e = Sx(a)) == null || !e.delegate) {
      var f = Bc() ? 16 : 6;
      Ox().C(f, void 0, void 0, b.commandType);
      d({ failureType: f });
      return;
    }
    Sx(a).delegate(b, c, d);
  };
  function Xx(a, b, c, d, e) {
    var f = F(277) ? Rx() : Qx();
    if (f === null) {
      d(Bc() ? 16 : 6);
      return;
    }
    var g,
      h = (g = Sx(f.origin)) == null ? void 0 : g.initTime,
      l = Math.round(Fb()),
      n = {
        commandType: 0,
        params: {
          url: a,
          method: 0,
          templates: b,
          body: "",
          processResponse: !1,
          sinceInit: h ? l - h : void 0,
        },
      };
    e && (n.params.encryptionKeyString = e);
    Wx(
      f.origin,
      n,
      function (p) {
        c(p);
      },
      function (p) {
        d(p.failureType);
      }
    );
  }
  function Yx(a, b, c, d) {
    var e = Rx(a);
    if (e === null) {
      d("_is_sw=f" + (Bc() ? 16 : 6) + "te");
      return;
    }
    var f = b ? 1 : 0,
      g = Math.round(Fb()),
      h,
      l = (h = Sx(e.origin)) == null ? void 0 : h.initTime,
      n = l ? g - l : void 0;
    Wx(
      e.origin,
      {
        commandType: 0,
        params: {
          url: a,
          method: f,
          templates: c,
          body: b || "",
          processResponse: !0,
          sinceInit: n,
          attributionReporting: !0,
          referer: x.location.href,
        },
      },
      function () {},
      function (p) {
        var q = "_is_sw=f" + p.failureType,
          r,
          u = (r = Sx(e.origin)) == null ? void 0 : r.getState();
        u !== void 0 && (q += "s" + u);
        d(n ? q + ("t" + n) : q + "te");
      }
    );
  }
  var Zx = function (a, b) {
      this.lr = a;
      this.timeoutMs = b;
      this.Va = void 0;
    },
    xl = function (a) {
      a.Va ||
        (a.Va = setTimeout(function () {
          a.lr();
          a.Va = void 0;
        }, a.timeoutMs));
    },
    yl = function (a) {
      a.Va && (clearTimeout(a.Va), (a.Va = void 0));
    };
  function Ay() {
    return $n("dedupe_gclid", function () {
      return Or();
    });
  }
  function Ky(a, b, c, d) {
    var e = Nc(),
      f;
    if (e === 1)
      a: {
        var g = hg(3);
        g = g.toLowerCase();
        for (
          var h = "https://" + g,
            l = "http://" + g,
            n = 1,
            p = A.getElementsByTagName("script"),
            q = 0;
          q < p.length && q < 100;
          q++
        ) {
          var r = p[q].src;
          if (r) {
            r = r.toLowerCase();
            if (r.indexOf(l) === 0) {
              f = 3;
              break a;
            }
            n === 1 && r.indexOf(h) === 0 && (n = 2);
          }
        }
        f = n;
      }
    else f = e;
    return (f === 2 || d || "http:" !== x.location.protocol ? a : b) + c;
  }
  function Ly(a, b, c, d, e) {
    if (!Xj(a)) {
      d.loadExperiments = Wi();
      Zj(a, d, e);
      var f = My(a),
        g = function () {
          Hj().container[a] && (Hj().container[a].state = 3);
          Ny();
        },
        h = { destinationId: a, endpoint: 0 };
      if (lj()) Dl(h, kj() + "/" + Oy(f), void 0, g);
      else {
        var l = Kb(a, "GTM-"),
          n = sk(),
          p = c ? "/gtag/js" : "/gtm.js",
          q = Py(b, p + f);
        if (!q) {
          var r = hg(3) + p;
          n &&
            Dc &&
            l &&
            (r = Dc.replace(/^(?:https?:\/\/)?/i, "").split(/[?#]/)[0]);
          q = Ky("https://", "http://", r + f);
        }
        Dl(h, q, void 0, g);
      }
    }
  }
  function Ny() {
    ak() ||
      yb(bk(), function (a, b) {
        Qy(a, b.transportUrl, b.context);
        K(92);
      });
  }
  function Qy(a, b, c, d) {
    if (!Yj(a))
      if ((c.loadExperiments || (c.loadExperiments = Wi()), ak())) {
        var e = Hj(),
          f = Gj(a);
        f
          ? (f.state = 0)
          : ((f = { state: 0, transportUrl: b, context: c, parent: Sj() }),
            (e.destinationArray[a] = [f]));
        Ij({ ctid: a, isDestination: !0 }, d);
        K(91);
      } else {
        var g = Hj(),
          h = Gj(a);
        h
          ? (h.state = 1)
          : ((h = { context: c, state: 1, parent: Sj() }),
            (g.destinationArray[a] = [h]));
        Ij({ ctid: a, isDestination: !0 }, d);
        var l = { destinationId: a, endpoint: 0 };
        if (lj()) {
          var n = "gtd" + My(a, !0);
          Dl(l, kj() + "/" + Oy(n));
        } else {
          var p = "/gtag/destination" + My(a, !0),
            q = Py(b, p);
          q || (q = Ky("https://", "http://", hg(3) + p));
          Dl(l, q);
        }
      }
  }
  function My(a, b) {
    b = b === void 0 ? !1 : b;
    var c = "?id=" + encodeURIComponent(a),
      d = hg(19);
    d !== "dataLayer" && (c += "&l=" + d);
    if (!Kb(a, "GTM-") || b)
      c = F(130) ? c + (lj() ? "&sc=1" : "&cx=c") : c + "&cx=c";
    var e = c,
      f,
      g = { xn: ig(15), Bn: hg(14) };
    f = lf(g);
    c = e + ("&gtm=" + f);
    sk() && (c += "&sign=" + Yi.Wi);
    var h = ig(54);
    h === 1 ? (c += "&fps=fc") : h === 2 && (c += "&fps=fe");
    return c;
  }
  function Oy(a) {
    if (!F(274)) return a;
    var b = hg(58);
    if (!b) return K(182), a;
    try {
      return nf(a, b);
    } catch (c) {
      return K(183), a;
    }
  }
  function Py(a, b) {
    if (!F(284)) return rk(a, b);
    if ((lj() || gg(50)) && a) {
      var c = hg(58),
        d = hg(18);
      if (c && d)
        try {
          b = d + "/" + nf(b, c);
        } catch (e) {
          K(183);
        }
      return qk(a, b);
    }
  }
  var Ry = new RegExp(
      /^(.*\.)?(google|youtube|blogger|withgoogle)(\.com?)?(\.[a-z]{2})?\.?$/
    ),
    Sy = {
      cl: ["ecl"],
      customPixels: ["nonGooglePixels"],
      ecl: ["cl"],
      ehl: ["hl"],
      gaawc: ["googtag"],
      hl: ["ehl"],
      html: [
        "customScripts",
        "customPixels",
        "nonGooglePixels",
        "nonGoogleScripts",
        "nonGoogleIframes",
      ],
      customScripts: [
        "html",
        "customPixels",
        "nonGooglePixels",
        "nonGoogleScripts",
        "nonGoogleIframes",
      ],
      nonGooglePixels: [],
      nonGoogleScripts: ["nonGooglePixels"],
      nonGoogleIframes: ["nonGooglePixels"],
    },
    Ty = {
      cl: ["ecl"],
      customPixels: ["customScripts", "html"],
      ecl: ["cl"],
      ehl: ["hl"],
      gaawc: ["googtag"],
      hl: ["ehl"],
      html: ["customScripts"],
      customScripts: ["html"],
      nonGooglePixels: [
        "customPixels",
        "customScripts",
        "html",
        "nonGoogleScripts",
        "nonGoogleIframes",
      ],
      nonGoogleScripts: ["customScripts", "html"],
      nonGoogleIframes: ["customScripts", "html", "nonGoogleScripts"],
    },
    Uy =
      "google customPixels customScripts html nonGooglePixels nonGoogleScripts nonGoogleIframes".split(
        " "
      );
  function Vy() {
    var a = mp("gtm.allowlist") || mp("gtm.whitelist");
    a && K(9);
    cj &&
      (F(212)
        ? (a = void 0)
        : (a = ["google", "gtagfl", "lcl", "zone", "cmpPartners"]));
    Ry.test(x.location && x.location.hostname) &&
      (cj
        ? K(116)
        : (K(117),
          gg(48) &&
            ((a = []),
            window.console &&
              window.console.log &&
              window.console.log("GTM blocked. See go/13687728."))));
    var b = a && Jb(Cb(a), Sy),
      c = mp("gtm.blocklist") || mp("gtm.blacklist");
    c || ((c = mp("tagTypeBlacklist")) && K(3));
    c ? K(8) : (c = []);
    Ry.test(x.location && x.location.hostname) &&
      ((c = Cb(c)),
      c.push("nonGooglePixels", "nonGoogleScripts", "sandboxedScripts"));
    Cb(c).indexOf("google") >= 0 && K(2);
    var d = c && Jb(Cb(c), Ty),
      e = {};
    return function (f) {
      var g = f && f[pf.Sa];
      if (!g || typeof g !== "string") return !0;
      g = g.replace(/^_*/, "");
      if (e[g] !== void 0) return e[g];
      var h = ij[g] || [],
        l = !0;
      if (a) {
        var n;
        if ((n = l))
          a: {
            if (b.indexOf(g) < 0) {
              if (cj && h.indexOf("cmpPartners") >= 0) {
                n = !0;
                break a;
              }
              if (h && h.length > 0)
                for (var p = 0; p < h.length; p++) {
                  if (b.indexOf(h[p]) < 0) {
                    K(11);
                    n = !1;
                    break a;
                  }
                }
              else {
                n = !1;
                break a;
              }
            }
            n = !0;
          }
        l = n;
      }
      var q = !1;
      if (c) {
        var r = d.indexOf(g) >= 0;
        if (r) q = r;
        else {
          var u = wb(d, h || []);
          u && K(10);
          q = u;
        }
      }
      var t = !l || q;
      !t &&
        (h.indexOf("sandboxedScripts") === -1
          ? 0
          : cj && h.indexOf("cmpPartners") >= 0
          ? !Wy()
          : b && b.indexOf("sandboxedScripts") !== -1
          ? 0
          : wb(d, Uy)) &&
        (t = !0);
      return (e[g] = t);
    };
  }
  function Wy() {
    var a = zg(wg.C, hg(5), function () {
      return {};
    });
    try {
      return a("inject_cmp_banner"), !0;
    } catch (b) {
      return !1;
    }
  }
  var Xy = function () {
    this.H = 0;
    this.C = {};
  };
  Xy.prototype.addListener = function (a, b, c) {
    var d = ++this.H;
    this.C[a] = this.C[a] || {};
    this.C[a][String(d)] = { listener: b, Ve: c };
    return d;
  };
  Xy.prototype.removeListener = function (a, b) {
    var c = this.C[a],
      d = String(b);
    if (!c || !c[d]) return !1;
    delete c[d];
    return !0;
  };
  var Zy = function (a, b) {
    var c = [];
    yb(Yy.C[a], function (d, e) {
      c.indexOf(e.listener) < 0 &&
        (e.Ve === void 0 || b.indexOf(e.Ve) >= 0) &&
        c.push(e.listener);
    });
    return c;
  };
  function $y(a, b, c) {
    return {
      entityType: a,
      indexInOriginContainer: b,
      nameInOriginContainer: c,
      originContainerId: hg(5),
      originCId: Oj(),
    };
  }
  function az(a, b) {
    if (data.entities) {
      var c = data.entities[a];
      if (c) return c[b];
    }
  }
  var cz = function (a, b) {
      this.C = !1;
      this.T = [];
      this.eventData = { tags: [] };
      this.V = !1;
      this.H = this.P = 0;
      bz(this, a, b);
    },
    dz = function (a, b, c, d) {
      if ($i.hasOwnProperty(b) || b === "__zone") return -1;
      var e = {};
      rd(d) && (e = sd(d, e));
      e.id = c;
      e.status = "timeout";
      return a.eventData.tags.push(e) - 1;
    },
    ez = function (a, b, c, d) {
      var e = a.eventData.tags[b];
      e && ((e.status = c), (e.executionTime = d));
    },
    fz = function (a) {
      if (!a.C) {
        for (var b = a.T, c = 0; c < b.length; c++) b[c]();
        a.C = !0;
        a.T.length = 0;
      }
    },
    bz = function (a, b, c) {
      b !== void 0 && a.hg(b);
      c &&
        x.setTimeout(function () {
          fz(a);
        }, Number(c));
    };
  cz.prototype.hg = function (a) {
    var b = this,
      c = Hb(function () {
        Tc(function () {
          a(hg(5), b.eventData);
        });
      });
    this.C ? c() : this.T.push(c);
  };
  var gz = function (a) {
      a.P++;
      return Hb(function () {
        a.H++;
        a.V && a.H >= a.P && fz(a);
      });
    },
    hz = function (a) {
      a.V = !0;
      a.H >= a.P && fz(a);
    };
  var iz = {};
  function jz() {
    return x[kz()];
  }
  function kz() {
    return x.GoogleAnalyticsObject || "ga";
  }
  function nz() {
    var a = hg(5);
  }
  function oz(a, b) {
    return function () {
      var c = jz(),
        d = c && c.getByName && c.getByName(a);
      if (d) {
        var e = d.get("sendHitTask");
        d.set("sendHitTask", function (f) {
          var g = f.get("hitPayload"),
            h = f.get("hitCallback"),
            l = g.indexOf("&tid=" + b) < 0;
          l &&
            (f.set(
              "hitPayload",
              g.replace(/&tid=UA-[0-9]+-[0-9]+/, "&tid=" + b),
              !0
            ),
            f.set("hitCallback", void 0, !0));
          e(f);
          l &&
            (f.set("hitPayload", g, !0),
            f.set("hitCallback", h, !0),
            f.set("_x_19", void 0, !0),
            e(f));
        });
      }
    };
  }
  var uz = ["es", "1"],
    vz = {},
    wz = {};
  function xz(a, b) {
    if (Lk) {
      var c;
      c = b.match(/^(gtm|gtag)\./) ? encodeURIComponent(b) : "*";
      vz[a] = [
        ["e", c],
        ["eid", a],
      ];
      Hp(a);
    }
  }
  function yz(a) {
    var b = a.eventId,
      c = a.Wd;
    if (!vz[b]) return [];
    var d = [];
    wz[b] || d.push(uz);
    d.push.apply(d, ya(vz[b]));
    c && (wz[b] = !0);
    return d;
  }
  var zz = {},
    Az = {},
    Bz = {};
  function Cz(a, b, c, d) {
    Lk &&
      F(120) &&
      ((d === void 0 ? 0 : d)
        ? ((Bz[b] = Bz[b] || 0), ++Bz[b])
        : c !== void 0
        ? ((Az[a] = Az[a] || {}), (Az[a][b] = Math.round(c)))
        : ((zz[a] = zz[a] || {}), (zz[a][b] = (zz[a][b] || 0) + 1)));
  }
  function Dz(a) {
    var b = a.eventId,
      c = a.Wd,
      d = zz[b] || {},
      e = [],
      f;
    for (f in d) d.hasOwnProperty(f) && e.push("" + f + d[f]);
    c && delete zz[b];
    return e.length ? [["md", e.join(".")]] : [];
  }
  function Ez(a) {
    var b = a.eventId,
      c = a.Wd,
      d = Az[b] || {},
      e = [],
      f;
    for (f in d) d.hasOwnProperty(f) && e.push("" + f + d[f]);
    c && delete Az[b];
    return e.length ? [["mtd", e.join(".")]] : [];
  }
  function Fz() {
    for (
      var a = [], b = m(Object.keys(Bz)), c = b.next();
      !c.done;
      c = b.next()
    ) {
      var d = c.value;
      a.push("" + d + Bz[d]);
    }
    return a.length ? [["mec", a.join(".")]] : [];
  }
  var Gz = {};
  function Hz(a, b, c) {
    Gz[a] != null || (Gz[a] = {});
    var d;
    (d = Gz[a])[c] != null || (d[c] = {});
    Gz[a][c][b] = (Gz[a][c][b] || 0) + 1;
  }
  var Iz = {},
    Jz = {};
  function Kz(a, b, c) {
    if (Lk && b) {
      var d = Ik(b);
      Iz[a] = Iz[a] || [];
      Iz[a].push(c + d);
      var e = b[pf.Sa];
      if (!e) throw Error("Error: No function name given for function call.");
      var f = (Sf[e] ? "1" : "2") + d;
      Jz[a] = Jz[a] || [];
      Jz[a].push(f);
      Hp(a);
    }
  }
  function Lz(a) {
    var b = a.eventId,
      c = a.Wd,
      d = [],
      e = Iz[b] || [];
    e.length && d.push(["tr", e.join(".")]);
    var f = Jz[b] || [];
    f.length && d.push(["ti", f.join(".")]);
    c && (delete Iz[b], delete Jz[b]);
    return d;
  }
  function Mz(a, b, c) {
    c = c === void 0 ? !1 : c;
    Nz().addRestriction(0, a, b, c);
  }
  function Oz(a, b, c) {
    c = c === void 0 ? !1 : c;
    Nz().addRestriction(1, a, b, c);
  }
  function Pz() {
    var a = Oj();
    return Nz().getRestrictions(1, a);
  }
  var Qz = function () {
      this.container = {};
      this.C = {};
    },
    Rz = function (a, b) {
      var c = a.container[b];
      c ||
        ((c = {
          _entity: { internal: [], external: [] },
          _event: { internal: [], external: [] },
        }),
        (a.container[b] = c));
      return c;
    };
  Qz.prototype.addRestriction = function (a, b, c, d) {
    d = d === void 0 ? !1 : d;
    if (!d || !this.C[b]) {
      var e = Rz(this, b);
      a === 0
        ? d
          ? e._entity.external.push(c)
          : e._entity.internal.push(c)
        : a === 1 &&
          (d ? e._event.external.push(c) : e._event.internal.push(c));
    }
  };
  Qz.prototype.getRestrictions = function (a, b) {
    var c = Rz(this, b);
    if (a === 0) {
      var d, e;
      return [].concat(
        ya(
          (c == null
            ? void 0
            : (d = c._entity) == null
            ? void 0
            : d.internal) || []
        ),
        ya(
          (c == null
            ? void 0
            : (e = c._entity) == null
            ? void 0
            : e.external) || []
        )
      );
    }
    if (a === 1) {
      var f, g;
      return [].concat(
        ya(
          (c == null ? void 0 : (f = c._event) == null ? void 0 : f.internal) ||
            []
        ),
        ya(
          (c == null ? void 0 : (g = c._event) == null ? void 0 : g.external) ||
            []
        )
      );
    }
    return [];
  };
  Qz.prototype.getExternalRestrictions = function (a, b) {
    var c = Rz(this, b),
      d,
      e;
    return a === 0
      ? (c == null ? void 0 : (d = c._entity) == null ? void 0 : d.external) ||
          []
      : (c == null ? void 0 : (e = c._event) == null ? void 0 : e.external) ||
          [];
  };
  Qz.prototype.removeExternalRestrictions = function (a) {
    var b = Rz(this, a);
    b._event && (b._event.external = []);
    b._entity && (b._entity.external = []);
    this.C[a] = !0;
  };
  function Nz() {
    return $n("r", function () {
      return new Qz();
    });
  }
  function Sz(a, b, c, d) {
    var e = Qf[a],
      f = Tz(a, b, c, d);
    if (!f) return null;
    var g = dg(e[pf.Cm], c, []);
    if (g && g.length) {
      var h = g[0];
      f = Sz(
        h.index,
        {
          onSuccess: f,
          onFailure: h.Zm === 1 ? b.terminate : f,
          terminate: b.terminate,
        },
        c,
        d
      );
    }
    return f;
  }
  function Tz(a, b, c, d) {
    function e() {
      function w() {
        Im(3);
        var R = Fb() - I;
        $y(1, a, Qf[a][pf.uh]);
        Kz(c.id, f, "7");
        ez(c.Sc, E, "exception", R);
        F(109) && ox(c, f, Iw.N.Yi);
        L || ((L = !0), h());
      }
      if (f[pf.yp]) h();
      else {
        var y = cg(f, c, []),
          z = y[pf.Un];
        if (z != null)
          for (var D = 0; D < z.length; D++)
            if (!Sn(z[D])) {
              h();
              return;
            }
        var E = dz(c.Sc, String(f[pf.Sa]), Number(f[pf.Gh]), y[pf.METADATA]),
          L = !1;
        y.vtp_gtmOnSuccess = function () {
          if (!L) {
            L = !0;
            var R = Fb() - I;
            Kz(c.id, Qf[a], "5");
            ez(c.Sc, E, "success", R);
            F(109) && ox(c, f, Iw.N.aj);
            g();
          }
        };
        y.vtp_gtmOnFailure = function () {
          if (!L) {
            L = !0;
            var R = Fb() - I;
            Kz(c.id, Qf[a], "6");
            ez(c.Sc, E, "failure", R);
            F(109) && ox(c, f, Iw.N.Zi);
            h();
          }
        };
        y.vtp_gtmTagId = f.tag_id;
        y.vtp_gtmEventId = c.id;
        c.priorityId && (y.vtp_gtmPriorityId = c.priorityId);
        Kz(c.id, f, "1");
        F(109) && nx(c, f);
        var I = Fb();
        try {
          eg(y, { event: c, index: a, type: 1 });
        } catch (R) {
          w(R);
        }
        F(109) && ox(c, f, Iw.N.Lm);
      }
    }
    var f = Qf[a],
      g = b.onSuccess,
      h = b.onFailure,
      l = b.terminate;
    if (c.isBlocked(f)) return null;
    var n = dg(f[pf.Mm], c, []);
    if (n && n.length) {
      var p = n[0],
        q = Sz(p.index, { onSuccess: g, onFailure: h, terminate: l }, c, d);
      if (!q) return null;
      g = q;
      h = p.Zm === 2 ? l : q;
    }
    if (f[pf.vm] || f[pf.Ap]) {
      var r = f[pf.vm] ? Rf : c.Sr,
        u = g,
        t = h;
      if (!r[a]) {
        var v = Uz(a, r, Hb(e));
        g = v.onSuccess;
        h = v.onFailure;
      }
      return function () {
        r[a](u, t);
      };
    }
    return e;
  }
  function Uz(a, b, c) {
    var d = [],
      e = [];
    b[a] = Vz(d, e, c);
    return {
      onSuccess: function () {
        b[a] = Wz;
        for (var f = 0; f < d.length; f++) d[f]();
      },
      onFailure: function () {
        b[a] = Xz;
        for (var f = 0; f < e.length; f++) e[f]();
      },
    };
  }
  function Vz(a, b, c) {
    return function (d, e) {
      a.push(d);
      b.push(e);
      c();
    };
  }
  function Wz(a) {
    a();
  }
  function Xz(a, b) {
    b();
  }
  var $z = function (a, b) {
    for (var c = [], d = 0; d < Qf.length; d++)
      if (a[d]) {
        var e = Qf[d];
        var f = gz(b.Sc);
        try {
          var g = Sz(d, { onSuccess: f, onFailure: f, terminate: f }, b, d);
          if (g) {
            var h = e[pf.Sa];
            if (!h)
              throw Error("Error: No function name given for function call.");
            var l = Sf[h];
            c.push({
              In: d,
              priorityOverride:
                (l ? l.priorityOverride || 0 : 0) || az(e[pf.Sa], 1) || 0,
              execute: g,
            });
          } else Yz(d, b), f();
        } catch (p) {
          f();
        }
      }
    c.sort(Zz);
    for (var n = 0; n < c.length; n++) c[n].execute();
    return c.length > 0;
  };
  function aA(a, b) {
    if (!Yy) return !1;
    var c = a["gtm.triggers"] && String(a["gtm.triggers"]),
      d = Zy(a.event, c ? String(c).split(",") : []);
    if (!d.length) return !1;
    for (var e = 0; e < d.length; ++e) {
      var f = gz(b);
      try {
        d[e](a, f);
      } catch (g) {
        f();
      }
    }
    return !0;
  }
  function Zz(a, b) {
    var c,
      d = b.priorityOverride,
      e = a.priorityOverride;
    c = d > e ? 1 : d < e ? -1 : 0;
    var f;
    if (c !== 0) f = c;
    else {
      var g = a.In,
        h = b.In;
      f = g > h ? 1 : g < h ? -1 : 0;
    }
    return f;
  }
  function Yz(a, b) {
    if (Lk) {
      var c = function (d) {
        var e = b.isBlocked(Qf[d]) ? "3" : "4",
          f = dg(Qf[d][pf.Cm], b, []);
        f && f.length && c(f[0].index);
        Kz(b.id, Qf[d], e);
        var g = dg(Qf[d][pf.Mm], b, []);
        g && g.length && c(g[0].index);
      };
      c(a);
    }
  }
  var bA = !1,
    Yy;
  function cA() {
    Yy || (Yy = new Xy());
    return Yy;
  }
  function dA(a) {
    var b = a["gtm.uniqueEventId"],
      c = a["gtm.priorityId"],
      d = a.event;
    if (F(109)) {
    }
    if (d === "gtm.js") {
      if (bA) return !1;
      bA = !0;
    }
    var e = !1,
      f = Pz(),
      g = sd(a, null);
    if (
      !f.every(function (u) {
        return u({ originalEventData: g });
      })
    ) {
      if (d !== "gtm.js" && d !== "gtm.init" && d !== "gtm.init_consent")
        return !1;
      e = !0;
    }
    xz(b, d);
    var h = a.eventCallback,
      l = a.eventTimeout,
      n = {
        id: b,
        priorityId: c,
        name: d,
        isBlocked: eA(g, e),
        Sr: [],
        logMacroError: function (u, t, v) {
          K(6);
          Im(0);
          $y(2, t, v);
        },
        cachedModelValues: fA(),
        Sc: new cz(function () {
          if (F(109)) {
          }
          h && h.apply(h, Array.prototype.slice.call(arguments, 0));
        }, l),
        originalEventData: g,
      };
    F(120) && Lk && (n.reportMacroDiscrepancy = Cz);
    F(109) && kx(n.id);
    var p = rg(n);
    F(109) && lx(n.id);
    e && (p = gA(p));
    F(109) && jx(b);
    var q = $z(p, n),
      r = aA(a, n.Sc);
    hz(n.Sc);
    (d !== "gtm.js" && d !== "gtm.sync") || nz();
    return hA(p, q) || r;
  }
  function fA() {
    var a = {};
    a.event = rp("event", 1);
    a.ecommerce = rp("ecommerce", 1);
    a.gtm = rp("gtm");
    a.eventModel = rp("eventModel");
    return a;
  }
  function eA(a, b) {
    var c = Vy();
    return function (d) {
      var e = c(d);
      if ((!cj || !F(407)) && e) return !0;
      var f = d && d[pf.Sa];
      if (!f || typeof f !== "string") return !0;
      f = f.replace(/^_*/, "");
      e && cj && F(407) && Lk && Hz(Number(a["gtm.uniqueEventId"]), f, "bl");
      var g,
        h = Oj();
      g = Nz().getRestrictions(0, h);
      var l = a;
      b &&
        ((l = sd(a, null)), (l["gtm.uniqueEventId"] = Number.MAX_SAFE_INTEGER));
      for (
        var n = !1, p = ij[f] || [], q = m(g), r = q.next();
        !r.done;
        r = q.next()
      ) {
        var u = r.value;
        try {
          u({ entityId: f, securityGroups: p, originalEventData: l }) ||
            (n = !0);
        } catch (t) {
          n = !0;
        }
      }
      return n || e;
    };
  }
  function gA(a) {
    for (var b = [], c = 0; c < a.length; c++)
      if (a[c]) {
        var d = String(Qf[c][pf.Sa]);
        if (Zi[d] || Qf[c][pf.Bp] !== void 0 || az(d, 2)) b[c] = !0;
      }
    return b;
  }
  function hA(a, b) {
    if (!b) return b;
    for (var c = 0; c < a.length; c++)
      if (a[c] && Qf[c] && !$i[String(Qf[c][pf.Sa])]) return !0;
    return !1;
  }
  function iA() {
    cA().addListener("gtm.init", function (a, b) {
      Ui.H = !0;
      tm();
      b();
    });
  }
  function jA() {
    if (Zn.pscdl !== void 0) lm(hm.Z.bi) === void 0 && km(hm.Z.bi, Zn.pscdl);
    else {
      var a = function (c) {
          Zn.pscdl = c;
          km(hm.Z.bi, c);
        },
        b = function () {
          a("error");
        };
      try {
        Ac.cookieDeprecationLabel
          ? (a("pending"),
            Ac.cookieDeprecationLabel.getValue().then(a).catch(b))
          : a("noapi");
      } catch (c) {
        b(c);
      }
    }
  }
  var kA = !1,
    lA = 0,
    mA = [];
  function nA(a) {
    if (!kA) {
      var b = A.createEventObject,
        c = A.readyState === "complete",
        d = A.readyState === "interactive";
      if (!a || a.type !== "readystatechange" || c || (!b && d)) {
        kA = !0;
        for (var e = 0; e < mA.length; e++) Tc(mA[e]);
      }
      mA.push = function () {
        for (var f = Ca.apply(0, arguments), g = 0; g < f.length; g++) Tc(f[g]);
        return 0;
      };
    }
  }
  function oA() {
    if (!kA && lA < 140) {
      lA++;
      try {
        var a, b;
        (b = (a = A.documentElement).doScroll) == null || b.call(a, "left");
        nA();
      } catch (c) {
        x.setTimeout(oA, 50);
      }
    }
  }
  function pA() {
    var a = x;
    kA = !1;
    lA = 0;
    if (
      (A.readyState === "interactive" && !A.createEventObject) ||
      A.readyState === "complete"
    )
      nA();
    else {
      Rc(A, "DOMContentLoaded", nA);
      Rc(A, "readystatechange", nA);
      if (A.createEventObject && A.documentElement.doScroll) {
        var b = !0;
        try {
          b = !a.frameElement;
        } catch (c) {}
        b && oA();
      }
      Rc(a, "load", nA);
    }
  }
  function qA(a) {
    kA ? a() : mA.push(a);
  }
  function rA(a, b) {
    a.hasOwnProperty("gtm.uniqueEventId") ||
      Object.defineProperty(a, "gtm.uniqueEventId", { value: fo() });
    b.eventId = a["gtm.uniqueEventId"];
    b.priorityId = a["gtm.priorityId"];
    return { eventId: b.eventId, priorityId: b.priorityId };
  }
  function sA(a) {
    for (var b = m([J.m.ud, J.m.Mc]), c = b.next(); !c.done; c = b.next()) {
      var d = c.value,
        e = (a && a[d]) || Pp.C[d];
      if (e) return e;
    }
  }
  var tA = 0;
  function uA(a) {
    Nk && a === void 0 && tA === 0 && (jk("mcc", "1"), (tA = 1));
  }
  var vA = !1;
  function wA(a, b) {
    return arguments.length === 1 ? xA("set", a) : xA("set", a, b);
  }
  function yA(a, b) {
    return arguments.length === 1 ? xA("config", a) : xA("config", a, b);
  }
  function zA(a, b, c) {
    c = c || {};
    c[J.m.sd] = a;
    return xA("event", b, c);
  }
  function xA() {
    return arguments;
  }
  var AA = function () {
    this.messages = [];
    this.C = [];
  };
  AA.prototype.enqueue = function (a, b, c) {
    var d = this.messages.length + 1;
    a["gtm.uniqueEventId"] = b;
    a["gtm.priorityId"] = d;
    var e = la(Object, "assign").call(Object, {}, c, {
        eventId: b,
        priorityId: d,
        fromContainerExecution: !0,
      }),
      f = { message: a, notBeforeEventId: b, priorityId: d, messageContext: e };
    this.messages.push(f);
    for (var g = 0; g < this.C.length; g++)
      try {
        this.C[g](f);
      } catch (h) {}
  };
  AA.prototype.listen = function (a) {
    this.C.push(a);
  };
  AA.prototype.get = function () {
    for (var a = {}, b = 0; b < this.messages.length; b++) {
      var c = this.messages[b],
        d = a[c.notBeforeEventId];
      d || ((d = []), (a[c.notBeforeEventId] = d));
      d.push(c);
    }
    return a;
  };
  AA.prototype.prune = function (a) {
    for (var b = [], c = [], d = 0; d < this.messages.length; d++) {
      var e = this.messages[d];
      e.notBeforeEventId === a ? b.push(e) : c.push(e);
    }
    this.messages = c;
    return b;
  };
  function BA(a, b, c) {
    c.eventMetadata = c.eventMetadata || {};
    c.eventMetadata[N.A.Oa] = hg(6);
    CA().enqueue(a, b, c);
  }
  function DA() {
    var a = EA;
    CA().listen(a);
  }
  function CA() {
    return $n("mb", function () {
      return new AA();
    });
  }
  var FA = 0,
    GA = 0;
  var HA = {},
    IA = {};
  function JA(a, b) {
    for (
      var c = [], d = [], e = {}, f = 0;
      f < a.length;
      e = { Nj: void 0, sj: void 0 }, f++
    ) {
      var g = a[f];
      if (g.indexOf("-") >= 0) {
        if (((e.Nj = lo(g, b)), e.Nj)) {
          var h = Mj();
          ub(
            h,
            (function (r) {
              return function (u) {
                return r.Nj.destinationId === u;
              };
            })(e)
          )
            ? c.push(g)
            : d.push(g);
        }
      } else {
        var l = HA[g] || [];
        e.sj = {};
        l.forEach(
          (function (r) {
            return function (u) {
              r.sj[u] = !0;
            };
          })(e)
        );
        for (var n = Pj(), p = 0; p < n.length; p++)
          if (e.sj[n[p]]) {
            c = c.concat(Mj());
            break;
          }
        var q = IA[g] || [];
        q.length && (c = c.concat(q));
      }
    }
    return { Gj: c, jr: d };
  }
  function KA(a) {
    yb(HA, function (b, c) {
      var d = c.indexOf(a);
      d >= 0 && c.splice(d, 1);
    });
  }
  function LA(a) {
    yb(IA, function (b, c) {
      var d = c.indexOf(a);
      d >= 0 && c.splice(d, 1);
    });
  }
  var MA = !1,
    NA = void 0,
    OA = void 0;
  function PA(a, b, c) {
    var d = sd(a, null);
    d.eventId = void 0;
    d.inheritParentConfig = void 0;
    Object.keys(b).some(function (f) {
      return b[f] !== void 0;
    }) && K(136);
    var e = sd(b, null);
    sd(c, e);
    BA(yA(Pj()[0], e), a.eventId, d);
  }
  function QA(a, b) {
    var c = {},
      d = ((c.event = a), c);
    b &&
      ((d.eventModel = sd(b, null)),
      b[J.m.yf] && (d.eventCallback = b[J.m.yf]),
      b[J.m.ah] && (d.eventTimeout = b[J.m.ah]));
    return d;
  }
  function RA(a, b) {
    var c = a && a[J.m.sd];
    c === void 0 && ((c = mp(J.m.sd, 2)), c === void 0 && (c = "default"));
    if (rb(c) || Array.isArray(c)) {
      var d;
      d = b.isGtmEvent
        ? rb(c)
          ? [c]
          : c
        : c.toString().replace(/\s+/g, "").split(",");
      var e = JA(d, b.isGtmEvent),
        f = e.Gj,
        g = e.jr;
      if (g.length)
        for (var h = sA(a), l = 0; l < g.length; l++) {
          var n = lo(g[l], b.isGtmEvent);
          if (n) {
            var p = n.destinationId,
              q = void 0;
            ((q = Gj(n.destinationId)) == null ? void 0 : q.state) === 0 ||
              Qy(p, h, {
                source: 3,
                fromContainerExecution: b.fromContainerExecution,
              });
          }
        }
      var r = f.concat(g);
      return { Gj: mo(f, b.isGtmEvent), Vp: mo(r, b.isGtmEvent) };
    }
  }
  var SA = {
      config: function (a, b) {
        var c = rA(a, b);
        if (!(a.length < 2) && rb(a[1])) {
          var d = {};
          if (a.length > 2) {
            if ((a[2] !== void 0 && !rd(a[2])) || a.length > 3) return;
            d = a[2];
          }
          var e = lo(a[1], b.isGtmEvent);
          if (e) {
            var f, g, h;
            a: {
              if (!gg(7)) {
                var l = Rj(Sj());
                if (ck(l)) {
                  var n = l.parent,
                    p = n.isDestination;
                  h = { nr: Rj(n), gr: p };
                  break a;
                }
              }
              h = void 0;
            }
            var q = h;
            q && ((f = q.nr), (g = q.gr));
            xz(c.eventId, "gtag.config");
            var r = e.destinationId,
              u = e.id !== r;
            if (u ? Mj().indexOf(r) === -1 : Pj().indexOf(r) === -1) {
              if (!b.inheritParentConfig && !d[J.m.Gc]) {
                var t = sA(d);
                if (u)
                  Qy(r, t, {
                    source: 2,
                    fromContainerExecution: b.fromContainerExecution,
                  });
                else if (f !== void 0 && f.containers.indexOf(r) !== -1) {
                  var v = d;
                  NA ? PA(b, v, NA) : OA || (OA = sd(v, null));
                } else
                  Ly(r, t, !0, {
                    source: 2,
                    fromContainerExecution: b.fromContainerExecution,
                  });
              }
            } else {
              if (f && (K(128), g && K(130), b.inheritParentConfig)) {
                var w;
                var y = d;
                OA
                  ? (PA(b, OA, y), (w = !1))
                  : ((!y[J.m.wd] && gg(11) && NA) || (NA = sd(y, null)),
                    (w = !0));
                w && f.containers && f.containers.join(",");
                return;
              }
              Nk && (tA === 1 && (gk.mcc = !1), (tA = 2));
              if (gg(11) && !u && !d[J.m.wd]) {
                var z = MA;
                MA = !0;
                var D = d;
                if (F(278)) {
                  var E = Object.keys(D).length > 0 ? 2 : 1,
                    L,
                    I,
                    R =
                      (b == null
                        ? void 0
                        : (I = b.originatingEntity) == null
                        ? void 0
                        : I.originContainerId) || "";
                  L = R ? (Kb(R, "GTM-") ? 3 : 2) : 1;
                  z
                    ? (K(184),
                      GA === L || (GA !== 3 && L !== 3) || K(185),
                      (FA !== 2 && E !== 2) || K(186))
                    : ((FA = E), (GA = L));
                }
                if (z) return;
              }
              vA || K(43);
              if (!b.noTargetGroup)
                if (u) {
                  LA(e.id);
                  var X = e.id,
                    Z = d[J.m.hh] || "default";
                  Z = String(Z).split(",");
                  for (var Q = 0; Q < Z.length; Q++) {
                    var W = IA[Z[Q]] || [];
                    IA[Z[Q]] = W;
                    W.indexOf(X) < 0 && W.push(X);
                  }
                } else {
                  KA(e.id);
                  var ma = e.id,
                    ka = d[J.m.hh] || "default";
                  ka = ka.toString().split(",");
                  for (var T = 0; T < ka.length; T++) {
                    var U = HA[ka[T]] || [];
                    HA[ka[T]] = U;
                    U.indexOf(ma) < 0 && U.push(ma);
                  }
                }
              delete d[J.m.hh];
              var ha = b.eventMetadata || {};
              ha.hasOwnProperty(N.A.Cd) ||
                (ha[N.A.Cd] = !b.fromContainerExecution);
              b.eventMetadata = ha;
              delete d[J.m.yf];
              for (var va = u ? [e.id] : Mj(), pa = 0; pa < va.length; pa++) {
                var Ma = d,
                  Wa = va[pa],
                  qb = sd(b, null),
                  cb = lo(Wa, qb.isGtmEvent);
                cb && Pp.push("config", [Ma], cb, qb);
              }
            }
          }
        }
      },
      consent: function (a, b) {
        if (a.length === 3) {
          K(39);
          var c = rA(a, b),
            d = a[1],
            e = {},
            f = jn(a[2]),
            g;
          for (g in f)
            if (f.hasOwnProperty(g)) {
              var h = f[g];
              e[g] =
                g === J.m.Jg
                  ? Array.isArray(h)
                    ? NaN
                    : Number(h)
                  : g === J.m.kc
                  ? (Array.isArray(h) ? h : [h]).map(kn)
                  : ln(h);
            }
          b.fromContainerExecution || (e[J.m.X] && K(139), e[J.m.La] && K(140));
          d === "default"
            ? On(e)
            : d === "update"
            ? Qn(e, c)
            : d === "declare" && b.fromContainerExecution && Nn(e);
        }
      },
      container_config: function (a, b) {
        if (
          F(240) &&
          b.isGtmEvent &&
          !(
            (b.eventMetadata &&
              b.eventMetadata[N.A.th] &&
              b.eventMetadata[N.A.Oa] !== Oj()) ||
            a.length !== 3
          ) &&
          rb(a[1]) &&
          rd(a[2])
        ) {
          var c = a[2],
            d = lo(a[1], !0);
          if (d) {
            var e = d.destinationId,
              f = sd(b, null),
              g = lo(e, f.isGtmEvent);
            g && Pp.push("container_config", [c], g, f);
          }
        }
      },
      destination_config: function (a, b) {
        if (
          F(240) &&
          b.isGtmEvent &&
          !(
            (b.eventMetadata &&
              b.eventMetadata[N.A.th] &&
              b.eventMetadata[N.A.Oa] !== Oj()) ||
            a.length !== 3
          ) &&
          rb(a[1]) &&
          rd(a[2])
        ) {
          var c = a[2],
            d = lo(a[1], !0);
          if (d) {
            var e = d.destinationId,
              f = sd(b, null),
              g = lo(e, f.isGtmEvent);
            g && Pp.push("destination_config", [c], g, f);
          }
        }
      },
      event: function (a, b) {
        var c = a[1];
        if (!(a.length < 2) && rb(c)) {
          var d = void 0;
          if (a.length > 2) {
            if ((!rd(a[2]) && a[2] !== void 0) || a.length > 3) return;
            d = a[2];
          }
          var e = QA(c, d),
            f = rA(a, b),
            g = f.eventId,
            h = f.priorityId;
          e["gtm.uniqueEventId"] = g;
          h && (e["gtm.priorityId"] = h);
          if (c === "optimize.callback")
            return (e.eventModel = e.eventModel || {}), e;
          var l = RA(d, b);
          if (l) {
            for (
              var n = l.Gj,
                p = l.Vp,
                q = p.map(function (R) {
                  return R.id;
                }),
                r = p.map(function (R) {
                  return R.destinationId;
                }),
                u = n.map(function (R) {
                  return R.id;
                }),
                t = m(Mj()),
                v = t.next();
              !v.done;
              v = t.next()
            ) {
              var w = v.value;
              r.indexOf(w) < 0 && u.push(w);
            }
            xz(g, c);
            for (var y = m(u), z = y.next(); !z.done; z = y.next()) {
              var D = z.value,
                E = sd(b, null),
                L = sd(d, null);
              delete L[J.m.yf];
              var I = E.eventMetadata || {};
              I.hasOwnProperty(N.A.Cd) ||
                (I[N.A.Cd] = !E.fromContainerExecution);
              I[N.A.Ti] = q.slice();
              I[N.A.eg] = r.slice();
              E.eventMetadata = I;
              Op(c, L, D, E);
            }
            e.eventModel = e.eventModel || {};
            q.length > 0
              ? (e.eventModel[J.m.sd] = q.join(","))
              : delete e.eventModel[J.m.sd];
            vA || K(43);
            b.noGtmEvent === void 0 &&
              b.eventMetadata &&
              b.eventMetadata[N.A.Jm] &&
              (b.noGtmEvent = !0);
            e.eventModel[J.m.Fc] && (b.noGtmEvent = !0);
            return b.noGtmEvent ? void 0 : e;
          }
        }
      },
      get: function (a, b) {
        K(53);
        if (a.length === 4 && rb(a[1]) && rb(a[2]) && pb(a[3])) {
          var c = lo(a[1], b.isGtmEvent),
            d = String(a[2]),
            e = a[3];
          if (c) {
            vA || K(43);
            var f = sA();
            if (
              ub(Mj(), function (h) {
                return c.destinationId === h;
              })
            ) {
              rA(a, b);
              var g = {};
              sd(((g[J.m.Cf] = d), (g[J.m.Bf] = e), g), null);
              Qp(
                d,
                function (h) {
                  Tc(function () {
                    e(h);
                  });
                },
                c.id,
                b
              );
            } else
              Qy(c.destinationId, f, {
                source: 4,
                fromContainerExecution: b.fromContainerExecution,
              });
          }
        }
      },
      js: function (a, b) {
        if (a.length === 2 && a[1].getTime) {
          vA = !0;
          var c = rA(a, b),
            d = c.eventId,
            e = c.priorityId,
            f = {};
          return (
            (f.event = "gtm.js"),
            (f["gtm.start"] = a[1].getTime()),
            (f["gtm.uniqueEventId"] = d),
            (f["gtm.priorityId"] = e),
            f
          );
        }
      },
      policy: function (a) {
        if (a.length === 3 && rb(a[1]) && pb(a[2])) {
          if ((xg(a[1], a[2]), K(74), a[1] === "all")) {
            K(75);
            var b = !1;
            try {
              b = a[2](hg(5), "unknown", {});
            } catch (c) {}
            b || K(76);
          }
        } else K(73);
      },
      set: function (a, b) {
        var c = void 0;
        a.length === 2 && rd(a[1])
          ? (c = sd(a[1], null))
          : a.length === 3 &&
            rb(a[1]) &&
            ((c = {}),
            rd(a[2]) || Array.isArray(a[2])
              ? (c[a[1]] = sd(a[2], null))
              : (c[a[1]] = a[2]));
        if (c) {
          var d = rA(a, b),
            e = d.eventId,
            f = d.priorityId;
          sd(c, null);
          hg(5);
          var g = sd(c, null);
          Pp.push("set", [g], void 0, b);
          c["gtm.uniqueEventId"] = e;
          f && (c["gtm.priorityId"] = f);
          delete c.event;
          b.overwriteModelFields = !0;
          return c;
        }
      },
    },
    TA = { policy: !0 };
  var VA = function (a) {
    if (UA(a)) return a;
    this.value = a;
  };
  VA.prototype.getUntrustedMessageValue = function () {
    return this.value;
  };
  var UA = function (a) {
    return !a || pd(a) !== "object" || rd(a)
      ? !1
      : "getUntrustedMessageValue" in a;
  };
  VA.prototype.getUntrustedMessageValue = VA.prototype.getUntrustedMessageValue;
  var WA = !1,
    XA = [];
  function YA() {
    if (!WA) {
      WA = !0;
      for (var a = 0; a < XA.length; a++) Tc(XA[a]);
    }
  }
  function ZA(a) {
    WA ? Tc(a) : XA.push(a);
  }
  var $A = 0,
    aB = {},
    bB = [],
    cB = [],
    dB = !1,
    eB = !1;
  function fB(a, b) {
    return (
      a.messageContext.eventId - b.messageContext.eventId ||
      a.messageContext.priorityId - b.messageContext.priorityId
    );
  }
  function gB(a, b, c) {
    a.eventCallback = b;
    c && (a.eventTimeout = c);
    return hB(a);
  }
  function iB(a, b) {
    if (!sb(b) || b < 0) b = 0;
    var c = eo(),
      d = 0,
      e = !1,
      f = void 0;
    f = x.setTimeout(function () {
      e || ((e = !0), a());
      f = void 0;
    }, b);
    return function () {
      var g = c ? c.subscribers : 1;
      ++d === g &&
        (f && (x.clearTimeout(f), (f = void 0)), e || (a(), (e = !0)));
    };
  }
  function jB(a) {
    if (a == null || typeof a !== "object") return !1;
    if (a.event) return !0;
    if (zb(a)) {
      var b = a[0];
      if (b === "config" || b === "event" || b === "js" || b === "get")
        return !0;
    }
    return !1;
  }
  function kB() {
    var a;
    if (cB.length) a = cB.shift();
    else if (bB.length) a = bB.shift();
    else return;
    var b;
    var c = a;
    if (dB || !jB(c.message)) b = c;
    else {
      dB = !0;
      var d = c.message["gtm.uniqueEventId"],
        e,
        f;
      typeof d === "number"
        ? ((e = d - 2), (f = d - 1))
        : ((e = fo()), (f = fo()), (c.message["gtm.uniqueEventId"] = fo()));
      var g = {},
        h = {
          message:
            ((g.event = "gtm.init_consent"), (g["gtm.uniqueEventId"] = e), g),
          messageContext: { eventId: e },
        },
        l = {},
        n = {
          message: ((l.event = "gtm.init"), (l["gtm.uniqueEventId"] = f), l),
          messageContext: { eventId: f },
        };
      bB.unshift(n, c);
      b = h;
    }
    return b;
  }
  function lB() {
    for (var a = !1, b; !eB && (b = kB()); ) {
      eB = !0;
      delete jp.eventModel;
      lp();
      var c = b,
        d = c.message,
        e = c.messageContext;
      if (d == null) eB = !1;
      else {
        e.fromContainerExecution && qp();
        try {
          if (pb(d))
            try {
              d.call(np);
            } catch (L) {}
          else if (Array.isArray(d)) {
            if (rb(d[0])) {
              var f = d[0].split("."),
                g = f.pop(),
                h = d.slice(1),
                l = mp(f.join("."), 2);
              if (l != null)
                try {
                  l[g].apply(l, h);
                } catch (L) {}
            }
          } else {
            var n = void 0;
            if (zb(d))
              a: {
                if (d.length && rb(d[0])) {
                  var p = SA[d[0]];
                  if (p && (!e.fromContainerExecution || !TA[d[0]])) {
                    n = p(d, e);
                    break a;
                  }
                }
                n = void 0;
              }
            else n = d;
            if (n) {
              var q;
              for (
                var r = n,
                  u = r._clear || e.overwriteModelFields,
                  t = m(Object.keys(r)),
                  v = t.next();
                !v.done;
                v = t.next()
              ) {
                var w = v.value;
                w !== "_clear" && (u && pp(w), pp(w, r[w]));
              }
              fj || (fj = r["gtm.start"]);
              var y = r["gtm.uniqueEventId"];
              r.event
                ? (typeof y !== "number" &&
                    ((y = fo()),
                    (r["gtm.uniqueEventId"] = y),
                    pp("gtm.uniqueEventId", y)),
                  (q = dA(r)))
                : (q = !1);
              a = q || a;
            }
          }
        } finally {
          e.fromContainerExecution && lp(!0);
          var z = d["gtm.uniqueEventId"];
          if (typeof z === "number") {
            for (var D = aB[String(z)] || [], E = 0; E < D.length; E++)
              cB.push(mB(D[E]));
            D.length && cB.sort(fB);
            delete aB[String(z)];
            z > $A && ($A = z);
          }
          eB = !1;
        }
      }
    }
    return !a;
  }
  function nB() {
    if (F(109)) {
      var a = !gg(51);
    }
    var c = lB();
    if (F(109)) {
    }
    try {
      var e = x[hg(19)],
        f = hg(5),
        g = e.hide;
      if (g && g[f] !== void 0 && g.end) {
        g[f] = !1;
        var h = !0,
          l;
        for (l in g)
          if (g.hasOwnProperty(l) && g[l] === !0) {
            h = !1;
            break;
          }
        h && (g.end(), (g.end = null));
      }
    } catch (n) {
      hg(5);
    }
    return c;
  }
  function EA(a) {
    if ($A < a.notBeforeEventId) {
      var b = String(a.notBeforeEventId);
      aB[b] = aB[b] || [];
      aB[b].push(a);
    } else
      cB.push(mB(a)),
        cB.sort(fB),
        Tc(function () {
          eB || lB();
        });
  }
  function mB(a) {
    return { message: a.message, messageContext: a.messageContext };
  }
  function oB() {
    function a(f) {
      var g = {};
      if (UA(f)) {
        var h = f;
        f = UA(h) ? h.getUntrustedMessageValue() : void 0;
        g.fromContainerExecution = !0;
      }
      return { message: f, messageContext: g };
    }
    var b = Ec(hg(19), []),
      c = co();
    c.pruned === !0 && K(83);
    aB = CA().get();
    DA();
    qA(function () {
      if (!c.gtmDom) {
        c.gtmDom = !0;
        var f = {};
        b.push(((f.event = "gtm.dom"), f));
      }
    });
    ZA(function () {
      if (!c.gtmLoad) {
        c.gtmLoad = !0;
        var f = {};
        b.push(((f.event = "gtm.load"), f));
      }
    });
    c.subscribers = (c.subscribers || 0) + 1;
    var d = b.push;
    b.push = function () {
      var f;
      if (Zn.SANDBOXED_JS_SEMAPHORE > 0) {
        f = [];
        for (var g = 0; g < arguments.length; g++) f[g] = new VA(arguments[g]);
      } else f = [].slice.call(arguments, 0);
      var h = f.map(function (q) {
        return a(q);
      });
      bB.push.apply(bB, h);
      var l = d.apply(b, f),
        n = Math.max(100, mg(1, 300));
      if (this.length > n)
        for (K(4), c.pruned = !0; this.length > n; ) this.shift();
      var p = typeof l !== "boolean" || l;
      return lB() && p;
    };
    var e = b.slice(0).map(function (f) {
      return a(f);
    });
    bB.push.apply(bB, e);
    if (!gg(51)) {
      if (F(109)) {
      }
      Tc(nB);
    }
  }
  var hB = function (a) {
    return x[hg(19)].push(a);
  };
  function pB(a) {
    hB(a);
  }
  function qB() {
    var a,
      b = yj(x.location.href);
    (a = b.hostname + b.pathname) && jk("dl", encodeURIComponent(a));
    var c;
    var d = hg(5);
    if (d) {
      var e = gg(7) ? 1 : 0,
        f,
        g = Sj(),
        h = Rj(g),
        l = (f = h && h.context) && f.fromContainerExecution ? 1 : 0,
        n = (f && f.source) || 0,
        p = hg(6);
      c = d + ";" + p + ";" + l + ";" + n + ";" + e;
    } else c = void 0;
    var q = c;
    q && jk("tdp", q);
    var r = fq(!0);
    r !== void 0 && jk("frm", String(r));
  }
  var rB = wk(),
    sB = void 0;
  function tB(a) {
    return yk(a, function (b) {
      return b.jb > 0 ? String(b.jb) : void 0;
    });
  }
  function uB() {
    if (wn() || Nk)
      jk(
        "csp",
        function () {
          var a = tB(rB);
          zk(rB);
          return a;
        },
        !1
      ),
        jk(
          "mde",
          function () {
            var a = tB(Bk);
            zk(Bk);
            return a;
          },
          !1
        ),
        x.addEventListener("securitypolicyviolation", vB);
  }
  function vB(a) {
    if (a.disposition === "enforce") {
      K(179);
      var b = Hk(a.effectiveDirective);
      if (b) {
        var c;
        var d = Fk(b, a.blockedURI);
        c = d ? Dk[b][d] : void 0;
        if (c) {
          var e;
          a: {
            try {
              var f = new URL(a.blockedURI),
                g = f.pathname.indexOf(";");
              e =
                g >= 0
                  ? f.origin + f.pathname.substring(0, g)
                  : f.origin + f.pathname;
              break a;
            } catch (v) {}
            e = void 0;
          }
          var h = e;
          if (h) {
            for (var l = m(c), n = l.next(); !n.done; n = l.next()) {
              var p = n.value;
              if (!p.yn) {
                p.yn = !0;
                if (F(59)) {
                  var q = { eventId: p.eventId, priorityId: p.priorityId };
                  if (wn()) {
                    var r = q,
                      u = {
                        type: 1,
                        blockedUrl: h,
                        endpoint: p.endpoint,
                        violation: a.effectiveDirective,
                      };
                    if (wn()) {
                      var t = Cn("TAG_DIAGNOSTICS", {
                        eventId: r == null ? void 0 : r.eventId,
                        priorityId: r == null ? void 0 : r.priorityId,
                      });
                      t.tagDiagnostics = u;
                      vn(t);
                    }
                  }
                }
                wB(p.destinationId, p.endpoint);
              }
            }
            Gk(b, a.blockedURI);
          }
        }
      }
    }
  }
  function wB(a, b) {
    Ak(rB, a, b);
    kk("csp", !0);
    kk("mde", !0);
    b !== 61 &&
      b !== 56 &&
      sB === void 0 &&
      (sB = x.setTimeout(function () {
        rB.jb > 0 && tm(!1);
        sB = void 0;
      }, 500));
  }
  var xB = void 0;
  function yB() {
    F(236) &&
      x.addEventListener("pageshow", function (a) {
        a &&
          (jk("bfc", function () {
            return xB ? "1" : "0";
          }),
          a.persisted ? ((xB = !0), kk("bfc", !0), tm()) : (xB = !1));
      });
  }
  function zB() {
    var a;
    var b = Qj();
    if (b)
      if (b.canonicalContainerId) a = b.canonicalContainerId;
      else {
        var c,
          d =
            b.scriptContainerId ||
            ((c = b.destinations) == null ? void 0 : c[0]);
        a = d ? "_" + d : void 0;
      }
    else a = void 0;
    var e = a;
    e && jk("pcid", e);
  }
  var AB = {},
    BB =
      ((AB[1] = function () {
        return x.fetch;
      }),
      (AB[2] = function () {
        return Math.random;
      }),
      (AB[3] = function () {
        return Ac.sendBeacon;
      }),
      (AB[4] = function () {
        return x.XMLHttpRequest;
      }),
      AB);
  function CB() {
    if (F(409)) {
      for (
        var a = [], b = m(Object.keys(BB)), c = b.next();
        !c.done;
        c = b.next()
      ) {
        var d = c.value,
          e = BB[d](),
          f;
        if (!(f = typeof e !== "function")) {
          var g = Function.prototype.toString.call(e);
          f = Lb(g, "{ [native code] }") || Lb(g, "{\n    [native code]\n}");
        }
        f || a.push(d);
      }
      a.length > 0 && jk("jsp", a.join("~"));
    }
  }
  var DB = /^(https?:)?\/\//;
  function EB() {
    var a = Tj();
    if (a) {
      var b;
      a: {
        var c,
          d = (c = a.scriptElement) == null ? void 0 : c.src;
        if (d) {
          var e;
          try {
            var f;
            e = (f = gd()) == null ? void 0 : f.getEntriesByType("resource");
          } catch (q) {}
          if (e) {
            for (var g = -1, h = m(e), l = h.next(); !l.done; l = h.next()) {
              var n = l.value;
              if (
                n.initiatorType === "script" &&
                ((g += 1), n.name.replace(DB, "") === d.replace(DB, ""))
              ) {
                b = g;
                break a;
              }
            }
            K(146);
          } else K(145);
        }
        b = void 0;
      }
      var p = b;
      p !== void 0 &&
        (a.canonicalContainerId && jk("rtg", String(a.canonicalContainerId)),
        jk("slo", String(p)),
        jk("hlo", a.htmlLoadOrder || "-1"),
        jk("lst", String(a.loadScriptType || "0")));
    } else K(144);
  }
  function ZB() {}
  var $B = function () {};
  $B.prototype.toString = function () {
    return "undefined";
  };
  var aC = new $B();
  var hC = {};
  function iC(a) {
    Lk && (hC[a] = (hC[a] || 0) + 1);
  }
  function jC() {
    var a = [];
    hC[1] && a.push("1." + hC[1]);
    hC[2] && a.push("2." + hC[2]);
    hC[3] && a.push("3." + hC[3]);
    return a.length ? [["odp", a.join("~")]] : [];
  }
  function kC() {
    (F(212) || F(405)) &&
      hg(5).indexOf("GTM-") !== 0 &&
      (Ax("detect_link_click_events", function (a, b, c) {
        var d = c.options;
        return F(405)
          ? ((d == null ? void 0 : d.waitForTags) === !0 && iC(1), !0)
          : (d == null ? void 0 : d.waitForTags) !== !0;
      }),
      Ax("detect_form_submit_events", function (a, b, c) {
        var d = c.options;
        return F(405)
          ? ((d == null ? void 0 : d.waitForTags) === !0 && iC(2), !0)
          : (d == null ? void 0 : d.waitForTags) !== !0;
      }),
      Ax("detect_youtube_activity_events", function (a, b, c) {
        var d = c.options;
        return F(405)
          ? ((d == null ? void 0 : d.fixMissingApi) === !0 && iC(3), !0)
          : (d == null ? void 0 : d.fixMissingApi) !== !0;
      }));
    (F(212) || F(407)) &&
      cj &&
      Mz(Oj(), function (a) {
        var b, c, d;
        b = a.entityId;
        c = a.securityGroups;
        d = a.originalEventData;
        var e = "__" + b,
          f = az(e, 5) || !(!Sf[e] || !Sf[e][5]) || c.includes("cmpPartners");
        return F(407)
          ? (f || (Lk && Hz(Number(d["gtm.uniqueEventId"]), b, "r")), !0)
          : f;
      });
  }
  function lC(a, b) {
    function c(g) {
      var h = yj(g),
        l = sj(h, "protocol"),
        n = sj(h, "host", !0),
        p = sj(h, "port"),
        q = sj(h, "path").toLowerCase().replace(/\/$/, "");
      if (
        l === void 0 ||
        (l === "http" && p === "80") ||
        (l === "https" && p === "443")
      )
        (l = "web"), (p = "default");
      return [l, n, p, q];
    }
    for (var d = c(String(a)), e = c(String(b)), f = 0; f < d.length; f++)
      if (d[f] !== e[f]) return !1;
    return !0;
  }
  function mC(a) {
    return nC(a) ? 1 : 0;
  }
  function nC(a) {
    var b = a.arg0,
      c = a.arg1;
    if (a.any_of && Array.isArray(c)) {
      for (var d = 0; d < c.length; d++) {
        var e = sd(a, {});
        sd({ arg1: c[d], any_of: void 0 }, e);
        if (mC(e)) return !0;
      }
      return !1;
    }
    switch (a["function"]) {
      case "_cn":
        return ih(b, c);
      case "_css":
        var f;
        a: {
          if (b)
            try {
              for (var g = 0; g < dh.length; g++) {
                var h = dh[g];
                if (b[h] != null) {
                  f = b[h](c);
                  break a;
                }
              }
            } catch (l) {}
          f = !1;
        }
        return f;
      case "_ew":
        return eh(b, c);
      case "_eq":
        return jh(b, c);
      case "_ge":
        return kh(b, c);
      case "_gt":
        return mh(b, c);
      case "_lc":
        return fh(b, c);
      case "_le":
        return lh(b, c);
      case "_lt":
        return nh(b, c);
      case "_re":
        return hh(b, c, a.ignore_case);
      case "_sw":
        return oh(b, c);
      case "_um":
        return lC(b, c);
    }
    return !1;
  }
  var oC = function () {
    this.C = this.gppString = void 0;
  };
  oC.prototype.reset = function () {
    this.C = this.gppString = void 0;
  };
  var pC = new oC();
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function (
    a,
    b
  ) {
    return a + b;
  });
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function (a, b) {
    return a + b;
  });
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function (
    a,
    b
  ) {
    return a + b;
  });
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function (
    a,
    b
  ) {
    return a + b;
  });
  [
    2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
    2, 2, 2, 2, 2, 2, 2,
  ].reduce(function (a, b) {
    return a + b;
  });
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function (a, b) {
    return a + b;
  });
  var qC = function (a, b, c, d) {
    mq.call(this);
    this.Dh = b;
    this.Zf = c;
    this.Pc = d;
    this.wb = new Map();
    this.Eh = 0;
    this.wa = new Map();
    this.Za = new Map();
    this.V = void 0;
    this.H = a;
  };
  ua(qC, mq);
  qC.prototype.P = function () {
    delete this.C;
    this.wb.clear();
    this.wa.clear();
    this.Za.clear();
    this.V && (iq(this.H, "message", this.V), delete this.V);
    delete this.H;
    delete this.Pc;
    mq.prototype.P.call(this);
  };
  var rC = function (a) {
      if (a.C) return a.C;
      a.Zf && a.Zf(a.H) ? (a.C = a.H) : (a.C = eq(a.H, a.Dh));
      var b;
      return (b = a.C) != null ? b : null;
    },
    tC = function (a, b, c) {
      if (rC(a))
        if (a.C === a.H) {
          var d = a.wb.get(b);
          d && d(a.C, c);
        } else {
          var e = a.wa.get(b);
          if (e && e.Fj) {
            sC(a);
            var f = ++a.Eh;
            a.Za.set(f, {
              Uh: e.Uh,
              oq: e.kn(c),
              persistent: b === "addEventListener",
            });
            a.C.postMessage(e.Fj(c, f), "*");
          }
        }
    },
    sC = function (a) {
      a.V ||
        ((a.V = function (b) {
          try {
            var c;
            c = a.Pc ? a.Pc(b) : void 0;
            if (c) {
              var d = c.ur,
                e = a.Za.get(d);
              if (e) {
                e.persistent || a.Za.delete(d);
                var f;
                (f = e.Uh) == null || f.call(e, e.oq, c.payload);
              }
            }
          } catch (g) {}
        }),
        hq(a.H, "message", a.V));
    };
  var uC = function (a, b) {
      var c = b.listener,
        d = (0, a.__gpp)("addEventListener", c);
      d && c(d, !0);
    },
    vC = function (a, b) {
      (0, a.__gpp)("removeEventListener", b.listener, b.listenerId);
    },
    wC = {
      kn: function (a) {
        return a.listener;
      },
      Fj: function (a, b) {
        var c = {};
        return (
          (c.__gppCall = {
            callId: b,
            command: "addEventListener",
            version: "1.1",
          }),
          c
        );
      },
      Uh: function (a, b) {
        var c = b.__gppReturn;
        a(c.returnValue, c.success);
      },
    },
    xC = {
      kn: function (a) {
        return a.listener;
      },
      Fj: function (a, b) {
        var c = {};
        return (
          (c.__gppCall = {
            callId: b,
            command: "removeEventListener",
            version: "1.1",
            parameter: a.listenerId,
          }),
          c
        );
      },
      Uh: function (a, b) {
        var c = b.__gppReturn,
          d = c.returnValue.data;
        a == null || a(d, c.success);
      },
    };
  function yC(a) {
    var b = {};
    typeof a.data === "string" ? (b = JSON.parse(a.data)) : (b = a.data);
    return { payload: b, ur: b.__gppReturn.callId };
  }
  var zC = function (a, b) {
    var c;
    c = (b === void 0 ? {} : b).timeoutMs;
    mq.call(this);
    this.caller = new qC(
      a,
      "__gppLocator",
      function (d) {
        return typeof d.__gpp === "function";
      },
      yC
    );
    this.caller.wb.set("addEventListener", uC);
    this.caller.wa.set("addEventListener", wC);
    this.caller.wb.set("removeEventListener", vC);
    this.caller.wa.set("removeEventListener", xC);
    this.timeoutMs = c != null ? c : 500;
  };
  ua(zC, mq);
  zC.prototype.P = function () {
    this.caller.dispose();
    mq.prototype.P.call(this);
  };
  zC.prototype.addEventListener = function (a) {
    var b = this,
      c = cq(function () {
        a(AC, !0);
      }),
      d =
        this.timeoutMs === -1
          ? void 0
          : setTimeout(function () {
              c();
            }, this.timeoutMs);
    tC(this.caller, "addEventListener", {
      listener: function (e, f) {
        clearTimeout(d);
        try {
          var g;
          var h;
          ((h = e.pingData) == null ? void 0 : h.gppVersion) === void 0 ||
          e.pingData.gppVersion === "1" ||
          e.pingData.gppVersion === "1.0"
            ? (b.removeEventListener(e.listenerId),
              (g = {
                eventName: "signalStatus",
                data: "ready",
                pingData: {
                  internalErrorState: 1,
                  gppString: "GPP_ERROR_STRING_IS_DEPRECATED_SPEC",
                  applicableSections: [-1],
                },
              }))
            : Array.isArray(e.pingData.applicableSections)
            ? (g = e)
            : (b.removeEventListener(e.listenerId),
              (g = {
                eventName: "signalStatus",
                data: "ready",
                pingData: {
                  internalErrorState: 2,
                  gppString:
                    "GPP_ERROR_STRING_EXPECTED_APPLICATION_SECTION_ARRAY",
                  applicableSections: [-1],
                },
              }));
          a(g, f);
        } catch (l) {
          if (e == null ? 0 : e.listenerId)
            try {
              b.removeEventListener(e.listenerId);
            } catch (n) {
              a(BC, !0);
              return;
            }
          a(CC, !0);
        }
      },
    });
  };
  zC.prototype.removeEventListener = function (a) {
    tC(this.caller, "removeEventListener", {
      listener: function () {},
      listenerId: a,
    });
  };
  var CC = {
      eventName: "signalStatus",
      data: "ready",
      pingData: {
        internalErrorState: 2,
        gppString: "GPP_ERROR_STRING_UNAVAILABLE",
        applicableSections: [-1],
      },
      listenerId: -1,
    },
    AC = {
      eventName: "signalStatus",
      data: "ready",
      pingData: {
        gppString: "GPP_ERROR_STRING_LISTENER_REGISTRATION_TIMEOUT",
        internalErrorState: 2,
        applicableSections: [-1],
      },
      listenerId: -1,
    },
    BC = {
      eventName: "signalStatus",
      data: "ready",
      pingData: {
        gppString: "GPP_ERROR_STRING_REMOVE_EVENT_LISTENER_ERROR",
        internalErrorState: 2,
        applicableSections: [-1],
      },
      listenerId: -1,
    };
  function DC(a) {
    var b;
    if (!(b = a.pingData.signalStatus === "ready")) {
      var c = a.pingData.applicableSections;
      b = !c || (c.length === 1 && c[0] === -1);
    }
    if (b) {
      pC.gppString = a.pingData.gppString;
      var d = a.pingData.applicableSections.join(",");
      pC.C = d;
    }
  }
  function EC() {
    try {
      var a = new zC(x, { timeoutMs: -1 });
      rC(a.caller) && a.addEventListener(DC);
    } catch (b) {}
  }
  function FC() {
    var a = [
        ["cv", hg(1)],
        ["rv", hg(14)],
        [
          "tc",
          Qf.filter(function (c) {
            return c;
          }).length,
        ],
      ],
      b = ig(15);
    b && a.push(["x", b]);
    mk() && a.push(["tag_exp", mk()]);
    return a;
  }
  var GC = {},
    HC = {};
  function IC(a) {
    var b = a.eventId,
      c = a.Wd,
      d = [],
      e = GC[b] || [];
    e.length && d.push(["hf", e.join(".")]);
    var f = HC[b] || [];
    f.length && d.push(["ht", f.join(".")]);
    c && (delete GC[b], delete HC[b]);
    return d;
  }
  function JC() {
    return !1;
  }
  function KC() {
    var a = {};
    return function (b, c, d) {};
  }
  function LC() {
    var a = MC;
    return function (b, c, d) {
      var e = d && d.event;
      NC(c);
      var f = Uh(b) ? void 0 : 1,
        g = new $a();
      yb(c, function (r, u) {
        var t = Hd(u, void 0, f);
        t === void 0 && u !== void 0 && K(44);
        g.set(r, t);
      });
      a.Pb(pg());
      var h = {
        Um: Dg(b),
        eventId: e == null ? void 0 : e.id,
        priorityId: e !== void 0 ? e.priorityId : void 0,
        hg:
          e !== void 0
            ? function (r) {
                e.Sc.hg(r);
              }
            : void 0,
        Mb: function () {
          return b;
        },
        log: function () {},
        wq: {
          index: d == null ? void 0 : d.index,
          type: d == null ? void 0 : d.type,
          name: d == null ? void 0 : d.name,
        },
        Cr: !!az(b, 3),
        originalEventData: e == null ? void 0 : e.originalEventData,
      };
      e &&
        e.cachedModelValues &&
        (h.cachedModelValues = {
          gtm: e.cachedModelValues.gtm,
          ecommerce: e.cachedModelValues.ecommerce,
        });
      if (JC()) {
        var l = KC(),
          n,
          p;
        h.qb = {
          Uj: [],
          ig: {},
          fc: function (r, u, t) {
            u === 1 && (n = r);
            u === 7 && (p = t);
            l(r, u, t);
          },
          Th: ni(),
        };
        h.log = function (r) {
          var u = Ca.apply(1, arguments);
          n && l(n, 4, { level: r, source: p, message: u });
        };
      }
      var q = cf(a, h, [b, g]);
      a.Pb();
      q instanceof Fa && (q.type === "return" ? (q = q.data) : (q = void 0));
      return B(q, void 0, f);
    };
  }
  function NC(a) {
    var b = a.gtmOnSuccess,
      c = a.gtmOnFailure;
    pb(b) &&
      (a.gtmOnSuccess = function () {
        Tc(b);
      });
    pb(c) &&
      (a.gtmOnFailure = function () {
        Tc(c);
      });
  }
  function OC(a) {}
  OC.K = "internal.addAdsClickIds";
  function PC(a, b) {
    var c = this;
  }
  PC.publicName = "addConsentListener";
  var QC = !1;
  function RC(a) {
    for (var b = 0; b < a.length; ++b)
      if (QC)
        try {
          a[b]();
        } catch (c) {
          K(77);
        }
      else a[b]();
  }
  function SC(a, b, c) {
    var d = this,
      e;
    return e;
  }
  SC.K = "internal.addDataLayerEventListener";
  function TC(a, b, c) {}
  TC.publicName = "addDocumentEventListener";
  function UC(a, b, c, d) {}
  UC.publicName = "addElementEventListener";
  function VC(a) {
    return a.J.ob();
  }
  function WC(a) {}
  WC.publicName = "addEventCallback";
  function kD(a) {}
  kD.K = "internal.addFormAbandonmentListener";
  function lD(a, b, c, d) {}
  lD.K = "internal.addFormData";
  var mD = {},
    nD = [],
    oD = {},
    pD = 0,
    qD = 0;
  function xD(a, b) {}
  xD.K = "internal.addFormInteractionListener";
  function ED(a, b) {}
  ED.K = "internal.addFormSubmitListener";
  function JD(a) {}
  JD.K = "internal.addGaSendListener";
  function KD(a) {
    if (!a) return {};
    var b = a.wq;
    return $y(b.type, b.index, b.name);
  }
  function LD(a) {
    return a ? { originatingEntity: KD(a) } : {};
  }
  function TD(a) {
    var b = Zn.zones;
    return b
      ? b.getIsAllowedFn(Pj(), a)
      : function () {
          return !0;
        };
  }
  function UD() {
    var a = Zn.zones;
    a && a.unregisterChild(Pj());
  }
  function VD() {
    Oz(Oj(), function (a) {
      var b = a.originalEventData["gtm.uniqueEventId"],
        c = Zn.zones;
      return c ? c.isActive(Pj(), b) : !0;
    });
    Mz(Oj(), function (a) {
      var b, c;
      b = a.entityId;
      c = a.securityGroups;
      return TD(Number(a.originalEventData["gtm.uniqueEventId"]))(b, c);
    });
  }
  var WD = function (a, b) {
    this.tagId = a;
    this.canonicalId = b;
  };
  function XD(a, b) {
    var c = this;
    return a;
  }
  XD.K = "internal.loadGoogleTag";
  function YD(a) {
    return new zd("", function (b) {
      var c = this.evaluate(b);
      if (c instanceof zd)
        return new zd("", function () {
          var d = Ca.apply(0, arguments),
            e = this,
            f = sd(VC(this), null);
          f.eventId = a.eventId;
          f.priorityId = a.priorityId;
          f.originalEventData = a.originalEventData;
          var g = d.map(function (l) {
              return e.evaluate(l);
            }),
            h = this.J.mb();
          h.Sd(f);
          return c.Nb.apply(c, [h].concat(ya(g)));
        });
    });
  }
  function ZD(a, b, c) {
    var d = this;
  }
  ZD.K = "internal.addGoogleTagRestriction";
  var $D = {},
    aE = [];
  function hE(a, b) {}
  hE.K = "internal.addHistoryChangeListener";
  function iE(a, b, c) {}
  iE.publicName = "addWindowEventListener";
  function jE(a, b) {
    return !0;
  }
  jE.publicName = "aliasInWindow";
  function kE(a, b, c) {}
  kE.K = "internal.appendRemoteConfigParameter";
  function lE(a) {
    var b;
    return b;
  }
  lE.publicName = "callInWindow";
  function mE(a) {}
  mE.publicName = "callLater";
  function nE(a) {}
  nE.K = "callOnDomReady";
  function oE(a) {}
  oE.K = "callOnWindowLoad";
  function pE(a, b) {
    var c;
    return c;
  }
  pE.K = "internal.computeGtmParameter";
  function qE(a, b) {
    var c = this;
  }
  qE.K = "internal.consentScheduleFirstTry";
  function rE(a, b) {
    var c = this;
  }
  rE.K = "internal.consentScheduleRetry";
  function sE(a) {
    var b;
    return b;
  }
  sE.K = "internal.copyFromCrossContainerData";
  function tE(a, b) {
    var c;
    if (!Fh(a) || (!Kh(b) && b !== null && !Ah(b)))
      throw G(this.getName(), ["string", "number|undefined"], arguments);
    H(this, "read_data_layer", a);
    c = (b || 2) !== 2 ? mp(a, 1) : op(a, [x, A]);
    var d = Hd(c, this.J, Uh(VC(this).Mb()) ? 2 : 1);
    d === void 0 && c !== void 0 && K(45);
    return d;
  }
  tE.publicName = "copyFromDataLayer";
  function uE(a) {
    var b = void 0;
    return b;
  }
  uE.K = "internal.copyFromDataLayerCache";
  function vE(a) {
    var b;
    return b;
  }
  vE.publicName = "copyFromWindow";
  function wE(a) {
    var b = void 0;
    return Hd(b, this.J, 1);
  }
  wE.K = "internal.copyKeyFromWindow";
  var xE = function (a) {
    return a === Hl.aa.Ra && Zl[a] === Gl.Ka.Ee && !Sn(J.m.W);
  };
  var yE = function () {
      return "0";
    },
    zE = function (a) {
      if (typeof a !== "string") return "";
      var b = ["gclid", "dclid", "wbraid", "_gl"];
      F(102) && b.push("gbraid");
      return zj(a, b, "0");
    };
  var AE = {},
    BE = {},
    CE = {},
    DE = {},
    EE = {},
    FE = {},
    GE = {},
    HE = {},
    IE = {},
    JE = {},
    KE = {},
    LE = {},
    ME = {},
    NE = {},
    OE = {},
    PE = {},
    QE = {},
    RE = {},
    SE = {},
    TE = {},
    UE = {},
    VE = {},
    WE = {},
    XE = {},
    YE = {},
    ZE = {},
    $E =
      ((ZE[J.m.Na] = ((AE[2] = [xE]), AE)),
      (ZE[J.m.If] = ((BE[2] = [xE]), BE)),
      (ZE[J.m.Af] = ((CE[2] = [xE]), CE)),
      (ZE[J.m.vl] = ((DE[2] = [xE]), DE)),
      (ZE[J.m.wl] = ((EE[2] = [xE]), EE)),
      (ZE[J.m.xl] = ((FE[2] = [xE]), FE)),
      (ZE[J.m.yl] = ((GE[2] = [xE]), GE)),
      (ZE[J.m.zl] = ((HE[2] = [xE]), HE)),
      (ZE[J.m.Gb] = ((IE[2] = [xE]), IE)),
      (ZE[J.m.Jf] = ((JE[2] = [xE]), JE)),
      (ZE[J.m.Kf] = ((KE[2] = [xE]), KE)),
      (ZE[J.m.Lf] = ((LE[2] = [xE]), LE)),
      (ZE[J.m.Mf] = ((ME[2] = [xE]), ME)),
      (ZE[J.m.Nf] = ((NE[2] = [xE]), NE)),
      (ZE[J.m.Of] = ((OE[2] = [xE]), OE)),
      (ZE[J.m.Pf] = ((PE[2] = [xE]), PE)),
      (ZE[J.m.Qf] = ((QE[2] = [xE]), QE)),
      (ZE[J.m.rb] = ((RE[1] = [xE]), RE)),
      (ZE[J.m.gd] = ((SE[1] = [xE]), SE)),
      (ZE[J.m.ld] = ((TE[1] = [xE]), TE)),
      (ZE[J.m.me] = ((UE[1] = [xE]), UE)),
      (ZE[J.m.ef] =
        ((VE[1] = [
          function (a) {
            return F(102) && xE(a);
          },
        ]),
        VE)),
      (ZE[J.m.Ac] = ((WE[1] = [xE]), WE)),
      (ZE[J.m.ya] = ((XE[1] = [xE]), XE)),
      (ZE[J.m.Ya] = ((YE[1] = [xE]), YE)),
      ZE),
    aF = {},
    bF =
      ((aF[J.m.rb] = yE),
      (aF[J.m.gd] = yE),
      (aF[J.m.ld] = yE),
      (aF[J.m.me] = yE),
      (aF[J.m.ef] = yE),
      (aF[J.m.Ac] = function (a) {
        if (!rd(a)) return {};
        var b = sd(a, null);
        delete b.match_id;
        return b;
      }),
      (aF[J.m.ya] = zE),
      (aF[J.m.Ya] = zE),
      aF),
    cF = {},
    dF = {},
    eF = ((dF[N.A.Ta] = ((cF[2] = [xE]), cF)), dF),
    fF = {};
  var gF = function (a, b, c, d) {
    this.C = a;
    this.P = b;
    this.T = c;
    this.V = d;
  };
  gF.prototype.getValue = function (a) {
    a = a === void 0 ? Hl.aa.Qc : a;
    if (
      !this.P.some(function (b) {
        return b(a);
      })
    )
      return this.T.some(function (b) {
        return b(a);
      })
        ? this.V(this.C)
        : this.C;
  };
  gF.prototype.H = function () {
    return pd(this.C) === "array" || rd(this.C) ? sd(this.C, null) : this.C;
  };
  var hF = function () {},
    iF = function (a, b) {
      this.conditions = a;
      this.C = b;
    },
    jF = function (a, b, c) {
      var d,
        e = ((d = a.conditions[b]) == null ? void 0 : d[2]) || [],
        f,
        g = ((f = a.conditions[b]) == null ? void 0 : f[1]) || [];
      return new gF(c, e, g, a.C[b] || hF);
    },
    kF,
    lF;
  var mF,
    nF = !1;
  function oF() {
    nF = !0;
    gg(52) && ((mF = productSettings), (productSettings = void 0));
    mF = mF || {};
  }
  function pF(a) {
    nF || oF();
    return mF[a];
  }
  var qF = function (a, b, c) {
      this.eventName = b;
      this.D = c;
      this.C = {};
      this.isAborted = !1;
      this.target = a;
      this.metadata = {};
      for (
        var d = c.eventMetadata || {}, e = m(Object.keys(d)), f = e.next();
        !f.done;
        f = e.next()
      ) {
        var g = f.value;
        P(this, g, d[g]);
      }
    },
    Gu = function (a, b) {
      var c, d;
      return (c = a.C[b]) == null
        ? void 0
        : (d = c.getValue) == null
        ? void 0
        : d.call(c, O(a, N.A.fg));
    },
    S = function (a, b, c) {
      var d = a.C,
        e;
      c === void 0
        ? (e = void 0)
        : (kF != null || (kF = new iF($E, bF)), (e = jF(kF, b, c)));
      d[b] = e;
    };
  qF.prototype.mergeHitDataForKey = function (a, b) {
    var c, d, e;
    c =
      (d = this.C[a]) == null ? void 0 : (e = d.H) == null ? void 0 : e.call(d);
    if (!c) return S(this, a, b), !0;
    if (!rd(c)) return !1;
    S(this, a, la(Object, "assign").call(Object, c, b));
    return !0;
  };
  var rF = function (a, b) {
    b = b === void 0 ? {} : b;
    for (var c = m(Object.keys(a.C)), d = c.next(); !d.done; d = c.next()) {
      var e = d.value,
        f = void 0,
        g = void 0,
        h = void 0;
      b[e] =
        (f = a.C[e]) == null
          ? void 0
          : (h = (g = f).H) == null
          ? void 0
          : h.call(g);
    }
    return b;
  };
  qF.prototype.copyToHitData = function (a, b, c) {
    var d = M(this.D, a);
    d === void 0 && (d = b);
    if (rb(d) && c !== void 0 && F(92))
      try {
        d = c(d);
      } catch (e) {}
    d !== void 0 && S(this, a, d);
  };
  var O = function (a, b) {
      var c = a.metadata[b];
      if (b === N.A.fg) {
        var d;
        return c == null ? void 0 : (d = c.H) == null ? void 0 : d.call(c);
      }
      var e;
      return c == null
        ? void 0
        : (e = c.getValue) == null
        ? void 0
        : e.call(c, O(a, N.A.fg));
    },
    P = function (a, b, c) {
      var d = a.metadata,
        e;
      c === void 0
        ? (e = c)
        : (lF != null || (lF = new iF(eF, fF)), (e = jF(lF, b, c)));
      d[b] = e;
    },
    sF = function (a, b) {
      b = b === void 0 ? {} : b;
      for (
        var c = m(Object.keys(a.metadata)), d = c.next();
        !d.done;
        d = c.next()
      ) {
        var e = d.value,
          f = void 0,
          g = void 0,
          h = void 0;
        b[e] =
          (f = a.metadata[e]) == null
            ? void 0
            : (h = (g = f).H) == null
            ? void 0
            : h.call(g);
      }
      return b;
    },
    tF = function (a, b, c) {
      var d = pF(a.target.destinationId);
      return d && d[b] !== void 0 ? d[b] : c;
    },
    uF = function (a) {
      for (
        var b = new qF(a.target, a.eventName, a.D),
          c = rF(a),
          d = m(Object.keys(c)),
          e = d.next();
        !e.done;
        e = d.next()
      ) {
        var f = e.value;
        S(b, f, c[f]);
      }
      for (
        var g = sF(a), h = m(Object.keys(g)), l = h.next();
        !l.done;
        l = h.next()
      ) {
        var n = l.value;
        P(b, n, g[n]);
      }
      b.isAborted = a.isAborted;
      return b;
    },
    vF = function (a) {
      var b = a.D,
        c = b.eventId,
        d = b.priorityId;
      return d ? c + "_" + d : String(c);
    };
  qF.prototype.accept = function () {
    var a = mm(hm.Z.Ci, {}),
      b = vF(this),
      c = this.target.destinationId;
    a[b] || (a[b] = {});
    a[b][c] = Oj();
    var d = hm.Z.Ci;
    if (im(d)) {
      var e;
      (e = jm(d)) == null || e.notify();
    }
  };
  qF.prototype.canBeAccepted = function (a) {
    var b = lm(hm.Z.Ci);
    if (!b) return !0;
    var c = b[vF(this)];
    if (!c) return !0;
    var d = c[a != null ? a : this.target.destinationId];
    return d === void 0 || d === Oj();
  };
  function wF(a) {
    return {
      getDestinationId: function () {
        return a.target.destinationId;
      },
      getEventName: function () {
        return a.eventName;
      },
      setEventName: function (b) {
        a.eventName = b;
      },
      getHitData: function (b) {
        return Gu(a, b);
      },
      setHitData: function (b, c) {
        S(a, b, c);
      },
      setHitDataIfNotDefined: function (b, c) {
        Gu(a, b) === void 0 && S(a, b, c);
      },
      copyToHitData: function (b, c) {
        a.copyToHitData(b, c);
      },
      getMetadata: function (b) {
        return O(a, b);
      },
      setMetadata: function (b, c) {
        P(a, b, c);
      },
      isAborted: function () {
        return a.isAborted;
      },
      abort: function () {
        a.isAborted = !0;
      },
      getFromEventContext: function (b) {
        return M(a.D, b);
      },
      nb: function () {
        return a;
      },
      getHitKeys: function () {
        return Object.keys(a.C);
      },
      getMergedValues: function (b) {
        return a.D.getMergedValues(b, 3);
      },
      mergeHitDataForKey: function (b, c) {
        return rd(c) ? a.mergeHitDataForKey(b, c) : !1;
      },
      accept: function () {
        a.accept();
      },
      canBeAccepted: function (b) {
        return a.canBeAccepted(b);
      },
    };
  }
  function xF(a, b) {
    var c;
    return c;
  }
  xF.K = "internal.copyPreHit";
  function yF(a, b) {
    var c = null;
    return Hd(c, this.J, 2);
  }
  yF.publicName = "createArgumentsQueue";
  function zF(a) {
    return Hd(
      function (c) {
        var d = jz();
        if (typeof c === "function")
          d(function () {
            c(function (f, g, h) {
              var l = jz(),
                n = l && l.getByName && l.getByName(f);
              return new x.gaplugins.Linker(n).decorate(g, h);
            });
          });
        else if (Array.isArray(c)) {
          var e = String(c[0]).split(".");
          b[e.length === 1 ? e[0] : e[1]] && d.apply(null, c);
        } else if (c === "isLoaded") return !!d.loaded;
      },
      this.J,
      1
    );
  }
  zF.K = "internal.createGaCommandQueue";
  function AF(a) {
    return Hd(
      function () {
        if (!pb(e.push))
          throw Error("Object at " + a + " in window is not an array.");
        e.push.apply(e, Array.prototype.slice.call(arguments, 0));
      },
      this.J,
      Uh(VC(this).Mb()) ? 2 : 1
    );
  }
  AF.publicName = "createQueue";
  function BF(a, b) {
    var c = null;
    if (!Fh(a) || !Gh(b))
      throw G(this.getName(), ["string", "string|undefined"], arguments);
    try {
      var d = (b || "")
        .split("")
        .filter(function (e) {
          return "ig".indexOf(e) >= 0;
        })
        .join("");
      c = new Ed(new RegExp(a, d));
    } catch (e) {}
    return c;
  }
  BF.K = "internal.createRegex";
  function CF(a) {}
  CF.K = "internal.declareConsentState";
  function DF(a) {
    var b = "";
    return b;
  }
  DF.K = "internal.decodeUrlHtmlEntities";
  function EF(a, b, c) {
    var d;
    return d;
  }
  EF.K = "internal.decorateUrlWithGaCookies";
  function FF() {}
  FF.K = "internal.deferCustomEvents";
  function GF(a, b) {
    if (!HF) return null;
    if (Element.prototype.closest)
      try {
        return a.closest(b);
      } catch (e) {
        return null;
      }
    var c =
        Element.prototype.matches ||
        Element.prototype.webkitMatchesSelector ||
        Element.prototype.mozMatchesSelector ||
        Element.prototype.msMatchesSelector ||
        Element.prototype.oMatchesSelector,
      d = a;
    if (!A.documentElement.contains(d)) return null;
    do {
      try {
        if (c.call(d, b)) return d;
      } catch (e) {
        break;
      }
      d = d.parentElement || d.parentNode;
    } while (d !== null && d.nodeType === 1);
    return null;
  }
  var IF = !1;
  if (A.querySelectorAll)
    try {
      var JF = A.querySelectorAll(":root");
      JF && JF.length == 1 && JF[0] == A.documentElement && (IF = !0);
    } catch (a) {}
  var HF = IF;
  function KF() {
    var a = x.screen;
    return { width: a ? a.width : 0, height: a ? a.height : 0 };
  }
  function LF(a) {
    if (A.hidden) return !0;
    var b = a.getBoundingClientRect();
    if (b.top === b.bottom || b.left === b.right || !x.getComputedStyle)
      return !0;
    var c = x.getComputedStyle(a, null);
    if (c.visibility === "hidden") return !0;
    for (var d = a, e = c; d; ) {
      if (e.display === "none") return !0;
      var f = e.opacity,
        g = e.filter;
      if (g) {
        var h = g.indexOf("opacity(");
        h >= 0 &&
          ((g = g.substring(h + 8, g.indexOf(")", h))),
          g.charAt(g.length - 1) === "%" && (g = g.substring(0, g.length - 1)),
          (f = String(Math.min(Number(g), Number(f)))));
      }
      if (f !== void 0 && Number(f) <= 0) return !0;
      (d = d.parentElement) && (e = x.getComputedStyle(d, null));
    }
    return !1;
  }
  function QG(a) {
    var b;
    return b;
  }
  QG.K = "internal.detectUserProvidedData";
  function VG(a, b) {
    return f;
  }
  VG.K = "internal.enableAutoEventOnClick";
  function cH(a, b) {
    return p;
  }
  cH.K = "internal.enableAutoEventOnElementVisibility";
  function dH() {}
  dH.K = "internal.enableAutoEventOnError";
  var eH = {},
    fH = [],
    gH = {},
    hH = 0,
    iH = 0;
  function oH(a, b) {
    var c = this;
    return d;
  }
  oH.K = "internal.enableAutoEventOnFormInteraction";
  function tH(a, b) {
    var c = this;
    return f;
  }
  tH.K = "internal.enableAutoEventOnFormSubmit";
  function yH() {
    var a = this;
  }
  yH.K = "internal.enableAutoEventOnGaSend";
  var zH = {},
    AH = [];
  function HH(a, b) {
    var c = this;
    return f;
  }
  HH.K = "internal.enableAutoEventOnHistoryChange";
  var IH = ["http://", "https://", "javascript:", "file://"];
  function MH(a, b) {
    var c = this;
    return h;
  }
  MH.K = "internal.enableAutoEventOnLinkClick";
  var NH, OH;
  function ZH(a, b) {
    var c = this;
    return d;
  }
  ZH.K = "internal.enableAutoEventOnScroll";
  function $H(a) {
    return function () {
      if (a.limit && a.Ij >= a.limit) a.Rh && x.clearInterval(a.Rh);
      else {
        a.Ij++;
        var b = Fb();
        hB({
          event: a.eventName,
          "gtm.timerId": a.Rh,
          "gtm.timerEventNumber": a.Ij,
          "gtm.timerInterval": a.interval,
          "gtm.timerLimit": a.limit,
          "gtm.timerStartTime": a.Gn,
          "gtm.timerCurrentTime": b,
          "gtm.timerElapsedTime": b - a.Gn,
          "gtm.triggers": a.Xr,
        });
      }
    };
  }
  function aI(a, b) {
    return f;
  }
  aI.K = "internal.enableAutoEventOnTimer";
  var tc = Aa(["data-gtm-yt-inspected-"]),
    cI = ["www.youtube.com", "www.youtube-nocookie.com"],
    dI,
    eI = !1;
  function oI(a, b) {
    var c = this;
    return e;
  }
  oI.K = "internal.enableAutoEventOnYouTubeActivity";
  eI = !1;
  function pI(a, b) {
    if (!Fh(a) || !zh(b))
      throw G(this.getName(), ["string", "Object|undefined"], arguments);
    var c = b ? B(b) : {},
      d = a,
      e = !1;
    return e;
  }
  pI.K = "internal.evaluateBooleanExpression";
  var qI;
  function rI(a) {
    var b = !1;
    return b;
  }
  rI.K = "internal.evaluateMatchingRules";
  var tI = [J.m.W, J.m.X];
  function EI(a) {
    if (F(10)) return;
    var b = lj() || gg(50) || !!tk(a.D);
    F(245) && (b = gg(50) || !!tk(a.D));
    if (b || F(168)) return;
    Vx({ Hn: F(131) });
  }
  function JI() {
    var a;
    a = a === void 0 ? document : a;
    var b;
    return !(
      (b = a.featurePolicy) == null ||
      !b.allowedFeatures().includes("attribution-reporting")
    );
  }
  var SI = /^(www\.)?google(\.com?)?(\.[a-z]{2}t?)?$/,
    TI = /^www.googleadservices.com$/;
  function UI(a) {
    a || (a = VI());
    return a.Yr
      ? !1
      : a.Mq ||
        a.Nq ||
        a.Pq ||
        a.Oq ||
        a.Me ||
        a.Lh ||
        a.Aq ||
        a.ac === "aw.ds" ||
        (F(235) && a.ac === "aw.dv") ||
        a.Eq
      ? !0
      : !1;
  }
  function VI() {
    var a = {},
      b = hs(!0);
    a.Yr = !!b._up;
    var c = Lt(),
      d = nu();
    a.Mq = c.aw !== void 0;
    a.Nq = c.dc !== void 0;
    a.Pq = c.wbraid !== void 0;
    a.Oq = c.gbraid !== void 0;
    a.ac = typeof c.gclsrc === "string" ? c.gclsrc : void 0;
    a.Me = d.Me;
    a.Lh = d.Lh;
    var e = A.referrer ? sj(yj(A.referrer), "host") : "";
    a.Eq = SI.test(e);
    a.Aq = TI.test(e);
    return a;
  }
  var mJ = {};
  var oJ =
    "platform platformVersion architecture model uaFullVersion bitness fullVersionList wow64".split(
      " "
    );
  function pJ(a) {
    var b;
    return (b = a.google_tag_data) != null ? b : (a.google_tag_data = {});
  }
  function qJ(a) {
    var b = a.google_tag_data,
      c;
    if (b != null && b.uach) {
      var d = b.uach,
        e = la(Object, "assign").call(Object, {}, d);
      d.fullVersionList && (e.fullVersionList = d.fullVersionList.slice(0));
      c = e;
    } else c = null;
    return c;
  }
  function rJ(a) {
    var b, c;
    return (c = (b = a.google_tag_data) == null ? void 0 : b.uach_promise) !=
      null
      ? c
      : null;
  }
  function sJ(a) {
    var b, c;
    return (
      typeof ((b = a.navigator) == null
        ? void 0
        : (c = b.userAgentData) == null
        ? void 0
        : c.getHighEntropyValues) === "function"
    );
  }
  function tJ(a) {
    if (!sJ(a)) return null;
    var b = pJ(a);
    if (b.uach_promise) return b.uach_promise;
    var c = a.navigator.userAgentData
      .getHighEntropyValues(oJ)
      .then(function (d) {
        b.uach != null || (b.uach = d);
        return d;
      });
    return (b.uach_promise = c);
  }
  function zJ(a, b) {
    b = b === void 0 ? !1 : b;
    var c = O(a, N.A.eg),
      d = tF(a, "custom_event_accept_rules", !1) && !b;
    if (c) {
      var e = c.indexOf(a.target.destinationId) >= 0,
        f = !0;
      F(240) && O(a, N.A.th) && (f = O(a, N.A.Oa) === Oj());
      e && f ? P(a, N.A.Hg, !0) : (P(a, N.A.Hg, !1), d || (a.isAborted = !0));
      if (F(240))
        if (a.canBeAccepted()) {
          var g = Nj().indexOf(a.target.destinationId) >= 0,
            h = !1;
          if (!g) {
            var l,
              n =
                (l = Gj(a.target.destinationId)) == null
                  ? void 0
                  : l.canonicalContainerId;
            n && (h = Oj() === n);
          }
          g || h ? O(a, N.A.Hg) && a.accept() : (a.isAborted = !0);
        } else a.isAborted = !0;
      else O(a, N.A.Hg) && a.accept();
    }
  }
  function VJ() {
    var a = x.__uspapi;
    if (pb(a)) {
      var b = "";
      try {
        a("getUSPData", 1, function (c, d) {
          if (d && c) {
            var e = c.uspString;
            e && RegExp("^[\\da-zA-Z-]{1,20}$").test(e) && (b = e);
          }
        });
      } catch (c) {}
      return b;
    }
  }
  function YJ(a) {
    Nk &&
      ((Bm = !0),
      a.eventName === J.m.na
        ? Hm(a.D, a.target.id)
        : (O(a, N.A.be) || (Em[a.target.id] = !0), uA(O(a, N.A.Oa))));
  }
  var dK = { Sf: { Vn: "cd", Wn: "ce", Xn: "cf", Yn: "cpf", Zn: "cu" } };
  function gK(a, b) {
    b = b === void 0 ? !0 : b;
    var c = nb("GTAG_EVENT_FEATURE_CHANNEL");
    c && (S(a, J.m.Df, c), b && lb());
  }
  function sK(a) {}
  function UK() {
    return Gq(7) && Gq(9) && Gq(10);
  }
  function PL(a, b, c, d) {}
  PL.K = "internal.executeEventProcessor";
  function QL(a) {
    var b;
    return Hd(b, this.J, 1);
  }
  QL.K = "internal.executeJavascriptString";
  function RL(a) {
    var b;
    return b;
  }
  function SL(a) {
    var b = "";
    return b;
  }
  SL.K = "internal.generateClientId";
  function TL(a) {
    var b = {};
    return Hd(b);
  }
  TL.K = "internal.getAdsCookieWritingOptions";
  function UL(a, b) {
    var c = !1;
    return c;
  }
  UL.K = "internal.getAllowAdPersonalization";
  function VL() {
    var a;
    return a;
  }
  VL.K = "internal.getAndResetEventUsage";
  function WL(a, b) {
    b = b === void 0 ? !0 : b;
    var c;
    return c;
  }
  WL.K = "internal.getAuid";
  var XL = null;
  function YL() {
    var a = new $a();
    return a;
  }
  YL.publicName = "getContainerVersion";
  function ZL(a, b) {
    b = b === void 0 ? !0 : b;
    var c;
    return c;
  }
  ZL.publicName = "getCookieValues";
  function $L() {
    var a = "";
    return a;
  }
  $L.K = "internal.getCorePlatformServicesParam";
  function aM() {
    return Pm();
  }
  aM.K = "internal.getCountryCode";
  function bM() {
    var a = [];
    return Hd(a);
  }
  bM.K = "internal.getDestinationIds";
  function cM(a) {
    var b = new $a();
    return b;
  }
  cM.K = "internal.getDeveloperIds";
  function dM(a) {
    var b;
    return b;
  }
  dM.K = "internal.getEcsidCookieValue";
  function eM(a, b) {
    var c = null;
    return c;
  }
  eM.K = "internal.getElementAttribute";
  function fM(a) {
    var b = null;
    return b;
  }
  fM.K = "internal.getElementById";
  function gM(a) {
    var b = "";
    return b;
  }
  gM.K = "internal.getElementInnerText";
  function hM(a, b) {
    var c = null;
    return Hd(c);
  }
  hM.K = "internal.getElementProperty";
  function iM(a) {
    var b;
    return b;
  }
  iM.K = "internal.getElementValue";
  function jM(a) {
    var b = 0;
    return b;
  }
  jM.K = "internal.getElementVisibilityRatio";
  function kM(a) {
    var b = null;
    return b;
  }
  kM.K = "internal.getElementsByCssSelector";
  function lM(a) {
    var b;
    if (!Fh(a)) throw G(this.getName(), ["string"], arguments);
    H(this, "read_event_data", a);
    var c;
    a: {
      var d = a,
        e = VC(this).originalEventData;
      if (e) {
        for (
          var f = e, g = {}, h = {}, l = {}, n = [], p = d.split("\\\\"), q = 0;
          q < p.length;
          q++
        ) {
          for (var r = p[q].split("\\."), u = 0; u < r.length; u++) {
            for (var t = r[u].split("."), v = 0; v < t.length; v++)
              n.push(t[v]), v !== t.length - 1 && n.push(l);
            u !== r.length - 1 && n.push(h);
          }
          q !== p.length - 1 && n.push(g);
        }
        for (
          var w = [], y = "", z = m(n), D = z.next();
          !D.done;
          D = z.next()
        ) {
          var E = D.value;
          E === l
            ? (w.push(y), (y = ""))
            : (y = E === g ? y + "\\" : E === h ? y + "." : y + E);
        }
        y && w.push(y);
        for (var L = m(w), I = L.next(); !I.done; I = L.next()) {
          if (f == null) {
            c = void 0;
            break a;
          }
          f = f[I.value];
        }
        c = f;
      } else c = void 0;
    }
    b = Hd(c, this.J, 1);
    return b;
  }
  lM.K = "internal.getEventData";
  function mM(a) {
    var b = null;
    return b;
  }
  mM.K = "internal.getFirstElementByCssSelector";
  var nM = {};
  nM.disableUserDataWithoutCcd = F(223);
  nM.enableDecodeUri = F(92);
  nM.enableGaAdsConversions = F(122);
  nM.enableGaAdsConversionsClientId = F(121);
  nM.enableUrlDecodeEventUsage = F(139);
  function oM() {
    return Hd(nM);
  }
  oM.K = "internal.getFlags";
  function pM() {
    var a;
    return a;
  }
  pM.K = "internal.getGsaExperimentId";
  function qM() {
    return new Ed(aC);
  }
  qM.K = "internal.getHtmlId";
  function rM(a) {
    var b;
    return b;
  }
  rM.K = "internal.getIframingState";
  function sM(a, b) {
    var c = {};
    return Hd(c);
  }
  sM.K = "internal.getLinkerValueFromLocation";
  function tM() {
    var a = new $a();
    return a;
  }
  tM.K = "internal.getPrivacyStrings";
  function uM(a, b) {
    var c;
    return c;
  }
  uM.K = "internal.getProductSettingsParameter";
  function vM(a, b) {
    var c;
    return c;
  }
  vM.publicName = "getQueryParameters";
  function wM(a, b) {
    var c;
    return c;
  }
  wM.publicName = "getReferrerQueryParameters";
  function xM(a) {
    var b = "";
    if (!Gh(a)) throw G(this.getName(), ["string|undefined"], arguments);
    H(this, "get_referrer", a);
    b = uj(yj(A.referrer), a);
    return b;
  }
  xM.publicName = "getReferrerUrl";
  function yM() {
    return Qm();
  }
  yM.K = "internal.getRegionCode";
  function zM(a, b) {
    var c;
    return c;
  }
  zM.K = "internal.getRemoteConfigParameter";
  function AM() {
    var a = new $a();
    a.set("width", 0);
    a.set("height", 0);
    return a;
  }
  AM.K = "internal.getScreenDimensions";
  function BM() {
    var a = "";
    return a;
  }
  BM.K = "internal.getTopSameDomainUrl";
  function CM() {
    var a = "";
    return a;
  }
  CM.K = "internal.getTopWindowUrl";
  function DM(a) {
    var b = "";
    if (!Gh(a)) throw G(this.getName(), ["string|undefined"], arguments);
    H(this, "get_url", a);
    b = sj(yj(x.location.href), a);
    return b;
  }
  DM.publicName = "getUrl";
  function EM() {
    H(this, "get_user_agent");
    return Ac.userAgent;
  }
  EM.K = "internal.getUserAgent";
  function FM() {
    var a;
    return a ? Hd(uJ(a)) : a;
  }
  FM.K = "internal.getUserAgentClientHints";
  function MM() {
    var a = x;
    return (a.gaGlobal = a.gaGlobal || {});
  }
  function NM() {
    var a = MM();
    a.hid = a.hid || vb();
    return a.hid;
  }
  function OM(a, b) {
    var c = MM();
    if (c.vid === void 0 || (b && !c.from_cookie))
      (c.vid = a), (c.from_cookie = b);
  }
  function lN(a) {
    (CI(a) || lj()) && S(a, J.m.Bl, Qm() || Pm());
    !CI(a) && lj() && S(a, J.m.Ji, "::");
  }
  function mN(a) {
    if (lj() && !CI(a) && (Tm() || S(a, J.m.jl, !0), F(78))) {
      fK(a);
      eK(a, dK.Sf.Yn, mn(M(a.D, J.m.Wa)));
      var b = dK.Sf.Zn;
      var c = M(a.D, J.m.yc);
      eK(a, b, c === !0 ? 1 : c === !1 ? 0 : void 0);
      eK(a, dK.Sf.Xn, mn(M(a.D, J.m.Cb)));
      eK(a, dK.Sf.Vn, Mr(ln(M(a.D, J.m.tb)), ln(M(a.D, J.m.Ub))));
    }
  }
  var HN = { AW: hm.Z.Nn, G: hm.Z.mp, DC: hm.Z.hp };
  function IN(a) {
    var b = Gv(a);
    return (
      "" +
      di(
        b
          .map(function (c) {
            return c.value;
          })
          .join("!")
      )
    );
  }
  function JN(a) {
    var b = lo(a);
    return b && HN[b.prefix];
  }
  function KN(a, b) {
    var c = a[b];
    c &&
      (c.clearTimerId && x.clearTimeout(c.clearTimerId),
      (c.clearTimerId = x.setTimeout(function () {
        delete a[b];
      }, 36e5)));
  }
  var qO = function (a) {
    for (
      var b = {}, c = String(pO.cookie).split(";"), d = 0;
      d < c.length;
      d++
    ) {
      var e = c[d].split("="),
        f = e[0].trim();
      if (f && a(f)) {
        var g = e.slice(1).join("=").trim();
        g && (g = decodeURIComponent(g));
        var h = void 0,
          l = void 0;
        ((h = b)[(l = f)] || (h[l] = [])).push(g);
      }
    }
    return b;
  };
  var rO = window,
    pO = document,
    sO = function (a) {
      var b = rO._gaUserPrefs;
      if (
        (b && b.ioo && b.ioo()) ||
        pO.documentElement.hasAttribute("data-google-analytics-opt-out") ||
        (a && rO["ga-disable-" + a] === !0)
      )
        return !0;
      try {
        var c = rO.external;
        if (c && c._gaUserPrefs && c._gaUserPrefs == "oo") return !0;
      } catch (f) {}
      for (
        var d =
            qO(function (f) {
              return f === "AMP_TOKEN";
            }).AMP_TOKEN || [],
          e = 0;
        e < d.length;
        e++
      )
        if (d[e] == "$OPT_OUT") return !0;
      return pO.getElementById("__gaOptOutExtension") ? !0 : !1;
    };
  var tO =
    "gclid dclid gclsrc wbraid gbraid gad_source gad_campaignid utm_source utm_medium utm_campaign utm_term utm_content utm_id".split(
      " "
    );
  function uO() {
    var a = A.location,
      b,
      c =
        a == null
          ? void 0
          : (b = a.search) == null
          ? void 0
          : b.replace("?", ""),
      d;
    if (c) {
      for (
        var e = [], f = qj(c, !0), g = m(tO), h = g.next();
        !h.done;
        h = g.next()
      ) {
        var l = h.value,
          n = f[l];
        if (n)
          for (var p = 0; p < n.length; p++) {
            var q = n[p];
            q !== void 0 && e.push({ name: l, value: q });
          }
      }
      d = e;
    } else d = [];
    return d;
  }
  function FO(a) {
    yb(a, function (c) {
      c.charAt(0) === "_" && delete a[c];
    });
    var b = a[J.m.xd] || {};
    yb(b, function (c) {
      c.charAt(0) === "_" && delete b[c];
    });
  }
  function jP(a, b) {}
  function kP(a, b) {
    var c = function () {};
    return c;
  }
  function lP(a, b, c) {}
  var mP = Tg.O.zk,
    nP = Tg.O.Ak;
  function oP(a, b) {
    if (F(240)) {
      var c = Mj();
      c && c.indexOf(b) > -1 && (a[N.A.th] = !0);
    }
  }
  function qP(a, b, c) {
    var d = this;
  }
  qP.K = "internal.gtagConfig";
  function rP(a, b, c) {
    var d = this;
  }
  rP.K = "internal.gtagDestinationConfig";
  function tP(a, b) {}
  tP.publicName = "gtagSet";
  function uP() {
    var a = {};
    return a;
  }
  function vP(a) {}
  vP.K = "internal.initializeServiceWorker";
  function wP(a, b) {}
  wP.publicName = "injectHiddenIframe";
  var xP = (function () {
    var a = 0;
    return function (b) {
      switch (b) {
        case 1:
          a |= 1;
          break;
        case 2:
          a |= 2;
          break;
        case 3:
          a |= 4;
      }
      return a;
    };
  })();
  function yP(a, b, c, d, e) {}
  yP.K = "internal.injectHtml";
  var CP = {};
  function EP(a, b, c, d) {}
  var FP = { dl: 1, id: 1 },
    GP = {};
  function HP(a, b, c, d) {}
  F(160) ? (HP.publicName = "injectScript") : (EP.publicName = "injectScript");
  HP.K = "internal.injectScript";
  function IP() {
    var a = !1;
    return a;
  }
  IP.K = "internal.isAutoPiiEligible";
  function JP(a) {
    var b = !0;
    return b;
  }
  JP.publicName = "isConsentGranted";
  function KP(a) {
    var b = !1;
    return b;
  }
  KP.K = "internal.isDebugMode";
  function LP() {
    return Sm();
  }
  LP.K = "internal.isDmaRegion";
  function MP(a) {
    var b = !1;
    return b;
  }
  MP.K = "internal.isEntityInfrastructure";
  function NP(a) {
    var b = !1;
    return b;
  }
  NP.K = "internal.isFeatureEnabled";
  function OP() {
    var a = !1;
    return a;
  }
  OP.K = "internal.isFpfe";
  function PP() {
    var a = !1;
    return a;
  }
  PP.K = "internal.isGcpConversion";
  function QP() {
    var a = !1;
    return a;
  }
  QP.K = "internal.isLandingPage";
  function RP() {
    var a = !1;
    return a;
  }
  RP.K = "internal.isOgt";
  function SP() {
    var a;
    return a;
  }
  SP.K = "internal.isSafariPcmEligibleBrowser";
  function TP() {
    var a = ii(function (b) {
      VC(this).log("error", b);
    });
    a.publicName = "JSON";
    return a;
  }
  function UP(a) {
    var b = void 0;
    if (!Fh(a)) throw G(this.getName(), ["string"], arguments);
    b = yj(a);
    return Hd(b);
  }
  UP.K = "internal.legacyParseUrl";
  function VP() {
    return !1;
  }
  var WP = {
    getItem: function (a) {
      var b = null;
      return b;
    },
    setItem: function (a, b) {
      return !1;
    },
    removeItem: function (a) {},
  };
  function XP() {}
  XP.publicName = "logToConsole";
  function YP(a, b) {}
  YP.K = "internal.mergeRemoteConfig";
  function ZP(a, b, c) {
    c = c === void 0 ? !0 : c;
    var d = [];
    return Hd(d);
  }
  ZP.K = "internal.parseCookieValuesFromString";
  function $P(a) {
    var b = void 0;
    if (typeof a !== "string") return;
    a && Kb(a, "//") && (a = A.location.protocol + a);
    if (typeof URL === "function") {
      var c;
      a: {
        var d;
        try {
          d = new URL(a);
        } catch (w) {
          c = void 0;
          break a;
        }
        for (
          var e = {}, f = Array.from(d.searchParams), g = 0;
          g < f.length;
          g++
        ) {
          var h = f[g][0],
            l = f[g][1];
          e.hasOwnProperty(h)
            ? typeof e[h] === "string"
              ? (e[h] = [e[h], l])
              : e[h].push(l)
            : (e[h] = l);
        }
        c = Hd({
          href: d.href,
          origin: d.origin,
          protocol: d.protocol,
          username: d.username,
          password: d.password,
          host: d.host,
          hostname: d.hostname,
          port: d.port,
          pathname: d.pathname,
          search: d.search,
          searchParams: e,
          hash: d.hash,
        });
      }
      return c;
    }
    var n;
    try {
      n = yj(a);
    } catch (w) {
      return;
    }
    if (!n.protocol || !n.host) return;
    var p = {};
    if (n.search)
      for (
        var q = n.search.replace("?", "").split("&"), r = 0;
        r < q.length;
        r++
      ) {
        var u = q[r].split("="),
          t = u[0],
          v = rj(u.splice(1).join("=")) || "";
        v = v.replace(/\+/g, " ");
        p.hasOwnProperty(t)
          ? typeof p[t] === "string"
            ? (p[t] = [p[t], v])
            : p[t].push(v)
          : (p[t] = v);
      }
    n.searchParams = p;
    n.origin = n.protocol + "//" + n.host;
    n.username = "";
    n.password = "";
    b = Hd(n);
    return b;
  }
  $P.publicName = "parseUrl";
  function aQ(a) {}
  aQ.K = "internal.processAsNewEvent";
  function bQ(a, b, c) {
    var d;
    return d;
  }
  bQ.K = "internal.pushToDataLayer";
  function cQ(a) {
    var b = Ca.apply(1, arguments),
      c = !1;
    return c;
  }
  cQ.publicName = "queryPermission";
  function dQ(a) {
    var b = this;
  }
  dQ.K = "internal.queueAdsTransmission";
  function eQ(a) {
    var b = void 0;
    return b;
  }
  eQ.publicName = "readAnalyticsStorage";
  function fQ() {
    var a = "";
    return a;
  }
  fQ.publicName = "readCharacterSet";
  function gQ() {
    return hg(19);
  }
  gQ.K = "internal.readDataLayerName";
  function hQ() {
    var a = "";
    return a;
  }
  hQ.publicName = "readTitle";
  function iQ(a, b) {
    var c = this;
  }
  iQ.K = "internal.registerCcdCallback";
  function jQ(a, b) {
    return !0;
  }
  jQ.K = "internal.registerDestination";
  var kQ = ["config", "event", "get", "set"];
  function lQ(a, b, c) {}
  lQ.K = "internal.registerGtagCommandListener";
  function mQ(a, b) {
    var c = !1;
    return c;
  }
  mQ.K = "internal.removeDataLayerEventListener";
  function nQ(a, b) {}
  nQ.K = "internal.removeFormData";
  function oQ() {}
  oQ.publicName = "resetDataLayer";
  function pQ(a, b, c) {
    var d = void 0;
    return d;
  }
  pQ.K = "internal.scrubUrlParams";
  function qQ(a) {}
  qQ.K = "internal.sendAdsHit";
  function rQ(a, b, c, d) {}
  rQ.K = "internal.sendGtagEvent";
  function sQ(a, b, c) {}
  sQ.publicName = "sendPixel";
  function tQ(a, b) {}
  tQ.K = "internal.setAnchorHref";
  function uQ(a) {}
  uQ.K = "internal.setContainerConsentDefaults";
  function vQ(a, b, c, d) {
    var e = this;
    d = d === void 0 ? !0 : d;
    var f = !1;
    return f;
  }
  vQ.publicName = "setCookie";
  function wQ(a) {}
  wQ.K = "internal.setCorePlatformServices";
  function xQ(a, b) {}
  xQ.K = "internal.setDataLayerValue";
  function yQ(a) {}
  yQ.publicName = "setDefaultConsentState";
  function zQ(a, b) {}
  zQ.K = "internal.setDelegatedConsentType";
  function AQ(a, b) {}
  AQ.K = "internal.setFormAction";
  function BQ(a, b, c) {
    c = c === void 0 ? !1 : c;
  }
  BQ.K = "internal.setInCrossContainerData";
  function CQ(a, b, c) {
    return !1;
  }
  CQ.publicName = "setInWindow";
  function DQ(a, b, c) {}
  DQ.K = "internal.setProductSettingsParameter";
  function EQ(a, b, c) {}
  EQ.K = "internal.setRemoteConfigParameter";
  function FQ(a, b) {}
  FQ.K = "internal.setTransmissionMode";
  function GQ(a, b, c, d) {
    var e = this;
  }
  GQ.publicName = "sha256";
  function HQ(a, b, c) {}
  HQ.K = "internal.sortRemoteConfigParameters";
  function IQ(a) {}
  IQ.K = "internal.storeAdsBraidLabels";
  function JQ(a, b) {
    var c = void 0;
    return c;
  }
  JQ.K = "internal.subscribeToCrossContainerData";
  function KQ(a) {}
  KQ.K = "internal.taskSendAdsHits";
  var LQ = {},
    MQ = {};
  LQ.getItem = function (a) {
    var b = null;
    return b;
  };
  LQ.setItem = function (a, b) {};
  LQ.removeItem = function (a) {};
  LQ.clear = function () {};
  LQ.publicName = "templateStorage";
  LQ.resetForTest = function () {
    for (var a = m(Object.keys(MQ)), b = a.next(); !b.done; b = a.next())
      delete MQ[b.value];
  };
  function NQ(a, b) {
    var c = !1;
    return c;
  }
  NQ.K = "internal.testRegex";
  function OQ(a) {
    var b;
    return b;
  }
  function PQ(a, b) {}
  PQ.K = "internal.trackUsage";
  function QQ(a, b) {
    var c;
    return c;
  }
  QQ.K = "internal.unsubscribeFromCrossContainerData";
  function RQ(a) {}
  RQ.publicName = "updateConsentState";
  function SQ(a) {
    var b = !1;
    return b;
  }
  SQ.K = "internal.userDataNeedsEncryption";
  var TQ;
  function UQ(a, b, c) {
    TQ = TQ || new yi();
    TQ.add(a, b, c);
  }
  function VQ(a, b) {
    var c = (TQ = TQ || new yi());
    if (c.C.hasOwnProperty(a))
      throw Error(
        "Attempting to add a private function which already exists: " + a + "."
      );
    if (c.contains(a))
      throw Error(
        "Attempting to add a private function with an existing API name: " +
          a +
          "."
      );
    c.C[a] = pb(b) ? Nh(a, b) : Oh(a, b);
  }
  function WQ() {
    return function (a) {
      var b;
      var c = TQ;
      if (c.contains(a)) b = c.get(a, this);
      else {
        var d;
        if ((d = c.C.hasOwnProperty(a))) {
          var e = this.J.ob();
          if (e) {
            var f = !1,
              g = e.Mb();
            if (g) {
              Uh(g) || (f = !0);
            }
            d = f;
          } else d = !0;
        }
        if (d) {
          var h = c.C.hasOwnProperty(a) ? c.C[a] : void 0;
          b = h;
        } else throw Error(a + " is not a valid API name.");
      }
      return b;
    };
  }
  function XQ() {
    var a = function (c) {
        return void VQ(c.K, c);
      },
      b = function (c) {
        return void UQ(c.publicName, c);
      };
    b(PC);
    b(WC);
    b(jE);
    b(lE);
    b(mE);
    b(tE);
    b(vE);
    b(yF);
    b(TP());
    b(AF);
    b(YL);
    b(ZL);
    b(vM);
    b(wM);
    b(xM);
    b(DM);
    b(tP);
    b(wP);
    b(JP);
    b(XP);
    b($P);
    b(cQ);
    b(fQ);
    b(hQ);
    b(sQ);
    b(vQ);
    b(yQ);
    b(CQ);
    b(GQ);
    b(LQ);
    b(RQ);
    UQ("Math", Sh());
    UQ("Object", ri);
    UQ("TestHelper", Ai());
    UQ("assertApi", Ph);
    UQ("assertThat", Qh);
    UQ("decodeUri", Vh);
    UQ("decodeUriComponent", Wh);
    UQ("encodeUri", Xh);
    UQ("encodeUriComponent", Yh);
    UQ("fail", ci);
    UQ("generateRandom", fi);
    UQ("getTimestamp", gi);
    UQ("getTimestampMillis", gi);
    UQ("getType", hi);
    UQ("makeInteger", ji);
    UQ("makeNumber", ki);
    UQ("makeString", li);
    UQ("makeTableMap", mi);
    UQ("mock", pi);
    UQ("mockObject", qi);
    UQ("fromBase64", RL, !("atob" in x));
    UQ("localStorage", WP, !VP());
    UQ("toBase64", OQ, !("btoa" in x));
    a(OC);
    a(SC);
    a(lD);
    a(xD);
    a(ED);
    a(JD);
    a(ZD);
    a(hE);
    a(kE);
    a(nE);
    a(oE);
    a(pE);
    a(qE);
    a(rE);
    a(sE);
    a(uE);
    a(wE);
    a(xF);
    a(zF);
    a(BF);
    a(CF);
    a(DF);
    a(EF);
    a(FF);
    a(QG);
    a(VG);
    a(cH);
    a(dH);
    a(oH);
    a(tH);
    a(yH);
    a(HH);
    a(MH);
    a(ZH);
    a(aI);
    a(oI);
    a(pI);
    a(rI);
    a(PL);
    a(QL);
    a(SL);
    a(TL);
    a(UL);
    a(VL);
    a(WL);
    a(aM);
    a(bM);
    a(cM);
    a(dM);
    a(eM);
    a(fM);
    a(gM);
    a(hM);
    a(iM);
    a(jM);
    a(kM);
    a(lM);
    a(mM);
    a(oM);
    a(pM);
    a(qM);
    a(rM);
    a(sM);
    a(tM);
    a(uM);
    a(yM);
    a(zM);
    a(AM);
    a(BM);
    a(CM);
    a(FM);
    a(qP);
    a(rP);
    a(vP);
    a(yP);
    a(HP);
    a(IP);
    a(KP);
    a(LP);
    a(MP);
    a(NP);
    a(OP);
    a(PP);
    a(QP);
    a(RP);
    a(SP);
    a(UP);
    a(XD);
    a(YP);
    a(ZP);
    a(aQ);
    a(bQ);
    a(dQ);
    a(gQ);
    a(iQ);
    a(jQ);
    a(lQ);
    a(mQ);
    a(nQ);
    a(pQ);
    a(qQ);
    a(rQ);
    a(tQ);
    a(uQ);
    a(wQ);
    a(xQ);
    a(zQ);
    a(AQ);
    a(BQ);
    a(DQ);
    a(EQ);
    a(FQ);
    a(HQ);
    a(IQ);
    a(JQ);
    a(KQ);
    a(NQ);
    a(PQ);
    a(QQ);
    a(SQ);
    VQ("internal.IframingStateSchema", uP());
    VQ("internal.quickHash", ei);
    F(104) && a($L);
    F(160) ? b(HP) : b(EP);
    F(177) && b(eQ);
    return WQ();
  }
  var MC;
  function YQ() {
    var a = data.sandboxed_scripts,
      b = data.security_groups;
    a: {
      var c = data.runtime || [],
        d = data.runtime_lines;
      MC = new af();
      ZQ();
      Mf = LC();
      var e = MC,
        f = XQ(),
        g = new Ad("require", f);
      g.Ua();
      e.C.C.set("require", g);
      Va.set("require", g);
      for (var h = [], l = 0; l < c.length; l++) {
        var n = c[l];
        if (!Array.isArray(n) || n.length < 3) {
          if (n.length === 0) continue;
          break a;
        }
        d && d[l] && d[l].length && og(n, d[l]);
        try {
          MC.execute(n), F(120) && Lk && n[0] === 50 && h.push(n[1]);
        } catch (r) {}
      }
      F(120) && (Zf = h);
    }
    if (a && a.length)
      for (var p = 0; p < a.length; p++) {
        var q = a[p].replace(/^_*/, "");
        ij[q] = ["sandboxedScripts"];
      }
    $Q(b);
  }
  function ZQ() {
    MC.Yc(function (a, b, c) {
      Zn.SANDBOXED_JS_SEMAPHORE = Zn.SANDBOXED_JS_SEMAPHORE || 0;
      Zn.SANDBOXED_JS_SEMAPHORE++;
      try {
        return a.apply(b, c);
      } finally {
        Zn.SANDBOXED_JS_SEMAPHORE--;
      }
    });
  }
  function $Q(a) {
    a &&
      yb(a, function (b, c) {
        for (var d = 0; d < c.length; d++) {
          var e = c[d].replace(/^_*/, "");
          ij[e] = ij[e] || [];
          ij[e].push(b);
        }
      });
  }
  function aR(a) {
    BA(wA("developer_id." + a, !0), 0, {});
  }
  var bR = Array.isArray;
  function cR(a, b) {
    return sd(a, b || null);
  }
  function V(a) {
    return window.encodeURIComponent(a);
  }
  function dR(a, b, c) {
    Qc(a, b, c);
  }
  function eR(a) {
    var b = ["veinteractive.com", "ve-interactive.cn"];
    if (!a) return !1;
    var c = sj(yj(a), "host");
    if (!c) return !1;
    for (var d = 0; b && d < b.length; d++) {
      var e = b[d] && b[d].toLowerCase();
      if (e) {
        var f = c.length - e.length;
        f > 0 && e.charAt(0) !== "." && (f--, (e = "." + e));
        if (f >= 0 && c.indexOf(e, f) === f) return !0;
      }
    }
    return !1;
  }
  function fR(a, b, c) {
    for (var d = {}, e = !1, f = 0; a && f < a.length; f++)
      a[f] &&
        a[f].hasOwnProperty(b) &&
        a[f].hasOwnProperty(c) &&
        ((d[a[f][b]] = a[f][c]), (e = !0));
    return e ? d : null;
  }
  function gR(a, b) {
    var c = {};
    if (a) for (var d in a) a.hasOwnProperty(d) && (c[d] = a[d]);
    if (b) {
      var e = fR(b, "parameter", "parameterValue");
      e && (c = cR(e, c));
    }
    return c;
  }
  function hR(a, b, c) {
    return a === void 0 || a === c ? b : a;
  }
  function iR() {
    try {
      if (!F(243)) return null;
      rr("4");
      var a = [],
        b;
      a: {
        try {
          b = !(!HF || !A.querySelector('script[data-requiremodule^="mage/"]'));
          break a;
        } catch (e) {}
        b = !1;
      }
      b && a.push("ac");
      var c;
      a: {
        try {
          c = !(
            !HF || !A.querySelector('script[src^="//assets.squarespace.com/"]')
          );
          break a;
        } catch (e) {}
        c = !1;
      }
      c && a.push("sqs");
      var d;
      a: {
        try {
          d = !(
            !HF ||
            !A.querySelector(
              'script[src*="woocommerce"],link[href*="woocommerce"],[class|="woocommerce"]'
            )
          );
          break a;
        } catch (e) {}
        d = !1;
      }
      d && a.push("woo");
      sr("4");
      if (a.length > 0) return { plf: a.join(".") };
    } catch (e) {}
    return null;
  }
  function jR(a, b, c) {
    return Mc(a, b, c, void 0);
  }
  function kR(a, b) {
    return mp(a, b || 2);
  }
  function lR(a, b) {
    x[a] = b;
  }
  function mR(a, b, c) {
    var d = x;
    b && (d[a] === void 0 || (c && !d[a])) && (d[a] = b);
    return d[a];
  }
  var nR = {},
    oR = Si.M;
  var Y = { securityGroups: {} };

  (Y.securityGroups.get_referrer = ["google"]),
    (function () {
      function a(b, c, d) {
        return { component: c, queryKey: d };
      }
      (function (b) {
        Y.__get_referrer = b;
        Y.__get_referrer.F = "get_referrer";
        Y.__get_referrer.isVendorTemplate = !0;
        Y.__get_referrer.priorityOverride = 0;
        Y.__get_referrer.isInfrastructure = !1;
        Y.__get_referrer["5"] = !1;
      })(function (b) {
        var c = b.vtp_urlParts === "any" ? null : [];
        c &&
          (b.vtp_protocol && c.push("protocol"),
          b.vtp_host && c.push("host"),
          b.vtp_port && c.push("port"),
          b.vtp_path && c.push("path"),
          b.vtp_extension && c.push("extension"),
          b.vtp_query && c.push("query"));
        var d =
            c && b.vtp_queriesAllowed !== "any" ? b.vtp_queryKeys || [] : null,
          e = b.vtp_createPermissionError;
        return {
          assert: function (f, g, h) {
            if (g) {
              if (!rb(g)) throw e(f, {}, "URL component must be a string.");
              if (c && c.indexOf(g) < 0)
                throw e(f, {}, "Prohibited URL component: " + g);
              if (g === "query" && d) {
                if (!h)
                  throw e(
                    f,
                    {},
                    "Prohibited from getting entire URL query when query keys are specified."
                  );
                if (!rb(h)) throw e(f, {}, "Query key must be a string.");
                if (d.indexOf(h) < 0)
                  throw e(f, {}, "Prohibited query key: " + h);
              }
            } else if (c)
              throw e(
                f,
                {},
                "Prohibited from getting entire URL when components are specified."
              );
          },
          U: a,
        };
      });
    })();
  (Y.securityGroups.read_event_data = ["google"]),
    (function () {
      function a(b, c) {
        return { key: c };
      }
      (function (b) {
        Y.__read_event_data = b;
        Y.__read_event_data.F = "read_event_data";
        Y.__read_event_data.isVendorTemplate = !0;
        Y.__read_event_data.priorityOverride = 0;
        Y.__read_event_data.isInfrastructure = !1;
        Y.__read_event_data["5"] = !1;
      })(function (b) {
        var c = b.vtp_eventDataAccess,
          d = b.vtp_keyPatterns || [],
          e = b.vtp_createPermissionError;
        return {
          assert: function (f, g) {
            if (g != null && !rb(g))
              throw e(f, { key: g }, "Key must be a string.");
            if (c !== "any") {
              try {
                if (c === "specific" && g != null && ch(g, d)) return;
              } catch (h) {
                throw e(f, { key: g }, "Invalid key filter.");
              }
              throw e(f, { key: g }, "Prohibited read from event data.");
            }
          },
          U: a,
        };
      });
    })();

  (Y.securityGroups.read_data_layer = ["google"]),
    (function () {
      function a(b, c) {
        return { key: c };
      }
      (function (b) {
        Y.__read_data_layer = b;
        Y.__read_data_layer.F = "read_data_layer";
        Y.__read_data_layer.isVendorTemplate = !0;
        Y.__read_data_layer.priorityOverride = 0;
        Y.__read_data_layer.isInfrastructure = !1;
        Y.__read_data_layer["5"] = !1;
      })(function (b) {
        var c = b.vtp_allowedKeys || "specific",
          d = b.vtp_keyPatterns || [],
          e = b.vtp_createPermissionError;
        return {
          assert: function (f, g) {
            if (!rb(g)) throw e(f, {}, "Keys must be strings.");
            if (c !== "any") {
              try {
                if (ch(g, d)) return;
              } catch (h) {
                throw e(f, {}, "Invalid key filter.");
              }
              throw e(
                f,
                {},
                "Prohibited read from data layer variable: " + g + "."
              );
            }
          },
          U: a,
        };
      });
    })();

  (Y.securityGroups.get_url = ["google"]),
    (function () {
      function a(b, c, d) {
        return { component: c, queryKey: d };
      }
      (function (b) {
        Y.__get_url = b;
        Y.__get_url.F = "get_url";
        Y.__get_url.isVendorTemplate = !0;
        Y.__get_url.priorityOverride = 0;
        Y.__get_url.isInfrastructure = !1;
        Y.__get_url["5"] = !1;
      })(function (b) {
        var c = b.vtp_urlParts === "any" ? null : [];
        c &&
          (b.vtp_protocol && c.push("protocol"),
          b.vtp_host && c.push("host"),
          b.vtp_port && c.push("port"),
          b.vtp_path && c.push("path"),
          b.vtp_extension && c.push("extension"),
          b.vtp_query && c.push("query"),
          b.vtp_fragment && c.push("fragment"));
        var d =
            c && b.vtp_queriesAllowed !== "any" ? b.vtp_queryKeys || [] : null,
          e = b.vtp_createPermissionError;
        return {
          assert: function (f, g, h) {
            if (g) {
              if (!rb(g)) throw e(f, {}, "URL component must be a string.");
              if (c && c.indexOf(g) < 0)
                throw e(f, {}, "Prohibited URL component: " + g);
              if (g === "query" && d) {
                if (!h)
                  throw e(
                    f,
                    {},
                    "Prohibited from getting entire URL query when query keys are specified."
                  );
                if (!rb(h)) throw e(f, {}, "Query key must be a string.");
                if (d.indexOf(h) < 0)
                  throw e(f, {}, "Prohibited query key: " + h);
              }
            } else if (c)
              throw e(
                f,
                {},
                "Prohibited from getting entire URL when components are specified."
              );
          },
          U: a,
        };
      });
    })();

  var bo = {
    dataLayer: np,
    callback: function (a) {
      hj.hasOwnProperty(a) && pb(hj[a]) && hj[a]();
      delete hj[a];
    },
    bootstrap: 0,
  };
  function pR() {
    ao();
    Vj();
    Ny();
    Ib(ij, Y.securityGroups);
    var a = Rj(Sj()),
      b,
      c = a == null ? void 0 : (b = a.context) == null ? void 0 : b.source;
    Bn(c, a == null ? void 0 : a.parent);
    (c !== 2 && c !== 4 && c !== 3) || K(142);
    Yf = { gq: ug };
  }
  function qR() {
    var a = hg(60);
    a && a && (mJ[a] = !0);
  }
  function Mm() {
    try {
      if (gg(47) || !dk()) {
        Xi();
        if (F(109)) {
        }
        Ta[7] = !0;
        var a = $n("debugGroupId", function () {
          return String(Math.floor(Number.MAX_SAFE_INTEGER * Math.random()));
        });
        Jn(a);
        io();
        EC();
        zq();
        jA();
        if (Wj()) {
          hg(5);
          UD();
          Nz().removeExternalRestrictions(Oj());
        } else {
          sw();
          Wf();
          Sf = Y;
          Tf = mC;
          zx();
          YQ();
          pR();
          kC();
          Km || ((Jm = Om()), Jm["0"] && mm(hm.Z.Ce, JSON.stringify(Jm)));
          Yn();
          oB();
          pA();
          WA = !1;
          A.readyState === "complete" ? YA() : Rc(x, "load", YA);
          iA();
          Lk &&
            (xp(Kp),
            x.setInterval(Jp, 864e5),
            xp(FC),
            xp(yz),
            xp(Nw),
            xp(Np),
            xp(IC),
            xp(Lz),
            F(120) && (xp(Dz), xp(Ez), xp(Fz)),
            (hC = {}),
            xp(jC));
          Nk &&
            (ym(),
            zo(),
            qB(),
            EB(),
            zB(),
            jk("bt", String(gg(47) ? 2 : gg(50) ? 1 : 0)),
            jk("ct", String(gg(47) ? 0 : gg(50) ? 1 : 3)),
            uB(),
            yB(),
            CB());
          ZB();
          Im(1);
          VD();
          gj = Fb();
          bo.bootstrap = gj;
          gg(51) && nB();
          F(109) && ix();
          F(134) &&
            (typeof x.name === "string" &&
            Kb(x.name, "web-pixel-sandbox-CUSTOM") &&
            hd()
              ? aR("dMDg0Yz")
              : x.Shopify && (aR("dN2ZkMj"), hd() && aR("dNTU0Yz")));
          F(410) && qR();
        }
      }
    } catch (b) {
      Im(4), Gp();
    }
  }
  (function (a) {
    function b() {
      n = A.documentElement.getAttribute("data-tag-assistant-present");
      on(n) && (l = h.Il);
    }
    function c() {
      l && Dc ? g(l) : a();
    }
    if (!x[hg(37)]) {
      var d = !1;
      if (A.referrer) {
        var e = yj(A.referrer);
        d = uj(e, "host") === hg(38);
      }
      if (!d) {
        var f = vr(hg(39));
        d = !(!f.length || !f[0].length);
      }
      d && ((x[hg(37)] = !0), Mc(hg(40)));
    }
    var g = function (t) {
        var v = "GTM",
          w = "GTM";
        cj && ((v = "OGT"), (w = "GTAG"));
        var y = hg(23),
          z = x[y];
        z ||
          ((z = []),
          (x[y] = z),
          Mc(
            "https://" +
              hg(3) +
              "/debug/bootstrap?id=" +
              hg(5) +
              "&src=" +
              w +
              "&cond=" +
              String(t) +
              "&gtm=" +
              tp()
          ));
        var D = {
          messageType: "CONTAINER_STARTING",
          data: {
            scriptSource: Dc,
            containerProduct: v,
            debug: !1,
            id: hg(5),
            targetRef: { ctid: hg(5), isDestination: Lj(), canonicalId: hg(6) },
            aliases: Pj(),
            destinations: Mj(),
          },
        };
        D.data.resume = function () {
          a();
        };
        gg(2) && (D.data.initialPublish = !0);
        z.push(D);
      },
      h = { pp: 1, Xl: 2, ym: 3, uk: 4, Il: 5 };
    h[h.pp] = "GTM_DEBUG_LEGACY_PARAM";
    h[h.Xl] = "GTM_DEBUG_PARAM";
    h[h.ym] = "REFERRER";
    h[h.uk] = "COOKIE";
    h[h.Il] = "EXTENSION_PARAM";
    var l = void 0,
      n = void 0,
      p = sj(x.location, "query", !1, void 0, "gtm_debug");
    on(p) && (l = h.Xl);
    if (!l && A.referrer) {
      var q = yj(A.referrer);
      uj(q, "host") === hg(24) && (l = h.ym);
    }
    if (!l) {
      var r = vr("__TAG_ASSISTANT");
      r.length && r[0].length && (l = h.uk);
    }
    l || b();
    if (!l && nn(n)) {
      var u = !1;
      Rc(
        A,
        "TADebugSignal",
        function () {
          u || ((u = !0), b(), c());
        },
        !1
      );
      x.setTimeout(function () {
        u || ((u = !0), b(), c());
      }, 200);
    } else c();
  })(function () {
    !gg(47) || Om()["0"] ? Mm() : Lm();
  });
})();
