!(function () {
  "use strict";
  const t = document.currentScript,
    e = "data-",
    n = t.getAttribute.bind(t),
    o = "https://datafa.st/api/events";
  function a(t) {
    if (!t) return !1;
    const e = t.toLowerCase();
    return (
      !!["localhost", "127.0.0.1", "::1"].includes(e) ||
      !!/^127(\.[0-9]+){0,3}$/.test(e) ||
      !!/^(\[)?::1?\]?$/.test(e) ||
      !(!e.endsWith(".local") && !e.endsWith(".localhost"))
    );
  }
  function r() {
    try {
      if (
        !0 === window.navigator.webdriver ||
        window.callPhantom ||
        window._phantom ||
        window.__nightmare
      )
        return !0;
      if (
        !window.navigator ||
        !window.location ||
        !window.document ||
        "object" != typeof window.navigator ||
        "object" != typeof window.location ||
        "object" != typeof window.document
      )
        return !0;
      const t = window.navigator;
      if (
        !t.userAgent ||
        "" === t.userAgent ||
        "undefined" === t.userAgent ||
        t.userAgent.length < 5
      )
        return !0;
      const e = t.userAgent.toLowerCase();
      if (
        e.includes("headlesschrome") ||
        e.includes("phantomjs") ||
        e.includes("selenium") ||
        e.includes("webdriver") ||
        e.includes("puppeteer") ||
        e.includes("playwright")
      )
        return !0;
      const n = [
        "__webdriver_evaluate",
        "__selenium_evaluate",
        "__webdriver_script_function",
        "__webdriver_unwrapped",
        "__fxdriver_evaluate",
        "__driver_evaluate",
        "_Selenium_IDE_Recorder",
        "_selenium",
        "calledSelenium",
        "$cdc_asdjflasutopfhvcZLmcfl_",
      ];
      for (const t of n) if (void 0 !== window[t]) return !0;
      if (
        document.documentElement &&
        (document.documentElement.getAttribute("webdriver") ||
          document.documentElement.getAttribute("selenium") ||
          document.documentElement.getAttribute("driver"))
      )
        return !0;
      if (
        e.includes("python") ||
        e.includes("curl") ||
        e.includes("wget") ||
        e.includes("java/") ||
        e.includes("go-http") ||
        e.includes("node.js") ||
        e.includes("axios") ||
        e.includes("postman")
      )
        return !0;
    } catch (t) {
      return !1;
    }
    return !1;
  }
  function i(t, e, n) {
    let o = "";
    if (n) {
      const t = new Date();
      t.setTime(t.getTime() + 24 * n * 60 * 60 * 1e3),
        (o = "; expires=" + t.toUTCString());
    }
    let r = t + "=" + (e || "") + o + "; path=/";
    if (!a(window.location.hostname) && "file:" !== window.location.protocol) {
      const t = window.location.hostname;
      r +=
        t === _ || t.endsWith("." + _)
          ? "; domain=." + _.replace(/^\./, "")
          : "; domain=." + t.replace(/^\./, "");
    }
    document.cookie = r;
  }
  function s(t) {
    const e = t + "=",
      n = document.cookie.split(";");
    for (let t = 0; t < n.length; t++) {
      let o = n[t];
      for (; " " === o.charAt(0); ) o = o.substring(1, o.length);
      if (0 === o.indexOf(e)) return o.substring(e.length, o.length);
    }
    return null;
  }
  function c() {
    let t = (function () {
      try {
        return (
          new URL(window.location.href).searchParams.get("_df_vid") || null
        );
      } catch {
        return null;
      }
    })();
    return t
      ? (i("datafast_visitor_id", t, 365),
        (function () {
          try {
            const t = new URL(window.location.href);
            (t.searchParams.has("_df_vid") || t.searchParams.has("_df_sid")) &&
              (t.searchParams.delete("_df_vid"),
              t.searchParams.delete("_df_sid"),
              window.history.replaceState({}, "", t.toString()));
          } catch {}
        })(),
        t)
      : ((t = s("datafast_visitor_id")),
        t ||
          ((t = "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(
            /[xy]/g,
            function (t) {
              const e = (16 * Math.random()) | 0;
              return ("x" == t ? e : (3 & e) | 8).toString(16);
            }
          )),
          i("datafast_visitor_id", t, 365)),
        t);
  }
  function l() {
    let t = (function () {
      try {
        return (
          new URL(window.location.href).searchParams.get("_df_sid") || null
        );
      } catch {
        return null;
      }
    })();
    return t
      ? (i("datafast_session_id", t, 1 / 48), t)
      : ((t = s("datafast_session_id")),
        t ||
          ((t = "sxxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(
            /[xy]/g,
            function (t) {
              const e = (16 * Math.random()) | 0;
              return ("x" == t ? e : (3 & e) | 8).toString(16);
            }
          )),
          i("datafast_session_id", t, 1 / 48)),
        t);
  }
  let d = [];
  window.datafast &&
    window.datafast.q &&
    Array.isArray(window.datafast.q) &&
    (d = window.datafast.q.map((t) => Array.from(t)));
  let u = !0,
    f = "";
  u && r() && ((u = !1), (f = "Tracking disabled - bot detected"));
  const m = "true" === n(e + "allow-file-protocol"),
    w = "true" === n(e + "allow-localhost");
  u &&
    ((a(window.location.hostname) && !w) ||
      ("file:" === window.location.protocol && !m)) &&
    ((u = !1),
    (f =
      "file:" === window.location.protocol
        ? "Tracking disabled on file protocol (use data-allow-file-protocol='true' to enable)"
        : "Tracking disabled on localhost (use data-allow-localhost='true' to enable)"));
  const g = "true" === n(e + "debug"),
    h = "true" === n(e + "disable-console");
  u &&
    window !== window.parent &&
    !g &&
    ((u = !1), (f = "Tracking disabled inside an iframe"));
  const p = n(e + "website-id"),
    _ = n(e + "domain"),
    v = n(e + "allowed-hostnames"),
    y = v
      ? v
          .split(",")
          .map((t) => t.trim())
          .filter(Boolean)
      : [];
  function x(t, e, ...n) {
    if (h) return;
    const o = "DataFast:";
    switch (t) {
      case "info":
      default:
        console.log(o, e, ...n);
        break;
      case "warn":
        console.warn(o, e, ...n);
        break;
      case "error":
        console.error(o, e, ...n);
    }
  }
  !u || (p && _) || ((u = !1), (f = "Missing website ID or domain"));
  const b = n(e + "api-url");
  let S;
  if (b)
    try {
      new URL(b), (S = b);
    } catch (t) {
      try {
        S = new URL(b, window.location.origin).href;
      } catch (t) {
        x(
          "error",
          `Could not construct valid URL from data-api-url "${b}". Falling back to ${o}`
        ),
          (S = o);
      }
    }
  else {
    const e = !t.src.includes("datafa.st");
    S = e ? new URL("/api/events", window.location.origin).href : o;
  }
  function E() {
    const t = window.location.href;
    if (!t)
      return void x(
        "warn",
        "Unable to collect href. This may indicate incorrect script implementation or browser issues."
      );
    const e = new URL(t),
      n = {},
      o = e.searchParams.get("fbclid"),
      a = e.searchParams.get("gclid"),
      r = e.searchParams.get("gclsrc"),
      i = e.searchParams.get("wbraid"),
      s = e.searchParams.get("gbraid"),
      d = e.searchParams.get("li_fat_id"),
      u = e.searchParams.get("msclkid"),
      f = e.searchParams.get("ttclid"),
      m = e.searchParams.get("twclid");
    a && (n.gclid = a),
      r && (n.gclsrc = r),
      i && (n.wbraid = i),
      s && (n.gbraid = s),
      d && (n.li_fat_id = d),
      o && (n.fbclid = o),
      u && (n.msclkid = u),
      f && (n.ttclid = f),
      m && (n.twclid = m);
    return {
      websiteId: p,
      domain: _,
      href: t,
      referrer: document.referrer || null,
      viewport: { width: window.innerWidth, height: window.innerHeight },
      visitorId: c(),
      sessionId: l(),
      adClickIds: Object.keys(n).length > 0 ? n : void 0,
    };
  }
  function L(t, e) {
    return "true" === localStorage.getItem("datafast_ignore")
      ? (x("info", "Event ignored - tracking disabled via localStorage flag"),
        void (e && e({ status: 200 })))
      : r()
      ? (x("info", "Event ignored - bot detected"),
        void (e && e({ status: 200 })))
      : void (function (t, e) {
          const n = new XMLHttpRequest();
          n.open("POST", S, !0),
            n.setRequestHeader("Content-Type", "application/json"),
            (n.onreadystatechange = function () {
              if (n.readyState === XMLHttpRequest.DONE) {
                if (200 === n.status) {
                  x("info", `${t.type || "Event"} tracked successfully`);
                  i("datafast_session_id", l(), 1 / 48);
                } else
                  x(
                    "error",
                    `Failed to track ${t.type || "event"} - HTTP ${n.status}`
                  );
                e && e({ status: n.status });
              }
            }),
            n.send(JSON.stringify(t));
        })(t, e);
  }
  let P = 0,
    I = "";
  function k(t) {
    if (!u)
      return (
        x("info", `Pageview ignored - ${f}`), void (t && t({ status: 200 }))
      );
    const e = Date.now(),
      n = window.location.href;
    if (n === I && e - P < 6e4)
      return (
        x("info", "Pageview ignored - throttled (same URL within 1 minute)"),
        void (t && t({ status: 200 }))
      );
    (P = e),
      (I = n),
      (function (t, e) {
        try {
          sessionStorage.setItem(
            "datafast_pageview_state",
            JSON.stringify({ time: t, url: e })
          );
        } catch (t) {}
      })(e, n);
    const o = E();
    (o.type = "pageview"), L(o, t);
  }
  function A(t, e, n) {
    if (!u)
      return (
        x("info", `Payment event ignored - ${f}`),
        void (n && n({ status: 200 }))
      );
    const o = E();
    (o.type = "payment"),
      "stripe" === t
        ? (o.extraData = { stripe_session_id: e })
        : "lemonsqueezy" === t
        ? (o.extraData = { lemonsqueezy_order_id: e })
        : "polar" === t && (o.extraData = { polar_checkout_id: e }),
      L(o, n);
  }
  function $(t, e, n) {
    if (!u)
      return (
        x("info", `Custom event '${t}' ignored - ${f}`),
        void (n && n({ status: 200 }))
      );
    const o = E();
    (o.type = t), (o.extraData = e), L(o, n);
  }
  function R(t, e) {
    if (u)
      if (t)
        if ("payment" !== t || e?.email)
          if ("identify" !== t || e?.user_id)
            if ("payment" === t) $(t, { email: e.email });
            else if ("identify" === t)
              !(function (t, e, n) {
                if (!u)
                  return (
                    x("info", `Identify event ignored - ${f}`),
                    void (n && n({ status: 200 }))
                  );
                const o = E();
                (o.type = "identify"),
                  (o.extraData = {
                    user_id: t,
                    name: e.name || "",
                    image: e.image || "",
                    ...e,
                  }),
                  L(o, n);
              })(e.user_id, e);
            else {
              const n = U(e || {});
              if (null === n)
                return void x(
                  "error",
                  "Custom event rejected due to validation errors"
                );
              $("custom", { eventName: t, ...n });
            }
          else x("warn", `Missing user_id for ${t} event`);
        else x("warn", `Missing email for ${t} event`);
      else x("warn", "Missing event_name for custom event");
    else x("info", `Event '${t}' ignored - ${f}`);
  }
  function U(t) {
    if (!t || "object" != typeof t || Array.isArray(t))
      return x("warn", "customData must be a non-null object"), {};
    const e = {};
    let n = 0;
    function o(t) {
      if (null == t) return "";
      let e = String(t);
      return (
        e.length > 255 && (e = e.substring(0, 255)),
        (e = e
          .replace(/[<>'"&]/g, "")
          .replace(/javascript:/gi, "")
          .replace(/on\w+=/gi, "")
          .replace(/data:/gi, "")
          .replace(/vbscript:/gi, "")
          .trim()),
        e
      );
    }
    for (const [r, i] of Object.entries(t)) {
      if ("eventName" === r) {
        e[r] = o(i);
        continue;
      }
      if (n >= 10)
        return x("error", "Maximum 10 custom parameters allowed"), null;
      if (
        "string" != typeof (a = r) ||
        0 === a.length ||
        a.length > 32 ||
        !/^[a-z0-9_-]+$/.test(a.toLowerCase())
      )
        return (
          x(
            "error",
            `Invalid property name "${r}". Use only lowercase letters, numbers, underscores, and hyphens. Max 32 characters.`
          ),
          null
        );
      const t = r.toLowerCase(),
        s = o(i);
      (e[t] = s), n++;
    }
    var a;
    return e;
  }
  if (
    ((window.datafast = R),
    window.datafast.q && delete window.datafast.q,
    (function () {
      for (; d.length > 0; ) {
        const t = d.shift();
        if (Array.isArray(t) && t.length > 0)
          try {
            R.apply(null, t);
          } catch (e) {
            x("error", "Error processing queued call:", e, t);
          }
      }
    })(),
    !u)
  )
    return void x("warn", f);
  function T(t) {
    if (!t) return null;
    const e = t.replace(/^www\./, "").split(".");
    return e.length >= 2 ? e.slice(-2).join(".") : t;
  }
  function q(t) {
    if (t && t.href)
      try {
        const n = new URL(t.href);
        if ("http:" !== n.protocol && "https:" !== n.protocol) return;
        const o = n.hostname,
          a = window.location.hostname;
        if (o === a) return;
        if (((e = a), T(o) === T(e))) return;
        !(function (t) {
          if (!t) return !1;
          if (t === _) return !0;
          for (const e of y) if (t === e) return !0;
          return !1;
        })(o)
          ? $("external_link", { url: t.href, text: t.textContent.trim() })
          : (t.href = (function (t) {
              try {
                const e = new URL(t),
                  n = c(),
                  o = l();
                return (
                  e.searchParams.set("_df_vid", n),
                  e.searchParams.set("_df_sid", o),
                  e.toString()
                );
              } catch {
                return t;
              }
            })(t.href));
      } catch {}
    var e;
  }
  function D(t) {
    const e = t.getAttribute("data-fast-goal");
    if (e && e.trim()) {
      const n = { eventName: e.trim() };
      for (const e of t.attributes)
        if (
          e.name.startsWith("data-fast-goal-") &&
          "data-fast-goal" !== e.name
        ) {
          const t = e.name.substring(15);
          if (t) {
            n[t.replace(/-/g, "_")] = e.value;
          }
        }
      const o = U(n);
      null !== o && $("custom", o);
    }
  }
  function M(t, e) {
    const n = t.getAttribute("data-fast-scroll");
    if (n && n.trim()) {
      const o = t.getAttribute("data-fast-scroll-delay");
      let a = 0;
      if (null !== o) {
        const t = parseInt(o, 10);
        !isNaN(t) && t >= 0 && (a = t);
      }
      const r = () => {
        const o = t.getBoundingClientRect();
        if (!(o.bottom > 0 && o.top < window.innerHeight))
          return void e.unobserve(t);
        const r = (function () {
            const t = Math.max(
                document.body.scrollHeight,
                document.body.offsetHeight,
                document.documentElement.clientHeight,
                document.documentElement.scrollHeight,
                document.documentElement.offsetHeight
              ),
              e = window.innerHeight,
              n = window.pageYOffset || document.documentElement.scrollTop,
              o = t - e;
            return o <= 0 ? 100 : Math.min(100, Math.round((n / o) * 100));
          })(),
          i = t.getAttribute("data-fast-scroll-threshold");
        let s = 0.5;
        if (null !== i) {
          const t = parseFloat(i);
          !isNaN(t) && t >= 0 && t <= 1 && (s = t);
        }
        const c = {
          eventName: n.trim(),
          scroll_percentage: r.toString(),
          threshold: s.toString(),
          delay: a.toString(),
        };
        for (const e of t.attributes)
          if (
            e.name.startsWith("data-fast-scroll-") &&
            "data-fast-scroll" !== e.name &&
            "data-fast-scroll-threshold" !== e.name &&
            "data-fast-scroll-delay" !== e.name
          ) {
            const t = e.name.substring(17);
            if (t) {
              c[t.replace(/-/g, "_")] = e.value;
            }
          }
        const l = U(c);
        null !== l && $("custom", l), e.unobserve(t);
      };
      a > 0 ? setTimeout(r, a) : r();
    }
  }
  function j() {
    if (!window.IntersectionObserver)
      return void x(
        "warn",
        "Intersection Observer not supported, scroll tracking disabled"
      );
    const t = document.querySelectorAll("[data-fast-scroll]");
    if (0 === t.length) return;
    const e = new Map();
    t.forEach(function (t) {
      const n = t.getAttribute("data-fast-scroll-threshold");
      let o = 0.5;
      if (null !== n) {
        const t = parseFloat(n);
        !isNaN(t) && t >= 0 && t <= 1
          ? (o = t)
          : x(
              "warn",
              `Invalid threshold value "${n}" for element. Using default 0.5. Threshold must be between 0 and 1.`
            );
      }
      e.has(o) || e.set(o, []), e.get(o).push(t);
    }),
      e.forEach(function (t, e) {
        const n = new IntersectionObserver(
          function (t) {
            t.forEach(function (t) {
              t.isIntersecting && M(t.target, n);
            });
          },
          { root: null, rootMargin: "0px", threshold: e }
        );
        t.forEach(function (t) {
          n.observe(t);
        });
      });
  }
  !(function () {
    try {
      const t = sessionStorage.getItem("datafast_pageview_state");
      if (t) {
        const { time: e, url: n } = JSON.parse(t);
        (P = e || 0), (I = n || "");
      }
    } catch (t) {
      (P = 0), (I = "");
    }
  })(),
    document.addEventListener("click", function (t) {
      const e = t.target.closest("[data-fast-goal]");
      e && D(e);
      q(t.target.closest("a"));
    }),
    document.addEventListener("keydown", function (t) {
      if ("Enter" === t.key || " " === t.key) {
        const e = t.target.closest("[data-fast-goal]");
        e && D(e);
        q(t.target.closest("a"));
      }
    }),
    "loading" === document.readyState
      ? document.addEventListener("DOMContentLoaded", j)
      : j();
  let N = null;
  function C() {
    k(),
      (function () {
        try {
          const t = new URL(window.location.href).searchParams.get(
            "session_id"
          );
          t &&
            t.startsWith("cs_") &&
            !sessionStorage.getItem("datafast_stripe_payment_sent_" + t) &&
            (A("stripe", t),
            sessionStorage.setItem("datafast_stripe_payment_sent_" + t, "1"));
        } catch (t) {
          x("error", "Error auto detecting Stripe session ID:", t);
        }
      })(),
      (function () {
        try {
          const t = new URL(window.location.href).searchParams.get(
            "checkout_id"
          );
          t &&
            !sessionStorage.getItem("datafast_polar_payment_sent_" + t) &&
            (A("polar", t),
            sessionStorage.setItem("datafast_polar_payment_sent_" + t, "1"));
        } catch (t) {
          x("error", "Error auto detecting Polar checkout ID:", t);
        }
      })(),
      (function () {
        try {
          const t = new URL(window.location.href).searchParams.get("order_id");
          t &&
            !sessionStorage.getItem(
              "datafast_lemonsqueezy_payment_sent_" + t
            ) &&
            (A("lemonsqueezy", t),
            sessionStorage.setItem(
              "datafast_lemonsqueezy_payment_sent_" + t,
              "1"
            ));
        } catch (t) {
          x("error", "Error auto detecting Lemonsqueezy order ID:", t);
        }
      })();
  }
  function O() {
    N && clearTimeout(N), (N = setTimeout(C, 100));
  }
  C();
  let H = window.location.pathname;
  const z = window.history.pushState;
  (window.history.pushState = function () {
    z.apply(this, arguments),
      H !== window.location.pathname && ((H = window.location.pathname), O());
  }),
    window.addEventListener("popstate", function () {
      H !== window.location.pathname && ((H = window.location.pathname), O());
    });
})();
